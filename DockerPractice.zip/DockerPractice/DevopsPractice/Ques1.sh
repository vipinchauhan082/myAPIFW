#!/bin/sh
# MY_MESSAGE="Hello World"
# echo $MY_MESSAGE
DIRPATH="./apps/test1"
FILEPATH=$DIRPATH/file1.txt
USER="vipchauh"
if [ -d $DIRPATH ] 
then
    echo "Directory $DIRPATH already exists." 
else
    mkdir -p -m 700 $DIRPATH
    echo "Directory $DIRPATH has been created "
fi
if [ -f $FILEPATH ]; then  
    echo " $FILEPATH exist"  
else  
    touch $DIRPATH/file1.txt
    echo " $FILEPATH has been created"  
fi  
chmod o+x $DIRPATH/file1.txt
if id -u "$USER" >/dev/null 2>&1; then
    echo '$USER exists'
else
    useradd $USER
    echo '$USER created'
fi
chown $USER $DIRPATH/file1.txt