#!/bin/sh
input_file="weekdays.txt"
N=1
while IFS= read -r line; do

  if [[ $line =~ "date" ]]; then
    echo $N
      printf '%s\n' "$line"
    sed -i '$N s/sunday/monday/g' input_file
  fi
  N=`expr $N + 1`
done < $input_file



sed -ie '5,${/date/s/sunday/monday/g;}' weekdays.txt