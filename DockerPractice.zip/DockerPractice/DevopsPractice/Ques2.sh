#!/bin/sh
WEEKDAY[0]="Sunday"
WEEKDAY[1]="Monday"
WEEKDAY[2]="Tuesday"
WEEKDAY[3]="Wednesday"
WEEKDAY[4]="Thursday"
WEEKDAY[5]="Friday"
WEEKDAY[6]="Saturday"
read -p "Enter weekday: "  weekday
if [ $weekday -lt 0 -o $weekday -gt 6 ]; then
    echo "Invalid input"
else
    echo "User selected ${WEEKDAY[$weekday]}!"
fi