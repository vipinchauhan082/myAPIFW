#!/bin/sh

find ../../../Documents/ -mtime -2

find ../../../Documents/ -mtime -2 | wc -l 