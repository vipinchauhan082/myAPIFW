echo "****************************** Deploy service artifact ****************************"
gcloud container clusters get-credentials eplus-mfa-bld-02-kcl-euwe2-microfrontapp --region europe-west2 --project eplus-mfa-bld-02-1727
return 0