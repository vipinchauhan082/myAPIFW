echo "****************************** Deploy istio VirtualService & Gateway ****************************"
gcloud container clusters get-credentials eplus-icp-bld-02-kcl-01-euwe2 --region europe-west2 --project eplus-icp-bld-02-112d
return 0