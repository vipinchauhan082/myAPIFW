package com.lbg.epscw.mortgagesrvc.dto.comms;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Locale;

@Data
@AllArgsConstructor
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
@Builder
public class Address {

    @JsonProperty("FirstLine")
    private String firstLine;

    @JsonProperty("SecondLine")
    private String secondLine;

    @JsonProperty("ThirdLine")
    private String thirdLine;

    @JsonProperty("City")
    private String city;

    @JsonProperty("PostalCode")
    private String postalCode;

    @JsonProperty("CountryCode")
    private String countryCode;
}
