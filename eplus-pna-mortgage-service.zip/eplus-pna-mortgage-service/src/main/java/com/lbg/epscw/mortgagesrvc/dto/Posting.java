package com.lbg.epscw.mortgagesrvc.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class Posting {

    @JsonProperty("credit")
    private boolean credit;

    @JsonProperty("amount")
    private String amount;

    @JsonProperty("denomination")
    private String denomination;

    @JsonProperty("account_id")
    private String accountId;

    @JsonProperty("account_address")
    private String accountAddress;

    @JsonProperty("asset")
    private String asset;

    @JsonProperty("phase")
    private String phase;
}
