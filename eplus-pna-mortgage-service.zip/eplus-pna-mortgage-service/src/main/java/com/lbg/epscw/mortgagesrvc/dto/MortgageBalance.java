package com.lbg.epscw.mortgagesrvc.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.lbg.epscw.mortgagesrvc.enums.Currency;
import io.swagger.v3.oas.annotations.media.ArraySchema;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import java.util.List;
import java.util.Map;

@Data
public class MortgageBalance {

    @JsonProperty("Aggregated")
    private Map<String,String> aggregatedMap;

    @JsonProperty("Currency")
    private Currency currency;

    @JsonProperty("Balance")
    @ArraySchema(schema = @Schema(anyOf = {MortgageAccountBalance.class,MortgageSubAccountBalance.class}))
    private List<AccountBalance> mortgageAccountBalanceList;
}
