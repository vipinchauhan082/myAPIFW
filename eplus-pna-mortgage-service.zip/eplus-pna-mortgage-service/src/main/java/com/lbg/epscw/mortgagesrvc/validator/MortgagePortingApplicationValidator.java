package com.lbg.epscw.mortgagesrvc.validator;

import com.lbg.epscw.mortgagesrvc.exception.MortgageServiceException;
import com.lbg.epscw.mortgagesrvc.exception.MortgageValidationException;
import com.lbg.epscw.mortgagesrvc.model.MortgageApplicationInfo;
import com.lbg.epscw.mortgagesrvc.model.MortgagePortingApplicationStatus;
import com.lbg.epscw.mortgagesrvc.service.MortgagePortingStateMachine;
import lombok.extern.flogger.Flogger;
import org.springframework.stereotype.Service;

import java.util.Collection;

import static com.lbg.epscw.mortgagesrvc.constants.CommonConstants.*;

@Service
@Flogger
public class MortgagePortingApplicationValidator {
    private final MortgagePortingStateMachine stateMachine;

    public MortgagePortingApplicationValidator(MortgagePortingStateMachine stateMachine) {
        this.stateMachine = stateMachine;
    }

    public void validateCurrentState(MortgageApplicationInfo applicationInfo, Collection<MortgagePortingApplicationStatus> permittedStates) {
        throwIfApplicationNotFound(applicationInfo);
        if (!permittedStates.contains(applicationInfo.getStatus())) {
            throw new MortgageValidationException(MORTGAGE_PORTING_APPLICATION, INVALID_STATUS);
        }
    }

    public void validateNextState(MortgageApplicationInfo application, MortgagePortingApplicationStatus nextState) {
        throwIfApplicationNotFound(application);
        Collection<MortgagePortingApplicationStatus> permittedStates = stateMachine.next(application.getStatus());
        if (!permittedStates.contains(nextState)) {
            throw new MortgageValidationException(MORTGAGE_PORTING_APPLICATION, INVALID_STATUS);
        }
    }

    private void throwIfApplicationNotFound(MortgageApplicationInfo application) {
        if (application == null) {
            throw new MortgageServiceException(MORTGAGE_PORTING_APPLICATION, NOT_FOUND);
        }
    }
}
