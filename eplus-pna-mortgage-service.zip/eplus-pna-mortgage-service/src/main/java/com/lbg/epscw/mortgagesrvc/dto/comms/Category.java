package com.lbg.epscw.mortgagesrvc.dto.comms;

public enum Category {

    REGULAR, MARKETING
}
