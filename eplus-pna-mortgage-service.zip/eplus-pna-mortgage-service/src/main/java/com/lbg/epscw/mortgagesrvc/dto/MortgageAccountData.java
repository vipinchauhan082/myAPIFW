package com.lbg.epscw.mortgagesrvc.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;


@Builder
@Data
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class MortgageAccountData {

    @JsonProperty("mortgageNumber")
    private String mortgageNumber;
    @JsonProperty("mortgagePrincipal")
    private String mortgagePrincipal;
    @JsonProperty("keyDate")
    private String keyDate;
    @JsonProperty("mortgageType")
    private String mortgageType;
    @JsonProperty("totalTerm")
    private String totalTerm;
    @JsonProperty("productId")
    private String productId;
    @JsonProperty("paymentArrangementStartMonth")
    private String paymentArrangementStartMonth;
    @JsonProperty("paymentArrangementEndMonth")
    private String paymentArrangementEndMonth;
    @JsonProperty("paymentArrangementAmountType")
    private String paymentArrangementAmountType;
    @JsonProperty("paymentArrangementAmount")
    private String paymentArrangementAmount;
    @JsonProperty("paymentArrangementType")
    private String paymentArrangementType;
    @JsonProperty("accountOpeningDate")
    private String accountOpeningDate;
    @JsonProperty("sortCode")
    private String accountSortCode;
    @JsonProperty("accountNumber")
    private String accountNumber;
    @JsonProperty("accountId")
    private String accountId;
    @JsonProperty("nominatedAdhocOverpaymentAccount")
    private String nominatedAdhocOverpaymentAccount;
    @JsonProperty("offSettingOption")
    private String offSettingOption;
    @JsonProperty("productFamily")
    private String productFamily;
    @JsonProperty("mortgagePaymentOption")
    private String mortgagePaymentOption;
    @JsonProperty("accountStatus")
    private String status;
    @JsonProperty("paymentHolidayMonths")
    private String[] paymentHolidayMonths;
    @JsonProperty("bairdMortgage")
    private String bairdMortgage;
    @JsonProperty("arrangement")
    private String arrangement;
    @JsonProperty("arrangementToPay")
    private String arrangementToPay;
    @JsonProperty("arrangementUntil")
    private String arrangementUntil;
    @JsonProperty("initialTerm")
    private String initialTerm;
    @JsonProperty("monthlyRepaymentAmount")
    private String monthlyRepaymentAmount;
    @JsonProperty("ctlIndicator")
    private String ctlIndicator;
    @JsonProperty("ctlStartDate")
    private String ctlStartDate;
    @JsonProperty("interestRate")
    private String interestRate;
    @JsonProperty("depositAccount")
    private String depositAccount;
    @JsonProperty("planNumber")
    private String planNumber;
    @JsonProperty("cbsCustomerId")
    private String stakeholderId;
    @JsonProperty("mortgageInArrears")
    private boolean mortgageInArrears;
    @JsonProperty("jarName")
    private String jarName;
    @JsonProperty("sequenceId")
    private String sequenceId;
    @JsonProperty("remainingTerm")
    private String remainingTerm;



    public MortgageAccountData(String accountId) {
        super();
        this.accountId = accountId;
    }

    public MortgageAccountData(String accountId, String mortgageNumber, String mortgagePrincipal, String keyDate, String mortgageType,
                               String totalTerm, String productId) {
        this.accountId = accountId;
        this.mortgageNumber = mortgageNumber;
        this.mortgagePrincipal = mortgagePrincipal;
        this.keyDate = keyDate;
        this.mortgageType = mortgageType;
        this.totalTerm = totalTerm;
        this.productId = productId;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        MortgageAccountData other = (MortgageAccountData) obj;
        if (accountId == null) {
            if (other.accountId != null)
                return false;
        } else if (!accountId.equals(other.accountId))
            return false;
        return true;
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((accountId == null) ? 0 : accountId.hashCode());
        return result;
    }
}