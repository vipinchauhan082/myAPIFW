package com.lbg.epscw.mortgagesrvc.dto;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;

@JsonDeserialize(as = MortgageSubAccountBalance.class)
public interface AccountBalance {

}
