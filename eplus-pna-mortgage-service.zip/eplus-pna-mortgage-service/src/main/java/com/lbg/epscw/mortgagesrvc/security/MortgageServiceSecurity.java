package com.lbg.epscw.mortgagesrvc.security;

import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.config.http.SessionCreationPolicy;


@EnableWebSecurity
public class MortgageServiceSecurity extends WebSecurityConfigurerAdapter {


    /**
     * Method to configure Web Security settings
     * @param http
     * @throws Exception
     */
    @Override
    protected void configure(HttpSecurity http) throws Exception {
        http.headers().httpStrictTransportSecurity().includeSubDomains(true)
            .maxAgeInSeconds(31536000).and().contentTypeOptions().and().frameOptions();

        http.sessionManagement().sessionCreationPolicy(SessionCreationPolicy.STATELESS);

        http.csrf().disable();
    }
}
