package com.lbg.epscw.mortgagesrvc.dto;


import lombok.Data;

@Data
public class AccountAttrKeyVal {


    private String value;

    private String key;

    private String accountId;
}
