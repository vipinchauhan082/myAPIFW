package com.lbg.epscw.mortgagesrvc.validator;

import com.google.common.flogger.StackSize;
import com.lbg.epscw.mortgagesrvc.constants.CommonConstants;
import com.lbg.epscw.mortgagesrvc.dto.MortgageAccountData;
import com.lbg.epscw.mortgagesrvc.dto.MortgageAccountInfo;
import com.lbg.epscw.mortgagesrvc.dto.PaymentHolidayEligibility;
import com.lbg.epscw.mortgagesrvc.exception.MortgageValidationException;
import com.lbg.epscw.mortgagesrvc.model.PaymentHolidayRequest;
import com.lbg.epscw.mortgagesrvc.restclient.MortgageAccountInfoRestClient;
import com.lbg.epscw.mortgagesrvc.restclient.MortgagePaymentHolidayEligibilityRestClient;
import lombok.extern.flogger.Flogger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import javax.validation.Valid;
import java.time.LocalDate;
import java.time.YearMonth;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.Arrays;
import java.util.Map;
import java.util.Objects;

import static com.lbg.epscw.mortgagesrvc.constants.CommonConstants.*;

@Component
@Flogger
public class MortgagePaymentHolidayValidator {

    private final MortgageAccountInfoRestClient mortgageAccountInfoRestClient;

    private final MortgagePaymentHolidayEligibilityRestClient mortgagePaymentHolidayEligibilityRestClient;

    @Autowired
    public MortgagePaymentHolidayValidator(MortgageAccountInfoRestClient mortgageAccountInfoRestClient, MortgagePaymentHolidayEligibilityRestClient mortgagePaymentHolidayEligibilityRestClient) {
        super();
        this.mortgageAccountInfoRestClient = mortgageAccountInfoRestClient;
        this.mortgagePaymentHolidayEligibilityRestClient = mortgagePaymentHolidayEligibilityRestClient;
    }

    public void validateAddPaymentHolidayRequest(@Valid PaymentHolidayRequest addPaymentHolidayRequest, String accountId, Map<String, String> reqHeaders) {

        if (!checkIfValidMonthAndYear(addPaymentHolidayRequest)) {
            log.atSevere().log(INVALID_YEAR_OR_MONTH);
            throw new MortgageValidationException(DATE, INVALID_YEAR_OR_MONTH);
        }
        PaymentHolidayEligibility paymentHolidayEligibility = mortgagePaymentHolidayEligibilityRestClient.getMortgagePaymentHolidayEligibility(accountId, addPaymentHolidayRequest.getStartMonthYear(), addPaymentHolidayRequest.getEndMonthYear(), reqHeaders);
        if (!paymentHolidayEligibility.isEligibleForPaymentHoliday()) {
            String reasonDetails = CollectionUtils.isEmpty(paymentHolidayEligibility.getEligibilityFailureReasonList()) ?
                    "" : paymentHolidayEligibility.getEligibilityFailureReasonList().get(0).getMessage();
            String errorMsg = "Adding Payment Holiday not eligible for account " + accountId + " " + reasonDetails;
           log.atSevere().withStackTrace(StackSize.MEDIUM).log(errorMsg);
            throw new MortgageValidationException(paymentHolidayEligibility.getEligibilityFailureReasonList().get(0).getCode(), errorMsg);
       }
    }

    private boolean checkIfValidStartMonthYear(String startMonthYear) {
        return YearMonth.parse(startMonthYear, DateTimeFormatter.ofPattern(PAYMENT_HOLIDAY_DATE_FORMAT)).isAfter(YearMonth.now(ZoneId.systemDefault()));
    }

    private boolean checkIfValidEndMonthYear(String startMonthYear, String endMonthYear) {
        YearMonth startMonthYearParsed = YearMonth.parse(startMonthYear, DateTimeFormatter.ofPattern(PAYMENT_HOLIDAY_DATE_FORMAT));
        YearMonth endMonthYearParsed = YearMonth.parse(endMonthYear, DateTimeFormatter.ofPattern(PAYMENT_HOLIDAY_DATE_FORMAT));

        if (startMonthYearParsed.isBefore(endMonthYearParsed)) {
            if (endMonthYearParsed.getYear() == startMonthYearParsed.getYear() && !startMonthYearParsed.plusMonths(1).equals(endMonthYearParsed)) {
                return false;
            } else {
                if (endMonthYearParsed.getYear() - startMonthYearParsed.getYear() == 1) {
                    if ((startMonthYearParsed.getMonthValue() <= 10) || (endMonthYearParsed.getMonthValue() >= 3)) {
                        return false;
                    }
                } else if (endMonthYearParsed.getYear() - startMonthYearParsed.getYear() > 1) {
                    return false;
                }
            }
            return true;
        } else {
            return false;
        }
    }

    private boolean checkIfValidMonthAndYear(PaymentHolidayRequest request) {
        if (checkIfValidStartMonthYear(request.getStartMonthYear())) {
            if (request.getEndMonthYear() != null) {
                return checkIfValidEndMonthYear(request.getStartMonthYear(), request.getEndMonthYear());
            } else
                return true;
        }
        return false;
    }

    public void validateCancelPaymentHolidayRequest(PaymentHolidayRequest cancelPaymentHolidayRequest, String accountId, Map<String, String> reqHeaders) {
        if (!checkIfValidMonthAndYear(cancelPaymentHolidayRequest)) {
            log.atSevere().log(INVALID_YEAR_OR_MONTH);
            throw new MortgageValidationException(DATE, INVALID_YEAR_OR_MONTH);
        }
        MortgageAccountInfo mortgageAccountDetails = mortgageAccountInfoRestClient.getMortgageAccountInfo(accountId, reqHeaders);
        MortgageAccountData mortgageAccountData = mortgageAccountDetails.getMortgageAccountData().stream().filter(x -> !accountId.equals(x.getAccountId())).findAny().orElse(null);
        if (mortgageAccountData != null && Integer.valueOf(mortgageAccountData.getKeyDate()) >= LocalDate.now(ZoneId.systemDefault()).getDayOfMonth() && Integer.valueOf(mortgageAccountData.getKeyDate()) - LocalDate.now(ZoneId.systemDefault()).getDayOfMonth() <= 3) {
            String errorMsg = "Payment Holiday cancel not eligible";
            log.atSevere().log(errorMsg);
            throw new MortgageValidationException(MORTGAGE_PAYMENT_HOLIDAY, CommonConstants.NOT_ELIGIBLE);
        }
        if (accountId == null || Objects.requireNonNull(mortgageAccountData).getPaymentHolidayMonths() == null || !Arrays.asList(mortgageAccountData.getPaymentHolidayMonths()).contains(cancelPaymentHolidayRequest.getStartMonthYear())) {
            String errorMsg = "Payment Holiday does not exist";
            log.atSevere().log(errorMsg);
            throw new MortgageValidationException(MORTGAGE_PAYMENT_HOLIDAY, NOT_EXIST);
        }
        if (Arrays.asList(mortgageAccountData.getPaymentHolidayMonths()).contains(cancelPaymentHolidayRequest.getStartMonthYear()) && cancelPaymentHolidayRequest.getEndMonthYear() != null) {
            YearMonth startMonthYearParsed = YearMonth.parse(cancelPaymentHolidayRequest.getStartMonthYear(), DateTimeFormatter.ofPattern(PAYMENT_HOLIDAY_DATE_FORMAT));
            YearMonth endMonthYearParsed = YearMonth.parse(cancelPaymentHolidayRequest.getEndMonthYear(), DateTimeFormatter.ofPattern(PAYMENT_HOLIDAY_DATE_FORMAT));
            long i = 1;
            while (!startMonthYearParsed.plusMonths(i - 1).equals(endMonthYearParsed)) {
                if (!Arrays.asList(mortgageAccountData.getPaymentHolidayMonths()).contains(startMonthYearParsed.plusMonths(i).format(DateTimeFormatter.ofPattern(PAYMENT_HOLIDAY_DATE_FORMAT)))) {
                    String errorMsg = "Payment Holiday does not exist";
                    log.atSevere().log(errorMsg);
                    throw new MortgageValidationException(MORTGAGE_PAYMENT_HOLIDAY, NOT_EXIST);
                }
                i++;
            }
        }
    }
}
