package com.lbg.epscw.mortgagesrvc.dto.comms;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;

@lombok.Data
@AllArgsConstructor
@Builder
@JsonIgnoreProperties(ignoreUnknown = true)
public class Data {

    @JsonProperty("dateOfLetter")
    private String dateOfLetter;

    @JsonProperty("ref")
    private String reference;

    @JsonProperty("planNumber")
    private String planNumber;

    @JsonProperty("accountNumber")
    private String accountNumber;

    @JsonProperty("accountNickName")
    private String jarName;

    @JsonProperty("redemptionDate")
    private String redemptionDate;

    @JsonProperty("settlementAmount")
    private String settlementAmount;

    @JsonProperty("dailyInterestAmount")
    private String dailyInterestAmount;

    @JsonProperty("statementValidDate")
    private String statementValidDate;

    @JsonProperty("mortgageBalanceOnDate")
    private String mortgageBalanceOnDate;

    @JsonProperty("anticipatedInterestAmount")
    private String anticipatedInterestAmount;

    @JsonProperty("accountSortCode")
    private String accountSortCode;

    @JsonProperty("recipient")
    private String recipient;

    @JsonProperty("templateReference")
    private String templateReference;
}
