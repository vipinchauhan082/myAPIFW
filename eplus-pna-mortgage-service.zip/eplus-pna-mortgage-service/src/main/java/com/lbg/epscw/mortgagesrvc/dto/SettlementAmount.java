package com.lbg.epscw.mortgagesrvc.dto;


import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.Valid;
import javax.validation.constraints.NotEmpty;
import java.util.List;

@Builder
@Data
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
@Valid
public class SettlementAmount {

    @JsonProperty("AggregatedSettlementAmount")
    @NotEmpty(message = "AggregatedSettlementAmount")
    private AggregatedSettlementAmountInfo aggregatedSettlementAmountInfo;

    @JsonProperty("SubAccountsSettlementAmount")
    @NotEmpty(message = "SubAccountsSettlementAmount")
    private List<SubAccountsSettlementAmount> subAccountsSettlementAmountList;

    @JsonProperty("Currency")
    @NotEmpty(message = "Currency")
    private String currency;
}
