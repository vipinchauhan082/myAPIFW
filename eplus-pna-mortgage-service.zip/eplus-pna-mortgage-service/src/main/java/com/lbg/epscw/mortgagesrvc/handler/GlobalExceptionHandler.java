package com.lbg.epscw.mortgagesrvc.handler;

import com.fasterxml.jackson.databind.exc.UnrecognizedPropertyException;
import com.google.common.flogger.FluentLogger;
import com.lbg.epscw.accessvalidation.exception.AccessValidationException;
import com.lbg.epscw.entitlement.exception.EntitlementException;
import com.lbg.epscw.entitlement.exception.EntitlementValidationException;
import com.lbg.epscw.handler.constants.SystemErrors;
import com.lbg.epscw.handler.exception.BaseServiceException;
import com.lbg.epscw.handler.exception.RestServiceException;
import com.lbg.epscw.handler.model.ErrorResponse;
import com.lbg.epscw.handler.model.ErrorResponse.ErrorResponseBuilder;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.security.authentication.AuthenticationServiceException;
import org.springframework.web.HttpMediaTypeNotSupportedException;
import org.springframework.web.HttpRequestMethodNotSupportedException;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.MissingRequestHeaderException;
import org.springframework.web.bind.ServletRequestBindingException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.servlet.NoHandlerFoundException;

import javax.servlet.http.HttpServletRequest;
import javax.validation.ConstraintViolationException;
import javax.validation.ValidationException;

import static com.lbg.epscw.mortgagesrvc.constants.CommonConstants.ACCESS_DOT_UNAUTHORISED;
import static com.lbg.epscw.mortgagesrvc.constants.CommonConstants.ERROR_CODE_INITIAL_PART;
import static org.springframework.http.HttpStatus.BAD_REQUEST;
import static org.springframework.http.HttpStatus.FORBIDDEN;
import static org.springframework.http.HttpStatus.INTERNAL_SERVER_ERROR;
import static org.springframework.http.HttpStatus.NOT_FOUND;
import static org.springframework.http.HttpStatus.UNAUTHORIZED;
import static org.springframework.http.HttpStatus.UNSUPPORTED_MEDIA_TYPE;

/**
 * Controller Advice to receive and process various exceptions
 */
@ControllerAdvice
public class GlobalExceptionHandler {

    private static final FluentLogger logger = FluentLogger.forEnclosingClass();

    /**
     * This method gets all the constraint violations and returns ResponseEntity.ErrorCode object
     * It traverses the Constraint Violation Object to figure out header/param and there corresponding violations
     *
     * @param exception
     * @return
     */
    @ExceptionHandler({IllegalArgumentException.class,
            ServletRequestBindingException.class,
            MissingRequestHeaderException.class,
            HttpMessageNotReadableException.class,
            UnrecognizedPropertyException.class,
            MethodArgumentNotValidException.class,
            ConstraintViolationException.class,
            HttpRequestMethodNotSupportedException.class,
            ValidationException.class})
    public ResponseEntity<ErrorResponse> handleException(Exception exception,
                                                                            HttpServletRequest httpServletRequest) {
        ErrorResponse errorResponse =
                new ErrorResponse.ErrorResponseBuilder(SystemErrors.BAD_REQUEST.getErrorCode(), httpServletRequest, ERROR_CODE_INITIAL_PART)
                        .withException(exception)
                        .build();
        logger.atSevere().log("Exception: %s ", errorResponse);
        return new ResponseEntity<>(errorResponse, BAD_REQUEST);

    }

    /**
     * This method handles Access Denied Exceptions
     *
     * @param ex
     * @return
     */
    @ExceptionHandler(AccessDeniedException.class)
    public ResponseEntity<ErrorResponse> handleAccessDeniedException(AccessDeniedException ex, HttpServletRequest httpServletRequest) {
        ErrorResponse errorResponse =
                new ErrorResponse.ErrorResponseBuilder(SystemErrors.FORBIDDEN.getErrorCode(), httpServletRequest, ERROR_CODE_INITIAL_PART)
                        .withException(ex)
                        .build();
        logger.atSevere().log("AccessDeniedException: %s ", errorResponse);
        return new ResponseEntity<>(errorResponse, FORBIDDEN);
    }

    /**
     * This method handles the Entitlement exceptions thrown from entitlement service
     *
     * @param ex
     * @return
     */
    @ExceptionHandler({AccessValidationException.class,
            EntitlementValidationException.class,
            EntitlementException.class})
    public ResponseEntity<ErrorResponse> handleAccessValidationException(
            RuntimeException ex, HttpServletRequest httpServletRequest) {
        RestServiceException restServiceException = new RestServiceException(SystemErrors.UNAUTHORISED.getErrorCode(), UNAUTHORIZED, ACCESS_DOT_UNAUTHORISED, ex.getMessage());
        ErrorResponse errorResponse =
                new ErrorResponse.ErrorResponseBuilder(SystemErrors.UNAUTHORISED.getErrorCode(), httpServletRequest, ERROR_CODE_INITIAL_PART)
                        .withException(restServiceException)
                        .build();
        logger.atSevere().log("AccessValidationException: %s ", errorResponse);
        return new ResponseEntity<>(errorResponse, UNAUTHORIZED);
    }

    /**
     * Handles authentication exception
     *
     * @param ex
     * @return
     */
    @ExceptionHandler(AuthenticationServiceException.class)
    public ResponseEntity<ErrorResponse> handleAuthenticationServiceException(
            AuthenticationServiceException ex, HttpServletRequest httpServletRequest) {
        ErrorResponse errorResponse =
                new ErrorResponse.ErrorResponseBuilder(SystemErrors.UNAUTHORISED.getErrorCode(), httpServletRequest, ERROR_CODE_INITIAL_PART)
                        .withException(ex)
                        .build();
        logger.atSevere().log("AuthenticationServiceException: %s ", errorResponse);
        return new ResponseEntity<>(errorResponse, UNAUTHORIZED);
    }

    /**
     * This method handles runtime exceptions
     *
     * @param ex
     * @return
     */
    @ExceptionHandler(RuntimeException.class)
    public ResponseEntity<ErrorResponse> handleRuntimeException(RuntimeException ex, HttpServletRequest httpServletRequest) {
        ErrorResponse errorResponse =
                new ErrorResponse.ErrorResponseBuilder(SystemErrors.INTERNAL_SERVER_ERROR.getErrorCode(), httpServletRequest, ERROR_CODE_INITIAL_PART)
                        .withException(ex)
                        .build();
        logger.atSevere().log("RuntimeException: %s ", errorResponse);
        return new ResponseEntity<>(errorResponse, INTERNAL_SERVER_ERROR);
    }

    /**
     * Handle all BaseServiceException
     *
     * @param ex
     * @param httpServletRequest
     * @return
     */
    @ExceptionHandler(BaseServiceException.class)
    public ResponseEntity<ErrorResponse> handleBaseServiceException(BaseServiceException ex, HttpServletRequest httpServletRequest) {
        ErrorResponse errorResponse = new ErrorResponseBuilder(ex.getErrorCode(), httpServletRequest,
                ERROR_CODE_INITIAL_PART)
                .withException(ex)
                .build();
        logger.atSevere().log("Service Exception: %s ", errorResponse);
        return new ResponseEntity<>(errorResponse, ex.getHttpStatus());
    }

    @ExceptionHandler(RestServiceException.class)
    public ResponseEntity<ErrorResponse> handleRestServiceException(RestServiceException ex, HttpServletRequest httpServletRequest) {
        ErrorResponse errorResponse =
                new ErrorResponseBuilder(ex.getErrorCode(), httpServletRequest, ERROR_CODE_INITIAL_PART)
                        .withException(ex)
                        .build();
        logger.atSevere().log("RestServiceException: %s ", errorResponse);
        return new ResponseEntity<>(errorResponse, ex.getHttpStatus());
    }

    @ExceptionHandler(HttpMediaTypeNotSupportedException.class)
    @ResponseStatus(UNSUPPORTED_MEDIA_TYPE)
    public ResponseEntity<ErrorResponse> handleUnsupportedMediaException(HttpServletRequest httpServletRequest) {
        ErrorResponse errorResponse =
                new ErrorResponse.ErrorResponseBuilder(SystemErrors.UNSUPPORTED_MEDIA_TYPE.getErrorCode(), httpServletRequest, ERROR_CODE_INITIAL_PART)
                        .build();
        logger.atSevere().log("HttpMediaTypeNotSupportedException: %s ", errorResponse);
        return new ResponseEntity<>(errorResponse, UNSUPPORTED_MEDIA_TYPE);
    }

    @ExceptionHandler(NoHandlerFoundException.class)
    @ResponseStatus(NOT_FOUND)
    public ResponseEntity<ErrorResponse> handleNotFoundException(NoHandlerFoundException ex, HttpServletRequest httpServletRequest) {
        ErrorResponse errorResponse =
                new ErrorResponse.ErrorResponseBuilder(SystemErrors.NOT_FOUND.getErrorCode(), httpServletRequest, ERROR_CODE_INITIAL_PART)
                        .withException(ex)
                        .build();
        logger.atSevere().log("NoHandlerFoundException: %s ", errorResponse);
        return new ResponseEntity<>(errorResponse, NOT_FOUND);
    }

}
