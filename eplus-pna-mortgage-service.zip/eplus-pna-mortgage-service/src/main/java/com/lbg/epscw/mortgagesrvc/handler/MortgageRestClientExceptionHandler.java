package com.lbg.epscw.mortgagesrvc.handler;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.lbg.epscw.handler.constants.SystemErrors;
import com.lbg.epscw.handler.exception.RestServiceException;
import com.lbg.epscw.handler.handlers.RestClientExceptionHandler;
import lombok.extern.flogger.Flogger;
import org.springframework.http.HttpStatus;

@Flogger
public class MortgageRestClientExceptionHandler extends RestClientExceptionHandler {

    public MortgageRestClientExceptionHandler(ObjectMapper objectMapper) {
        super(objectMapper);
    }

    @Override
    protected void throwServiceSpecificException(HttpStatus httpStatus, String reasonCodeSuffix, String message) {
        log.atSevere().log("HttpStatus: %s, ReasonCodeSuffix: %s, Message: %s", httpStatus, reasonCodeSuffix, message);
        switch (httpStatus) {
            case BAD_REQUEST:
                throw new RestServiceException(SystemErrors.BAD_REQUEST.getErrorCode(), httpStatus, reasonCodeSuffix, message);
            case UNAUTHORIZED:
                throw new RestServiceException(SystemErrors.UNAUTHORISED.getErrorCode(), httpStatus, reasonCodeSuffix, message);
            case FORBIDDEN:
                throw new RestServiceException(SystemErrors.FORBIDDEN.getErrorCode(), httpStatus, reasonCodeSuffix, message);
            case NOT_FOUND:
                throw new RestServiceException(SystemErrors.NOT_FOUND.getErrorCode(), httpStatus, reasonCodeSuffix, message);
            case SERVICE_UNAVAILABLE:
                throw new RestServiceException(SystemErrors.SERVICE_UNAVAILABLE.getErrorCode(), httpStatus, reasonCodeSuffix, message);
            default:
                throw new RestServiceException(SystemErrors.INTERNAL_SERVER_ERROR.getErrorCode(), httpStatus, reasonCodeSuffix, message);
        }
    }

}