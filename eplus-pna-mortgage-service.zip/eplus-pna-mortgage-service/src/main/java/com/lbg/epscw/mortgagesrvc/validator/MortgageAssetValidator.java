package com.lbg.epscw.mortgagesrvc.validator;

import com.lbg.epscw.mortgagesrvc.model.MortgageApplicationInfo;
import com.lbg.epscw.mortgagesrvc.model.MortgagePortingApplicationStatus;
import lombok.extern.flogger.Flogger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Collection;

@Flogger
@Component
public class MortgageAssetValidator {

    private final MortgagePortingApplicationValidator stateValidator;

    @Autowired
    public MortgageAssetValidator(MortgagePortingApplicationValidator stateValidator) {
        this.stateValidator = stateValidator;
    }

    public void validate(MortgageApplicationInfo applicationInfo, Collection<MortgagePortingApplicationStatus> statuses){
        stateValidator.validateCurrentState(applicationInfo, statuses);
    }
}
