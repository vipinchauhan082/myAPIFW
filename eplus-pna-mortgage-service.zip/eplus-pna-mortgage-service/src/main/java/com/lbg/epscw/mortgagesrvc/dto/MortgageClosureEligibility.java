package com.lbg.epscw.mortgagesrvc.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import java.util.List;

@Data
public class MortgageClosureEligibility {

    @JsonProperty("eligibleForClosure")
    private boolean eligibleForClosure;

    @JsonProperty("eligibilityFailureReason")
    private List<EligibilityFailureReason> eligibilityFailureReasonList;

    @JsonProperty("accountStatus")
    private String accountStatus;

}
