package com.lbg.epscw.mortgagesrvc.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class CapitalizeArrearsResponse {

    @JsonProperty("AccountId")
    private String internalAccountId;

    @JsonProperty("ProductName")
    private String productName;

    @JsonProperty("ProductId")
    private String productId;

    @JsonProperty("Status")
    private String status;

    @JsonProperty("ClientBatchId")
    private String clientBatchId;

}
