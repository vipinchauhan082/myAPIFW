package com.lbg.epscw.mortgagesrvc.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
public class UpdateApplicationPortingDetailsRequest {

    @JsonProperty("request_id")
    private String requestId;


    @JsonProperty("AccountId")
    private String accountId;


    @JsonProperty("AccountNumber")
    private String accountNumber;

    @JsonProperty("SortCode")
    private String sortCode;

    @JsonProperty("Status")
    private String status;
}
