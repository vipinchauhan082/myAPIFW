package com.lbg.epscw.mortgagesrvc.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.lbg.epscw.mortgagesrvc.enums.Recipient;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotBlank;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@JsonIgnoreProperties(ignoreUnknown = true)
public class RedemptionStatementRequest {

    @JsonProperty("statementGenerationDate")
    private String statementGenerationDate;

    @JsonProperty("overarchingAccountId")
    private String overarchingAccountId;

    @JsonProperty("recipientId")
    private String recipientId;

    @JsonProperty("recipientName")
    private String recipientName;

    @JsonProperty("redemptionDate")
    private String redemptionDate;

    @JsonProperty("aggregatedBalance")
    private String aggregatedBalance;

    @JsonProperty("totalSettlementAmount")
    private String totalSettlementAmount;

    @JsonProperty("totalDailyInterest")
    private String totalDailyInterest;

    @JsonProperty("totalAnticipatedInterest")
    private String totalAnticipatedInterest;

    @JsonProperty("validUntil")
    private String validUntil;

    @JsonProperty("reference")
    private String reference;

    @JsonProperty("AddressFirstLine")
    private String addressFirstLine;

    @JsonProperty("AddressSecondLine")
    private String addressSecondLine;

    @JsonProperty("AddressThirdLine")
    private String addressThirdLine;

    @JsonProperty("City")
    private String city;

    @JsonProperty("Postcode")
    private String postcode;

    @JsonProperty("Country")
    private String country;

    @JsonProperty("Recipient")
    private Recipient recipient;
}
