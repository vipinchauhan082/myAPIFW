package com.lbg.epscw.mortgagesrvc.validator;

import com.google.common.flogger.FluentLogger;
import com.lbg.epscw.mortgagesrvc.dto.MortgageAccountData;
import com.lbg.epscw.mortgagesrvc.dto.MortgageAccountInfo;
import com.lbg.epscw.mortgagesrvc.exception.InvalidUpdateRequestException;
import com.lbg.epscw.mortgagesrvc.restclient.MortgageAccountInfoRestClient;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Map;

import static com.lbg.epscw.mortgagesrvc.constants.CommonConstants.NOT_EXIST;
import static com.lbg.epscw.mortgagesrvc.constants.CommonConstants.OFFSETTING_OPTION;

@Component
public class MortgageOffsettingValidator {

    private static final FluentLogger logger = FluentLogger.forEnclosingClass();

    private MortgageAccountInfoRestClient mortgageAccountInfoRestClient;

    @Autowired
    public MortgageOffsettingValidator(MortgageAccountInfoRestClient mortgageAccountInfoRestClient) {
        super();
        this.mortgageAccountInfoRestClient = mortgageAccountInfoRestClient;
    }

    /**
     * This method is for validating that if the offsettingOption is already SetUp.
     * @param accountId
     * @param headers
     */
    public MortgageAccountInfo validateUpdateOffsettingOption(String accountId, Map<String, String> headers){

        MortgageAccountInfo mortgageAccountDetails = mortgageAccountInfoRestClient.getMortgageAccountInfo(accountId, headers);

        MortgageAccountData mortgageAccountData=mortgageAccountDetails.getMortgageAccountData().stream().filter(x->accountId.equals(x.getAccountId())).findAny().orElse(null);
        if( mortgageAccountData!=null && mortgageAccountData.getOffSettingOption() == null){
            String errorMsg="Offsetting Option does not exist";
            logger.atSevere().log(errorMsg);
            throw new InvalidUpdateRequestException(OFFSETTING_OPTION,NOT_EXIST);
        }
        return mortgageAccountDetails;
    }


}
