package com.lbg.epscw.mortgagesrvc.validator;

import com.google.common.flogger.FluentLogger;
import com.lbg.epscw.mortgagesrvc.dto.MortgageAccountData;
import com.lbg.epscw.mortgagesrvc.dto.MortgageAccountInfo;
import com.lbg.epscw.mortgagesrvc.enums.PaymentArrangementAmountTypeEnum;
import com.lbg.epscw.mortgagesrvc.enums.PaymentArrangementTypeEnum;
import com.lbg.epscw.mortgagesrvc.exception.InvalidUpdateRequestException;
import com.lbg.epscw.mortgagesrvc.exception.VaultValidationException;
import com.lbg.epscw.mortgagesrvc.model.AccountStatus;
import com.lbg.epscw.mortgagesrvc.model.PaymentArrangementRequest;
import com.lbg.epscw.mortgagesrvc.model.PaymentArrangementUpdateRequest;
import com.lbg.epscw.mortgagesrvc.restclient.MortgageAccountInfoRestClient;
import lombok.extern.flogger.Flogger;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.ObjectUtils;

import javax.validation.Valid;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.Date;
import java.util.Map;

import static com.lbg.epscw.mortgagesrvc.constants.CommonConstants.*;

@Component
@Flogger
public class MortgagePaymentArrangementValidator {

    private MortgageAccountInfoRestClient mortgageAccountInfoRestClient;
    private static final FluentLogger logger = FluentLogger.forEnclosingClass();

    @Autowired
    public MortgagePaymentArrangementValidator(MortgageAccountInfoRestClient mortgageAccountInfoRestClient) {
        super();
        this.mortgageAccountInfoRestClient = mortgageAccountInfoRestClient;
    }

    /**
     * This method is for verifying the params for the setupPaymentArrangementRequest
     * @param paymentArrangementRequest
     * @param accountId
     * @param headers
     */
    public void validateSetupPaymentArrangementRequest(@Valid PaymentArrangementRequest paymentArrangementRequest, String accountId, Map<String, String> headers) {
        log.atInfo().log("validateSetupPaymentArrangementRequest start");

        //validating the payment arrangement amount as given in request
        validateSetUpPaymentArrangementAmount(paymentArrangementRequest, accountId);

        //validating the date format(MM/YYYY) of payment arrangement start month as given in request
        Date startDate=validateDateFormat(paymentArrangementRequest.getPaymentArrangementStartMonth());

        //validating that if this account is a valid sub-account and checking if currently any payment Arrangement exists
        MortgageAccountInfo mortgageAccountDetails= checkIfAccountExist(accountId,headers);
        MortgageAccountData mortgageAccountData = mortgageAccountDetails.getMortgageAccountData().get(0);

        //validating that startDate is not a past date
        if(!validateNotPastDate(startDate, mortgageAccountData.getKeyDate())){
            String errorMsg = DATE_PASSED;
            log.atSevere().log(errorMsg);
            throw new InvalidUpdateRequestException(DATE, PAST_DATE);
        }

        //validating if endDate exists and is not a past date and end date is greater than start date
        if (!ObjectUtils.isEmpty(paymentArrangementRequest.getPaymentArrangementEndMonth())) {
            Date endDate = validateDateFormat(paymentArrangementRequest.getPaymentArrangementEndMonth());
            if(!validateNotPastDate(endDate, mortgageAccountData.getKeyDate())){
                String errorMsg = DATE_PASSED;
                log.atSevere().log(errorMsg);
                throw new InvalidUpdateRequestException(DATE, PAST_DATE);
            }
            if(validateStartDateGreaterThanEndDate(startDate, endDate)){
                logger.atSevere().log( START_DATE_GREATER + accountId);
                throw new InvalidUpdateRequestException(MORTGAGE_INFO, START_DATE_GREATER);
            }
        }
        if(mortgageAccountData.getPaymentArrangementAmountType()!=null && ( mortgageAccountData.getPaymentArrangementEndMonth()==null ||
                validateNotPastDate(validateDateFormat(mortgageAccountData.getPaymentArrangementEndMonth()), mortgageAccountData.getKeyDate()))) {
            String errorMsg = "PaymentArrangement exist --> " + mortgageAccountData.getPaymentArrangementType();
            log.atSevere().log(errorMsg);
            throw new InvalidUpdateRequestException(MORTGAGE_INFO, PAYMENT_ARRANGEMENT_OPTIONS_EXIST);
        }

        log.atInfo().log("validateSetupPaymentArrangementRequest end");
    }

    private void validateSetUpPaymentArrangementAmount(PaymentArrangementRequest paymentArrangementRequest, String accountId) {
        logger.atInfo().log("validateSetUpPaymentArrangementAmount Entry --> " + accountId);

        try {
            Double amount = Double.parseDouble(paymentArrangementRequest.getPaymentArrangementAmount());
            if (amount < 0) {
                logger.atSevere().log("validateSetUpPaymentArrangementAmount Exit with exception amount negative --> " + accountId);
                throw new VaultValidationException(AMOUNT, NEGATIVE);
            }
        } catch (NumberFormatException ex) {
            logger.atSevere().log("validateSetUpPaymentArrangementAmount Exit with exception--> " + " " + ex.getMessage() + accountId);
            throw new VaultValidationException(AMOUNT, NUMBER_FORMAT);
        }
    }

    private void validateAmendPaymentArrangementAmount(PaymentArrangementUpdateRequest paymentArrangementUpdateRequest, String accountId) {
        logger.atInfo().log("validateAmendPaymentArrangementAmount Entry --> " + accountId);

        if(!ObjectUtils.isEmpty(paymentArrangementUpdateRequest.getPaymentArrangementAmount())) {
            try {
                Double amount = Double.parseDouble(paymentArrangementUpdateRequest.getPaymentArrangementAmount());
                if (amount < 0) {
                    logger.atSevere().log("validateAmendPaymentArrangementAmount Exit with exception amount negative --> " + accountId);
                    throw new VaultValidationException(AMOUNT, NEGATIVE);
                }
            } catch (NumberFormatException ex) {
                logger.atSevere().log("validateAmendPaymentArrangementAmount Exit with exception--> " + " " + ex.getMessage() + accountId);
                throw new VaultValidationException(AMOUNT, NUMBER_FORMAT);
            }
        }else {
            throw new VaultValidationException(AMOUNT, NULL_OR_EMPTY);
        }
    }

    private MortgageAccountInfo checkIfAccountExist(String accountId, Map<String, String> headers) {
        MortgageAccountInfo mortgageAccountDetails = mortgageAccountInfoRestClient.getMortgageAccountInfo(accountId, headers);
        if (mortgageAccountDetails.getMortgageAccountData().size() > 1 || (StringUtils.isNotEmpty(mortgageAccountDetails.getMortgageAccountData().get(0).getStatus()) && mortgageAccountDetails.getMortgageAccountData().get(0).getStatus().equals(AccountStatus.ACCOUNT_STATUS_CLOSED.name()))) {
            String errorMsg = "Mortgage sub account does not exist";
            log.atSevere().log(errorMsg);
            throw new InvalidUpdateRequestException(MORTGAGE_INFO, SUB_ACCOUNT);
        }
        return mortgageAccountDetails;
    }

    public Date validateDateFormat(String strDate) {
        SimpleDateFormat dateFormat = new SimpleDateFormat(DATE_FORMAT);
        dateFormat.setLenient(false);
        Date date;
        try {
            date = dateFormat.parse(strDate);
        }
        /* Date format is invalid */ catch (ParseException e) {
            String errorMsg = "Invalid date format";
            log.atSevere().log(errorMsg);
            throw new InvalidUpdateRequestException(DATE, INVALID_DATE_FORMAT);
        }
        logger.atInfo().log("validateDateFormat Exit -->");
        return date;
    }

    private boolean validateNotPastDate(Date date, String keyDate) {
        LocalDate localEndDate = date.toInstant().atZone(ZoneId.systemDefault()).toLocalDate().plusDays(Long.parseLong(keyDate) - 1L);
        LocalDate localCurrentDate = LocalDate.now(ZoneId.systemDefault());
        return localEndDate.isAfter(localCurrentDate);
    }

    public void validateUpdatePaymentArrangementRequest(@Valid PaymentArrangementUpdateRequest paymentArrangementUpdateRequest, String accountId, Map<String, String> headers) {
        validateAmendPaymentArrangementAmount(paymentArrangementUpdateRequest, accountId);

        MortgageAccountInfo mortgageAccountDetails = checkIfAccountExist(accountId, headers);

        MortgageAccountData mortgageAccountData = mortgageAccountDetails.getMortgageAccountData().get(0);

        //validating if endDate exists and is not a past date and end date is greater than start date
        if(StringUtils.isNotBlank(paymentArrangementUpdateRequest.getPaymentArrangementStartMonth())
                && validateDateFormat(paymentArrangementUpdateRequest.getPaymentArrangementStartMonth()).before(new Date())){
            logger.atSevere().log(DATE_PASSED);
            throw new InvalidUpdateRequestException(DATE, PAST_DATE);
        }
        if(StringUtils.isNotBlank(paymentArrangementUpdateRequest.getPaymentArrangementEndMonth()) &&
                validateDateFormat(paymentArrangementUpdateRequest.getPaymentArrangementEndMonth()).before(new Date())){
            logger.atSevere().log(DATE_PASSED);
            throw new InvalidUpdateRequestException(DATE, PAST_DATE);
        }
        if (StringUtils.isNotBlank(paymentArrangementUpdateRequest.getPaymentArrangementStartMonth()) && StringUtils.isNotBlank(paymentArrangementUpdateRequest.getPaymentArrangementEndMonth())) {
            Date startDate = validateDateFormat(paymentArrangementUpdateRequest.getPaymentArrangementStartMonth());
            Date endDate = validateDateFormat(paymentArrangementUpdateRequest.getPaymentArrangementEndMonth());
            if(validateStartDateGreaterThanEndDate(startDate,endDate)){
                logger.atSevere().log( START_DATE_GREATER + accountId);
                throw new InvalidUpdateRequestException(MORTGAGE_INFO, START_DATE_GREATER);
            }
        }

        if (!checkIfValidUpdatePaymentArrangementStartDate(mortgageAccountData, validateDateFormat(paymentArrangementUpdateRequest.getPaymentArrangementStartMonth()))) {
            logger.atSevere().log("Invalid update request for Payment Arrangement start date");
            throw new InvalidUpdateRequestException(INVALID, PAYMENT_ARRANGEMENT_MONTH,mortgageAccountData.getPaymentArrangementType(),
                    START_DATE, mortgageAccountData.getPaymentArrangementStartMonth());
        }

        if(StringUtils.isNotBlank(paymentArrangementUpdateRequest.getPaymentArrangementEndMonth())
            && !checkIfValidUpdatePaymentArrangementEndDate(mortgageAccountData, validateDateFormat(paymentArrangementUpdateRequest.getPaymentArrangementEndMonth()))){
                logger.atSevere().log("Invalid update request for Payment Arrangement end date");
                throw new InvalidUpdateRequestException(INVALID, PAYMENT_ARRANGEMENT_MONTH,mortgageAccountData.getPaymentArrangementType(),
                        END_DATE, mortgageAccountData.getPaymentArrangementEndMonth());
        }
        if(StringUtils.isNotBlank(mortgageAccountData.getPaymentArrangementType()) && !validateType(mortgageAccountData)){
            throw new VaultValidationException(INVALID, TYPE, mortgageAccountData.getMortgageType());
        }
    }

    private boolean validateType(MortgageAccountData mortgageAccountData) {
        return (mortgageAccountData.getPaymentArrangementType().equals(PaymentArrangementTypeEnum.OVERPAYMENT.name())
                || (mortgageAccountData.getPaymentArrangementType().equals(PaymentArrangementTypeEnum.UNDERPAYMENT.name())));
    }

    private boolean checkIfValidUpdatePaymentArrangementStartDate(MortgageAccountData mortgageAccountData, Date startMonthYear){

        return (StringUtils.isNotEmpty(mortgageAccountData.getPaymentArrangementStartMonth())
                && validatePreDate(validateDateFormat(mortgageAccountData.getPaymentArrangementStartMonth()), startMonthYear));
    }

    private boolean checkIfValidUpdatePaymentArrangementEndDate(MortgageAccountData mortgageAccountData, Date endMonthYear){
        if(StringUtils.isNotEmpty(mortgageAccountData.getPaymentArrangementEndMonth())) {
            return (validatePreDate(validateDateFormat(mortgageAccountData.getPaymentArrangementEndMonth()), endMonthYear));
        }
        return true;
    }

    private boolean validatePreDate(Date oldDate, Date newDate) {
        LocalDate localOldDate = oldDate.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
        LocalDate localNewDate = newDate.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
        return localNewDate.isBefore(localOldDate);
    }

    private boolean validateStartDateGreaterThanEndDate(Date startDate, Date endDate) {
        return endDate.compareTo(startDate) < 0;
    }

    public void validateCancelPaymentArrangement(String accountId, Map<String, String> headers) {
        MortgageAccountInfo mortgageAccountDetails = checkIfAccountExist(accountId, headers);

        MortgageAccountData mortgageAccountData = mortgageAccountDetails.getMortgageAccountData().get(0);
        if(StringUtils.isNotEmpty(mortgageAccountData.getPaymentArrangementEndMonth()) && validateStartDateGreaterThanEndDate(validateDateFormat(mortgageAccountData.getPaymentArrangementStartMonth()),
                validateDateFormat(mortgageAccountData.getPaymentArrangementEndMonth()))){
            logger.atSevere().log( START_DATE_GREATER + accountId);
            throw new InvalidUpdateRequestException(MORTGAGE_INFO, START_DATE_GREATER);
        }
        if (!checkIfValidPaymentArrangementExist(mortgageAccountData)) {
            String errorMsg = "Payment Arrangement option does not exist";
            log.atSevere().log(errorMsg);
            throw new InvalidUpdateRequestException(INVALID, PAYMENT_ARRANGEMENT_OPTION);
        }
    }

    private boolean checkIfValidPaymentArrangementExist(MortgageAccountData mortgageAccountData){
        return (StringUtils.isNotEmpty(mortgageAccountData.getPaymentArrangementType()) &&
                (mortgageAccountData.getPaymentArrangementType().equals(PaymentArrangementTypeEnum.OVERPAYMENT.name())
                || (mortgageAccountData.getPaymentArrangementType().equals(PaymentArrangementTypeEnum.UNDERPAYMENT.name()))) &&
                StringUtils.isNotEmpty(mortgageAccountData.getPaymentArrangementAmountType()) &&
                (mortgageAccountData.getPaymentArrangementAmountType().equals(PaymentArrangementAmountTypeEnum.VARIABLE_PAYMENT_AMOUNT.name())
                || mortgageAccountData.getPaymentArrangementAmountType().equals(PaymentArrangementAmountTypeEnum.FIXED_PAYMENT_AMOUNT.name())) &&
                StringUtils.isNotEmpty(mortgageAccountData.getPaymentArrangementStartMonth()) &&
                validateNotPastDate(validateDateFormat(mortgageAccountData.getPaymentArrangementStartMonth()), mortgageAccountData.getKeyDate()));
    }
}
