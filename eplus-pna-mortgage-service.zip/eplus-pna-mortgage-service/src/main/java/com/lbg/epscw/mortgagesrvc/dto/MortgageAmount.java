package com.lbg.epscw.mortgagesrvc.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;
import org.springframework.util.ObjectUtils;

import static com.lbg.epscw.mortgagesrvc.constants.CommonConstants.DEFAULT_AMOUNT;

@Data
public class MortgageAmount {

    @JsonProperty("Amount")
    private String amount;

    @JsonProperty("Interest")
    private String interest;

    public MortgageAmount(){
    }

    public MortgageAmount(String amount) {
        if (ObjectUtils.isEmpty(amount)) {
            this.amount = DEFAULT_AMOUNT;
        } else {
            this.amount = amount;
        }
    }

    public MortgageAmount(String amount, String interest) {
        if (ObjectUtils.isEmpty(amount)) {
            this.amount = DEFAULT_AMOUNT;
        } else {
            this.amount = amount;
        }
        if (ObjectUtils.isEmpty(interest)) {
            this.interest = DEFAULT_AMOUNT;
        } else {
            this.interest = interest;
        }
    }
}