package com.lbg.epscw.mortgagesrvc.dto.comms;

public enum Priority {
    HIGHEST, HIGH, MEDIUM, LOW
}
