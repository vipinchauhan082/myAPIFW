package com.lbg.epscw.mortgagesrvc.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
public class BankAccountRequest {
    @JsonProperty("request_id")
    private String requestId;

    @JsonProperty("bank_account")
    private BankAccount bankAccount;

    @JsonProperty("account_id")
    private String accountId;
}
