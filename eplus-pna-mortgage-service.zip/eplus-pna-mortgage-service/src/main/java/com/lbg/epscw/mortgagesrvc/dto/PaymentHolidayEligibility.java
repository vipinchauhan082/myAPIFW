package com.lbg.epscw.mortgagesrvc.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import java.util.List;

@Data
public class PaymentHolidayEligibility {

    @JsonProperty("eligibleForPaymentHoliday")
    private boolean eligibleForPaymentHoliday;

    @JsonProperty("accountStatus")
    private String accountStatus;

    @JsonProperty("eligibilityFailureReason")
    private List<EligibilityFailureReason> eligibilityFailureReasonList;
}
