package com.lbg.epscw.mortgagesrvc.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
public class ExternalAccountOpenRequest {

    @JsonProperty("request_id")
    private String requestId;

    @JsonProperty("bban")
    private UkBankAccountNumber ukBankAccountNumber;
}
