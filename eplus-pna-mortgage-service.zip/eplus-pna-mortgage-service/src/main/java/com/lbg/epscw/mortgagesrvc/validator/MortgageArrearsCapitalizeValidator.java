package com.lbg.epscw.mortgagesrvc.validator;

import com.lbg.epscw.mortgagesrvc.constants.CommonConstants;
import com.lbg.epscw.mortgagesrvc.dto.MortgageAccountData;
import com.lbg.epscw.mortgagesrvc.dto.MortgageAccountInfo;
import com.lbg.epscw.mortgagesrvc.dto.MortgageResponse;
import com.lbg.epscw.mortgagesrvc.exception.MortgageValidationException;
import com.lbg.epscw.mortgagesrvc.model.OverarchingAccountInfo;
import com.lbg.epscw.mortgagesrvc.restclient.MortgageAccountBalanceRestClient;
import com.lbg.epscw.mortgagesrvc.restclient.MortgageAccountInfoRestClient;
import com.lbg.epscw.mortgagesrvc.util.MortgageServiceUtil;
import lombok.extern.flogger.Flogger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.stream.Collectors;

import static com.lbg.epscw.mortgagesrvc.constants.CommonConstants.ARREARS_AMOUNT;
import static com.lbg.epscw.mortgagesrvc.constants.CommonConstants.MORTGAGE_FAMILY;

@Flogger
@Component
public class MortgageArrearsCapitalizeValidator {

    private MortgageAccountInfoRestClient mortgageAccountInfoRestClient;

    private MortgageAccountBalanceRestClient mortgageAccountBalanceRestClient;

    private MortgageServiceUtil mortgageServiceUtil;

    @Autowired
    public MortgageArrearsCapitalizeValidator(MortgageAccountInfoRestClient mortgageAccountInfoRestClient, MortgageAccountBalanceRestClient mortgageAccountBalanceRestClient, MortgageServiceUtil mortgageServiceUtil) {
        this.mortgageAccountInfoRestClient = mortgageAccountInfoRestClient;
        this.mortgageAccountBalanceRestClient = mortgageAccountBalanceRestClient;
        this.mortgageServiceUtil = mortgageServiceUtil;
    }

    public List<MortgageAccountData> validateCapitalizationOfArrears(OverarchingAccountInfo overarchingAccountInfo, Map<String,String> headers){
        MortgageAccountInfo mortgageAccountInfo =mortgageAccountInfoRestClient.getMortgageAccountInfo(overarchingAccountInfo.getAccountId(), headers);
        List<MortgageAccountData> mortgageRepaymentAccountData = mortgageAccountInfo.getMortgageAccountData().stream().filter(account->account.getProductFamily().equals("Mortgage Payment")).collect(Collectors.toList());
        if(mortgageRepaymentAccountData.isEmpty()){
            throw new MortgageValidationException(CommonConstants.MORTGAGE_OVERARCHING, CommonConstants.INVALID);
        }
        overarchingAccountInfo.setStakeholderId(mortgageRepaymentAccountData.get(0).getStakeholderId());

        MortgageResponse mortgageBalanceInfo = mortgageAccountBalanceRestClient.getMortgageAccountBalanceInfo(overarchingAccountInfo.getAccountId(), headers);
        overarchingAccountInfo.setArrearsBalance(mortgageBalanceInfo.getMortgageBalance().getAggregatedMap().get(ARREARS_AMOUNT));


        if(Objects.nonNull(overarchingAccountInfo.getArrearsBalance()) && Double.parseDouble(overarchingAccountInfo.getArrearsBalance())<=0.0 ){
            throw new MortgageValidationException(CommonConstants.MORTGAGE_CAPITALIZATION_ARREARS, CommonConstants.NOT_ELIGIBLE);
        }


        return mortgageAccountInfo.getMortgageAccountData().stream().filter(account->account.getProductFamily().equals(MORTGAGE_FAMILY))
                .sorted((o1, o2) -> mortgageServiceUtil.compareDate(o1.getAccountOpeningDate(),o2.getAccountOpeningDate())).collect(Collectors.toList());

    }
}
