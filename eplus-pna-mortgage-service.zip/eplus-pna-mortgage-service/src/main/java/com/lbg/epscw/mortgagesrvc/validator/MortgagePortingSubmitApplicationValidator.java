package com.lbg.epscw.mortgagesrvc.validator;

import com.lbg.epscw.mortgagesrvc.dto.MortgagePortingApplicationSubAccountDetails;
import com.lbg.epscw.mortgagesrvc.exception.MortgageValidationException;
import com.lbg.epscw.mortgagesrvc.model.MortgageApplicationInfo;
import lombok.extern.flogger.Flogger;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;

import static com.lbg.epscw.mortgagesrvc.constants.CommonConstants.INVALID_BORROWING_AMOUNT;
import static com.lbg.epscw.mortgagesrvc.constants.CommonConstants.MORTGAGE_SUBMIT_APPLICATION;
import static com.lbg.epscw.mortgagesrvc.model.MortgagePortingApplicationStatus.SUBMITTED;
import static java.math.BigDecimal.ZERO;

@Component
@Flogger
public class MortgagePortingSubmitApplicationValidator {
    private final MortgagePortingApplicationValidator applicationValidator;

    public MortgagePortingSubmitApplicationValidator(MortgagePortingApplicationValidator applicationValidator) {
        this.applicationValidator = applicationValidator;
    }

    public void validate(MortgageApplicationInfo applicationInfo) {
        applicationValidator.validateNextState(applicationInfo, SUBMITTED);

        BigDecimal totalPrincipalAmount = applicationInfo.getSubAccountDetails().stream()
                .map(MortgagePortingApplicationSubAccountDetails::getLoanAmount)
                .map(BigDecimal::new)
                .reduce(ZERO, BigDecimal::add);

        if (totalPrincipalAmount.compareTo(new BigDecimal(applicationInfo.getBorrowingAmount())) != 0) {
            String errorMsg = "Invalid Borrowing Amount";
            log.atSevere().log(errorMsg);
            throw new MortgageValidationException(MORTGAGE_SUBMIT_APPLICATION, INVALID_BORROWING_AMOUNT);
        }
    }
}
