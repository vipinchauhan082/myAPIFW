package com.lbg.epscw.mortgagesrvc.validator;

import com.google.common.flogger.FluentLogger;
import com.lbg.epscw.mortgagesrvc.dto.MortgageAccountData;
import com.lbg.epscw.mortgagesrvc.dto.MortgageAccountInfo;
import com.lbg.epscw.mortgagesrvc.exception.InvalidUpdateRequestException;
import com.lbg.epscw.mortgagesrvc.restclient.MortgageAccountInfoRestClient;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Map;
import java.util.Objects;

import static com.lbg.epscw.mortgagesrvc.constants.CommonConstants.*;

@Component
public class MortgagePaymentOptionValidator {

    private static final FluentLogger logger = FluentLogger.forEnclosingClass();

    private MortgageAccountInfoRestClient mortgageAccountInfoRestClient;

    @Autowired
    public MortgagePaymentOptionValidator(MortgageAccountInfoRestClient mortgageAccountInfoRestClient) {
        super();
        this.mortgageAccountInfoRestClient = mortgageAccountInfoRestClient;
    }

    /**
     * This method is for validating that if the mortgage payment Option can be set/updated
     * for the given accountId.
     * @param accountId
     * @param headers
     */
    public MortgageAccountInfo validateUpdateMortgagePaymentOption(String accountId, Map<String, String> headers){

        MortgageAccountInfo mortgageAccountDetails = mortgageAccountInfoRestClient.getMortgageAccountInfo(accountId, headers);

        MortgageAccountData mortgageAccountData=mortgageAccountDetails.getMortgageAccountData().stream().
                filter(mortAccData -> Objects.nonNull(mortAccData.getProductFamily()) &&
                        mortAccData.getProductFamily().equals(MORTGAGE_PAYMENT)).findAny().orElse(null);

        if( mortgageAccountData == null){
            String errorMsg="Mortgage Payment Option can not be set at sub-account level";
            logger.atSevere().log(errorMsg);
            throw new InvalidUpdateRequestException(MPO_OPTION,REQUEST_INVALID);
        }
        validateUpdateMortgagePaymentOptionByOffsettingOption(mortgageAccountDetails);
        return mortgageAccountDetails;
    }

    /**
     * This method is for validating the offsetting option of the mortgage
     * for the given accountId.
     * @param mortgageAccountDetails
     */
    private void validateUpdateMortgagePaymentOptionByOffsettingOption(MortgageAccountInfo mortgageAccountDetails){

        MortgageAccountData mortgageAccountData=mortgageAccountDetails.getMortgageAccountData()
                .stream().filter(mortAccData -> Objects.nonNull(mortAccData.getOffSettingOption()) &&
                        mortAccData.getOffSettingOption().equals("OFFSET_CREDIT_BALANCES")).findAny().orElse(null);

        if( mortgageAccountData == null){
            String errorMsg="Mortgage Payment Option can not be set for Offsetting Option 'OFFSET_DEBIT_BALANCES' ";
            logger.atSevere().log(errorMsg);
            throw new InvalidUpdateRequestException(MPO_OPTION,OFFSETTING_INVALID);
        }
    }
}