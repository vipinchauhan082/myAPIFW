package com.lbg.epscw.mortgagesrvc.dto.comms;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
@Builder
public class HeaderData {

    @JsonProperty("CommunicationEvent")
    private String communicationEvent;

    @JsonProperty("ReferenceId")
    private String referenceId;

    @JsonProperty("CustomerId")
    private String customerId;

    @JsonProperty("AccountId")
    private String accountId;

    @JsonProperty("ExternalSystemId")
    private String externalSystemId;

    @JsonProperty("Priority")
    private Priority priority;

    @JsonProperty("Version")
    private String version;

    @JsonProperty("OverrideNotificationChannel")
    private OverrideNotificationChannel overrideNotificationChannel;

    @JsonProperty("Initiator")
    private String initiator;

    @JsonProperty("Category")
    private Category category;

    @JsonProperty("Documents")
    private List<Document> documents;

    @JsonProperty("MailToThirdParty")
    private boolean mailToThirdParty;

    @JsonProperty("ThirdParty")
    private ThirdaParty thirdaParty;
}
