package com.lbg.epscw.mortgagesrvc.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.lbg.epscw.mortgagesrvc.enums.Currency;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class MortgageSubAccountBalance implements AccountBalance {

    //@JsonProperty("ProductId")
    //private String productId;
    
    @JsonProperty("ProductFamily")
    private String productFamily;

    @JsonProperty("AccountId")
    private String accountId;

    @JsonProperty("OriginalPrincipal")
    private String mortgagePrincipal;

    @JsonProperty("Balance")
    private MortgageAmount balance;

    @JsonProperty("Arrear")
    private Arrear arrear;

    @JsonProperty("Currency")
    private Currency currency;

    @JsonProperty("BuiltUpReserve")
    private String builtUpReserve;

}
