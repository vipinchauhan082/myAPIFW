package com.lbg.epscw.mortgagesrvc.validator;

import com.google.common.flogger.FluentLogger;
import com.google.common.flogger.StackSize;
import com.lbg.epscw.mortgagesrvc.constants.CommonConstants;
import com.lbg.epscw.mortgagesrvc.dto.MortgageClosureEligibility;
import com.lbg.epscw.mortgagesrvc.exception.AccountClosureValidationException;
import com.lbg.epscw.mortgagesrvc.restclient.MortgageAccountClosureEligibilityRestClient;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import java.util.Map;

@Component
public class MortgageAccountClosureValidator {

    private static final FluentLogger logger = FluentLogger.forEnclosingClass();

    private MortgageAccountClosureEligibilityRestClient mortgageAccountClosureEligibilityRestClient;

    @Autowired
    public MortgageAccountClosureValidator(MortgageAccountClosureEligibilityRestClient mortgageAccountClosureEligibilityRestClient) {
        this.mortgageAccountClosureEligibilityRestClient = mortgageAccountClosureEligibilityRestClient;
    }

    /**
     * validates if account is eligible to close
     * @param accountId
     * @param headers
     */
    public void validateAccountClosure(String accountId, Map<String,String> headers, MortgageClosureEligibility mortgageClosureEligibility){
        MortgageClosureEligibility closureEligibility=mortgageAccountClosureEligibilityRestClient.getMortgageAccountClosureEligibilityInfo(accountId, headers);
        mortgageClosureEligibility.setAccountStatus(closureEligibility.getAccountStatus());
        if(!closureEligibility.isEligibleForClosure()){
            String reasonDetails = CollectionUtils.isEmpty(closureEligibility.getEligibilityFailureReasonList())?
                    "":closureEligibility.getEligibilityFailureReasonList().get(0).getMessage();
            String errorMsg = "Account closure failed for account "+accountId+" "+reasonDetails;

            logger.atSevere().withStackTrace(StackSize.MEDIUM).log(errorMsg);
            throw new AccountClosureValidationException(closureEligibility.getEligibilityFailureReasonList().get(0).getCode(), CommonConstants.ERROR);

        }
    }
}
