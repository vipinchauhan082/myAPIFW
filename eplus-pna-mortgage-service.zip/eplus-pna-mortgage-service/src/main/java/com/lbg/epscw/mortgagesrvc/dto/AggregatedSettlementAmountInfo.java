package com.lbg.epscw.mortgagesrvc.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.Valid;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

@Builder
@Data
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
@Valid
public class AggregatedSettlementAmountInfo {

    @JsonProperty("AccountId")
    @NotEmpty(message = "AccountId")
    private String accountId;

    @JsonProperty("RedemptionDateRequested")
    @NotEmpty(message = "RedemptionDateRequested")
    private String redemptionDateRequested;

    @Valid
    @JsonProperty("TotalSettlementDailyInterest")
    @NotNull(message = "TotalSettlementDailyInterest")
    private String totalSettlementDailyInterest ;

    @JsonProperty("TotalAnticipatedInterest")
    @NotEmpty(message = "TotalAnticipatedInterest")
    private String totalAnticipatedInterest;

    @JsonProperty("TotalSettlementAmount")
    @NotEmpty(message = "TotalSettlementAmount")
    private String totalSettlementAmount;

    @JsonProperty("DayInterestAfterRedemptionDate")
    @NotEmpty(message = "DayInterestAfterRedemptionDate")
    private String dayInterestAfterRedemptionDate;

}
