package com.lbg.epscw.mortgagesrvc.validator;


import com.lbg.epscw.mortgagesrvc.dto.MortgageAccountData;
import com.lbg.epscw.mortgagesrvc.dto.MortgageAccountInfo;
import com.lbg.epscw.mortgagesrvc.exception.MortgageValidationException;
import com.lbg.epscw.mortgagesrvc.util.MortgageServiceUtil;
import lombok.extern.flogger.Flogger;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Optional;

import static com.lbg.epscw.mortgagesrvc.constants.CommonConstants.MORTGAGE_INFO;
import static com.lbg.epscw.mortgagesrvc.constants.CommonConstants.MORTGAGE_PAYMENT;
import static com.lbg.epscw.mortgagesrvc.model.AccountStatus.ACCOUNT_STATUS_OPEN;
import static java.util.stream.Collectors.toList;

@Component
@Flogger
public class MortgagePortingCreateApplicationValidator {
    private final MortgageServiceUtil utility;

    public MortgagePortingCreateApplicationValidator(MortgageServiceUtil utility) {
        this.utility = utility;
    }

    public void validate(String customerId, MortgageAccountInfo accountInfo) {
        List<MortgageAccountData> account = accountInfo.getMortgageAccountData();
        validateAccountIsOpen(account);
        validateCustomerMatches(customerId, account);
    }

    private void validateAccountIsOpen(List<MortgageAccountData> accounts) {
        Optional<String> optionalStatus = accounts.stream()
                .filter(account -> account.getProductFamily().equalsIgnoreCase(MORTGAGE_PAYMENT))
                .map(MortgageAccountData::getStatus)
                .filter(StringUtils::isNotBlank)
                .findFirst();
        if (optionalStatus.isEmpty() || !ACCOUNT_STATUS_OPEN.name().equalsIgnoreCase(optionalStatus.get())) {
            String error = utility.getLocalizedMessage("PNA.MORTGAGE_API.PORTING.004");
            log.atSevere().log(error);
            throw new MortgageValidationException(MORTGAGE_INFO, error);
        }
    }

    private void validateCustomerMatches(String customerId, List<MortgageAccountData> accounts) {
        List<String> existingCustomerIds = accounts.stream()
                .filter(account -> account.getProductFamily().equalsIgnoreCase(MORTGAGE_PAYMENT))
                .map(MortgageAccountData::getStakeholderId)
                .filter(StringUtils::isNotBlank)
                .collect(toList());
        if (existingCustomerIds.isEmpty() || !existingCustomerIds.contains(customerId)) {
            String error = utility.getLocalizedMessage("PNA.MORTGAGE_API.PORTING.005");
            log.atSevere().log(error);
            throw new MortgageValidationException(MORTGAGE_INFO, error);
        }
    }
}
