package com.lbg.epscw.mortgagesrvc.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Builder;
import lombok.Data;

import java.util.List;

@Data
@Builder
public class PostingsInstructionsBatch {

    @JsonProperty("client_id")
    private String clientId;

    @JsonProperty("client_batch_id")
    private String clientBatchId;

    @JsonProperty("posting_instructions")
    List<PostingsInstruction> postingsInstructions;

    @JsonProperty("value_timestamp")
    private String valueTime;
}
