package com.lbg.epscw.mortgagesrvc.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import java.util.List;
import java.util.Map;

@JsonIgnoreProperties(ignoreUnknown = true)
@Data
public class VaultAccountResponse {

    @JsonProperty("id")
    private String accountId;

    @JsonProperty("stakeholder_ids")
    private List<String> stakeholderId;

    @JsonProperty("instance_param_vals")
    private Map<Object, Object> instanceParamVals;

    @JsonProperty("name")
    private String productName;

    @JsonProperty("status")
    private String status;
}
