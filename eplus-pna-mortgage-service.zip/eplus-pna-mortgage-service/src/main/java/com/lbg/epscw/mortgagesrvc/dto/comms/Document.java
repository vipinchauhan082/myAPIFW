package com.lbg.epscw.mortgagesrvc.dto.comms;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Map;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class Document {

    @JsonProperty("TemplateKey")
    private String templateKey;

    @JsonProperty("OverrideDocumentFileName")
    private String overrideDocumentFileName;

    @JsonProperty("ValidityStartDate")
    private String validityStartDate;

    @JsonProperty("ValidityEndDate")
    private String validityEndDate;

    @JsonProperty("MetaData")
    private Map<String,String> metaData;
}
