package com.lbg.epscw.mortgagesrvc.validator;

import com.lbg.epscw.handler.exception.system.SystemNotFoundException;
import com.lbg.epscw.mortgagesrvc.dto.MortgageAccountData;
import com.lbg.epscw.mortgagesrvc.dto.MortgageAccountInfo;
import com.lbg.epscw.mortgagesrvc.enums.MortgageFamily;
import com.lbg.epscw.mortgagesrvc.enums.Recipient;
import com.lbg.epscw.mortgagesrvc.exception.InvalidUpdateRequestException;
import com.lbg.epscw.mortgagesrvc.exception.MortgageValidationException;
import com.lbg.epscw.mortgagesrvc.model.RedemptionStatementPayloadRequest;
import com.lbg.epscw.mortgagesrvc.model.SettlementAmountRequest;
import com.lbg.epscw.mortgagesrvc.restclient.MortgageAccountInfoRestClient;
import io.micrometer.core.instrument.util.StringUtils;
import lombok.extern.flogger.Flogger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.ObjectUtils;

import javax.validation.Valid;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.*;
import java.util.regex.Pattern;

import static com.lbg.epscw.mortgagesrvc.constants.CommonConstants.*;

@Component
@Flogger
public class MortgageRedemptionValidator {

    private final MortgageAccountInfoRestClient mortgageAccountInfoRestClient;

    private static final String FIRST_LINE_MISSING= "The first line of the address is missing";
    private static final String POSTCODE_MISSING= "The postcode is missing";
    private static final String CITY_MISSING= "The town or city is missing";
    private static final String CITY_PATTERN_ISSUE= "The town or city must not contain special characters";
    private static final String COUNTRY_MISSING= "The country is missing";
    private static final String NAME_MISSING= "The recipient name is missing";
    private static final String NAME_SIZE_ERROR= "A minimum of 2 characters is required in the name field";

    private static final String ADDRESS_1ST_LINE_PATTERN_ERROR = "The address first line must not contain special characters";
    private static final String ADDRESS_2ND_LINE_PATTERN_ERROR = "The address second line must not contain special characters";
    private static final String ADDRESS_3RD_LINE_PATTERN_ERROR = "The address third line must not contain special characters";
    private static final String INVALID_POSTCODE = "The postcode is invalid";


    private static final String REGEX = "[A-Za-z0-9-'\\s]*";
    private static final Pattern PATTERN = Pattern.compile(REGEX);

    @Autowired
    public MortgageRedemptionValidator(MortgageAccountInfoRestClient mortgageAccountInfoRestClient) {
        this.mortgageAccountInfoRestClient = mortgageAccountInfoRestClient;
    }


    public List<String> validateRedemptionStatementPayload(RedemptionStatementPayloadRequest redemptionStatementPayloadRequest)
    {
        List<String> errors = new ArrayList<>();
        if(!redemptionStatementPayloadRequest.getRecipient().equals(Recipient.CUSTOMER)){
            //solicitor or other the address and name fields must be present!
            errors.addAll(checkSolicitorOtherFields(redemptionStatementPayloadRequest));
        }
        return errors;
    }

    public MortgageAccountData validateGenerateRedemptionStatement(String accountId, Map<String, String> reqHeaders) {

        MortgageAccountInfo mortgageAccountInfo = mortgageAccountInfoRestClient.getMortgageAccountInfo(accountId, reqHeaders);

        if (ObjectUtils.isEmpty(mortgageAccountInfo)) {
            throw new SystemNotFoundException(MORTGAGE_INFO, NOT_FOUND);
        }

        Optional<MortgageAccountData> overarchingAccount = mortgageAccountInfo.getMortgageAccountData().stream().
                filter(x -> x.getProductFamily().equals(MortgageFamily.MORTGAGE_PAYMENT.toString())).findAny();
        if (overarchingAccount.isEmpty()) {
            throw new MortgageValidationException(ACCOUNT_ID, REQUEST_INVALID);
        }


        return overarchingAccount.get();
    }

    private List<String> checkSolicitorOtherFields(RedemptionStatementPayloadRequest redemptionStatementPayloadRequest) {

        List<String> errors = new ArrayList<>();

        checkAddressLines(redemptionStatementPayloadRequest, errors);
        checkCityAndCountry(redemptionStatementPayloadRequest,errors);
        checkName(redemptionStatementPayloadRequest,errors);

        return errors;
    }

    private void checkName(RedemptionStatementPayloadRequest redemptionStatementPayloadRequest, List<String> errors) {
        if(StringUtils.isEmpty(redemptionStatementPayloadRequest.getRecipientName())){
            errors.add(NAME_MISSING);

        }else{
            if(redemptionStatementPayloadRequest.getRecipientName().length()< 2){
                errors.add(NAME_SIZE_ERROR);
            }
        }
    }

    private void checkCityAndCountry(RedemptionStatementPayloadRequest redemptionStatementPayloadRequest, List<String> errors) {
        if(StringUtils.isEmpty(redemptionStatementPayloadRequest.getCity())){
            errors.add(CITY_MISSING);
        }else{
            if(!PATTERN.matcher(redemptionStatementPayloadRequest.getCity()).matches()){
                errors.add(CITY_PATTERN_ISSUE);
            }
        }

        if(StringUtils.isEmpty(redemptionStatementPayloadRequest.getPostcode())){
            errors.add(POSTCODE_MISSING);
        }else{
            if(!PATTERN.matcher(redemptionStatementPayloadRequest.getPostcode()).matches()){
                errors.add(INVALID_POSTCODE);
            }
        }

        if(StringUtils.isEmpty(redemptionStatementPayloadRequest.getCountry())){
            errors.add(COUNTRY_MISSING);
        }
    }

    private void checkAddressLines(RedemptionStatementPayloadRequest redemptionStatementPayloadRequest, List<String> errors) {
        if((!StringUtils.isEmpty(redemptionStatementPayloadRequest.getAddressSecondLine())) && (!PATTERN.matcher(redemptionStatementPayloadRequest.getAddressSecondLine()).matches())){
                errors.add(ADDRESS_2ND_LINE_PATTERN_ERROR);
        }

        if((!StringUtils.isEmpty(redemptionStatementPayloadRequest.getAddressThirdLine())) &&
                (!PATTERN.matcher(redemptionStatementPayloadRequest.getAddressThirdLine()).matches())){
                errors.add(ADDRESS_3RD_LINE_PATTERN_ERROR);
        }

        if(StringUtils.isEmpty(redemptionStatementPayloadRequest.getAddressFirstLine())){
            errors.add(FIRST_LINE_MISSING);
        }else{
            if(!PATTERN.matcher(redemptionStatementPayloadRequest.getAddressFirstLine()).matches()){
                errors.add(ADDRESS_1ST_LINE_PATTERN_ERROR);
            }
        }

    }


    private Date validateDateFormat(String strDate) {
        SimpleDateFormat dateFormat = new SimpleDateFormat(REDEMPTION_DATE_FORMAT);
        dateFormat.setLenient(false);
        Date date;
        try {
            date = dateFormat.parse(strDate);
        } catch (ParseException e) {
            String errorMsgInvalid = "Invalid date format";
            log.atSevere().log(errorMsgInvalid);
            throw new InvalidUpdateRequestException(DATE, INVALID_REDEMPTION_DATE_FORMAT);
        }
        log.atInfo().log("validateDateFormat MortgageSettlementAmount Exit -->");
        return date;
    }

    private boolean validateNotPastDate(Date date) {
        LocalDate givenDate = date.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
        LocalDate localCurrentDate = LocalDate.now(ZoneId.systemDefault());
        return givenDate.isBefore(localCurrentDate);
    }

    public boolean isUUID(String string) {
        try {
            UUID.fromString(string);
            return true;
        } catch (Exception ex) {
            return false;
        }
    }

    public void validateSettlementAmountRequest(@Valid SettlementAmountRequest settlementAmountRequest, String accountId) {

        log.atInfo().log("validateSettlementAmountRequest Entry -->" + accountId);

        if (ObjectUtils.isEmpty(settlementAmountRequest.getRedemptionDate())) {
            log.atSevere().log(DATE_SELECT);
            throw new InvalidUpdateRequestException(DATE, DATE_SELECT);
        }

        if (ObjectUtils.isEmpty(accountId)) {
            log.atSevere().log(NO_ACCOUNT_ID);
            throw new InvalidUpdateRequestException(ACCOUNT_ID, NO_ACCOUNT_ID);
        }

        if (!isUUID(accountId)) {
            log.atSevere().log(INVALID);
            throw new InvalidUpdateRequestException(ACCOUNT_ID, INVALID);
        }

        Date date = validateDateFormat(settlementAmountRequest.getRedemptionDate());

        if (validateNotPastDate(date)) {
            log.atSevere().log(DATE_PASSED);
            throw new InvalidUpdateRequestException(DATE, PAST_REDEMPTION_DATE);
        }

        if (validateNotMoreThanThirtyDays(date)) {
            log.atSevere().log(DATE_SELECT_MESSAGE);
            throw new InvalidUpdateRequestException(DATE, DATE_SELECT_MESSAGE);
        }

        log.atInfo().log("validateSettlementAmountRequest Exit -->" + accountId);

    }

    private boolean validateNotMoreThanThirtyDays(Date date) {
        LocalDate localEndDate = date.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
        LocalDate localCurrentDate = LocalDate.now(ZoneId.systemDefault()).plusDays(THIRTY_AS_INT);
        return localEndDate.isAfter(localCurrentDate);

    }
}
