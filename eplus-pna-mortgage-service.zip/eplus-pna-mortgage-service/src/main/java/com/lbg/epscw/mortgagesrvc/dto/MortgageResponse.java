package com.lbg.epscw.mortgagesrvc.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
public class MortgageResponse {

    @JsonProperty("Data")
    private MortgageBalance mortgageBalance;

}
