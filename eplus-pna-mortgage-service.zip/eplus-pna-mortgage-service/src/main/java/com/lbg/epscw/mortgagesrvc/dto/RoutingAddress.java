package com.lbg.epscw.mortgagesrvc.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
public class RoutingAddress {
    @JsonProperty("bank_id_code")
    private String bankIdCode;

    @JsonProperty("bank_id")
    private String bankId;

    @JsonProperty("account_number")
    private String accountNumber;
}
