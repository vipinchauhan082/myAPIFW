package com.lbg.epscw.mortgagesrvc.validator;

import com.lbg.epscw.mortgagesrvc.dto.MortgageAccountData;
import com.lbg.epscw.mortgagesrvc.dto.MortgageAccountInfo;
import com.lbg.epscw.mortgagesrvc.exception.InvalidUpdateRequestException;
import com.lbg.epscw.mortgagesrvc.model.NominationRequest;
import com.lbg.epscw.mortgagesrvc.restclient.MortgageAccountInfoRestClient;
import org.springframework.stereotype.Component;

import java.util.Map;
import java.util.Optional;

import static com.lbg.epscw.mortgagesrvc.constants.CommonConstants.INVALID;
import static com.lbg.epscw.mortgagesrvc.constants.CommonConstants.PRODUCT_ID_LBG_MORTGAGE;
import static com.lbg.epscw.mortgagesrvc.constants.CommonConstants.VALUE;

@Component
public class NominationServiceValidator {

    private final MortgageAccountInfoRestClient mortgageAccountInfoRestClient;

    public NominationServiceValidator(MortgageAccountInfoRestClient mortgageAccountInfoRestClient) {
        this.mortgageAccountInfoRestClient = mortgageAccountInfoRestClient;
    }

    public void validateNominationRequest(NominationRequest nominationRequest, String accountId, Map<String, String> reqHeaders) {
        if(accountId.equalsIgnoreCase(nominationRequest.getNominatedAdhocOverpaymentAccount())) {
            throw new InvalidUpdateRequestException(VALUE, INVALID, "Nominated Account");
        }
        MortgageAccountInfo mortgageAccountInfo = mortgageAccountInfoRestClient.getMortgageAccountInfo(accountId, reqHeaders);
        if(isSubAccountPassedInPath(accountId, mortgageAccountInfo) ||
                !isNominatedAccountWithinMortgageRepaymentAccount(nominationRequest.getNominatedAdhocOverpaymentAccount(), mortgageAccountInfo)) {
            throw new InvalidUpdateRequestException(VALUE, INVALID, "Nominated Account");
        }
    }

    private boolean isSubAccountPassedInPath(String accountId, MortgageAccountInfo mortgageAccountInfo) {
        Optional<MortgageAccountData> mortgageAccountDataOptional = mortgageAccountInfo
                .getMortgageAccountData()
                .stream()
                .filter(mortgageAccountData -> accountId.equalsIgnoreCase(mortgageAccountData.getAccountId()))
                .findFirst();
        if(mortgageAccountDataOptional.isPresent()) {
            MortgageAccountData mortgageAccountData = mortgageAccountDataOptional.get();
            return PRODUCT_ID_LBG_MORTGAGE.equalsIgnoreCase(mortgageAccountData.getProductId());
        }
        return true;
    }

    private boolean isNominatedAccountWithinMortgageRepaymentAccount(String nominatedAccountId, MortgageAccountInfo mortgageAccountInfo) {
        return mortgageAccountInfo
                .getMortgageAccountData()
                .stream()
                .anyMatch(mortgageAccountData -> nominatedAccountId.equalsIgnoreCase(mortgageAccountData.getAccountId()));
    }
}
