package com.lbg.epscw.mortgagesrvc.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class VaultAccountNumberGenerationResponse {

    @JsonProperty("id")
    private String id;

    @JsonProperty("bank_id")
    private String sortCode;

    @JsonProperty("account_number")
    private String accountNumber;

    @JsonProperty("bank_id_code")
    private String bankIdCode;
}
