package com.lbg.epscw.mortgagesrvc.dto.comms;

public enum OverrideNotificationChannel {
    SMS, EMAIL, PAPER, PUSH
}
