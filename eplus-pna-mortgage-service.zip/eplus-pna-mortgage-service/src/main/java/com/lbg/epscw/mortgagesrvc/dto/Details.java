package com.lbg.epscw.mortgagesrvc.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Builder;
import lombok.Data;
import lombok.Getter;

@Data
@Builder
public class Details {

    @JsonProperty("brand")
    private String brand;

    @JsonProperty("plan_number")
    private String planNumber;
}
