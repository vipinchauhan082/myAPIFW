package com.lbg.epscw.mortgagesrvc.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
public class BankAccount {
    @JsonProperty("routing_address")
    private RoutingAddress routingAddress;
}
