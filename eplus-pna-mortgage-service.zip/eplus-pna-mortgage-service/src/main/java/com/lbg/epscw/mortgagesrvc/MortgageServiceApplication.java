package com.lbg.epscw.mortgagesrvc;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.lbg.epscw.mortgagesrvc.constants.CommonConstants;
import com.lbg.epscw.mortgagesrvc.handler.MortgageRestClientExceptionHandler;
import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Info;
import io.swagger.v3.oas.models.servers.Server;
import io.swagger.v3.oas.models.servers.ServerVariable;
import io.swagger.v3.oas.models.servers.ServerVariables;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.cloud.client.circuitbreaker.EnableCircuitBreaker;
import org.springframework.context.MessageSource;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.PropertySource;
import org.springframework.context.annotation.PropertySources;
import org.springframework.context.support.ReloadableResourceBundleMessageSource;
import org.springframework.core.env.Environment;
import org.springframework.retry.annotation.EnableRetry;
import org.springframework.util.ObjectUtils;
import org.springframework.validation.beanvalidation.LocalValidatorFactoryBean;
import org.springframework.web.client.ResponseErrorHandler;
import org.springframework.web.client.RestTemplate;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;


@SpringBootApplication(scanBasePackages = {"com.lbg.epscw"})
@EnableCircuitBreaker
@PropertySources(
        @PropertySource(value = {"classpath:application.properties"})
)
@EnableRetry
public class MortgageServiceApplication {

    @Autowired
    private Environment environment;

	public static void main(String[] args) {
        System.setProperty("flogger.backend_factory", "com.google.common.flogger.backend.slf4j.Slf4jBackendFactory#getInstance");
        SpringApplication.run(MortgageServiceApplication.class, args);
    }

    @Bean
    public OpenAPI mortgageServiceAPI(){

        OpenAPI openAPI = new OpenAPI();
        openAPI.info(new Info().title(environment.getProperty("openapiserver.title")).description(environment.getProperty("openapiserver.description")));

        Server localServer = new Server().url(environment.getProperty("openapiserver.local"))
                .variables(new ServerVariables().addServerVariable(CommonConstants.HOST_NAME,new ServerVariable()._default(environment.getProperty("openapiserver.local.default")))
                        .addServerVariable(CommonConstants.PORT,new ServerVariable()._default(environment.getProperty("openapiserver.local.port"))));

        Server nonprodServer = new Server().url(environment.getProperty("openapiserver.nonprod"))
                .variables(new ServerVariables().addServerVariable(CommonConstants.HOST_NAME,new ServerVariable()._default(environment.getProperty("openapiserver.nonprod.default"))));

        String serList = environment.getProperty("openapiserver.bld.serverlist");
        List<String> serverList = new ArrayList<>();
        if(!ObjectUtils.isEmpty(serList)){
            serverList = Arrays.asList(serList.split(","));
        }

        Server bldServer = new Server().url(environment.getProperty("openapiserver.bld"))
                .variables(new ServerVariables().addServerVariable(CommonConstants.HOST_NAME,new ServerVariable()._default(environment.getProperty("openapiserver.bld.default"))
                        ._enum(serverList)));

        List<Server> allServer = new ArrayList<>();
        allServer.add(localServer);
        allServer.add(nonprodServer);
        allServer.add(bldServer);

        openAPI.setServers(allServer);

        return openAPI;
    }

    @Bean
    public RestTemplate restTemplate() {
        return new RestTemplateBuilder()
                .errorHandler(mortgageRestClientExceptionHandler())
                .build();
    }

    @Bean
    public ResponseErrorHandler mortgageRestClientExceptionHandler() {
        return new MortgageRestClientExceptionHandler(new ObjectMapper());
    }

    @Bean
    public MessageSource messageSource() {
        ReloadableResourceBundleMessageSource messageSource  = new ReloadableResourceBundleMessageSource();
        messageSource.setBasename("classpath:ValidationMessages");
        messageSource.setDefaultEncoding("UTF-8");
        return messageSource;
    }

    @Bean
    public LocalValidatorFactoryBean getValidator() {
        LocalValidatorFactoryBean bean = new LocalValidatorFactoryBean();
        bean.setValidationMessageSource(messageSource());
        return bean;
    }
}
