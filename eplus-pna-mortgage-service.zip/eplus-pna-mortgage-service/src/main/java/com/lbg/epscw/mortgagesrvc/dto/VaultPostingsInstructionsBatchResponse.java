package com.lbg.epscw.mortgagesrvc.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class VaultPostingsInstructionsBatchResponse {

    @JsonProperty("id")
    private String id;

    @JsonProperty("create_timestamp")
    private String createEventTimestamp;

    @JsonProperty("done_timestamp")
    private String doneTimeStamp;

    @JsonProperty("done")
    private boolean done;
}
