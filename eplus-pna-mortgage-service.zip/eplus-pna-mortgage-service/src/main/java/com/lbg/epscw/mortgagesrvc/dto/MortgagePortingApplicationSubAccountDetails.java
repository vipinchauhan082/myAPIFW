package com.lbg.epscw.mortgagesrvc.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class MortgagePortingApplicationSubAccountDetails {

    @JsonProperty("LoanAmount")
    private String loanAmount;

    @JsonProperty("KeyDate")
    private String keyDate;

    @JsonProperty("DepositAccount")
    private String depositAccount;

    @JsonProperty("ProductId")
    private String productId;

    @JsonProperty("MortgageType")
    private String mortgageType;

    @JsonProperty("TotalTerm")
    private String totalTerm;

    @JsonProperty("InterestRate")
    private String interestRate;

    @JsonProperty("SubAccountType")
    private String subAccountType;

    @JsonProperty("SubAccountSeqId")
    private String subAccountSeqId;

}
