package com.lbg.epscw.mortgagesrvc.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;
import java.util.Map;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Account {

    @JsonProperty("product_id")
    private String productId;

    @JsonProperty("product_version_id")
    private String productVersionId;

    @JsonProperty("stakeholder_ids")
    private List<String> stakeholderId;

    @JsonProperty("instance_param_vals")
    private Map<String,String> instanceParam;

    @JsonProperty("details")
    private Map<String,String> details;

    @JsonProperty("status")
    private String status;

    @JsonProperty("permitted_denominations")
    private List<String> permittedDenomination;
}
