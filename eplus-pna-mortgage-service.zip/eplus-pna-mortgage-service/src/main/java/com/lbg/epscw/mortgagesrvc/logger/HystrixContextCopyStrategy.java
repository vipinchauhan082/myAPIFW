package com.lbg.epscw.mortgagesrvc.logger;

import com.netflix.hystrix.strategy.HystrixPlugins;
import com.netflix.hystrix.strategy.concurrency.HystrixConcurrencyStrategy;
import org.apache.logging.log4j.ThreadContext;
import org.springframework.stereotype.Component;

import java.util.Arrays;
import java.util.concurrent.Callable;


@Component
public class HystrixContextCopyStrategy extends HystrixConcurrencyStrategy {

    private static final String CORRELATION_ID_LOGGING = "correlation-id";

    private static final String BRAND_LOGGING = "brand";

    private static final String X_LOG_LEVEL = "X-Log-Level";

    public HystrixContextCopyStrategy() {
        HystrixPlugins.getInstance().registerConcurrencyStrategy(this);
    }

    @Override
    public <T> Callable<T> wrapCallable(Callable<T> callable) {

        return new CopyContext(callable, ThreadContext.get(CORRELATION_ID_LOGGING),
            ThreadContext.get(BRAND_LOGGING), ThreadContext.get(X_LOG_LEVEL));
    }

    public static class CopyContext<T> implements Callable<T> {

        private final Callable<T> actual;

        private final String correlationId;

        private final String brand;

        private final String logLevel;

        public CopyContext(Callable<T> callable, String correlationId, String brand,
            String logLevel) {
            this.actual = callable;
            this.correlationId = correlationId;
            this.brand = brand;
            this.logLevel = logLevel;
        }

        @Override
        public T call() throws Exception {
            ThreadContext.put(CORRELATION_ID_LOGGING, correlationId);
            ThreadContext.put(BRAND_LOGGING, brand);
            ThreadContext.put(X_LOG_LEVEL, logLevel);

            try {
                return actual.call();
            } finally {
                ThreadContext
                    .removeAll(Arrays.asList(CORRELATION_ID_LOGGING, BRAND_LOGGING, X_LOG_LEVEL));
            }
        }
    }
}
