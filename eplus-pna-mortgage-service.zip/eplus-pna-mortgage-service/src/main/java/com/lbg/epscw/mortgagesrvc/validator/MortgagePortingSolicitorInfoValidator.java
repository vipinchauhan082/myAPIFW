package com.lbg.epscw.mortgagesrvc.validator;

import com.lbg.epscw.mortgagesrvc.exception.MortgageValidationException;
import com.lbg.epscw.mortgagesrvc.model.MortgageApplicationInfo;
import com.lbg.epscw.mortgagesrvc.model.MortgagePortingApplicationStatus;
import com.lbg.epscw.mortgagesrvc.model.PortingUpdateSolicitorInfoRequest;
import lombok.extern.flogger.Flogger;
import org.springframework.stereotype.Component;

import java.util.Collection;

import static com.lbg.epscw.mortgagesrvc.constants.CommonConstants.INVALID_SORT_CODE_ACCOUNT_NUMBER;
import static com.lbg.epscw.mortgagesrvc.constants.CommonConstants.MORTGAGE_PORTING_APPLICATION;
import static com.lbg.epscw.mortgagesrvc.enums.SolicitorAccountSchema.SORT_CODE_ACCOUNT_NUMBER;
import static org.apache.commons.lang3.StringUtils.isBlank;

@Component
@Flogger
public class MortgagePortingSolicitorInfoValidator {
    private final MortgagePortingApplicationValidator stateValidator;

    public MortgagePortingSolicitorInfoValidator(MortgagePortingApplicationValidator stateValidator) {
        this.stateValidator = stateValidator;
    }

    public void validate(PortingUpdateSolicitorInfoRequest request, MortgageApplicationInfo applicationInfo, Collection<MortgagePortingApplicationStatus> statuses) {
        if (isBlank(request.getSchemaName())) {
            request.setSchemaName(SORT_CODE_ACCOUNT_NUMBER.name());
        }
        if (SORT_CODE_ACCOUNT_NUMBER.name().equalsIgnoreCase(request.getSchemaName()) && request.getIdentification().length() != 14) {
            throw new MortgageValidationException(MORTGAGE_PORTING_APPLICATION, INVALID_SORT_CODE_ACCOUNT_NUMBER);
        }

        stateValidator.validateCurrentState(applicationInfo, statuses);
    }
}
