package com.lbg.epscw.mortgagesrvc.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;
import org.springframework.util.ObjectUtils;

@Data
public class Arrear {

    @JsonProperty("Amount")
    private String amount;

    @JsonProperty("Interest")
    private String interest;

    public Arrear() {
    }

    public Arrear(String amount, String interest) {
        if (ObjectUtils.isEmpty(amount)) {
            this.amount = "0.00";
        } else {
            this.amount = amount;
        }
        if (ObjectUtils.isEmpty(interest)) {
            this.interest = "0.00";
        } else {
            this.interest = interest;
        }
    }

}
