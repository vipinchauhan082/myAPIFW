package com.lbg.epscw.mortgagesrvc.validator;

import com.lbg.epscw.mortgagesrvc.constants.CommonConstants;
import com.lbg.epscw.mortgagesrvc.dto.MortgageAccountData;
import com.lbg.epscw.mortgagesrvc.dto.MortgageAccountInfo;
import com.lbg.epscw.mortgagesrvc.exception.InvalidUpdateRequestException;
import com.lbg.epscw.mortgagesrvc.model.AccountStatus;
import com.lbg.epscw.mortgagesrvc.model.AccountStatusUpdateRequest;
import com.lbg.epscw.mortgagesrvc.restclient.MortgageAccountInfoRestClient;
import com.lbg.epscw.mortgagesrvc.service.MortgageAccountStatusStateMachine;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import java.util.Collection;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import static com.lbg.epscw.mortgagesrvc.constants.CommonConstants.MORTGAGE_PAYMENT_FAMILY;

@Component
public class MortgagePortingValidator {

    private MortgageAccountInfoRestClient mortgageAccountInfoRestClient;

    private MortgageAccountStatusStateMachine stateMachine;


    @Autowired
    public MortgagePortingValidator(MortgageAccountInfoRestClient mortgageAccountInfoRestClient, MortgageAccountStatusStateMachine stateMachine) {
        this.mortgageAccountInfoRestClient = mortgageAccountInfoRestClient;
        this.stateMachine = stateMachine;
    }


    /**
     * validates account status and throws exception
     * @param accountStatusUpdateRequest
     * @param headers
     * @return
     */
    public List<MortgageAccountData> validateAccountStatus(AccountStatusUpdateRequest accountStatusUpdateRequest, Map<String,String> headers){
        MortgageAccountInfo mortgageAccountInfo = mortgageAccountInfoRestClient.getMortgageAccountInfo(accountStatusUpdateRequest.getOverarchingAccount(),headers);

        List<MortgageAccountData> subAccountIds = getListOfAccountsToBeUpdated(accountStatusUpdateRequest, mortgageAccountInfo);

        // throws exception if all accounts are in same state
        if(subAccountIds.isEmpty()){
            throw new InvalidUpdateRequestException(CommonConstants.STATUS, CommonConstants.ALREADY_EXIST, accountStatusUpdateRequest.getAccountStatus().name());
        }
        // validate next state of account status
        validateAccountStatusNextState(subAccountIds, accountStatusUpdateRequest.getAccountStatus());
        return subAccountIds;

    }

    /**
     * validate next state of account status
     * @param subAccounts
     * @param status
     */
    public void validateAccountStatusNextState(List<MortgageAccountData> subAccounts, AccountStatus status){
        subAccounts.forEach(subAccount-> {
            Collection<AccountStatus> permittedStates = stateMachine.next(AccountStatus.valueOf(subAccount.getStatus()));
            if (!permittedStates.contains(status)) {
                throw new InvalidUpdateRequestException(CommonConstants.STATUS, CommonConstants.INVALID, subAccount.getAccountId(), subAccount.getStatus(), permittedStates);
            }
        });
    }

    /**
     * checks if all sub accounts are in same state.
     * @param mortgageAccountInfo
     * @param accountStatusUpdateRequest
     * @param subAccountIds
     * @return
     */
    public boolean allSubAccountInSameState(MortgageAccountInfo mortgageAccountInfo, AccountStatusUpdateRequest accountStatusUpdateRequest,
                                            List<MortgageAccountData> subAccountIds){
        return mortgageAccountInfo.getMortgageAccountData().size() == mortgageAccountInfo.getMortgageAccountData().stream().filter(account->account.getStatus()
                .equals(accountStatusUpdateRequest.getAccountStatus().name())).count()+ subAccountIds.size()+1;
    }

    /**
     * return list of accounts to be updated
     * @param accountStatusUpdateRequest
     * @param mortgageAccountInfo
     * @return
     */
    public List<MortgageAccountData> getListOfAccountsToBeUpdated(AccountStatusUpdateRequest accountStatusUpdateRequest, MortgageAccountInfo mortgageAccountInfo){
        List<MortgageAccountData> subAccountIds;
        // checks if request is either for overarching or all sub accounts in overarching
        if(CollectionUtils.isEmpty(accountStatusUpdateRequest.getSubAccountIds()) ||
                mortgageAccountInfo.getMortgageAccountData().size()== accountStatusUpdateRequest.getSubAccountIds().size()+1){
            //filtered account with already in same status as requested in request
            subAccountIds = mortgageAccountInfo.getMortgageAccountData().stream().filter(account->!account.getStatus().equals(accountStatusUpdateRequest.getAccountStatus().name()))
                    .sorted(Comparator.comparing(MortgageAccountData::getProductFamily)).collect(Collectors.toList());
        }
        // for only partial list of sub accounts in overarching
        else {
            subAccountIds = mortgageAccountInfo.getMortgageAccountData().stream().filter(account->!account.getStatus().equals(accountStatusUpdateRequest.getAccountStatus().name()))
                    .filter(account->accountStatusUpdateRequest.getSubAccountIds().contains(account.getAccountId())).collect(Collectors.toList());

            // checks if remaining sub accounts are also in same state to include overarching account with list of sub accounts
            if(allSubAccountInSameState(mortgageAccountInfo, accountStatusUpdateRequest, subAccountIds)){
                subAccountIds.addAll(mortgageAccountInfo.getMortgageAccountData().stream().filter(account->account.getProductFamily().equals(MORTGAGE_PAYMENT_FAMILY)).collect(Collectors.toList()));
            }
        }
        return subAccountIds;
    }
}
