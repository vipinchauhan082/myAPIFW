package com.lbg.epscw.mortgagesrvc.util;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.common.flogger.FluentLogger;
import com.google.common.flogger.StackSize;
import com.lbg.epscw.mortgagesrvc.dto.MortgageAccountData;
import com.lbg.epscw.mortgagesrvc.exception.MortgageServiceException;
import io.opencensus.trace.SpanBuilder;
import io.opencensus.trace.Tracing;
import io.opencensus.trace.samplers.Samplers;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.util.ObjectUtils;

import java.io.IOException;
import java.text.MessageFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.stream.IntStream;

import static com.lbg.epscw.mortgagesrvc.constants.CommonConstants.*;
import static java.text.MessageFormat.format;
import static java.util.UUID.randomUUID;


@Component
public class MortgageServiceUtil {

    private static final String LOG_PATTERN =
        "{0} with correlationId:{1}, brand:{2}, accountId:{3} ----->";

    private static final FluentLogger logger = FluentLogger.forEnclosingClass();

    @Value("${vault.access.token}")
    private String vaultAccessToken;

    private ObjectMapper mapper;


    @Autowired
    public MortgageServiceUtil(ObjectMapper mapper) {
        this.mapper = mapper;
    }

    /**
     * Method to read Object using ObjectMapper
     * @param value
     * @param clz
     * @return
     */
    public <T> T readObject(String value, Class<T> clz) {
        try {
            return mapper.readValue(value, clz);
        } catch (IOException exception) {
            logger.atSevere().withStackTrace(StackSize.MEDIUM).withCause(exception)
                .log(exception.getMessage());
            throw new MortgageServiceException(DESERIALIZE, ERROR, exception.getMessage());
        }
    }

    /**
     * Method to read Object using ObjectMapper
     * @param value
     * @param clz
     * @return
     */
    public <T> T readCollectionsObject(String value, TypeReference<T> clz) {
        try {
            return mapper.readValue(value, clz);
        } catch (IOException exception) {
            logger.atSevere().withStackTrace(StackSize.MEDIUM).withCause(exception)
                    .log(exception.getMessage());
            throw new MortgageServiceException(DESERIALIZE, ERROR, exception.getMessage());
        }
    }

    /**
     * Method to write Object as String using ObjectMapper
     * @param object
     * @return
     */
    public String writeObjectAsString(Object object) {
        try {
            return mapper.writeValueAsString(object);
        } catch (JsonProcessingException exception) {
            logger.atSevere().withStackTrace(StackSize.MEDIUM).withCause(exception)
                .log(exception.getMessage());
            throw new MortgageServiceException(DESERIALIZE, ERROR, exception.getMessage());
        }
    }

    /**
     * Method to search for a path within the value using ObjectMapper
     * @param value
     * @param path
     * @return
     */
    public String searchTree(String value, String path) {
        try {
            JsonNode root = mapper.readTree(value);
            return ObjectUtils.isEmpty(root.findValue(path)) ? "Expected field: {" + path + "} not found in Json: " + value:
                root.findValue(path).asText();
        } catch (IOException exception) {
            logger.atSevere().withStackTrace(StackSize.MEDIUM).withCause(exception)
                .log(exception.getMessage());
            throw new MortgageServiceException(DESERIALIZE, ERROR, exception.getMessage());
        }
    }

    /**
     * Method to read for a path within the value using ObjectMapper
     * @param value
     * @param path
     * @return
     */
    public String readTree(String value, String path) {
        try {
            JsonNode root = mapper.readTree(value);
            return root.path(path).toString();
        } catch (IOException exception) {
            logger.atSevere().withStackTrace(StackSize.MEDIUM).withCause(exception)
                .log(exception.getMessage());
            throw new MortgageServiceException(DESERIALIZE, ERROR, exception.getMessage());
        }
    }

    /**
     * Method to tracing build Span
     * @param name
     * @return
     */
    public SpanBuilder buildSpan(String name) {
        return Tracing.getTracer().spanBuilder(name).setRecordEvents(true)
            .setSampler(Samplers.alwaysSample());
    }

    /**
     * Method to get message based on key from .properties file
     * @param key
     * @param args
     * @return
     */
    public String getLocalizedMessage(String key, Object... args) {
        return format(
            ResourceBundle.getBundle("ValidationMessages", LocaleContextHolder.getLocale())
                .getString(key), args);
    }

    /**
     * Method to log entry-exit of another method
     * @param args
     */
    public void logMethodEntryExit(String... args) {
        logger.atInfo().log(MessageFormat.format(LOG_PATTERN, (Object) args));
    }

    /**
     * Method to fetch default Vault Headers
     * @return
     */
    public Map<String, String> fetchDefaultVaultHeaders() {
        Map<String, String> headers = new HashMap<>();
        headers.put(X_AUTH_TOKEN, vaultAccessToken);
        headers.put(CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE);
        return headers;
    }

    public int compareDate(String date1, String date2)  {
        SimpleDateFormat dateFormat = new SimpleDateFormat(DATE_FORMAT_ACCOUNT);
        int compare=0;
        try {
            compare= dateFormat.parse(date1).compareTo(dateFormat.parse(date2));
        } catch (ParseException e) {
            logger.atSevere().withStackTrace(StackSize.MEDIUM).withCause(e)
                    .log(e.getMessage());

        }

        return compare;
    }

    public String uuid() {
        return randomUUID().toString();
    }

    public <T> List<T> readList(String str, Class<T> type) {
        return readList(str, ArrayList.class, type);
    }

    public <T> List<T> readList(String str, Class<? extends Collection> type, Class<T> elementType) {
        try {
            return mapper.readValue(str, mapper.getTypeFactory().constructCollectionType(type, elementType));
        } catch (IOException e) {
            throw new MortgageServiceException(DESERIALIZE, ERROR, e.getMessage());
        }
    }

    public String getMaxSequenceNumber(List<MortgageAccountData> mortgageAccountData){
        return String.valueOf(mortgageAccountData.stream().flatMapToInt(acc-> IntStream.of(Integer.parseInt(acc.getSequenceId()))).max().orElse(0));
    }
    
}
