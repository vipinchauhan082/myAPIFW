package com.lbg.epscw.mortgagesrvc.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;
import java.util.Map;


@JsonIgnoreProperties(ignoreUnknown = true)
@Builder
@Data
@AllArgsConstructor
@NoArgsConstructor
public class AccountCreationResponse {

    @JsonProperty("id")
    private String internalAccountId;

    @JsonProperty("name")
    private String productName;

    @JsonProperty("product_id")
    private String productId;

    @JsonProperty("status")
    private String status;

    @JsonProperty("account_number")
    private String accountNumber;

    private String externalAccountId;

    private String bankIdCode;

    @JsonProperty("sort_code")
    private String sortCode;

    @JsonProperty("stakeholder_ids")
    private List<String> stakeholderId;

    @JsonProperty("instance_param_vals")
    private Map<Object, Object> instanceParamVals;

    @JsonProperty("details")
    private Map<String,String> details;

}
