package com.lbg.epscw.mortgagesrvc.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Builder;
import lombok.Data;

import java.util.Map;

@Data
@Builder
public class PostingsInstruction {

    @JsonProperty("client_transaction_id")
    private String clientTransactionId;

    @JsonProperty("instruction_details")
    private Map<String,String> instructionDetails;

    @JsonProperty("custom_instruction")
    private CustomInstruction customInstruction;
}
