package com.lbg.epscw.mortgagesrvc.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.Valid;
import javax.validation.constraints.NotEmpty;

@Builder
@Data
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
@Valid
public class SubAccountsSettlementAmount {

    @JsonProperty("AccountId")
    @NotEmpty(message = "AccountId")
    private String accountId;

    @JsonProperty("SettlementDailyInterest")
    @NotEmpty(message = "SettlementDailyInterest")
    private String settlementDailyInterest;

    @JsonProperty("AnticipatedInterest")
    @NotEmpty(message = "AnticipatedInterest")
    private String anticipatedInterest;

    @JsonProperty("SettlementAmount")
    @NotEmpty(message = "SettlementAmount")
    private String settlementAmount;

}
