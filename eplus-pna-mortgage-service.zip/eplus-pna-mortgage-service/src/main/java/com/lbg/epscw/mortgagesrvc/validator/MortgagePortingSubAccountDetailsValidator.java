package com.lbg.epscw.mortgagesrvc.validator;


import com.lbg.epscw.mortgagesrvc.dto.MortgageAccountData;
import com.lbg.epscw.mortgagesrvc.dto.MortgageAccountInfo;
import com.lbg.epscw.mortgagesrvc.exception.MortgageValidationException;
import com.lbg.epscw.mortgagesrvc.model.ApplicationMortgageDetails;
import com.lbg.epscw.mortgagesrvc.model.ApplicationMortgageDetailsUpdateRequest;
import com.lbg.epscw.mortgagesrvc.model.MortgageApplicationInfo;
import com.lbg.epscw.mortgagesrvc.model.MortgagePortingApplicationStatus;
import com.lbg.epscw.mortgagesrvc.restclient.MortgageAccountInfoRestClient;
import lombok.extern.flogger.Flogger;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.util.Arrays;
import java.util.Map;
import java.util.Optional;


import static com.lbg.epscw.mortgagesrvc.constants.CommonConstants.*;

@Component
@Flogger
public class MortgagePortingSubAccountDetailsValidator {

    private MortgageAccountInfoRestClient mortgageAccountInfoRestClient;


    public MortgagePortingSubAccountDetailsValidator(MortgageAccountInfoRestClient mortgageAccountInfoRestClient) {
        this.mortgageAccountInfoRestClient = mortgageAccountInfoRestClient;
    }

    public void validate(MortgageApplicationInfo mortgagePortingApplicationDetails , ApplicationMortgageDetailsUpdateRequest request, Map<String, String> reqHeaders){


        validateApplicationStatus(mortgagePortingApplicationDetails);

        validateLoanAmount(request);

        validateProductId(mortgagePortingApplicationDetails, request, reqHeaders);


    }

    private void validateProductId(MortgageApplicationInfo mortgagePortingApplicationDetails, ApplicationMortgageDetailsUpdateRequest request, Map<String, String> reqHeaders) {
        MortgageAccountInfo mortgageAccountInfoByMortgageNumber = mortgageAccountInfoRestClient.
                getMortgageInfoByMortgageNumber(mortgagePortingApplicationDetails.getPreviousMortgageNumber(), reqHeaders);

        Optional<MortgageAccountData> mortgageAccountData = mortgageAccountInfoByMortgageNumber.getMortgageAccountData().stream().
                filter(account -> account.getProductFamily().equals("Mortgage")).findAny();


        if (!mortgageAccountData.isPresent()) {
            String errorMsg = "Mortgage Details Not Found";
            log.atSevere().log(errorMsg);
            throw new MortgageValidationException(MORTGAGE_INFO, NOT_FOUND);
        }


        Optional<ApplicationMortgageDetails> mortgageDetailsOptional = request.getSubAccountDetails().stream().
                filter(subAccountDetails -> !subAccountDetails.getProductId().
                        equalsIgnoreCase(mortgageAccountData.get().getProductId())).findAny();

        if (mortgageDetailsOptional.isPresent()) {
            String errorMsg = "Invalid Product ID";
            log.atSevere().log(errorMsg);
            throw new MortgageValidationException(MORTGAGE_DETAILS_INFO, INVALID_PRODUCT_ID);
        }

    }

    /**
     * This method is for validating total borrowing amount value is less than the total principal loan amount
     * for the given accountId.
     * @param request
     */
    private void validateLoanAmount(ApplicationMortgageDetailsUpdateRequest request) {
        BigDecimal totalPrincipalAmount = request.getSubAccountDetails().stream().
                map(ApplicationMortgageDetails::getLoanAmount).map(BigDecimal::new).reduce(BigDecimal.ZERO, BigDecimal::add);


        if(new BigDecimal(request.getTotalBorrowingAmount()).compareTo((totalPrincipalAmount)) > 0){
            String errorMsg = "Invalid Borrowing Amount";
            log.atSevere().log(errorMsg);
            throw new MortgageValidationException(MORTGAGE_DETAILS_INFO, INVALID_BORROWING_AMOUNT);
        }
    }

    private void validateApplicationStatus(MortgageApplicationInfo mortgagePortingApplicationDetails) {
        if(!Arrays.asList(MortgagePortingApplicationStatus.OPEN.name(),MortgagePortingApplicationStatus.REOPEN.name()).
                contains( mortgagePortingApplicationDetails.getStatus().name())){
            String errorMsg = "Invalid Application Status";
            log.atSevere().log(errorMsg);
            throw new MortgageValidationException(MORTGAGE_DETAILS_INFO, INVALID_STATUS);

        }
    }
}
