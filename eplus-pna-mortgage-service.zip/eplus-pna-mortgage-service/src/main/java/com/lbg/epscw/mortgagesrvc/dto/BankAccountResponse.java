package com.lbg.epscw.mortgagesrvc.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class BankAccountResponse {
    @JsonProperty("id")
    private String id;

    @JsonProperty("routing_address")
    private RoutingAddress routingAddress;
}
