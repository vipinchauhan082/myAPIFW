package com.lbg.epscw.mortgagesrvc.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class VaultPostingsInstructionsBatchRequest {

    @JsonProperty("request_id")
    private String requestId;

    @JsonProperty("posting_instruction_batch")
    private PostingsInstructionsBatch postingsInstructionsBatch;
}
