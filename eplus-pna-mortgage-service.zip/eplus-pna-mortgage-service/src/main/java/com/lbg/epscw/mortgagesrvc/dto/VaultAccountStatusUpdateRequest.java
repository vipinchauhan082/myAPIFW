package com.lbg.epscw.mortgagesrvc.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
public class VaultAccountStatusUpdateRequest {

    @JsonProperty("request_id")
    private String requestId;

    @JsonProperty("account")
    private Account account;

    @JsonProperty("update_mask")
    private UpdatedMask updatedMask;
}
