package com.lbg.epscw.mortgagesrvc.validator;

import com.google.common.flogger.FluentLogger;
import com.google.common.flogger.StackSize;
import com.lbg.epscw.handler.exception.system.SystemBadRequestException;
import com.lbg.epscw.handler.exception.system.SystemNotFoundException;
import com.lbg.epscw.mortgagesrvc.dto.MortgageAccountData;
import com.lbg.epscw.mortgagesrvc.dto.MortgageAccountInfo;
import com.lbg.epscw.mortgagesrvc.enums.MortgageFamily;
import com.lbg.epscw.mortgagesrvc.exception.InvalidUpdateRequestException;
import com.lbg.epscw.mortgagesrvc.model.AccountOpenRequest;
import com.lbg.epscw.mortgagesrvc.model.BenefitsRequest;
import com.lbg.epscw.mortgagesrvc.restclient.MortgageAccountInfoRestClient;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.ObjectUtils;

import java.util.*;

import static com.lbg.epscw.mortgagesrvc.constants.CommonConstants.*;

@Component
public class MortgageSubAccountValidator {

    private static final FluentLogger logger = FluentLogger.forEnclosingClass();

    private final MortgageAccountInfoRestClient mortgageAccountInfoRestClient;

    @Autowired
    public MortgageSubAccountValidator(MortgageAccountInfoRestClient mortgageAccountInfoRestClient) {
        this.mortgageAccountInfoRestClient = mortgageAccountInfoRestClient;
    }


    /**
     * validates if account is eligible to close
     * @param accountOpenRequest
     */
    public void validateSubAccountOpening(AccountOpenRequest accountOpenRequest){
        String msg = "";

        if(accountOpenRequest.getProductFamily().equals(MortgageFamily.MORTGAGE)){
            msg = checkAttributes(accountOpenRequest);
        }

        if(!msg.isEmpty()){
            logger.atSevere().withStackTrace(StackSize.MEDIUM).log(NULL_OR_EMPTY+": "+msg);
            throw new SystemBadRequestException(VALUE, NULL_OR_EMPTY, "Empty attributes were:"+msg);
        }

    }

    private String checkAttributes(AccountOpenRequest accountOpenRequest){
        String msg = "";

        if(StringUtils.isEmpty(accountOpenRequest.getDepositAccount())){
            msg = msg.concat(DEPOSIT_ACCOUNT);
        }
        if(StringUtils.isEmpty(accountOpenRequest.getInterestRate())){
            msg = msg.concat(", "+INTEREST_RATE);
        }
        if(StringUtils.isEmpty(accountOpenRequest.getKeyDate())){
            msg = msg.concat(", "+KEY_DATE);
        }
        if(StringUtils.isEmpty(accountOpenRequest.getMortgageType())){
            msg = msg.concat(", "+KEY_MORTGAGE_TYPE);
        }
        if(StringUtils.isEmpty(accountOpenRequest.getMortgageCalculationPrincipal())){
            msg = msg.concat(", "+MORTGAGE_CALCULATION_PRINCIPAL);
        }
        if(StringUtils.isEmpty(accountOpenRequest.getTotalTerm())){
            msg = msg.concat(", "+PROPERTY_TOTAL_TERM);
        }
        if(null == accountOpenRequest.getStatus()){
            msg = msg.concat(", "+STATUS);
        }
        if(Objects.isNull(accountOpenRequest.getDetails()) || StringUtils.isEmpty(accountOpenRequest.getDetails().get(PLAN_NUMBER))){
            msg = msg.concat(", "+PLAN_NUMBER);
        }

        return msg;
    }


    /**
     * validates if account is an overarching account
     * if validated, returns list including all subaccount-ID
     * @param requestAccountId
     */
    public List<String> validateForOverarchingAccount(String requestAccountId, Map<String, String> reqHeaders){

        MortgageAccountInfo mortgageAccountDetails = mortgageAccountInfoRestClient.getMortgageAccountInfo(requestAccountId, reqHeaders);
        if(ObjectUtils.isEmpty(mortgageAccountDetails)){
            throw new SystemNotFoundException(MORTGAGE_INFO,NOT_FOUND);
        }

        Optional<MortgageAccountData> overarchingAccount = mortgageAccountDetails.getMortgageAccountData().stream().
                filter(x -> x.getProductFamily().equals(MortgageFamily.MORTGAGE_PAYMENT.toString())).findAny();
        if(overarchingAccount.isEmpty()){
            throw new InvalidUpdateRequestException(ACCOUNT_ID, REQUEST_INVALID);
        }

        ArrayList<String> accountIds = new ArrayList<>();
        mortgageAccountDetails.getMortgageAccountData().stream().filter(x -> !requestAccountId.equals(x.getAccountId())).
                forEach(s -> accountIds.add(s.getAccountId()));
        accountIds.add(requestAccountId);
        return accountIds;
    }

    public void validateBenefitRequest(BenefitsRequest request){
        if(request.getIsOnBenefits().equals("no"))
            request.setBenefitsSource("");//set Benefits-source to empty String => removes BenefitsSource param from vault-details (metadata)
        else if(null==request.getBenefitsSource())
            throw new InvalidUpdateRequestException(BENEFITS_SOURCE_REQUEST,REQUEST_INVALID);
    }

}
