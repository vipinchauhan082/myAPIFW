package com.lbg.epscw.mortgagesrvc.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class EligibilityFailureReason {

    @JsonProperty("code")
    private String code;

    @JsonProperty("message")
    private String message;

}
