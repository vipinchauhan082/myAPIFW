spockReports {
    set 'com.athaydes.spockframework.report.showCodeBlocks': false
    set 'com.athaydes.spockframework.report.outputDir': 'target/spock-reports'
}