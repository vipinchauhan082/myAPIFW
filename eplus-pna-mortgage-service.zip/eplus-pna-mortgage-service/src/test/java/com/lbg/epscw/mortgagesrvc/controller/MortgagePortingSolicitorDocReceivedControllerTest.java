package com.lbg.epscw.mortgagesrvc.controller;

import com.lbg.epscw.mortgagesrvc.exception.MortgageServiceException;
import com.lbg.epscw.mortgagesrvc.exception.MortgageValidationException;
import com.lbg.epscw.mortgagesrvc.model.PortingApplicationStatusResponse;
import com.lbg.epscw.mortgagesrvc.model.SolicitorDocReceivedRequest;
import com.lbg.epscw.mortgagesrvc.service.MortgagePortingApplicationInfoService;
import com.lbg.epscw.mortgagesrvc.service.MortgagePortingSolicitorDocReceivedService;
import com.lbg.epscw.mortgagesrvc.util.MortgageServiceUtil;
import com.lbg.epscw.mortgagesrvc.validator.MortgagePortingApplicationValidator;
import org.junit.Before;
import org.junit.Test;
import org.springframework.http.ResponseEntity;

import static com.lbg.epscw.mortgagesrvc.helper.MortgagePortingHelper.*;
import static com.lbg.epscw.mortgagesrvc.model.MortgagePortingApplicationStatus.SOLICITOR_DOC_RECEIVED;
import static io.opencensus.trace.Tracing.getTracer;
import static io.opencensus.trace.samplers.Samplers.alwaysSample;
import static java.time.LocalDate.now;
import static java.util.Collections.emptyMap;
import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.*;
import static org.springframework.http.HttpStatus.OK;

public class MortgagePortingSolicitorDocReceivedControllerTest {
    private MortgagePortingApplicationValidator validator;
    private MortgagePortingSolicitorDocReceivedService service;
    private MortgagePortingSolicitorDocReceivedController underTest;

    @Before
    public void setUp() {
        validator = mock(MortgagePortingApplicationValidator.class);
        MortgageServiceUtil utility = mock(MortgageServiceUtil.class);
        when(utility.buildSpan(anyString())).thenReturn(getTracer().spanBuilder("any").setSampler(alwaysSample()));
        MortgagePortingApplicationInfoService infoService = mock(MortgagePortingApplicationInfoService.class);
        service = mock(MortgagePortingSolicitorDocReceivedService.class);
        underTest = new MortgagePortingSolicitorDocReceivedController(validator, utility, infoService, service);
    }

    @Test
    public void check_solicitor_doc_received_returns_successful_response() {
        // Given
        when(service.solicitorDocReceived(any(), any())).thenReturn(PortingApplicationStatusResponse.builder().status(SOLICITOR_DOC_RECEIVED).applicationNumber(APPLICATION_NUMBER).build());
        // When
        SolicitorDocReceivedRequest request = SolicitorDocReceivedRequest.builder().completionDate(now()).titleDeedNumber(TITLE_DEED_NUMBER).build();
        ResponseEntity<PortingApplicationStatusResponse> responseEntity = underTest.solicitorDocReceived(BRAND, CHANNEL, CORRELATION_ID, JWT, INTERNAL_SYS_ID, emptyMap(), APPLICATION_NUMBER, request);
        // Then
        assertThat(responseEntity.getStatusCode(), is(OK));
        assertThat(responseEntity.getBody().getStatus(), is(SOLICITOR_DOC_RECEIVED));
        assertThat(responseEntity.getBody().getApplicationNumber(), is(APPLICATION_NUMBER));
    }

    @Test(expected = MortgageValidationException.class)
    public void verify_action_not_permitted() {
        //given
        doThrow(MortgageValidationException.class).when(validator).validateNextState(any(), any());
        //when
        SolicitorDocReceivedRequest request = SolicitorDocReceivedRequest.builder().completionDate(now()).titleDeedNumber(TITLE_DEED_NUMBER).build();
        underTest.solicitorDocReceived(BRAND, CHANNEL, CORRELATION_ID, JWT, INTERNAL_SYS_ID, emptyMap(), APPLICATION_NUMBER, request);
        //then expect exception
    }

    @Test(expected = MortgageServiceException.class)
    public void service_fails_to_update_application() {
        //given
        doThrow(MortgageServiceException.class).when(service).solicitorDocReceived(any(), any());
        //when
        SolicitorDocReceivedRequest request = SolicitorDocReceivedRequest.builder().completionDate(now()).titleDeedNumber(TITLE_DEED_NUMBER).build();
        underTest.solicitorDocReceived(BRAND, CHANNEL, CORRELATION_ID, JWT, INTERNAL_SYS_ID, emptyMap(), APPLICATION_NUMBER, request);
        //then expect exception
    }

}