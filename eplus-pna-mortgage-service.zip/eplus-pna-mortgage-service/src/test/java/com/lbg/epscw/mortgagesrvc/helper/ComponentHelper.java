package com.lbg.epscw.mortgagesrvc.helper;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.mock.web.MockHttpServletResponse;


public class ComponentHelper {

    private ObjectMapper mapper = new ObjectMapper();

    public String writeValueAsString(Object obj) {
        try {
            return mapper.writeValueAsString(obj);
        } catch (Exception ex) {
            throw new RuntimeException(ex.getMessage());
        }
    }

    public String getServletResponseAsString(MockHttpServletResponse servletResponse) {
        try {
            return servletResponse.getContentAsString();
        } catch (Exception ex) {
            throw new RuntimeException(ex.getMessage());
        }
    }
}


