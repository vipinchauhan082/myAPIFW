package com.lbg.epscw.mortgagesrvc.controller;

import com.lbg.epscw.mortgagesrvc.model.FulfilmentDecisionRequest;
import com.lbg.epscw.mortgagesrvc.model.PortingApplicationStatusResponse;
import com.lbg.epscw.mortgagesrvc.service.MortgagePortingApplicationInfoService;
import com.lbg.epscw.mortgagesrvc.service.MortgagePortingFulfilmentService;
import com.lbg.epscw.mortgagesrvc.util.MortgageServiceUtil;
import com.lbg.epscw.mortgagesrvc.validator.MortgagePortingApplicationValidator;
import org.junit.Before;
import org.junit.Test;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.util.Collections;

import static com.lbg.epscw.mortgagesrvc.helper.MortgagePortingHelper.*;
import static com.lbg.epscw.mortgagesrvc.helper.MortgagePortingHelper.INTERNAL_SYS_ID;
import static com.lbg.epscw.mortgagesrvc.model.MortgagePortingApplicationStatus.FUNDS_RELEASED;
import static com.lbg.epscw.mortgagesrvc.model.MortgagePortingApplicationStatus.OFFERED;
import static io.opencensus.trace.Tracing.getTracer;
import static io.opencensus.trace.samplers.Samplers.alwaysSample;
import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;


public class MortgagePortingFulfilmentDecisionControllerTest {

    private MortgagePortingApplicationValidator validator;
    private MortgagePortingFulfilmentService service;
    private MortgagePortingFulfilmentDecisionController underTest;

    @Before
    public void setUp() throws Exception {
        validator = mock(MortgagePortingApplicationValidator.class);
        MortgageServiceUtil utility = mock(MortgageServiceUtil.class);
        when(utility.buildSpan(anyString())).thenReturn(getTracer().spanBuilder("any").setSampler(alwaysSample()));
        MortgagePortingApplicationInfoService infoService = mock(MortgagePortingApplicationInfoService.class);
        service = mock(MortgagePortingFulfilmentService.class);
        underTest = new MortgagePortingFulfilmentDecisionController(validator, utility, service, infoService);

    }

    @Test
    public void check_lending_decision_returns_successful_response(){
        // Given
        when(service.fulfilApplication(anyString(),any())).thenReturn(PortingApplicationStatusResponse.builder().status(OFFERED).applicationNumber("1234").build());
        // When
        FulfilmentDecisionRequest request = FulfilmentDecisionRequest.builder().action(OFFERED.name()).iddReviewed(true).kfiReviewed(true).build();
        ResponseEntity<PortingApplicationStatusResponse> responseEntity = underTest.fulfilmentDecision(BRAND, CHANNEL, CORRELATION_ID, JWT, INTERNAL_SYS_ID, ACCOUNT_ID, request, Collections.emptyMap());
        // Then
        assertThat(responseEntity.getStatusCode(), is(HttpStatus.OK));
        assertThat(responseEntity.getBody().getStatus(), is(OFFERED));
        assertThat(responseEntity.getBody().getApplicationNumber(), is("1234"));
    }

    @Test(expected = IllegalArgumentException.class)
    public void check_lending_decision_throws_error_when_invalid_action(){
        doThrow(IllegalArgumentException.class).when(validator).validateNextState(any(), any());

        FulfilmentDecisionRequest request = FulfilmentDecisionRequest.builder().action(FUNDS_RELEASED.name()).iddReviewed(true).kfiReviewed(true).build();
        underTest.fulfilmentDecision(BRAND, CHANNEL, CORRELATION_ID, JWT, INTERNAL_SYS_ID, ACCOUNT_ID, request, Collections.emptyMap());

    }
}