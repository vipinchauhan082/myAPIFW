package com.lbg.epscw.mortgagesrvc.service;

import com.lbg.epscw.mortgagesrvc.exception.CircuitBreakerOpenException;
import com.lbg.epscw.mortgagesrvc.exception.MortgageServiceException;
import com.lbg.epscw.mortgagesrvc.model.MortgageApplicationInfo;
import com.lbg.epscw.mortgagesrvc.model.PortingApplicationStatusResponse;
import com.lbg.epscw.mortgagesrvc.restclient.MortgagePortingApplicationInfoRestClient;
import org.junit.Before;
import org.junit.Test;

import static com.lbg.epscw.mortgagesrvc.helper.MortgagePortingHelper.APPLICATION_NUMBER;
import static com.lbg.epscw.mortgagesrvc.model.MortgagePortingApplicationStatus.*;
import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

public class MortgagePortingWelcomePackServiceImplTest {
    private MortgagePortingApplicationInfoRestClient applicationClient;
    private MortgagePortingWelcomePackServiceImpl underTest;

    @Before
    public void setup() {
        applicationClient = mock(MortgagePortingApplicationInfoRestClient.class);
        underTest = new MortgagePortingWelcomePackServiceImpl(applicationClient);
    }

    @Test
    public void update_application_status_success(){
        // Given
        MortgageApplicationInfo expected = MortgageApplicationInfo.builder().status(WELCOME_PACK_RECEIVED).build();
        when(applicationClient.getApplicationInfo(any())).thenReturn(expected);
        when(applicationClient.updateApplication(anyString(), any())).thenReturn(expected);

        // When
        PortingApplicationStatusResponse actual = underTest.applicationWelcomePackReceived(APPLICATION_NUMBER, MortgageApplicationInfo.builder().applicationNumber("1234").status(APPROVED).build());

        // Then
        assertThat(actual, is(PortingApplicationStatusResponse.builder().applicationNumber(APPLICATION_NUMBER).status(WELCOME_PACK_RECEIVED).build()));
    }

    @Test(expected = MortgageServiceException.class)
    public void update_application_status_fails_when_application_status_does_not_match(){
        // Given
        when(applicationClient.getApplicationInfo(any())).thenReturn(MortgageApplicationInfo.builder().status(WELCOME_PACK_RECEIVED).build());
        when(applicationClient.updateApplication(anyString(), any())).thenReturn(MortgageApplicationInfo.builder().status(OPEN).build());
        // When
        underTest.applicationWelcomePackReceived(APPLICATION_NUMBER, MortgageApplicationInfo.builder().applicationNumber("1234").status(APPROVED).build());
    }

    @Test(expected = CircuitBreakerOpenException.class)
    public void update_status_fallback_throws_exception_on_broken_circuit() {
        underTest.fallbackApplicationWelcomePackReceived(APPLICATION_NUMBER, new MortgageApplicationInfo(), new IllegalArgumentException());
    }
}
