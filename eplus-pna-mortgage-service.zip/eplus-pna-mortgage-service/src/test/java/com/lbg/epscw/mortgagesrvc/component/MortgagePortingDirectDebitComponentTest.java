package com.lbg.epscw.mortgagesrvc.component;


import com.lbg.epscw.entitlement.service.EntitlementValidationServiceImpl;
import com.lbg.epscw.handler.model.ErrorInfo;
import com.lbg.epscw.mortgagesrvc.helper.ComponentHelper;
import com.lbg.epscw.mortgagesrvc.helper.MortgagePortingHelper;
import com.lbg.epscw.mortgagesrvc.logger.HystrixContextCopyStrategy;
import com.lbg.epscw.mortgagesrvc.model.MortgageApplicationInfo;
import com.lbg.epscw.mortgagesrvc.model.PortingApplicationStatusResponse;
import com.lbg.epscw.mortgagesrvc.service.MortgagePortingApplicationInfoService;
import com.lbg.epscw.mortgagesrvc.service.MortgagePortingDirectDebitService;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpHeaders;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import static com.google.api.client.http.HttpStatusCodes.*;
import static com.lbg.epscw.mortgagesrvc.helper.MortgagePortingHelper.APPLICATION_NUMBER;
import static com.lbg.epscw.mortgagesrvc.helper.MortgagePortingHelper.DIRECT_DEBIT_ENDPOINT;
import static com.lbg.epscw.mortgagesrvc.model.MortgagePortingApplicationStatus.DECLINED;
import static com.lbg.epscw.mortgagesrvc.model.MortgagePortingApplicationStatus.OPEN;
import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.anyString;
import static org.mockito.Mockito.when;


@Tag("component")
@ExtendWith(SpringExtension.class)
@SpringBootTest
@AutoConfigureMockMvc
public class MortgagePortingDirectDebitComponentTest extends WebMVCTest {
    private final MortgagePortingHelper portingHelper = new MortgagePortingHelper();
    private final ComponentHelper componentHelper = new ComponentHelper();

    @MockBean
    private EntitlementValidationServiceImpl entitlement;
    @MockBean
    private HystrixContextCopyStrategy hystrixContextCopyStrategy;
    @MockBean
    private MortgagePortingDirectDebitService service;
    @MockBean
    private MortgagePortingApplicationInfoService mortgagePortingApplicationInfoService;

    @Test
    public void verify_direct_debit_details_has_updated() {
        //given
        String payload = portingHelper.directDebitPayload();
        HttpHeaders headers = portingHelper.getAccountInfoHeaders();
        when(mortgagePortingApplicationInfoService.getApplicationInfo(anyString())).thenReturn(MortgageApplicationInfo.builder().status(OPEN).build());
        PortingApplicationStatusResponse expected = PortingApplicationStatusResponse.builder().applicationNumber(APPLICATION_NUMBER).status(OPEN).build();
        when(service.updateDirectDebitDetails(any(), any())).thenReturn(expected);
        //when
        MockHttpServletResponse response = doPUT(DIRECT_DEBIT_ENDPOINT, payload, headers);
        String responseString = componentHelper.getServletResponseAsString(response);
        PortingApplicationStatusResponse actual = readObject(responseString, PortingApplicationStatusResponse.class);
        //then
        assertThat(response.getStatus(), is(STATUS_CODE_OK));
        assertThat(actual.getApplicationNumber(), is(APPLICATION_NUMBER));
    }

    @Test
    public void assertThatInvalidStatusThrowsError() {
        //given
        when(mortgagePortingApplicationInfoService.getApplicationInfo(anyString())).thenReturn(MortgageApplicationInfo.builder().status(DECLINED).build());
        //when
        String payload = portingHelper.directDebitPayload();
        HttpHeaders headers = portingHelper.getAccountInfoHeaders();
        MockHttpServletResponse response = doPUT(DIRECT_DEBIT_ENDPOINT, payload, headers);
        ErrorInfo error = readErrorInfo(componentHelper.getServletResponseAsString(response));
        //then
        assertThat(response.getStatus(), is(STATUS_CODE_BAD_REQUEST));
        assertEquals("PNA.MORTGAGE_API.PUT_MORTGAGES_APPLICATION_DIRECT_DEBIT.MortgagePortingApplication.InvalidStatus", error.getReasonCode());
        assertEquals("Invalid Data", error.getMessage());

    }

    @Test
    public void return_error_when_application_id_is_invalid() {
        //given
        String payload = portingHelper.directDebitPayload();
        //when
        MockHttpServletResponse response = doPUT("/mortgages/application/invalid/direct-debit", payload, portingHelper.getAccountInfoHeaders());
        ErrorInfo error = readErrorInfo(componentHelper.getServletResponseAsString(response));
        //then
        assertThat(response.getStatus(), is(STATUS_CODE_BAD_REQUEST));
        assertEquals("PNA.MORTGAGE_API.PUT_MORTGAGES_APPLICATION_DIRECT_DEBIT.Param.Invalid", error.getReasonCode());
        assertEquals("Invalid application ID", error.getMessage());
    }

    @Test
    public void return_error_when_application_status_not_available() {
        //given
        when(mortgagePortingApplicationInfoService.getApplicationInfo(anyString())).thenReturn(null);
        //when
        String payload = portingHelper.directDebitPayload();
        HttpHeaders headers = portingHelper.getAccountInfoHeaders();
        MockHttpServletResponse response = doPUT(DIRECT_DEBIT_ENDPOINT, payload, headers);
        ErrorInfo error = readErrorInfo(componentHelper.getServletResponseAsString(response));
        //then
        assertThat(response.getStatus(), is(STATUS_CODE_SERVER_ERROR));
        assertEquals("PNA.MORTGAGE_API.PUT_MORTGAGES_APPLICATION_DIRECT_DEBIT.MortgagePortingApplication.NotFound", error.getReasonCode());
        assertEquals("Invalid Data", error.getMessage());
    }

    @Test
    public void return_error_response_when_schemeName_is_different() {
        //when
        String payload = portingHelper.directDebitPayloadSchemeNameNotExpected("SC");
        HttpHeaders headers = portingHelper.getAccountInfoHeaders();
        MockHttpServletResponse response = doPUT(DIRECT_DEBIT_ENDPOINT, payload, headers);
        ErrorInfo error = readErrorInfo(componentHelper.getServletResponseAsString(response));
        //then
        assertEquals(STATUS_CODE_BAD_REQUEST, response.getStatus());
        assertEquals("PNA.MORTGAGE_API.PUT_MORTGAGES_APPLICATION_DIRECT_DEBIT.Argument.Invalid", error.getReasonCode());
        assertEquals("SchemeName is not a valid. Must be either SortCodeAccountNumber,IBAN,PAN", error.getMessage());
    }

    @Test
    public void throws_exception_when_correlationId_is_missing() {
        //given
        HttpHeaders headers = portingHelper.getAccountInfoHeaders();
        headers.remove("x-lbg-txn-correlation-id");

        // when
        String payload = portingHelper.directDebitPayload();
        MockHttpServletResponse response = doPUT(DIRECT_DEBIT_ENDPOINT, payload, headers);
        ErrorInfo error = readErrorInfo(componentHelper.getServletResponseAsString(response));

        // then
        assertEquals(STATUS_CODE_BAD_REQUEST, response.getStatus());
        assertEquals("PNA.MORTGAGE_API.PUT_MORTGAGES_APPLICATION_DIRECT_DEBIT.Header.Missing.x-lbg-txn-correlation-id", error.getReasonCode());
        assertEquals("Missing request header x-lbg-txn-correlation-id for method parameter of type String", error.getMessage());
    }

    @Test
    public void throws_exception_when_brand_is_missing() {
        //given
        HttpHeaders headers = portingHelper.getAccountInfoHeaders();
        headers.remove("x-lbg-brand");

        // when
        String payload = portingHelper.directDebitPayload();
        MockHttpServletResponse response = doPUT(DIRECT_DEBIT_ENDPOINT, payload, headers);
        ErrorInfo error = readErrorInfo(componentHelper.getServletResponseAsString(response));

        // then
        assertEquals(STATUS_CODE_BAD_REQUEST, response.getStatus());
        assertEquals("PNA.MORTGAGE_API.PUT_MORTGAGES_APPLICATION_DIRECT_DEBIT.Header.Missing.x-lbg-brand", error.getReasonCode());
        assertEquals("Missing request header 'x-lbg-brand' for method parameter of type String", error.getMessage());
    }

    @Test
    public void throws_exception_when_channel_is_missing() {
        //given
        HttpHeaders headers = portingHelper.getAccountInfoHeaders();
        headers.remove("x-lbg-channel");

        // when
        String payload = portingHelper.directDebitPayload();
        MockHttpServletResponse response = doPUT(DIRECT_DEBIT_ENDPOINT, payload, headers);
        ErrorInfo error = readErrorInfo(componentHelper.getServletResponseAsString(response));

        // then
        assertEquals(STATUS_CODE_BAD_REQUEST, response.getStatus());
        assertEquals("PNA.MORTGAGE_API.PUT_MORTGAGES_APPLICATION_DIRECT_DEBIT.Header.Missing.x-lbg-channel", error.getReasonCode());
        assertEquals("Missing request header 'x-lbg-channel' for method parameter of type String", error.getMessage());
    }

    @Test
    public void throws_exception_when_brand_name_is_invalid() {
        //given
        HttpHeaders headers = portingHelper.getAccountInfoHeaders();
        headers.set("x-lbg-brand", "invalid");

        // when
        String payload = portingHelper.directDebitPayload();
        MockHttpServletResponse response = doPUT(DIRECT_DEBIT_ENDPOINT, payload, headers);
        ErrorInfo error = readErrorInfo(componentHelper.getServletResponseAsString(response));

        // then
        assertEquals(STATUS_CODE_BAD_REQUEST, response.getStatus());
        assertEquals("PNA.MORTGAGE_API.PUT_MORTGAGES_APPLICATION_DIRECT_DEBIT.Header.Invalid", error.getReasonCode());
        assertEquals("Invalid enum value for type x-lbg-brand", error.getMessage());
    }
}
