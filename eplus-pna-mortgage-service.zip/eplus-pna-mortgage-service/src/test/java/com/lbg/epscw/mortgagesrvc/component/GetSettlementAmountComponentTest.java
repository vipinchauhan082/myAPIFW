package com.lbg.epscw.mortgagesrvc.component;

import com.lbg.epscw.entitlement.service.EntitlementValidationServiceImpl;
import com.lbg.epscw.handler.model.ErrorInfo;
import com.lbg.epscw.handler.model.ErrorResponse;
import com.lbg.epscw.mortgagesrvc.dto.SettlementAmount;
import com.lbg.epscw.mortgagesrvc.dto.SettlementAmountInfo;
import com.lbg.epscw.mortgagesrvc.helper.ComponentHelper;
import com.lbg.epscw.mortgagesrvc.helper.MortgageRedemptionHelper;
import com.lbg.epscw.mortgagesrvc.logger.HystrixContextCopyStrategy;
import com.lbg.epscw.mortgagesrvc.model.MortgageSettlementAmountResponse;
import com.lbg.epscw.mortgagesrvc.restclient.MortgageSettlementAmountRestClient;
import com.lbg.epscw.mortgagesrvc.service.RestClientService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mockito;
import org.mockito.internal.util.MockUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.context.ApplicationContext;
import org.springframework.http.HttpHeaders;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.anyMap;
import static org.mockito.ArgumentMatchers.anyString;
import static org.powermock.api.mockito.PowerMockito.when;

@Tag("component")
@ExtendWith(SpringExtension.class)
@SpringBootTest
@AutoConfigureMockMvc
public class GetSettlementAmountComponentTest extends WebMVCTest {

    private static final String GET_SETTLEMENT_AMOUNT =
            "/mortgages/649270b9-e728-71bf-e6d9-1a3577b6a567/settlement-amount?redemptionDate=2021-03-02";

    @MockBean
    RestClientService restClientService;

    @MockBean
    private MortgageSettlementAmountRestClient mortgageSettlementAmountRestClient;

    @MockBean
    private HystrixContextCopyStrategy hystrixContextCopyStrategy;

    @MockBean
    private EntitlementValidationServiceImpl entitlementValidationService;

    @Autowired
    private ApplicationContext context;

    private ComponentHelper componentHelper = new ComponentHelper();

    private MortgageRedemptionHelper mortgageRedemptionHelper = new MortgageRedemptionHelper();

    @BeforeEach
    public void setup() {

        for (String name : context.getBeanDefinitionNames()) {
            Object bean = context.getBean(name);
            if (MockUtil.isMock(bean)) {
                Mockito.reset(bean);
            }
        }
    }

    @Test
    public void get_settlement_amount(){

        SettlementAmountInfo settlementAmountInfo = mortgageRedemptionHelper.settlementAmountInfoResponse();
        when(mortgageSettlementAmountRestClient.getSettlementAmountInfo(anyString(),anyString(),anyMap()))
                .thenReturn(settlementAmountInfo);

        MockHttpServletResponse servletResponse =
                doGET(GET_SETTLEMENT_AMOUNT, mortgageRedemptionHelper.getSettlementAmountHeaders());
        String responseString = componentHelper.getServletResponseAsString(servletResponse);

        MortgageSettlementAmountResponse settlementAmountResponse =
                readObject(responseString, MortgageSettlementAmountResponse.class);

        SettlementAmount settlementAmount = settlementAmountInfo.getSettlementAmount();

        assertEquals("1b69ad2f-63b3-c70f-6f52-ee85b97e314d",settlementAmount.getAggregatedSettlementAmountInfo().getAccountId());
        assertEquals("4.00",settlementAmount.getAggregatedSettlementAmountInfo().getTotalSettlementAmount());
        assertEquals("0.00",settlementAmount.getAggregatedSettlementAmountInfo().getTotalSettlementDailyInterest());
        assertEquals("GBP", settlementAmount.getCurrency());

    }

    @Test
    public void get_settlement_amount_throws_exception_when_correlationId_is_missing(){

        SettlementAmountInfo settlementAmountInfo = mortgageRedemptionHelper.settlementAmountInfoResponse();
        when(mortgageSettlementAmountRestClient.getSettlementAmountInfo(anyString(),anyString(),anyMap()))
                .thenReturn(settlementAmountInfo);

        HttpHeaders settlementHeaders = mortgageRedemptionHelper.getSettlementAmountHeaders();
        settlementHeaders.remove("x-lbg-txn-correlation-id");

        MockHttpServletResponse servletResponse =
                doGET(GET_SETTLEMENT_AMOUNT,settlementHeaders );
        String responseString = componentHelper.getServletResponseAsString(servletResponse);

        MortgageSettlementAmountResponse settlementAmountResponse =
                readObject(responseString, MortgageSettlementAmountResponse.class);

        ErrorResponse errorResponse = (ErrorResponse) readObject(responseString, ErrorResponse.class);
        ErrorInfo error = errorResponse.getErrors().get(0);

        assertEquals(400, servletResponse.getStatus());
        assertEquals("PNA.MORTGAGE_API.GET_MORTGAGES_SETTLEMENT_AMOUNT.Header.Missing.x-lbg-txn-correlation-id", error.getReasonCode());
        assertEquals(
                "Missing request header x-lbg-txn-correlation-id for method parameter of type String",
                error.getMessage());

    }


    @Test
    public void get_settlement_amount_throws_exception_when_brand_is_missing(){

        SettlementAmountInfo settlementAmountInfo = mortgageRedemptionHelper.settlementAmountInfoResponse();
        when(mortgageSettlementAmountRestClient.getSettlementAmountInfo(anyString(),anyString(),anyMap()))
                .thenReturn(settlementAmountInfo);

        HttpHeaders settlementHeaders = mortgageRedemptionHelper.getSettlementAmountHeaders();
        settlementHeaders.remove("x-lbg-brand");

        MockHttpServletResponse servletResponse =
                doGET(GET_SETTLEMENT_AMOUNT,settlementHeaders );
        String responseString = componentHelper.getServletResponseAsString(servletResponse);

        MortgageSettlementAmountResponse settlementAmountResponse =
                readObject(responseString, MortgageSettlementAmountResponse.class);

        ErrorResponse errorResponse = (ErrorResponse) readObject(responseString, ErrorResponse.class);
        ErrorInfo error = errorResponse.getErrors().get(0);

        assertEquals(400, servletResponse.getStatus());
        assertEquals("PNA.MORTGAGE_API.GET_MORTGAGES_SETTLEMENT_AMOUNT.Header.Missing.x-lbg-brand", error.getReasonCode());
        assertEquals(
                "Missing request header 'x-lbg-brand' for method parameter of type String",
                error.getMessage());

    }

    @Test
    public void get_settlement_amount_throws_exception_when_brand_is_invalid(){

        SettlementAmountInfo settlementAmountInfo = mortgageRedemptionHelper.settlementAmountInfoResponse();
        when(mortgageSettlementAmountRestClient.getSettlementAmountInfo(anyString(),anyString(),anyMap()))
                .thenReturn(settlementAmountInfo);

        HttpHeaders settlementHeaders = mortgageRedemptionHelper.getSettlementAmountHeaders();
        settlementHeaders.set("x-lbg-brand","dummy");

        MockHttpServletResponse servletResponse =
                doGET(GET_SETTLEMENT_AMOUNT,settlementHeaders );
        String responseString = componentHelper.getServletResponseAsString(servletResponse);

        MortgageSettlementAmountResponse settlementAmountResponse =
                readObject(responseString, MortgageSettlementAmountResponse.class);

        ErrorResponse errorResponse = (ErrorResponse) readObject(responseString, ErrorResponse.class);
        ErrorInfo error = errorResponse.getErrors().get(0);

        assertEquals(400, servletResponse.getStatus());
        assertEquals("PNA.MORTGAGE_API.GET_MORTGAGES_SETTLEMENT_AMOUNT.Header.Invalid", error.getReasonCode());
        assertEquals(
                "Invalid enum value for type x-lbg-brand",
                error.getMessage());

    }

    @Test
    public void get_settlement_amount_throws_exception_when_redemtion_date_si_more_than_10char(){

        SettlementAmountInfo settlementAmountInfo = mortgageRedemptionHelper.settlementAmountInfoResponse();
        when(mortgageSettlementAmountRestClient.getSettlementAmountInfo(anyString(),anyString(),anyMap()))
                .thenReturn(settlementAmountInfo);

        HttpHeaders settlementHeaders = mortgageRedemptionHelper.getSettlementAmountHeaders();

        MockHttpServletResponse servletResponse =
                doGET("/mortgages/649270b9-e728-71bf-e6d9-1a3577b6a567/settlement-amount?redemptionDate=1212-1212-1212",settlementHeaders );
        String responseString = componentHelper.getServletResponseAsString(servletResponse);

        MortgageSettlementAmountResponse settlementAmountResponse =
                readObject(responseString, MortgageSettlementAmountResponse.class);

        ErrorResponse errorResponse = (ErrorResponse) readObject(responseString, ErrorResponse.class);
        ErrorInfo error = errorResponse.getErrors().get(0);

        assertEquals(400, servletResponse.getStatus());
        assertEquals("PNA.MORTGAGE_API.GET_MORTGAGES_SETTLEMENT_AMOUNT.RequestParam.Invalid", error.getReasonCode());
        assertEquals(
                "redemptionDate should be max 10 characters",
                error.getMessage());

    }

    @Test
    public void get_settlement_amount_throws_exception_when_redemption_date_missing(){

        SettlementAmountInfo settlementAmountInfo = mortgageRedemptionHelper.settlementAmountInfoResponse();
        when(mortgageSettlementAmountRestClient.getSettlementAmountInfo(anyString(),anyString(),anyMap()))
                .thenReturn(settlementAmountInfo);

        HttpHeaders settlementHeaders = mortgageRedemptionHelper.getSettlementAmountHeaders();

        MockHttpServletResponse servletResponse =
                doGET("/mortgages/649270b9-e728-71bf-e6d9-1a3577b6a567/settlement-amount",settlementHeaders );
        String responseString = componentHelper.getServletResponseAsString(servletResponse);

        MortgageSettlementAmountResponse settlementAmountResponse =
                readObject(responseString, MortgageSettlementAmountResponse.class);

        ErrorResponse errorResponse = (ErrorResponse) readObject(responseString, ErrorResponse.class);
        ErrorInfo error = errorResponse.getErrors().get(0);

        assertEquals(400, servletResponse.getStatus());
        assertEquals("PNA.MORTGAGE_API.GET_MORTGAGES_SETTLEMENT_AMOUNT.RequestParam.Missing", error.getReasonCode());
        assertEquals(
                "Please select a date",
                error.getMessage());

    }



}
