package com.lbg.epscw.mortgagesrvc.component;

import com.lbg.epscw.entitlement.service.EntitlementValidationServiceImpl;
import com.lbg.epscw.handler.model.ErrorInfo;
import com.lbg.epscw.handler.model.ErrorResponse;
import com.lbg.epscw.mortgagesrvc.enums.RepaymentType;
import com.lbg.epscw.mortgagesrvc.helper.ComponentHelper;
import com.lbg.epscw.mortgagesrvc.helper.MortgageAccountDataHelper;
import com.lbg.epscw.mortgagesrvc.helper.MortgageAccountOptionDataHelper;
import com.lbg.epscw.mortgagesrvc.logger.HystrixContextCopyStrategy;
import com.lbg.epscw.mortgagesrvc.model.AccountOptionsUpdateRequest;
import com.lbg.epscw.mortgagesrvc.model.AccountOptionsUpdateResponse;
import com.lbg.epscw.mortgagesrvc.model.MortgageOptionsUpdateResponse;
import com.lbg.epscw.mortgagesrvc.model.VaultAccountOptionsUpdateRequest;
import com.lbg.epscw.mortgagesrvc.restclient.MortgageAccountInfoRestClient;
import com.lbg.epscw.mortgagesrvc.restclient.MortgageAccountOptionRestClient;
import com.lbg.epscw.mortgagesrvc.service.RestClientService;
import org.apache.commons.lang.RandomStringUtils;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.powermock.api.mockito.PowerMockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.context.ApplicationContext;
import org.springframework.http.HttpHeaders;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.test.context.junit.jupiter.SpringExtension;


import java.util.Map;

import static com.lbg.epscw.mortgagesrvc.constants.CommonConstants.KEY_MORTGAGE_TYPE;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.when;


@Tag("component")
@ExtendWith(SpringExtension.class)
@SpringBootTest
@AutoConfigureMockMvc
public class MortgageAccountOptionsUpdateComponentTest extends WebMVCTest {

    private static final String UPDATE_ACCOUNT_OPTIONS =
            "/mortgages/f76ca840-2553-d536-1ab8-9fa85c99db05/account-options";


    @MockBean
    RestClientService restClientService;

    @MockBean
    private HystrixContextCopyStrategy hystrixContextCopyStrategy;


    @MockBean
    private MortgageAccountOptionRestClient mortgageAccountOptionRestClient;

    @MockBean
    private MortgageAccountInfoRestClient mortgageAccountInfoRestClient;

    @MockBean
    private EntitlementValidationServiceImpl entitlementValidationService;

    @Autowired
    private ApplicationContext context;

    private ComponentHelper componentHelper = new ComponentHelper();

    private MortgageAccountOptionDataHelper mortgageAccountOptionDataHelper = new MortgageAccountOptionDataHelper();
    private MortgageAccountDataHelper mortgageAccountDataHelper = new MortgageAccountDataHelper();


    @Test
    public void update_account_options() {
        //given

        AccountOptionsUpdateResponse accountOptionsUpdateResponse = mortgageAccountOptionDataHelper.buildAccountOptionsUpdateResponse( KEY_MORTGAGE_TYPE,
                RepaymentType.CAPITAL_REPAYMENT.name());
        accountOptionsUpdateResponse.getInstanceParamValsUpdate().getInstanceParamVals().put("mortgage_calculation_principal","1000");
        PowerMockito.when(mortgageAccountOptionRestClient.updateAccountOptions(any(VaultAccountOptionsUpdateRequest.class))).thenReturn(accountOptionsUpdateResponse);

        PowerMockito.when(mortgageAccountInfoRestClient.getMortgageAccountInfo(any(String.class), any(Map.class))).thenReturn(mortgageAccountDataHelper.buildViewAccountInfo());

        AccountOptionsUpdateRequest accountUpdateReq =  mortgageAccountOptionDataHelper.buildAccountOptionsUpdateRequeste();



        String payload =
                componentHelper.writeValueAsString(accountUpdateReq);

        // when
        MockHttpServletResponse servletResponse = doPUT(UPDATE_ACCOUNT_OPTIONS, payload,
                mortgageAccountOptionDataHelper.getAccountInfoHeaders());
        String responseString = componentHelper.getServletResponseAsString(servletResponse);
        MortgageOptionsUpdateResponse viewAccountOptions =
                readObject(responseString, MortgageOptionsUpdateResponse.class);
        Map<String, String> accountOptions = viewAccountOptions.getInstanceParamVals();

        //then
        assertEquals("1601d0e5-e336-64d9-64ad-89ba6fdc2677", viewAccountOptions.getAccountId());
        assertEquals("ACCOUNT_UPDATE_STATUS_PENDING_EXECUTION", viewAccountOptions.getStatus());
        assertEquals("1000", accountOptions.get("LoanAmount"));
        assertEquals("CAPITAL_REPAYMENT", accountOptions.get("RepaymentType"));

    }


    @Test
    public void update_account_options_throws_exception_if_vault_throw_exception() {
        //given
        PowerMockito.when(mortgageAccountOptionRestClient.updateAccountOptions(any(VaultAccountOptionsUpdateRequest.class))).thenReturn(null);

        doThrow(new RuntimeException("Internal Server Error")).when(mortgageAccountOptionRestClient).
                updateAccountOptions(any(VaultAccountOptionsUpdateRequest.class));

        AccountOptionsUpdateRequest accountUpdateReq =  mortgageAccountOptionDataHelper.buildAccountOptionsUpdateRequeste();
        PowerMockito.when(mortgageAccountInfoRestClient.getMortgageAccountInfo(any(String.class), any(Map.class))).thenReturn(mortgageAccountDataHelper.buildViewAccountInfo());



        String payload =
                componentHelper.writeValueAsString(accountUpdateReq);

        // when
        MockHttpServletResponse servletResponse = doPUT(UPDATE_ACCOUNT_OPTIONS, payload,
                mortgageAccountOptionDataHelper.getAccountInfoHeaders());
        String responseString = componentHelper.getServletResponseAsString(servletResponse);
        ErrorResponse errorResponse = readObject(responseString, ErrorResponse.class);
        ErrorInfo error = errorResponse.getErrors().get(0);

        // then
        assertEquals(500, servletResponse.getStatus());
        assertEquals("PNA.MORTGAGE_API.PUT_MORTGAGES_ACCOUNT_OPTIONS.Runtime.Error", error.getReasonCode());
        assertEquals("Internal Server Error", error.getMessage());
    }


    @Test
    public void update_account_options_fails_on_invalid_brand_value() {
        AccountOptionsUpdateRequest accountUpdateReq =  mortgageAccountOptionDataHelper.buildAccountOptionsUpdateRequeste();
        String payload =
                componentHelper.writeValueAsString(accountUpdateReq);
        HttpHeaders httpHeaders = mortgageAccountOptionDataHelper.getAccountInfoHeaders();
        httpHeaders.set("x-lbg-brand", "xxx");

        // when
        MockHttpServletResponse servletResponse =
                doPUT(UPDATE_ACCOUNT_OPTIONS, payload, httpHeaders);
        String responseString = componentHelper.getServletResponseAsString(servletResponse);
        ErrorResponse errorResponse = readObject(responseString, ErrorResponse.class);
        ErrorInfo errorInfo = errorResponse.getErrors().get(0);

        // then
        assertEquals(400, servletResponse.getStatus());
        assertEquals("PNA.MORTGAGE_API.PUT_MORTGAGES_ACCOUNT_OPTIONS.Header.Invalid", errorInfo.getReasonCode());
        assertEquals("Invalid enum value for type x-lbg-brand", errorInfo.getMessage());
    }

    @Test
    public void update_account_options_fails_on_invalid_correlation_min_size() {
        AccountOptionsUpdateRequest accountUpdateReq =  mortgageAccountOptionDataHelper.buildAccountOptionsUpdateRequeste();
        String payload =
                componentHelper.writeValueAsString(accountUpdateReq);
        HttpHeaders httpHeaders = mortgageAccountOptionDataHelper.getAccountInfoHeaders();
        httpHeaders.set("x-lbg-txn-correlation-id", "xxx");

        // when
        MockHttpServletResponse servletResponse =
                doPUT(UPDATE_ACCOUNT_OPTIONS, payload, httpHeaders);
        String responseString = componentHelper.getServletResponseAsString(servletResponse);
        ErrorResponse errorResponse = (ErrorResponse) readObject(responseString, ErrorResponse.class);
        ErrorInfo errorInfo = errorResponse.getErrors().get(0);

        // then
        assertEquals(400, servletResponse.getStatus());
        assertEquals("PNA.MORTGAGE_API.PUT_MORTGAGES_ACCOUNT_OPTIONS.Header.Invalid", errorInfo.getReasonCode());
        assertEquals("x-lbg-txn-correlation-id size should be between 10 and 40", errorInfo.getMessage());
    }


    @Test
    public void update_account_options_fails_on_invalid_correlation_max_size() {
        AccountOptionsUpdateRequest accountUpdateReq =  mortgageAccountOptionDataHelper.buildAccountOptionsUpdateRequeste();
        String payload =
                componentHelper.writeValueAsString(accountUpdateReq);
        HttpHeaders httpHeaders = mortgageAccountOptionDataHelper.getAccountInfoHeaders();
        httpHeaders.set("x-lbg-txn-correlation-id", RandomStringUtils.random(50, "xxx"));

        // when
        MockHttpServletResponse servletResponse =
                doPUT(UPDATE_ACCOUNT_OPTIONS, payload, httpHeaders);
        String responseString = componentHelper.getServletResponseAsString(servletResponse);
        ErrorResponse errorResponse = (ErrorResponse) readObject(responseString, ErrorResponse.class);
        ErrorInfo errorInfo = errorResponse.getErrors().get(0);

        // then
        assertEquals(400, servletResponse.getStatus());
        assertEquals("PNA.MORTGAGE_API.PUT_MORTGAGES_ACCOUNT_OPTIONS.Header.Invalid", errorInfo.getReasonCode());
        assertEquals("x-lbg-txn-correlation-id size should be between 10 and 40", errorInfo.getMessage());
    }

    @Test
    public void update_account_options_fails_on_accountId_min_size() {
        String payload =
                componentHelper.writeValueAsString(mortgageAccountOptionDataHelper.buildAccountOptionsUpdateRequeste());

        // when
        MockHttpServletResponse servletResponse = doPUT("/mortgages/f76/account-options", payload,
                mortgageAccountOptionDataHelper.getAccountInfoHeaders());
        String responseString = componentHelper.getServletResponseAsString(servletResponse);
        ErrorResponse errorResponse =  readObject(responseString, ErrorResponse.class);
        ErrorInfo errorInfo = errorResponse.getErrors().get(0);

        // then
        assertEquals(400, servletResponse.getStatus());
        assertEquals("PNA.MORTGAGE_API.PUT_MORTGAGES_ACCOUNT_OPTIONS.Param.Invalid", errorInfo.getReasonCode());
        assertEquals("AccountId should be min 36 characters", errorInfo.getMessage());
    }

    @Test
    public void update_account_options_fails_on_accountId_max_size() {
        String payload =
                componentHelper.writeValueAsString(mortgageAccountOptionDataHelper.buildAccountOptionsUpdateRequeste());

        // when
        MockHttpServletResponse servletResponse =
                doPUT("/mortgages/" + RandomStringUtils.random(50, "xxx") + "/account-options", payload,
                        mortgageAccountOptionDataHelper.getAccountInfoHeaders());
        String responseString = componentHelper.getServletResponseAsString(servletResponse);
        ErrorResponse errorResponse = (ErrorResponse) readObject(responseString, ErrorResponse.class);
        ErrorInfo errorInfo = errorResponse.getErrors().get(0);

        // then
        assertEquals(400, servletResponse.getStatus());
        assertEquals("PNA.MORTGAGE_API.PUT_MORTGAGES_ACCOUNT_OPTIONS.Param.Invalid", errorInfo.getReasonCode());
        assertEquals("AccountId should be max 36 characters", errorInfo.getMessage());
    }
}
