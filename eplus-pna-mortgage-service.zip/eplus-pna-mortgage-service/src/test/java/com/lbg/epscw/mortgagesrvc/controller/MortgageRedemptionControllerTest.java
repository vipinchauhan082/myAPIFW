package com.lbg.epscw.mortgagesrvc.controller;

import com.lbg.epscw.mortgagesrvc.model.RedemptionStatementPayloadRequest;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit4.SpringRunner;

import static com.lbg.epscw.mortgagesrvc.helper.MortgagePortingHelper.*;
import static com.lbg.epscw.mortgagesrvc.helper.MortgageRedemptionHelper.REDEMPTION_DATE;
import static java.util.Collections.emptyMap;
import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.when;
import static org.springframework.http.ResponseEntity.ok;
import com.lbg.epscw.mortgagesrvc.dto.RedemptionStatementResponse;
import com.lbg.epscw.mortgagesrvc.helper.MortgageRedemptionHelper;
import com.lbg.epscw.mortgagesrvc.service.MortgageRedemptionService;
import com.lbg.epscw.mortgagesrvc.util.MortgageServiceUtil;
import com.lbg.epscw.mortgagesrvc.validator.MortgageRedemptionValidator;
import lombok.extern.flogger.Flogger;
import com.lbg.epscw.mortgagesrvc.model.MortgageSettlementAmountResponse;
import com.lbg.epscw.mortgagesrvc.service.MortgageSettlementAmountService;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpStatus;

import static org.junit.Assert.assertEquals;
import javax.validation.ConstraintViolationException;
import java.util.HashMap;


import static org.mockito.ArgumentMatchers.any;



@Flogger
@RunWith(SpringRunner.class)
@WebMvcTest(controllers = {MortgageServiceUtil.class, MortgageRedemptionController.class})
public class MortgageRedemptionControllerTest {


    private final MortgageRedemptionHelper mortgageRedemptionHelper = new MortgageRedemptionHelper();

    @MockBean
    private MortgageSettlementAmountService mortgageSettlementAmountService;

    @Autowired
    private MortgageServiceUtil mortgageServiceUtil;

    @MockBean
    private MortgageRedemptionValidator mortgageRedemptionValidator;

    @MockBean
    private MortgageRedemptionService mortgageRedemptionService;

    @Autowired
    private MortgageRedemptionController mortgageRedemptionController;

    private final static String ACCOUNT_ID = "144a38f3-a7b3-a3aa-d656-ff98fbaaa565";


    public MortgageRedemptionControllerTest() {

    }

    @Test
    public void shoudReturnSucess(){

        when(mortgageRedemptionValidator.validateGenerateRedemptionStatement(any(), any())).thenReturn(mortgageRedemptionHelper.mock_mortgageAccountData(ACCOUNT_ID));
        when(mortgageRedemptionService.sendRedemptionStatement(any(),any(),any(),any())).thenReturn(RedemptionStatementResponse.builder().message("Successful!").build());
        ResponseEntity<RedemptionStatementResponse> reponse = mortgageRedemptionController.generateAndSendRedemptionStatementData(
                "IF", "asjdksajdkajdskjsadkajskjasa", "123-456-789-12", null, new HashMap<String, String>(),
                mortgageRedemptionHelper.getRedemptionStatementRequest(),
                ACCOUNT_ID
        );

        assertEquals(HttpStatus.OK,reponse.getStatusCode());
    }


    @Test(expected = ConstraintViolationException.class)
    public void shouldThrowExceptionWhenAccountIdLengthIsSmall() {
        //when
        mortgageRedemptionController.generateAndSendRedemptionStatementData(
                "IF", "asjdksajdkajdskjsadkajskjasa", "123-456-789-12", null, new HashMap<String, String>(),
                mortgageRedemptionHelper.getRedemptionStatementRequest(),
                ACCOUNT_ID.substring(5)
        );
    }

    @Test(expected = ConstraintViolationException.class)
    public void shouldThrowExceptionWhenAccountIdLengthIsLong() {
        //when
        mortgageRedemptionController.generateAndSendRedemptionStatementData(
                "IF", "asjdksajdkajdskjsadkajskjasa", "123-456-789-12", null, new HashMap<String, String>(),
                mortgageRedemptionHelper.getRedemptionStatementRequest(),
                ACCOUNT_ID.concat("123")
        );
    }

    @Test(expected = ConstraintViolationException.class)
    public void shouldThrowExceptionWhenAccountIdIsEmpty() {
        //when
        mortgageRedemptionController.generateAndSendRedemptionStatementData(
                "IF", "asjdksajdkajdskjsadkajskjasa", "123-456-789-12", null, new HashMap<String, String>(),
                mortgageRedemptionHelper.getRedemptionStatementRequest(),
                ""
        );
    }

    @Test(expected = ConstraintViolationException.class)
    public void shouldThrowExceptionWhenAccountIdIsNull() {
        //when
        mortgageRedemptionController.generateAndSendRedemptionStatementData(
                "IF", "asjdksajdkajdskjsadkajskjasa", "123-456-789-12", null, new HashMap<String, String>(),
                mortgageRedemptionHelper.getRedemptionStatementRequest(),
                null
        );
    }

    @Test(expected = ConstraintViolationException.class)
    public void shouldThrowExceptionWhenBrandHeaderIsNull() {
        //when
        mortgageRedemptionController.generateAndSendRedemptionStatementData(
                null, "asjdksajdkajdskjsadkajskjasa", "123-456-789-12", null, new HashMap<String, String>(),
                mortgageRedemptionHelper.getRedemptionStatementRequest(),
                ACCOUNT_ID
        );
    }

    @Test(expected = ConstraintViolationException.class)
    public void shouldThrowExceptionWhenRecipientIsNull() {
        //Given
        RedemptionStatementPayloadRequest rspr= mortgageRedemptionHelper.getRedemptionStatementRequest();
        rspr.setRecipient(null);

        //when
        mortgageRedemptionController.generateAndSendRedemptionStatementData(
                null, "asjdksajdkajdskjsadkajskjasa", "123-456-789-12", null, new HashMap<String, String>(),
                rspr,
                ACCOUNT_ID
        );
    }


    @Test(expected = ConstraintViolationException.class)
    public void shouldThrowExceptionWhenBrandHeaderIsInvalid() {
        //when
        mortgageRedemptionController.generateAndSendRedemptionStatementData(
                "IFF", "asjdksajdkajdskjsadkajskjasa", "123-456-789-12", null, new HashMap<String, String>(),
                mortgageRedemptionHelper.getRedemptionStatementRequest(),
                ACCOUNT_ID
        );
    }

    @Test(expected = ConstraintViolationException.class)
    public void shouldThrowExceptionWhenCorrelationIdIsNull() {
        //when
        mortgageRedemptionController.generateAndSendRedemptionStatementData(
                "IF", null, "123-456-789-12", null, new HashMap<String, String>(),
                mortgageRedemptionHelper.getRedemptionStatementRequest(),
                ACCOUNT_ID
        );
    }

    @Test(expected = ConstraintViolationException.class)
    public void shouldThrowExceptionWhenCorrelationIdIsEmpty() {
        //when
        mortgageRedemptionController.generateAndSendRedemptionStatementData(
                "IF", "", "123-456-789-12", null, new HashMap<String, String>(),
                mortgageRedemptionHelper.getRedemptionStatementRequest(),
                ACCOUNT_ID
        );
    }

    @Test(expected = ConstraintViolationException.class)
    public void shouldThrowExceptionWhenCorrelationIdIsSmall() {
        //when
        mortgageRedemptionController.generateAndSendRedemptionStatementData(
                "IF", "asj", "123-456-789-12", null, new HashMap<String, String>(),
                mortgageRedemptionHelper.getRedemptionStatementRequest(),
                ACCOUNT_ID
        );
    }

    @Test(expected = ConstraintViolationException.class)
    public void shouldThrowExceptionWhenCorrelationIdIsLong() {
        //when
        mortgageRedemptionController.generateAndSendRedemptionStatementData(
                "IF", "aabcdenvkjrnrvrnkvnrekjvnrekvnrkvnrkvnkrevnkjrevnrevkrnvkvn", "123-456-789-12", null, new HashMap<String, String>(),
                mortgageRedemptionHelper.getRedemptionStatementRequest(),
                ACCOUNT_ID
        );
    }

    @Test
    public void get_settlement_amount(){

        MortgageSettlementAmountResponse mortgageSettlementAmountResponse = mortgageRedemptionHelper.settlementAmountResponse();

        when(mortgageSettlementAmountService.getSettlementAmount(any(), anyString(), anyMap()))
                .thenReturn(mortgageSettlementAmountResponse);

        ResponseEntity<MortgageSettlementAmountResponse> response = mortgageRedemptionController.getSettlementAmount(BRAND, CHANNEL, CORRELATION_ID, JWT, INTERNAL_SYS_ID, emptyMap(),REDEMPTION_DATE ,ACCOUNT_ID);

        assertThat(response, is(ok(mortgageSettlementAmountResponse)));
    }

}
