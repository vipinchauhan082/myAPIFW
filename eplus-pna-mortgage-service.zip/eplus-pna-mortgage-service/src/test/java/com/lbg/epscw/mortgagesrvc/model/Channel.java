package com.lbg.epscw.mortgagesrvc.model;

public enum Channel {
    DIGITAL, TELEPHONE
}
