package com.lbg.epscw.mortgagesrvc.service;

import com.lbg.epscw.mortgagesrvc.dto.*;
import com.lbg.epscw.mortgagesrvc.exception.CircuitBreakerOpenException;
import com.lbg.epscw.mortgagesrvc.exception.MortgageServiceException;
import com.lbg.epscw.mortgagesrvc.helper.AccountCreationHelper;
import com.lbg.epscw.mortgagesrvc.helper.MortgageArrearsCapitalizeHelper;
import com.lbg.epscw.mortgagesrvc.model.AccountOpenRequest;
import com.lbg.epscw.mortgagesrvc.model.AccountStatus;
import com.lbg.epscw.mortgagesrvc.model.OverarchingAccountInfo;
import com.lbg.epscw.mortgagesrvc.restclient.MortgageAccountOpenRestClient;
import com.lbg.epscw.mortgagesrvc.restclient.MortgageVaultPostingRestClient;
import com.lbg.epscw.mortgagesrvc.util.MortgageServiceUtil;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.List;

import static org.junit.Assert.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyMap;
import static org.powermock.api.mockito.PowerMockito.when;

@RunWith(SpringRunner.class)
public class MortgageArrearsCapitalizeServiceImplTest {

    @Mock
    private MortgageAccountOpenRestClient mortgageAccountOpenRestClient;

    @Mock
    private MortgageVaultPostingRestClient mortgageVaultPostingRestClient;

    @Mock
    private MortgageServiceUtil mortgageServiceUtil;

    @InjectMocks
    MortgageArrearsCapitalizeServiceImpl mortgageArrearsCapitalizeServiceImpl ;


    @Test
    public void mortgageArrearsCapitalizationConsiderSubAccountWithLongTermIFPrimaryAccountIsClosed(){
        List<MortgageAccountData> mortgageSubAccountData = AccountCreationHelper.getMortgageSubAccountData();
        mortgageSubAccountData.get(0).setStatus(AccountStatus.ACCOUNT_STATUS_CLOSED.name());

        ArgumentCaptor<AccountOpenRequest> captor = ArgumentCaptor.forClass(AccountOpenRequest.class);

        when(mortgageServiceUtil.getMaxSequenceNumber(any())).thenReturn("3");

        when(mortgageAccountOpenRestClient.createMortgageAccount(captor.capture(),anyMap())).thenReturn(new AccountCreationResponse());

        mortgageArrearsCapitalizeServiceImpl.createNewSubAccount(mortgageSubAccountData,new OverarchingAccountInfo(),AccountCreationHelper.generateRequiredHeaders());

        assertEquals("10",captor.getValue().getTotalTerm());

    }


    @Test
    public void mortgageArrearsCapitalizationConsiderPrimaySubAccountWhileCloning(){
        List<MortgageAccountData> mortgageSubAccountData = AccountCreationHelper.getMortgageSubAccountData();


        ArgumentCaptor<AccountOpenRequest> captor = ArgumentCaptor.forClass(AccountOpenRequest.class);

        when(mortgageServiceUtil.getMaxSequenceNumber(any())).thenReturn("3");

        when(mortgageAccountOpenRestClient.createMortgageAccount(captor.capture(),anyMap())).thenReturn(new AccountCreationResponse());

        mortgageArrearsCapitalizeServiceImpl.createNewSubAccount(mortgageSubAccountData,new OverarchingAccountInfo(),AccountCreationHelper.generateRequiredHeaders());

        assertEquals("10",captor.getValue().getTotalTerm());
        assertEquals("lbg_mortgage",captor.getValue().getProductId());

    }


    @Test(expected = MortgageServiceException.class)
    public void mortgageArrearsCapitalizationShouldResultInExceptionIfSubAccountAPIFails(){
        List<MortgageAccountData> mortgageSubAccountData = AccountCreationHelper.getMortgageSubAccountData();


        ArgumentCaptor<AccountOpenRequest> captor = ArgumentCaptor.forClass(AccountOpenRequest.class);

        when(mortgageServiceUtil.getMaxSequenceNumber(any())).thenReturn("3");

        when(mortgageAccountOpenRestClient.createMortgageAccount(captor.capture(),anyMap())).thenThrow(new RuntimeException("Server error"));

        mortgageArrearsCapitalizeServiceImpl.createNewSubAccount(mortgageSubAccountData,new OverarchingAccountInfo(),AccountCreationHelper.generateRequiredHeaders());



    }

    @Test(expected = MortgageServiceException.class)
    public void mortgageArrearsCapitalizationShouldResultInExceptionIfPostingArrearsFails(){
        List<MortgageAccountData> mortgageSubAccountData = AccountCreationHelper.getMortgageSubAccountData();
        OverarchingAccountInfo overarchingAccountInfo = new OverarchingAccountInfo();
        overarchingAccountInfo.setAccountId("456");
        overarchingAccountInfo.setArrearsBalance("25.4");
        overarchingAccountInfo.setStakeholderId("989");


        ArgumentCaptor<VaultPostingsInstructionsBatchRequest> captor = ArgumentCaptor.forClass(VaultPostingsInstructionsBatchRequest.class);

        when(mortgageVaultPostingRestClient.postingsInstructionsBatch(captor.capture())).thenThrow(new RuntimeException("Server error"));

        mortgageArrearsCapitalizeServiceImpl.postingArrearsToSubAccount("123",overarchingAccountInfo,AccountCreationHelper.generateRequiredHeaders());



    }

    @Test
    public void mortgageArrearsCapitalizationShouldSuccessfullyPostArrearsToNewSubAccount(){
        List<MortgageAccountData> mortgageSubAccountData = AccountCreationHelper.getMortgageSubAccountData();
        OverarchingAccountInfo overarchingAccountInfo = new OverarchingAccountInfo();
        overarchingAccountInfo.setAccountId("456");
        overarchingAccountInfo.setArrearsBalance("25.4");
        overarchingAccountInfo.setStakeholderId("989");


        ArgumentCaptor<VaultPostingsInstructionsBatchRequest> captor = ArgumentCaptor.forClass(VaultPostingsInstructionsBatchRequest.class);

        when(mortgageVaultPostingRestClient.postingsInstructionsBatch(captor.capture())).thenReturn(VaultPostingsInstructionsBatchResponse.builder().id("666").createEventTimestamp("2020-09-11").build());
        String clientBatchId = mortgageArrearsCapitalizeServiceImpl.postingArrearsToSubAccount("123",overarchingAccountInfo, AccountCreationHelper.generateRequiredHeaders());

        assertNotNull(clientBatchId);


    }

    @Test
    public void mortgageArrearsCapitalizationShouldSuccessfullyCreateAndPostArrearsToNewSubAccount(){
        List<MortgageAccountData> mortgageSubAccountData = AccountCreationHelper.getMortgageSubAccountData();
        OverarchingAccountInfo overarchingAccountInfo = new OverarchingAccountInfo();
        overarchingAccountInfo.setAccountId("456");
        overarchingAccountInfo.setArrearsBalance("25.4");
        overarchingAccountInfo.setStakeholderId("989");


        ArgumentCaptor<AccountOpenRequest> captor = ArgumentCaptor.forClass(AccountOpenRequest.class);

        when(mortgageServiceUtil.getMaxSequenceNumber(any())).thenReturn("3");

        when(mortgageAccountOpenRestClient.createMortgageAccount(captor.capture(),anyMap())).thenReturn(new AccountCreationResponse());

        ArgumentCaptor<VaultPostingsInstructionsBatchRequest> captorPostingArrear = ArgumentCaptor.forClass(VaultPostingsInstructionsBatchRequest.class);

        when(mortgageVaultPostingRestClient.postingsInstructionsBatch(captorPostingArrear.capture())).thenReturn(VaultPostingsInstructionsBatchResponse.builder().id("666").createEventTimestamp("2020-09-11").build());
        CapitalizeArrearsResponse capitalizeArrearsResponse = mortgageArrearsCapitalizeServiceImpl.mortgageArrearsCapitalization(mortgageSubAccountData,overarchingAccountInfo, MortgageArrearsCapitalizeHelper
        .generateHttpHeaders().toSingleValueMap());

        assertNotNull(capitalizeArrearsResponse);


    }




    @Test(expected = CircuitBreakerOpenException.class)
    public void testfallbackMortgageArrearsCapitalization(){
        List<MortgageAccountData> mortgageSubAccountData = AccountCreationHelper.getMortgageSubAccountData();


        mortgageArrearsCapitalizeServiceImpl.fallbackMortgageArrearsCapitalization(mortgageSubAccountData,
                new OverarchingAccountInfo(),AccountCreationHelper.generateRequiredHeaders(),new Exception("Circuit open on create"));



    }


}
