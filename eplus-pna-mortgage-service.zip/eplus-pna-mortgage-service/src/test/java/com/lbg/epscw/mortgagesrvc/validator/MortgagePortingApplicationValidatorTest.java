package com.lbg.epscw.mortgagesrvc.validator;

import com.lbg.epscw.mortgagesrvc.exception.MortgageServiceException;
import com.lbg.epscw.mortgagesrvc.exception.MortgageValidationException;
import com.lbg.epscw.mortgagesrvc.helper.MortgagePortingHelper;
import com.lbg.epscw.mortgagesrvc.model.MortgageApplicationInfo;
import com.lbg.epscw.mortgagesrvc.model.MortgagePortingApplicationStatus;
import com.lbg.epscw.mortgagesrvc.service.MortgagePortingStateMachine;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;

import java.util.Collections;

import static com.lbg.epscw.mortgagesrvc.model.MortgagePortingApplicationStatus.*;

public class MortgagePortingApplicationValidatorTest {
    private MortgagePortingHelper helper;
    private MortgagePortingApplicationValidator underTest;

    @Rule
    public ExpectedException thrown = ExpectedException.none();

    @Before
    public void setup() {
        helper = new MortgagePortingHelper();
        underTest = new MortgagePortingApplicationValidator(new MortgagePortingStateMachine());
    }

    @Test
    public void verify_credit_decision_actions_are_permitted() {
        MortgageApplicationInfo applicationInfo = helper.mortgageApplicationInfoWithStatus(MortgagePortingApplicationStatus.SUBMITTED.name());

        underTest.validateNextState(applicationInfo, APPROVED);
        underTest.validateNextState(applicationInfo, REOPEN);
        underTest.validateNextState(applicationInfo, DECLINED);
    }

    @Test
    public void validate_application_state() {
        underTest.validateCurrentState(helper.mortgageApplicationInfoWithStatus(OPEN.name()), Collections.singletonList(OPEN));
    }

    @Test
    public void valid_states_for_credit_decision() {
        assertValidState(OPEN, SUBMITTED);
    }

    @Test
    public void valid_states_for_application_complete() {
        assertValidState(WELCOME_PACK_RECEIVED, VALUATION_RECEIVED);
    }

    @Test
    public void valid_states_for_valuation_report_updated_process() {
        assertValidState(VALUATION_RECEIVED, REPROCESS);
    }

    @Test
    public void valid_states_for_valuation_report_updated_offered() {
        assertValidState(VALUATION_RECEIVED, OFFERED);
    }

    @Test
    public void valid_states_for_formal_mortgage_offer() {
        assertValidState(OFFERED, SOLICITOR_DOC_RECEIVED);
    }

    private void assertValidState(MortgagePortingApplicationStatus current, MortgagePortingApplicationStatus next) {
        MortgageApplicationInfo applicationInfo = helper.mortgageApplicationInfoWithStatus(current.name());
        underTest.validateNextState(applicationInfo, next);
    }

    @Test(expected = MortgageServiceException.class)
    public void throw_service_exception_when_application_unavailable_for_validate() {
        underTest.validateNextState(null, APPROVED);
    }

    @Test(expected = MortgageValidationException.class)
    public void throw_validation_exception_when_application_states_do_not_match() {
        underTest.validateCurrentState(helper.mortgageApplicationInfoWithStatus(OPEN.name()), Collections.singletonList(SUBMITTED));
    }

    @Test(expected = MortgageServiceException.class)
    public void throw_service_exception_when_application_unavailable_for_validate_application_state() {
        underTest.validateCurrentState(null, Collections.singletonList(OPEN));
    }
}