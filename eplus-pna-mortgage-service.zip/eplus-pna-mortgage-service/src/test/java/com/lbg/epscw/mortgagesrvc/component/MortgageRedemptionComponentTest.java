package com.lbg.epscw.mortgagesrvc.component;

import com.lbg.epscw.entitlement.service.EntitlementValidationService;
import com.lbg.epscw.handler.model.ErrorInfo;
import com.lbg.epscw.handler.model.ErrorResponse;
import com.lbg.epscw.mortgagesrvc.dto.RedemptionStatementResponse;
import com.lbg.epscw.mortgagesrvc.dto.comms.CommsResponse;
import com.lbg.epscw.mortgagesrvc.helper.ComponentHelper;
import com.lbg.epscw.mortgagesrvc.helper.MortgageRedemptionHelper;
import com.lbg.epscw.mortgagesrvc.logger.HystrixContextCopyStrategy;
import com.lbg.epscw.mortgagesrvc.model.RedemptionStatementPayloadRequest;
import com.lbg.epscw.mortgagesrvc.restclient.CustomerCommsRestClient;
import com.lbg.epscw.mortgagesrvc.restclient.MortgageAccountInfoRestClient;
import com.lbg.epscw.mortgagesrvc.service.RestClientService;
import org.apache.commons.lang.RandomStringUtils;
import org.junit.Before;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.internal.util.MockUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.context.ApplicationContext;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import static org.mockito.ArgumentMatchers.*;

import static org.junit.Assert.assertEquals;
import static org.junit.jupiter.api.Assertions.assertAll;
import static org.powermock.api.mockito.PowerMockito.mock;
import static org.mockito.Mockito.when;

@Tag("component")
@ExtendWith(SpringExtension.class)
@SpringBootTest
@AutoConfigureMockMvc
public class MortgageRedemptionComponentTest extends WebMVCTest {

    @MockBean
    private HystrixContextCopyStrategy hystrixContextCopyStrategy;

    @MockBean
    private RestClientService restClientService;

    @MockBean
    private EntitlementValidationService entitlementValidationService;

    @MockBean
    private MortgageAccountInfoRestClient mortgageAccountInfoRestClient;

    @MockBean
    private CustomerCommsRestClient customerCommsRestClient;

    @Autowired
    private ApplicationContext context;

    private ComponentHelper componentHelper;

    private MortgageRedemptionHelper mortgageRedemptionHelper;

    private static final String SEND_REDEMPTION_STATEMENT = "/redemption/e1b23552-aba5-6c8b-1dfb-5532a18b44cb/generate-statement-data";

    @Before
    public void setUp() {
        mortgageAccountInfoRestClient = mock(MortgageAccountInfoRestClient.class);
    }

    @BeforeEach
    public void beforeEach() {
        this.componentHelper = new ComponentHelper();
        this.mortgageRedemptionHelper = new MortgageRedemptionHelper();

        for (String name : context.getBeanDefinitionNames()) {
            Object bean = context.getBean(name);
            if (MockUtil.isMock(bean)) {
                Mockito.reset(bean);
            }
        }
    }


    @Test
    public void shouldReturnSuccess() {

        //given
        HttpHeaders accountInfoHeaders = mortgageRedemptionHelper.getAccountInfoHeaders();
        RedemptionStatementPayloadRequest redemptionStatementRequest =
                mortgageRedemptionHelper.getRedemptionStatementRequest();
        String payload = componentHelper.writeValueAsString(redemptionStatementRequest);

        when(mortgageAccountInfoRestClient.getMortgageAccountInfo(any(),any()))
                .thenReturn(mortgageRedemptionHelper
                        .mock_mortgageOverArchingAccountInfoResponse("e1b23552-aba5-6c8b-1dfb-5532a18b44cb"));
        when(customerCommsRestClient.sendComms(any(),any())).thenReturn(CommsResponse.builder().body("Successfully Sent!").build());
        //when
        MockHttpServletResponse servletResponse = doPOST(SEND_REDEMPTION_STATEMENT,
                payload, accountInfoHeaders);
        String responseString = componentHelper.getServletResponseAsString(servletResponse);
        RedemptionStatementResponse response = (RedemptionStatementResponse) readObject(responseString, RedemptionStatementResponse.class);

        //then
        assertAll(
                () -> Assertions.assertEquals(200, servletResponse.getStatus()),
        ()->Assertions.assertEquals("Successfully Sent!",response.getMessage())
        );
    }


    @Test
    public void shouldReturnErrorWhenBrandIsMissing() {
        //given
        RedemptionStatementPayloadRequest redemptionStatementRequest = mortgageRedemptionHelper.getRedemptionStatementRequest();
        String payload = componentHelper.writeValueAsString(redemptionStatementRequest);
        HttpHeaders accountInfoHeaders = mortgageRedemptionHelper.getAccountInfoHeaders();
        accountInfoHeaders.remove("x-lbg-brand");

        //when
        MockHttpServletResponse servletResponse = doPOST(SEND_REDEMPTION_STATEMENT, payload, accountInfoHeaders);
        String responseString = componentHelper.getServletResponseAsString(servletResponse);
        ErrorResponse errorResponse = (ErrorResponse) readObject(responseString, ErrorResponse.class);
        ErrorInfo errorInfo = errorResponse.getErrors().get(0);

        //then
        assertAll(
                () -> assertEquals(400, servletResponse.getStatus()),
                () -> assertEquals("PNA.MORTGAGE_API.SYS.001", errorResponse.getCode()),
                () -> assertEquals("Bad Request", errorResponse.getMessage()),
                () -> assertEquals("PNA.MORTGAGE_API.POST_REDEMPTION_GENERATE_STATEMENT_DATA.Header.Missing.x-lbg-brand", errorInfo.getReasonCode()),
                () -> assertEquals("Missing request header 'x-lbg-brand' for method parameter of type String", errorInfo.getMessage())
        );
    }

    @Test
    public void shouldReturnErrorWhenBrandIsIncorrect() {
        //given
        RedemptionStatementPayloadRequest redemptionStatementRequest = mortgageRedemptionHelper.getRedemptionStatementRequest();
        String payload = componentHelper.writeValueAsString(redemptionStatementRequest);
        HttpHeaders accountInfoHeaders = mortgageRedemptionHelper.getAccountInfoHeaders();
        accountInfoHeaders.set("x-lbg-brand", "xxx");

        //when
        MockHttpServletResponse servletResponse = doPOST(SEND_REDEMPTION_STATEMENT, payload, accountInfoHeaders);
        String responseString = componentHelper.getServletResponseAsString(servletResponse);
        ErrorResponse errorResponse = (ErrorResponse) readObject(responseString, ErrorResponse.class);
        ErrorInfo errorInfo = errorResponse.getErrors().get(0);

        //then
        assertAll(
                () -> assertEquals(400, servletResponse.getStatus()),
                () -> assertEquals("PNA.MORTGAGE_API.SYS.001", errorResponse.getCode()),
                () -> assertEquals("Bad Request", errorResponse.getMessage()),
                () -> assertEquals("PNA.MORTGAGE_API.POST_REDEMPTION_GENERATE_STATEMENT_DATA.Header.Invalid", errorInfo.getReasonCode()),
                () -> assertEquals("Invalid enum value for type x-lbg-brand", errorInfo.getMessage())
        );
    }

    @Test
    public void shouldReturnErrorWhenCorrelationIdIsMissing() {
        //given
        RedemptionStatementPayloadRequest redemptionStatementRequest = mortgageRedemptionHelper.getRedemptionStatementRequest();
        String payload = componentHelper.writeValueAsString(redemptionStatementRequest);
        HttpHeaders accountInfoHeaders = mortgageRedemptionHelper.getAccountInfoHeaders();
        accountInfoHeaders.remove("x-lbg-txn-correlation-id");

        //when
        MockHttpServletResponse servletResponse = doPOST(SEND_REDEMPTION_STATEMENT, payload, accountInfoHeaders);
        String responseString = componentHelper.getServletResponseAsString(servletResponse);
        ErrorResponse errorResponse = (ErrorResponse) readObject(responseString, ErrorResponse.class);
        ErrorInfo errorInfo = errorResponse.getErrors().get(0);

        //then
        assertAll(
                () -> assertEquals(400, servletResponse.getStatus()),
                () -> assertEquals("PNA.MORTGAGE_API.SYS.001", errorResponse.getCode()),
                () -> assertEquals("Bad Request", errorResponse.getMessage()),
                () -> assertEquals("PNA.MORTGAGE_API.POST_REDEMPTION_GENERATE_STATEMENT_DATA.Header.Missing.x-lbg-txn-correlation-id", errorInfo.getReasonCode()),
                () -> assertEquals("Missing request header x-lbg-txn-correlation-id for method parameter of type String", errorInfo.getMessage())
        );
    }

    @Test
    public void shouldReturnErrorWhenCorrelationIdIsLessThanTenCharacters() {
        //given
        RedemptionStatementPayloadRequest redemptionStatementRequest = mortgageRedemptionHelper.getRedemptionStatementRequest();
        String payload = componentHelper.writeValueAsString(redemptionStatementRequest);
        HttpHeaders accountInfoHeaders = mortgageRedemptionHelper.getAccountInfoHeaders();
        accountInfoHeaders.set("x-lbg-txn-correlation-id", RandomStringUtils.random(9));

        //when
        MockHttpServletResponse servletResponse = doPOST(SEND_REDEMPTION_STATEMENT, payload, accountInfoHeaders);
        String responseString = componentHelper.getServletResponseAsString(servletResponse);
        ErrorResponse errorResponse = (ErrorResponse) readObject(responseString, ErrorResponse.class);
        ErrorInfo errorInfo = errorResponse.getErrors().get(0);

        //then
        assertAll(
                () -> assertEquals(400, servletResponse.getStatus()),
                () -> assertEquals("PNA.MORTGAGE_API.SYS.001", errorResponse.getCode()),
                () -> assertEquals("Bad Request", errorResponse.getMessage()),
                () -> assertEquals("PNA.MORTGAGE_API.POST_REDEMPTION_GENERATE_STATEMENT_DATA.Header.Invalid", errorInfo.getReasonCode()),
                () -> assertEquals("x-lbg-txn-correlation-id size should be between 10 and 40", errorInfo.getMessage())
        );
    }

    @Test
    public void shouldReturnErrorWhenCorrelationIdIsGreaterThanFortyCharacters() {
        //given
        RedemptionStatementPayloadRequest redemptionStatementRequest = mortgageRedemptionHelper.getRedemptionStatementRequest();
        String payload = componentHelper.writeValueAsString(redemptionStatementRequest);
        HttpHeaders accountInfoHeaders = mortgageRedemptionHelper.getAccountInfoHeaders();
        accountInfoHeaders.set("x-lbg-txn-correlation-id", RandomStringUtils.random(50));


        //when
        MockHttpServletResponse servletResponse = doPOST(SEND_REDEMPTION_STATEMENT, payload, accountInfoHeaders);
        String responseString = componentHelper.getServletResponseAsString(servletResponse);
        ErrorResponse errorResponse = (ErrorResponse) readObject(responseString, ErrorResponse.class);
        ErrorInfo errorInfo = errorResponse.getErrors().get(0);

        //then
        assertAll(
                () -> assertEquals(400, servletResponse.getStatus()),
                () -> assertEquals("PNA.MORTGAGE_API.SYS.001", errorResponse.getCode()),
                () -> assertEquals("Bad Request", errorResponse.getMessage()),
                () -> assertEquals("PNA.MORTGAGE_API.POST_REDEMPTION_GENERATE_STATEMENT_DATA.Header.Invalid", errorInfo.getReasonCode()),
                () -> assertEquals("x-lbg-txn-correlation-id size should be between 10 and 40", errorInfo.getMessage())
        );
    }

    @Test
    public void shouldReturnErrorWhenAuthorisationIsMissing() {
        //given
        RedemptionStatementPayloadRequest redemptionStatementRequest = mortgageRedemptionHelper.getRedemptionStatementRequest();
        String payload = componentHelper.writeValueAsString(redemptionStatementRequest);
        HttpHeaders accountInfoHeaders = mortgageRedemptionHelper.getAccountInfoHeaders();
        accountInfoHeaders.remove("x-lbg-internal-system-id");
        accountInfoHeaders.remove("Authorization");

        //when
        MockHttpServletResponse servletResponse = doPOST(SEND_REDEMPTION_STATEMENT, payload, accountInfoHeaders);
        String responseString = componentHelper.getServletResponseAsString(servletResponse);
        ErrorResponse errorResponse = (ErrorResponse) readObject(responseString, ErrorResponse.class);
        ErrorInfo errorInfo = errorResponse.getErrors().get(0);

        //then
        assertAll(
                () -> assertEquals(401, servletResponse.getStatus()),
                () -> assertEquals("PNA.MORTGAGE_API.SYS.002", errorResponse.getCode()),
                () -> assertEquals("Resource Unauthorised", errorResponse.getMessage()),
                () -> assertEquals("PNA.MORTGAGE_API.POST_REDEMPTION_GENERATE_STATEMENT_DATA.Access.Unauthorised", errorInfo.getReasonCode()),
                () -> assertEquals("Please Supply headers : 'Authorization' or 'x-lbg-internal-system-id'", errorInfo.getMessage())
        );
    }

    @Test
    public void shouldReturnErrorWhenAccountIdIsMoreThan36Chars() {
        //given
        RedemptionStatementPayloadRequest redemptionStatementRequest = mortgageRedemptionHelper.getRedemptionStatementRequest();
        String payload = componentHelper.writeValueAsString(redemptionStatementRequest);

        //when
        MockHttpServletResponse servletResponse = doPOST("/redemption/" + RandomStringUtils.random(50) + "/generate-statement-data",
                payload,
                mortgageRedemptionHelper.getAccountInfoHeaders());
        String responseString = componentHelper.getServletResponseAsString(servletResponse);
        ErrorResponse errorResponse = (ErrorResponse) readObject(responseString, ErrorResponse.class);
        ErrorInfo errorInfo = errorResponse.getErrors().get(0);

        //then
        assertAll(
                () -> assertEquals(400, servletResponse.getStatus()),
                () -> assertEquals("PNA.MORTGAGE_API.SYS.001", errorResponse.getCode()),
                () -> assertEquals("Bad Request", errorResponse.getMessage()),
                () -> assertEquals("PNA.MORTGAGE_API.POST_REDEMPTION_GENERATE_STATEMENT_DATA.Param.Invalid", errorInfo.getReasonCode()),
                () -> assertEquals("AccountId should be max 36 characters", errorInfo.getMessage())
        );
    }

    @Test
    public void shouldReturnErrorWhenAccountIdIsLessThan36Chars() {
        //given
        RedemptionStatementPayloadRequest redemptionStatementRequest = mortgageRedemptionHelper.getRedemptionStatementRequest();
        String payload = componentHelper.writeValueAsString(redemptionStatementRequest);

        //when
        MockHttpServletResponse servletResponse = doPOST("/redemption/" + RandomStringUtils.random(5) + "/generate-statement-data",
                payload,
                mortgageRedemptionHelper.getAccountInfoHeaders());
        String responseString = componentHelper.getServletResponseAsString(servletResponse);
        ErrorResponse errorResponse = (ErrorResponse) readObject(responseString, ErrorResponse.class);
        ErrorInfo errorInfo = errorResponse.getErrors().get(0);

        //then
        assertAll(
                () -> assertEquals(400, servletResponse.getStatus()),
                () -> assertEquals("PNA.MORTGAGE_API.SYS.001", errorResponse.getCode()),
                () -> assertEquals("Bad Request", errorResponse.getMessage()),
                () -> assertEquals("PNA.MORTGAGE_API.POST_REDEMPTION_GENERATE_STATEMENT_DATA.Param.Invalid", errorInfo.getReasonCode()),
                () -> assertEquals("AccountId should be min 36 characters", errorInfo.getMessage())
        );
    }

    @Test
    public void shouldReturnErrorForAddWhenIncorrectEndpointIsCalled() {
        //given
        RedemptionStatementPayloadRequest redemptionStatementRequest = mortgageRedemptionHelper.getRedemptionStatementRequest();
        String payload = componentHelper.writeValueAsString(redemptionStatementRequest);
        HttpHeaders accountInfoHeaders = mortgageRedemptionHelper.getAccountInfoHeaders();

        //when
        MockHttpServletResponse servletResponse = doPOST(SEND_REDEMPTION_STATEMENT.concat("s"), payload, accountInfoHeaders);

        //then
        assertAll(
                () -> assertEquals(404, servletResponse.getStatus())
        );
    }

    @Test
    public void shouldReturnErrorForEmptyJson() {

        //given
        HttpHeaders accountInfoHeaders = mortgageRedemptionHelper.getAccountInfoHeaders();

        //when
        MockHttpServletResponse servletResponse = doPOST(SEND_REDEMPTION_STATEMENT,
                "{}", accountInfoHeaders);
        String responseString = componentHelper.getServletResponseAsString(servletResponse);
        ErrorResponse errorResponse = (ErrorResponse) readObject(responseString, ErrorResponse.class);
        ErrorInfo errorInfo = errorResponse.getErrors().get(0);

        //then
        assertAll(
                () -> Assertions.assertEquals(400, servletResponse.getStatus()),
                () -> Assertions.assertEquals("PNA.MORTGAGE_API.SYS.001", errorResponse.getCode()),
                () -> Assertions.assertEquals("Bad Request", errorResponse.getMessage())

        );
    }

    @Test
    public void shouldReturnErrorForEmptyRequestBody() {

        //given
        HttpHeaders accountInfoHeaders = mortgageRedemptionHelper.getAccountInfoHeaders();

        //when
        MockHttpServletResponse servletResponse = doPOST(SEND_REDEMPTION_STATEMENT,
                "", accountInfoHeaders);
        String responseString = componentHelper.getServletResponseAsString(servletResponse);
        ErrorResponse errorResponse = (ErrorResponse) readObject(responseString, ErrorResponse.class);
        ErrorInfo errorInfo = errorResponse.getErrors().get(0);

        //then
        assertAll(
                () -> Assertions.assertEquals(400, servletResponse.getStatus()),
                () -> Assertions.assertEquals("PNA.MORTGAGE_API.SYS.001", errorResponse.getCode()),
                () -> Assertions.assertEquals("Bad Request", errorResponse.getMessage())

        );
    }

}
