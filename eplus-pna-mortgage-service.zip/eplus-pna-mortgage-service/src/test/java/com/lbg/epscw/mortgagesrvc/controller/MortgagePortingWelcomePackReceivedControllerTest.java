package com.lbg.epscw.mortgagesrvc.controller;

import com.lbg.epscw.mortgagesrvc.exception.MortgageServiceException;
import com.lbg.epscw.mortgagesrvc.exception.MortgageValidationException;
import com.lbg.epscw.mortgagesrvc.model.MortgageApplicationInfo;
import com.lbg.epscw.mortgagesrvc.model.PortingApplicationStatusResponse;
import com.lbg.epscw.mortgagesrvc.service.MortgagePortingApplicationInfoService;
import com.lbg.epscw.mortgagesrvc.service.MortgagePortingWelcomePackService;
import com.lbg.epscw.mortgagesrvc.util.MortgageServiceUtil;
import com.lbg.epscw.mortgagesrvc.validator.MortgagePortingApplicationValidator;
import org.junit.Before;
import org.junit.Test;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.util.Collections;

import static com.google.api.client.http.OpenCensusUtils.getTracer;
import static com.lbg.epscw.mortgagesrvc.helper.MortgagePortingHelper.*;
import static com.lbg.epscw.mortgagesrvc.model.MortgagePortingApplicationStatus.APPROVED;
import static com.lbg.epscw.mortgagesrvc.model.MortgagePortingApplicationStatus.WELCOME_PACK_RECEIVED;
import static com.lbg.epscw.mortgagesrvc.model.PortingApplicationStatusResponse.builder;
import static io.opencensus.trace.samplers.Samplers.alwaysSample;
import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.*;

public class MortgagePortingWelcomePackReceivedControllerTest {

    private MortgagePortingApplicationInfoService infoService;
    private MortgagePortingApplicationValidator validator;
    private MortgagePortingWelcomePackService service;
    private MortgagePortingWelcomePackReceivedController underTest;

    @Before
    public void setUp() throws Exception{
        infoService = mock(MortgagePortingApplicationInfoService.class);
        validator = mock(MortgagePortingApplicationValidator.class);
        MortgageServiceUtil utility = mock(MortgageServiceUtil.class);
        when(utility.buildSpan(anyString())).thenReturn(getTracer().spanBuilder("any").setSampler(alwaysSample()));
        service = mock(MortgagePortingWelcomePackService.class);
        underTest = new MortgagePortingWelcomePackReceivedController(validator, utility, service, infoService);
    }

    @Test
    public void check_welcome_pack_received_returns_successful_response(){
        // Given
        when(infoService.getApplicationInfo(anyString())).thenReturn(MortgageApplicationInfo.builder().applicationNumber("1234").status(APPROVED).build());
        when(service.applicationWelcomePackReceived(anyString(), any())).thenReturn(builder().status(WELCOME_PACK_RECEIVED).applicationNumber("1234").build());

        // When
        ResponseEntity<PortingApplicationStatusResponse> responseEntity = underTest.welcomePackReceived(BRAND, CHANNEL, CORRELATION_ID, JWT, INTERNAL_SYS_ID, APPLICATION_NUMBER, Collections.emptyMap());

        // Then
        assertThat(responseEntity.getStatusCode(), is(HttpStatus.OK));
        assertThat(responseEntity.getBody().getStatus(), is(WELCOME_PACK_RECEIVED));
        assertThat(responseEntity.getBody().getApplicationNumber(), is("1234"));
    }

    @Test(expected = MortgageValidationException.class)
    public void check_welcome_pack_received_throws_error_when_invalid_action(){
        doThrow(MortgageValidationException.class).when(validator).validateNextState(any(),any());

        underTest.welcomePackReceived(BRAND, CHANNEL, CORRELATION_ID, JWT, INTERNAL_SYS_ID, APPLICATION_NUMBER, Collections.emptyMap());
    }

    @Test(expected = MortgageServiceException.class)
    public void check_welcome_pack_received_service_throws_error_when_invalid_action(){
        doThrow(MortgageServiceException.class).when(service).applicationWelcomePackReceived(anyString(),any());

        underTest.welcomePackReceived(BRAND, CHANNEL, CORRELATION_ID, JWT, INTERNAL_SYS_ID, APPLICATION_NUMBER, Collections.emptyMap());
    }
}
