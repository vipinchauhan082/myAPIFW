package com.lbg.epscw.mortgagesrvc.util;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.lbg.epscw.mortgagesrvc.dto.MortgageAccountData;
import com.lbg.epscw.mortgagesrvc.dto.MortgageAccountInfo;
import com.lbg.epscw.mortgagesrvc.dto.SettlementAmountInfo;
import com.lbg.epscw.mortgagesrvc.exception.MortgageServiceException;
import com.lbg.epscw.mortgagesrvc.helper.AccountCreationHelper;
import io.opencensus.trace.SpanBuilder;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit4.SpringRunner;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.ResourceBundle;

import static com.lbg.epscw.mortgagesrvc.constants.CommonConstants.ERROR;
import static com.lbg.epscw.mortgagesrvc.constants.CommonConstants.SERIALIZE;
import static junit.framework.Assert.assertNotNull;
import static junit.framework.TestCase.assertEquals;
import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.CoreMatchers.notNullValue;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.BDDMockito.given;


@RunWith(SpringRunner.class)
@WebMvcTest(controllers = {ResourceBundle.class})
public class MortgageServiceUtilTest {

    @MockBean
    private ObjectMapper mapper;

    @SuppressWarnings("unchecked")
    @Test
    public void readObject() {
        //given
        MortgageServiceUtil serviceUtil = new MortgageServiceUtil(new ObjectMapper());

        //when
        Map<String, String> response =
                (Map<String, String>) serviceUtil.readObject("{\"key\":\"value\"}", Map.class);

        //then
        assertEquals("value", response.get("key"));
    }

    @Test(expected = MortgageServiceException.class)
    public void readObject_fails_to_deserialize() {
        //given
        MortgageServiceUtil serviceUtil = new MortgageServiceUtil(new ObjectMapper());

        //when
        serviceUtil.readObject("{\"key\"}", Map.class);
    }

    @Test
    public void readObject_fails_to_deserialize_settlement_amount_object() {
        //given
        MortgageServiceUtil serviceUtil = new MortgageServiceUtil(new ObjectMapper());

        //when
        SettlementAmountInfo response = serviceUtil.readObject("{\n" +
                "    \"Data\": {\n" +
                "        \"AggregatedSettlementAmount\": {\n" +
                "            \"RedemptionDateRequested\": \"2021-02-11\",\n" +
                "            \"TotalAnticipatedInterest\": \"0.00\",\n" +
                "            \"TotalSettlementAmount\": \"4.00\",\n" +
                "            \"DayInterestAfterRedemptionDate\": \"\"\n" +
                "        },\n" +
                "        \"SubAccountsSettlementAmount\": [\n" +
                "            {\n" +
                "                \"AccountId\": \"649270b9-e728-71bf-e6d9-1a3577b6a567\",\n" +
                "                \"SettlementDailyInterest\": \"0.0\",\n" +
                "                \"AnticipatedInterest\": \"0.0\",\n" +
                "                \"SettlementAmount\": \"2.00\"\n" +
                "            }\n" +
                "        ],\n" +
                "        \"Currency\": \"GBP\"\n" +
                "    }\n" +
                "}", SettlementAmountInfo.class);
        assertEquals("4.00", response.getSettlementAmount().getAggregatedSettlementAmountInfo().getTotalSettlementAmount());
        assertEquals("", response.getSettlementAmount().getAggregatedSettlementAmountInfo().getDayInterestAfterRedemptionDate());
    }


    @Test
    public void write_object_as_string() {
        //given
        Map<String, String> map = new HashMap<>();
        map.put("key", "value");
        MortgageServiceUtil serviceUtil = new MortgageServiceUtil(new ObjectMapper());

        //when
        String response = serviceUtil.writeObjectAsString(map);

        //then
        assertEquals("{\"key\":\"value\"}", response);
    }

    @Test(expected = MortgageServiceException.class)
    public void write_object_as_string_fails_to_serialize() throws JsonProcessingException {
        //given
        given(mapper.writeValueAsString(any())).willAnswer(invocation -> {
            throw new MortgageServiceException(SERIALIZE, ERROR);
        });
        MortgageServiceUtil serviceUtil = new MortgageServiceUtil(mapper);

        //when
        serviceUtil.writeObjectAsString(new Object());
    }

    @Test
    public void searchTree() {
        //given
        MortgageServiceUtil serviceUtil = new MortgageServiceUtil(new ObjectMapper());

        //when
        String response = serviceUtil.searchTree("{\"key\":\"value\"}", "key");

        //then
        assertEquals("value", response);
    }

    @Test
    public void searchTree_does_not_find_desired_path() {
        //given
        MortgageServiceUtil serviceUtil = new MortgageServiceUtil(new ObjectMapper());

        //when
        String response = serviceUtil.searchTree("{\"key\":\"value\"}", "searchKey");

        //then
        assertEquals("Expected field: {searchKey} not found in Json: {\"key\":\"value\"}", response);
    }

    @Test(expected = MortgageServiceException.class)
    public void searchTree_fails_to_read() throws JsonProcessingException {
        //given
        given(mapper.readTree(anyString())).willAnswer(invocation -> {
            throw new IOException("Failed to serialize the data");
        });
        MortgageServiceUtil serviceUtil = new MortgageServiceUtil(mapper);

        //when
        String response = serviceUtil.searchTree("{\"key\":\"value\"}", "//key2");
    }

    @Test
    public void readTree() {
        //given
        MortgageServiceUtil serviceUtil = new MortgageServiceUtil(new ObjectMapper());

        //when
        String response = serviceUtil.readTree("{\"key\":\"value\"}", "key");

        //then
        assertEquals("\"value\"", response);
    }

    @Test(expected = MortgageServiceException.class)
    public void readTree_fails_to_read() throws JsonProcessingException {
        //given
        given(mapper.readTree(anyString())).willAnswer(invocation -> {
            throw new IOException("Failed to serialize the data");
        });
        MortgageServiceUtil serviceUtil = new MortgageServiceUtil(mapper);

        //when
        String response = serviceUtil.readTree("{\"key\":\"value\"}", "//key2");
    }

    @Test
    public void buildSpan() {
        //when
        MortgageServiceUtil serviceUtil = new MortgageServiceUtil(new ObjectMapper());
        SpanBuilder response = serviceUtil.buildSpan("Testing opencensus");

        //then
        assertNotNull(response);
    }

    @Test
    public void get_localized_message() {
        //given
        MortgageServiceUtil serviceUtil = new MortgageServiceUtil(new ObjectMapper());

        //when
        String response = serviceUtil.getLocalizedMessage("json.property.unrecognized", "x-correlation-id");

        //then
        assertEquals("JSON parse error: Unrecognized field x-correlation-id", response);
    }

    @Test
    public void logMethodEntryExit() {
        //given
        MortgageServiceUtil serviceUtil = new MortgageServiceUtil(new ObjectMapper());
        serviceUtil.logMethodEntryExit("value1", "value2", "value3", "value4");

        //then
        assertNotNull(serviceUtil);
    }

    @Test
    public void testFetchDefaultHeader() {
        //given
        MortgageServiceUtil serviceUtil = new MortgageServiceUtil(new ObjectMapper());
        //when
        assertNotNull(serviceUtil.fetchDefaultVaultHeaders());
    }


    @Test
    public void shouldReadMortgageInfoData() {
        //given
        MortgageServiceUtil mortgageServiceUtil = new MortgageServiceUtil(new ObjectMapper());

        //when
        MortgageAccountInfo viewMortgage = (MortgageAccountInfo) mortgageServiceUtil.readObject("{\n" +
                "    \"Data\": [\n" +
                "        {\n" +
                "            \"mortgageNumber\": \"number_1112\",\n" +
                "            \"mortgagePrincipal\": \"4000\",\n" +
                "            \"keyDate\": \"7\",\n" +
                "            \"mortgageType\": \"INTEREST_ONLY\",\n" +
                "            \"totalTerm\": \"24\",\n" +
                "            \"productId\": \"lbg_mortgage\",\n" +
                "            \"accountId\": \"1601d0e5-e336-64d9-64ad-89ba6fdc2677\"\n" +
                "        },\n" +
                "        {\n" +
                "            \"mortgageNumber\": \"number_1112\",\n" +
                "            \"mortgagePrincipal\": \"3000\",\n" +
                "            \"keyDate\": \"7\",\n" +
                "            \"mortgageType\": \"INTEREST_ONLY\",\n" +
                "            \"totalTerm\": \"24\",\n" +
                "            \"productId\": \"lbg_mortgage\",\n" +
                "            \"accountId\": \"53a9e0b4-56c1-ffcc-e9f7-9159d4b259cd\"\n" +
                "        },\n" +
                "        {\n" +
                "            \"mortgageNumber\": \"number_1112\",\n" +
                "            \"productId\": \"lbg_mortgage_repayment\",\n" +
                "            \"accountId\": \"6b80a0e0-10da-1dc9-563d-9538b9c5761b\"\n" +
                "        }\n" +
                "    ]\n" +
                "}", MortgageAccountInfo.class);

        //then
        assertEquals(3, viewMortgage.getMortgageAccountData().size());
        assertEquals("1601d0e5-e336-64d9-64ad-89ba6fdc2677", viewMortgage.getMortgageAccountData().get(0).getAccountId());
        assertEquals("53a9e0b4-56c1-ffcc-e9f7-9159d4b259cd", viewMortgage.getMortgageAccountData().get(1).getAccountId());
        assertEquals("6b80a0e0-10da-1dc9-563d-9538b9c5761b", viewMortgage.getMortgageAccountData().get(2).getAccountId());
    }


    @Test
    public void should_generate_uuid() {
        MortgageServiceUtil underTest = new MortgageServiceUtil(new ObjectMapper());
        assertThat(underTest.uuid(), is(notNullValue()));
    }

    @Test
    public void should_return_max_sequence_id_among_sub_accounts(){
        //given
        MortgageServiceUtil mortgageServiceUtil = new MortgageServiceUtil(new ObjectMapper());
        List<MortgageAccountData> mortgageSubAccountData = AccountCreationHelper.getMortgageSubAccountData();
        //then
        assertEquals("2",mortgageServiceUtil.getMaxSequenceNumber(mortgageSubAccountData));
    }

}

