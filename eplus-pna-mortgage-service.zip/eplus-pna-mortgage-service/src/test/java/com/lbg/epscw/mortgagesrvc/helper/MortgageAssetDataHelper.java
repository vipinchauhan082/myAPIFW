package com.lbg.epscw.mortgagesrvc.helper;

import com.lbg.epscw.mortgagesrvc.enums.ApplicationPurpose;
import com.lbg.epscw.mortgagesrvc.enums.TenureTypeEnum;
import com.lbg.epscw.mortgagesrvc.model.Asset;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;

import java.util.ArrayList;
import java.util.List;

import static com.lbg.epscw.mortgagesrvc.model.Channel.TELEPHONE;
import static java.lang.String.format;

public class MortgageAssetDataHelper {

    public static final String ASSET_ID = "243245";
    public static final String BRAND_ID = "2343";
    public static final String MORTGAGE_NUMBER = "233459845";
    public static final String ADDRESS_LINE_01 = "Address Line 01";
    public static final String ADDRESS_LINE_02 = "Address Line 02";
    public static final String ADDRESS_LINE_03 = "Address Line 03";
    public static final String ADDRESS_LINE_04 = "Address Line 04";
    public static final String ADDRESS_LINE_05 = "Address Line 05";
    public static final String CITY = "City";
    public static final String POSTAL_CODE = "Postal Code";
    public static final String STATE = "state";
    public static final String COUNTRY_NAME = "country name";
    public static final String LOCATE_ID = "123";
    public static final String LOCATE_STATUS = "verified";
    public static final String LOCATION_VERIFIED_BY = "D Rayman";
    public static final Long REMAINING_LEASE_TERM = 15l;
    public static final String FIRST_NAME = "first name";
    public static final String LAST_NAME = "last name";

    public static final String APPLICATION_ID = "12134";
    public static final String CUSTOMER_ID = "";
    public static final String SECOND_CUSTOMER_ID = "";
    public static final Integer NUMBER_Of_DEPENDENT = 2;

    public static final String MORTGAGE_ASSET_INFO_ENDPOINT = format("/mortgages/application/%S/asset-info", APPLICATION_ID);

    public static Asset generateMortgageAssetUpdateRequest(){
        List<String> occupants = new ArrayList<>();
        occupants.add(FIRST_NAME+" "+LAST_NAME);
        return Asset.builder()
                .assetId(ASSET_ID)
                .brandId(BRAND_ID)
                .mortgageNumber(MORTGAGE_NUMBER)
                .addressLine01(ADDRESS_LINE_01)
                .addressLine02(ADDRESS_LINE_02)
                .addressLine03(ADDRESS_LINE_03)
                .addressLine04(ADDRESS_LINE_04)
                .addressLine05(ADDRESS_LINE_05)
                .city(CITY)
                .postalCode(POSTAL_CODE)
                .state(STATE)
                .countryName(COUNTRY_NAME)
                .locateId(LOCATE_ID)
                .locateStatus(LOCATE_STATUS)
                .locateVerifiedBy(LOCATION_VERIFIED_BY)
                .tenure(TenureTypeEnum.LEASEHOLD.toString())
                .remainingLeaseTerm(REMAINING_LEASE_TERM)
                .occupants(occupants)
                .build();
    }

    public static Asset generateMortgageAssetCreateRequest(){
        List<String> occupants = new ArrayList<>();
        occupants.add(FIRST_NAME+" "+LAST_NAME);
        return Asset.builder()
                .brandId(BRAND_ID)
                .mortgageNumber(MORTGAGE_NUMBER)
                .addressLine01(ADDRESS_LINE_01)
                .addressLine02(ADDRESS_LINE_02)
                .addressLine03(ADDRESS_LINE_03)
                .addressLine04(ADDRESS_LINE_04)
                .addressLine05(ADDRESS_LINE_05)
                .city(CITY)
                .postalCode(POSTAL_CODE)
                .state(STATE)
                .countryName(COUNTRY_NAME)
                .locateId(LOCATE_ID)
                .locateStatus(LOCATE_STATUS)
                .locateVerifiedBy(LOCATION_VERIFIED_BY)
                .tenure(TenureTypeEnum.LEASEHOLD.toString())
                .remainingLeaseTerm(REMAINING_LEASE_TERM)
                .occupants(occupants)
                .build();
    }

    public static Asset assetResponse(){
        return Asset.builder()
                .applicationId(APPLICATION_ID)
                .assetId(ASSET_ID)
                .customerId(CUSTOMER_ID)
                .secondCustomerId(SECOND_CUSTOMER_ID)
                .mortgageNumber(MORTGAGE_NUMBER)
                .purpose(ApplicationPurpose.PORTING)
                .numberOfDependents(NUMBER_Of_DEPENDENT)
                .build();
    }

    public static Asset generateBadRequestOneMissing(){
        List<String> occupants = new ArrayList<>();
        occupants.add(FIRST_NAME+" "+LAST_NAME);
        return Asset.builder()
                .addressLine01(ADDRESS_LINE_01)
                .addressLine02(ADDRESS_LINE_02)
                .addressLine03(ADDRESS_LINE_03)
                .addressLine04(ADDRESS_LINE_04)
                .addressLine05(ADDRESS_LINE_05)
                .city(CITY)
                .postalCode(null)
                .state(STATE)
                .countryName(COUNTRY_NAME)
                .locateId(LOCATE_ID)
                .locateStatus(LOCATE_STATUS)
                .locateVerifiedBy(LOCATION_VERIFIED_BY)
                .tenure(TenureTypeEnum.LEASEHOLD.toString())
                .remainingLeaseTerm(REMAINING_LEASE_TERM)
                .occupants(occupants)
                .build();
    }

    public static Asset generateBadRequestMultiMissing(){
        return Asset.builder()
                .addressLine01(ADDRESS_LINE_01)
                .addressLine02(ADDRESS_LINE_02)
                .addressLine03(ADDRESS_LINE_03)
                .addressLine04(ADDRESS_LINE_04)
                .addressLine05(ADDRESS_LINE_05)
                .city(CITY)
                .postalCode("")
                .state("")
                .countryName(COUNTRY_NAME)
                .locateId(LOCATE_ID)
                .locateStatus(LOCATE_STATUS)
                .locateVerifiedBy(LOCATION_VERIFIED_BY)
                .tenure(TenureTypeEnum.LEASEHOLD.toString())
                .remainingLeaseTerm(0l)
                .occupants(new ArrayList<>())
                .build();
    }

    public Asset mortgageAssetPayload(){
        List<String> occupants = new ArrayList<>();
        occupants.add(FIRST_NAME+" "+LAST_NAME);
        return Asset.builder()
                .addressLine01(ADDRESS_LINE_01)
                .addressLine02(ADDRESS_LINE_02)
                .addressLine03(ADDRESS_LINE_03)
                .addressLine04(ADDRESS_LINE_04)
                .addressLine05(ADDRESS_LINE_05)
                .city(CITY)
                .postalCode(POSTAL_CODE)
                .countryName(COUNTRY_NAME)
                .tenure(TenureTypeEnum.LEASEHOLD.toString())
                .remainingLeaseTerm(15l)
                .occupants(occupants)
                .build();
    }

    public HttpHeaders getMortgageAssetHeaders() {
        HttpHeaders httpHeaders = new HttpHeaders();
        httpHeaders.add("Authorization", "Bearer b2c9119f-09e5-4ac9-9738-9e28b334d3fa");
        httpHeaders.add("x-lbg-internal-system-id", "test");
        httpHeaders.add("x-lbg-brand", "IF");
        httpHeaders.add("x-lbg-channel", TELEPHONE.name());
        httpHeaders.add("x-lbg-txn-correlation-id", "123-456-789-123");
        httpHeaders.setContentType(MediaType.APPLICATION_JSON);
        return httpHeaders;
    }
}
