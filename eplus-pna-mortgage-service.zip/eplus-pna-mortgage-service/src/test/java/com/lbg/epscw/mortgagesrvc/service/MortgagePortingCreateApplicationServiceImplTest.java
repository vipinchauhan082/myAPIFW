package com.lbg.epscw.mortgagesrvc.service;

import com.lbg.epscw.mortgagesrvc.dto.MortgageAccountInfo;
import com.lbg.epscw.mortgagesrvc.exception.CircuitBreakerOpenException;
import com.lbg.epscw.mortgagesrvc.exception.MortgageServiceException;
import com.lbg.epscw.mortgagesrvc.helper.MortgagePortingHelper;
import com.lbg.epscw.mortgagesrvc.model.CreatePortingApplicationRequest;
import com.lbg.epscw.mortgagesrvc.model.CreatePortingApplicationResponse;
import com.lbg.epscw.mortgagesrvc.model.MortgageApplicationInfo;
import com.lbg.epscw.mortgagesrvc.restclient.MortgageAccountInfoRestClient;
import com.lbg.epscw.mortgagesrvc.restclient.MortgagePortingApplicationInfoRestClient;
import com.lbg.epscw.mortgagesrvc.util.MortgageServiceUtil;
import org.junit.Before;
import org.junit.Test;

import static com.lbg.epscw.mortgagesrvc.helper.MortgagePortingHelper.*;
import static com.lbg.epscw.mortgagesrvc.model.MortgagePortingApplicationStatus.OPEN;
import static java.util.Collections.emptyMap;
import static java.util.Optional.empty;
import static java.util.Optional.of;
import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.CoreMatchers.notNullValue;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

public class MortgagePortingCreateApplicationServiceImplTest {
    private final MortgagePortingHelper helper = new MortgagePortingHelper();
    private MortgageServiceUtil mortgageServiceUtil;
    private MortgagePortingApplicationInfoRestClient applicationClient;
    private MortgageAccountInfoRestClient accountInfoRestClient;
    private MortgagePortingCreateApplicationServiceImpl underTest;

    @Before
    public void setup() {
        mortgageServiceUtil = mock(MortgageServiceUtil.class);
        applicationClient = mock(MortgagePortingApplicationInfoRestClient.class);
        accountInfoRestClient = mock(MortgageAccountInfoRestClient.class);
        underTest = new MortgagePortingCreateApplicationServiceImpl(mortgageServiceUtil, accountInfoRestClient, applicationClient);
    }

    @Test
    public void return_mortgage_account_info() {
        MortgageAccountInfo expected = helper.mortgageAccountInfoWithStatus(OPEN.name(), CUSTOMER_ID);
        when(accountInfoRestClient.getMortgageInfoByMortgageNumber(anyString(), anyMap())).thenReturn(expected);
        MortgageAccountInfo actual = underTest.mortgageInfoByMortgageNumber(EXISTING_MORTGAGE_NUMBER, emptyMap());
        assertThat(actual, is(expected));
    }

    @Test
    public void create_application_success() {
        when(mortgageServiceUtil.uuid()).thenReturn(EXISTING_MORTGAGE_NUMBER);
        when(applicationClient.createMortgageApplication(anyString(), any())).thenReturn(of(MortgageApplicationInfo.builder().status(OPEN).applicationNumber(APPLICATION_NUMBER).build()));
        CreatePortingApplicationResponse actual = underTest.createApplication(helper.createApplicationPayloadBuilder().build());
        assertThat(actual.getStatus(), is(OPEN));
        assertThat(actual.getApplicationNumber(), is(notNullValue()));
    }

    @Test(expected = MortgageServiceException.class)
    public void create_application_fails_when_no_application_found() {
        when(applicationClient.createMortgageApplication(anyString(), any())).thenReturn(empty());
        underTest.createApplication(helper.createApplicationPayloadBuilder().build());
    }

    @Test(expected = CircuitBreakerOpenException.class)
    public void create_fallback_throws_exception_on_broken_circuit_for_create_application() {
        underTest.fallbackCreateApplication(CreatePortingApplicationRequest.builder().build(), new IllegalArgumentException());
    }

    @Test(expected = CircuitBreakerOpenException.class)
    public void create_fallback_throws_exception_on_broken_circuit_for_get_mortgage_info() {
        underTest.fallbackMortgageInfoByMortgageNumber(EXISTING_MORTGAGE_NUMBER, emptyMap(), new IllegalArgumentException());
    }
}