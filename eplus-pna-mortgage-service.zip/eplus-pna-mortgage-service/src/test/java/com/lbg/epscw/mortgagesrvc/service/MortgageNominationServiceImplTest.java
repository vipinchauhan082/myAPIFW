package com.lbg.epscw.mortgagesrvc.service;

import com.lbg.epscw.mortgagesrvc.exception.CircuitBreakerOpenException;
import com.lbg.epscw.mortgagesrvc.helper.MortgageNominationHelper;
import com.lbg.epscw.mortgagesrvc.model.NominationResponse;
import com.lbg.epscw.mortgagesrvc.model.VaultAccountOptionsUpdateRequest;
import com.lbg.epscw.mortgagesrvc.restclient.MortgageAccountOptionRestClient;
import com.lbg.epscw.mortgagesrvc.util.MortgageServiceUtil;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.HashMap;
import java.util.Map;

import static org.junit.Assert.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.powermock.api.mockito.PowerMockito.when;

@RunWith(SpringRunner.class)
public class MortgageNominationServiceImplTest {

    public static final String MOCK_ACCOUNT_ID = "f76ca840-2553-d536-1ab8-9fa85c99db05";

    @Mock
    private MortgageAccountOptionRestClient mortgageAccountOptionRestClient;

    @Mock
    private MortgageServiceUtil mortgageServiceUtil;

    @InjectMocks
    private MortgageNominationServiceImpl mortgageNominationService;

    private final MortgageNominationHelper mortgageNominationHelper = new MortgageNominationHelper();

    @Test
    public void shouldAddNomination() {
        //given
        when(mortgageAccountOptionRestClient.updateAccountOptions(any(VaultAccountOptionsUpdateRequest.class)))
                .thenReturn(mortgageNominationHelper.getMockNominationUpdateResponse());
        when(mortgageServiceUtil.writeObjectAsString(any(Object.class))).thenReturn("{\"NominatedAdhocOverpaymentAccount\":\"f76ca840-2553-d536-1ab8-9fa85c99db05\"}");
        Map<String, String> objectMap = new HashMap<>();
        objectMap.put("NominatedAdhocOverpaymentAccount", "f76ca840-2553-d536-1ab8-9fa85c99db05");
        when(mortgageServiceUtil.readObject(any(String.class), any(Class.class))).thenReturn(objectMap);

        //when
        NominationResponse nominationResponse =
                mortgageNominationService.addNomination(mortgageNominationHelper.getNominationRequest(), MOCK_ACCOUNT_ID);

        //then
        assertEquals(MOCK_ACCOUNT_ID, nominationResponse.getAccountId());
        assertEquals("ACCOUNT_UPDATE_STATUS_PENDING_EXECUTION", nominationResponse.getStatus());
        assertEquals("90e804ab-5dad-7f7c-1d71-ab914545ebcc", nominationResponse.getAdditionalDetails().get("NominatedAdhocOverpaymentAccount"));
    }

    @Test
    public void shouldUpdateNomination() {
        //given
        when(mortgageAccountOptionRestClient.updateAccountOptions(any(VaultAccountOptionsUpdateRequest.class)))
                .thenReturn(mortgageNominationHelper.getMockNominationUpdateResponse());
        when(mortgageServiceUtil.writeObjectAsString(any(Object.class))).thenReturn("{\"NominatedAdhocOverpaymentAccount\":\"f76ca840-2553-d536-1ab8-9fa85c99db05\"}");
        Map<String, String> objectMap = new HashMap<>();
        objectMap.put("NominatedAdhocOverpaymentAccount", "f76ca840-2553-d536-1ab8-9fa85c99db05");
        when(mortgageServiceUtil.readObject(any(String.class), any(Class.class))).thenReturn(objectMap);

        //when
        NominationResponse nominationResponse =
                mortgageNominationService.updateNomination(mortgageNominationHelper.getNominationRequest(), MOCK_ACCOUNT_ID);

        //then
        assertEquals(MOCK_ACCOUNT_ID, nominationResponse.getAccountId());
        assertEquals("ACCOUNT_UPDATE_STATUS_PENDING_EXECUTION", nominationResponse.getStatus());
        assertEquals("90e804ab-5dad-7f7c-1d71-ab914545ebcc", nominationResponse.getAdditionalDetails().get("NominatedAdhocOverpaymentAccount"));
    }

    @Test
    public void shouldDeleteNomination() {
        //given
        when(mortgageAccountOptionRestClient.updateAccountOptions(any(VaultAccountOptionsUpdateRequest.class)))
                .thenReturn(mortgageNominationHelper.getMockNominationDeleteResponse());
        when(mortgageServiceUtil.writeObjectAsString(any(Object.class))).thenReturn("{\"NominatedAdhocOverpaymentAccount\":\"\"}");
        Map<String, String> objectMap = new HashMap<>();
        objectMap.put("NominatedAdhocOverpaymentAccount", "");
        when(mortgageServiceUtil.readObject(any(String.class), any(Class.class))).thenReturn(objectMap);

        //when
        NominationResponse nominationResponse =
                mortgageNominationService.deleteNomination(MOCK_ACCOUNT_ID);

        //then
        assertEquals(MOCK_ACCOUNT_ID, nominationResponse.getAccountId());
        assertEquals("ACCOUNT_UPDATE_STATUS_PENDING_EXECUTION", nominationResponse.getStatus());
        assertEquals("", nominationResponse.getAdditionalDetails().get("NominatedAdhocOverpaymentAccount"));
    }

    @Test(expected = CircuitBreakerOpenException.class)
    public void shouldThrowHystrixExceptionForFallbackUpdateNomination() {
        //then
        mortgageNominationService.fallbackUpdateNomination(mortgageNominationHelper.getNominationRequest(),
                MOCK_ACCOUNT_ID, new Exception("Circuit open on update nomination"));
    }

    @Test(expected = CircuitBreakerOpenException.class)
    public void shouldThrowHystrixExceptionForFallbackAddNomination() {
        //then
        mortgageNominationService.fallbackAddNomination(mortgageNominationHelper.getNominationRequest(),
                MOCK_ACCOUNT_ID, new Exception("Circuit open on add nomination"));
    }

    @Test(expected = CircuitBreakerOpenException.class)
    public void shouldThrowHystrixExceptionForFallbackDeleteNomination() {
        //then
        mortgageNominationService.fallbackDeleteNomination(
                MOCK_ACCOUNT_ID, new Exception("Circuit open on delete nomination"));
    }
}