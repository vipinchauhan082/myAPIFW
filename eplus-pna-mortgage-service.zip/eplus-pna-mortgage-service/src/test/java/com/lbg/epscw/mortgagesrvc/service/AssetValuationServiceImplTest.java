package com.lbg.epscw.mortgagesrvc.service;

import com.lbg.epscw.mortgagesrvc.exception.CircuitBreakerOpenException;
import com.lbg.epscw.mortgagesrvc.exception.MortgageServiceException;
import com.lbg.epscw.mortgagesrvc.model.*;
import com.lbg.epscw.mortgagesrvc.restclient.MortgagePortingApplicationAssetRestClient;
import com.lbg.epscw.mortgagesrvc.restclient.MortgagePortingApplicationInfoRestClient;
import org.junit.Before;
import org.junit.Test;

import static com.lbg.epscw.mortgagesrvc.helper.MortgagePortingHelper.APPLICATION_NUMBER;
import static com.lbg.epscw.mortgagesrvc.helper.MortgagePortingHelper.ASSET_NUMBER;
import static com.lbg.epscw.mortgagesrvc.model.MortgagePortingApplicationStatus.*;
import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

public class AssetValuationServiceImplTest {
    private MortgagePortingApplicationInfoRestClient applicationClient;
    private MortgagePortingApplicationAssetRestClient assetRestClient;
    private AssetValuationServiceImpl underTest;

    @Before
    public void setup() {
        applicationClient = mock(MortgagePortingApplicationInfoRestClient.class);
        assetRestClient = mock(MortgagePortingApplicationAssetRestClient.class);
        underTest = new AssetValuationServiceImpl(applicationClient, assetRestClient);
    }

    @Test
    public void update_application_success() {
        MortgageApplicationInfo expected = MortgageApplicationInfo.builder().status(VALUATION_RECEIVED).build();
        ValuationCriteria request = ValuationCriteria.builder().allocatedParkingSpace(true).build();
        Asset asset = Asset.builder().valuationCriteria(request).build();
        when(assetRestClient.getAssetByApplication(any())).thenReturn(asset);
        when(assetRestClient.updateAsset(any(), any())).thenReturn(asset);
        when(applicationClient.updateApplication(anyString(), any())).thenReturn(expected);
        PortingApplicationStatusResponse actual = underTest.captureAssetValuation(
                MortgageApplicationInfo.builder().applicationNumber(APPLICATION_NUMBER).assetId(ASSET_NUMBER).build(),
                AssetValuationRequest.builder().allocatedParkingSpace(true).build());
        assertThat(actual, is(PortingApplicationStatusResponse.builder().applicationNumber(APPLICATION_NUMBER).status(VALUATION_RECEIVED).build()));
    }

    @Test(expected = MortgageServiceException.class)
    public void update_application_status_fails() {
        MortgageApplicationInfo expected = MortgageApplicationInfo.builder().status(WELCOME_PACK_RECEIVED).build();
        ValuationCriteria request = ValuationCriteria.builder().allocatedParkingSpace(true).build();
        Asset asset = Asset.builder().valuationCriteria(request).build();
        when(assetRestClient.getAssetByApplication(any())).thenReturn(asset);
        when(assetRestClient.updateAsset(any(), any())).thenReturn(asset);
        when(applicationClient.updateApplication(anyString(), any())).thenReturn(expected);
        underTest.captureAssetValuation(MortgageApplicationInfo.builder().applicationNumber(APPLICATION_NUMBER).assetId(ASSET_NUMBER).build(),
                AssetValuationRequest.builder().allocatedParkingSpace(true).build());
    }

    @Test(expected = MortgageServiceException.class)
    public void update_asset_valuation_fails() {
        when(assetRestClient.getAssetByApplication(any())).thenReturn(Asset.builder().build());
        when(assetRestClient.updateAsset(any(), any())).thenReturn(Asset.builder().build());
        underTest.captureAssetValuation(MortgageApplicationInfo.builder().assetId(ASSET_NUMBER).applicationNumber(APPLICATION_NUMBER).build(),
                AssetValuationRequest.builder().allocatedParkingSpace(true).build());
    }

    @Test(expected = CircuitBreakerOpenException.class)
    public void update_fallback_throws_exception_on_broken_circuit() {
        MortgageApplicationInfo applicationInfo = MortgageApplicationInfo.builder().applicationNumber(APPLICATION_NUMBER).assetId(ASSET_NUMBER).build();
        AssetValuationRequest valuationRequest = AssetValuationRequest.builder().allocatedParkingSpace(true).build();
        underTest.fallbackCaptureAssetValuation(applicationInfo, valuationRequest, new IllegalArgumentException());
    }
}
