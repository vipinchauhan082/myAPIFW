package com.lbg.epscw.mortgagesrvc.filter;

import org.apache.logging.log4j.ThreadContext;
import org.junit.Test;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import java.io.IOException;

import static org.junit.Assert.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.powermock.api.mockito.PowerMockito.doNothing;
import static org.powermock.api.mockito.PowerMockito.mock;
import static org.powermock.api.mockito.PowerMockito.when;


public class LoggingFilterTest {

    @Test
    public void update_log_filter() throws IOException, ServletException {
        //given
        LoggingFilter filter = new LoggingFilter();
        HttpServletRequest request = mock(HttpServletRequest.class);
        ServletResponse response = mock(ServletResponse.class);
        FilterChain chain = mock(FilterChain.class);

        when(request.getHeader("X-Log-Level")).thenReturn("error");
        when(request.getHeader("x-lbg-txn-correlation-id")).thenReturn("1234");
        when(request.getHeader("x-lbg-brand")).thenReturn("IF");
        doNothing().when(chain).doFilter(any(), any());

        //when
        filter.doFilter(request, response, chain);

        //then
        assertEquals("error", ThreadContext.get("X-Log-Level"));
        assertEquals("1234", ThreadContext.get("correlation-id"));
        assertEquals("IF", ThreadContext.get("brand"));

    }
}
