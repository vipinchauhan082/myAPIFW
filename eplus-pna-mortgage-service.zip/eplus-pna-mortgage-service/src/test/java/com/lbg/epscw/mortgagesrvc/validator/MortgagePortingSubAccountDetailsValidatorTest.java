package com.lbg.epscw.mortgagesrvc.validator;


import com.lbg.epscw.mortgagesrvc.constants.CommonConstants;
import com.lbg.epscw.mortgagesrvc.dto.MortgageAccountInfo;
import com.lbg.epscw.mortgagesrvc.exception.MortgageValidationException;
import com.lbg.epscw.mortgagesrvc.helper.MortgagePortingHelper;
import com.lbg.epscw.mortgagesrvc.model.ApplicationMortgageDetailsUpdateRequest;
import com.lbg.epscw.mortgagesrvc.model.MortgageApplicationInfo;
import com.lbg.epscw.mortgagesrvc.model.MortgagePortingApplicationStatus;
import com.lbg.epscw.mortgagesrvc.restclient.MortgageAccountInfoRestClient;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.HashMap;

import static com.lbg.epscw.mortgagesrvc.model.MortgagePortingApplicationStatus.OPEN;
import static org.mockito.ArgumentMatchers.anyMap;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;

@RunWith(SpringRunner.class)
public class MortgagePortingSubAccountDetailsValidatorTest {

    @Mock
    private MortgageAccountInfoRestClient mortgageAccountInfoRestClient;


    @InjectMocks
    private MortgagePortingSubAccountDetailsValidator mortgagePortingSubAccountDetailsValidator;

    private final MortgagePortingHelper portingHelper = new MortgagePortingHelper();


    @Test(expected = MortgageValidationException.class)
    public void validate_application_status(){

        mortgagePortingSubAccountDetailsValidator.validate(portingHelper.mortgageApplicationInfoWithStatus(MortgagePortingApplicationStatus.DECLINED.name()),portingHelper.applicationMortgageDetailsUpdateRequestPayload(),new HashMap<>());

    }


    @Test(expected = MortgageValidationException.class)
    public void validate_loan_amount(){

        ApplicationMortgageDetailsUpdateRequest applicationMortgageDetailsUpdateRequest = portingHelper.applicationMortgageDetailsUpdateRequestPayload();
        applicationMortgageDetailsUpdateRequest.getSubAccountDetails().get(0).setLoanAmount("200");
        mortgagePortingSubAccountDetailsValidator.validate(portingHelper.mortgageApplicationInfoWithStatus(MortgagePortingApplicationStatus.OPEN.name()),applicationMortgageDetailsUpdateRequest,new HashMap<>());

    }


    @Test(expected = MortgageValidationException.class)
    public void validate_product_id(){

        ApplicationMortgageDetailsUpdateRequest applicationMortgageDetailsUpdateRequest = portingHelper.applicationMortgageDetailsUpdateRequestPayload();
        applicationMortgageDetailsUpdateRequest.getSubAccountDetails().get(0).setProductId("if_mortgage");





        MortgageApplicationInfo mortgageApplicationInfo = portingHelper.mortgageApplicationInfoWithStatus(OPEN.name());
        mortgageApplicationInfo.setPreviousMortgageNumber("mortgageNumber");

        when(mortgageAccountInfoRestClient.getMortgageInfoByMortgageNumber(anyString(),anyMap())).thenReturn(portingHelper.buildMortgageAccountInfo(false));
        mortgagePortingSubAccountDetailsValidator.validate(mortgageApplicationInfo,applicationMortgageDetailsUpdateRequest,new HashMap<>());

    }


    @Test(expected = MortgageValidationException.class)
    public void validate_existing_mortgage_details(){

        ApplicationMortgageDetailsUpdateRequest applicationMortgageDetailsUpdateRequest = portingHelper.applicationMortgageDetailsUpdateRequestPayload();
        applicationMortgageDetailsUpdateRequest.getSubAccountDetails().get(0).setProductId("if_mortgage");





        MortgageApplicationInfo mortgageApplicationInfo = portingHelper.mortgageApplicationInfoWithStatus(OPEN.name());
        mortgageApplicationInfo.setPreviousMortgageNumber("mortgageNumber");

        MortgageAccountInfo mortgageAccountInfo = portingHelper.buildMortgageAccountInfo(false);
        mortgageAccountInfo.getMortgageAccountData().get(0).setProductFamily("Mortgage Payment");
        when(mortgageAccountInfoRestClient.getMortgageInfoByMortgageNumber(anyString(),anyMap())).thenReturn(mortgageAccountInfo);
        mortgagePortingSubAccountDetailsValidator.validate(mortgageApplicationInfo,applicationMortgageDetailsUpdateRequest,new HashMap<>());

    }

    @Test
    public void validate_is_successful_all_check_matches() {
        ApplicationMortgageDetailsUpdateRequest applicationMortgageDetailsUpdateRequest = portingHelper.applicationMortgageDetailsUpdateRequestPayload();
        applicationMortgageDetailsUpdateRequest.getSubAccountDetails().get(0).setProductId(CommonConstants.PRODUCT_ID_LBG_MORTGAGE_REPAYMENT);

        MortgageApplicationInfo mortgageApplicationInfo = portingHelper.mortgageApplicationInfoWithStatus(OPEN.name());
        mortgageApplicationInfo.setPreviousMortgageNumber("mortgageNumber");

        when(mortgageAccountInfoRestClient.getMortgageInfoByMortgageNumber(anyString(),anyMap())).thenReturn(portingHelper.buildMortgageAccountInfo(false));
        mortgagePortingSubAccountDetailsValidator.validate(mortgageApplicationInfo,applicationMortgageDetailsUpdateRequest,new HashMap<>());
    }
}
