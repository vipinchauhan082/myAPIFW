package com.lbg.epscw.mortgagesrvc.handler;

import com.fasterxml.jackson.databind.exc.UnrecognizedPropertyException;
import com.lbg.epscw.accessvalidation.exception.AccessValidationException;
import com.lbg.epscw.entitlement.exception.EntitlementValidationException;
import com.lbg.epscw.handler.constants.SystemErrors;
import com.lbg.epscw.handler.exception.RestServiceException;
import com.lbg.epscw.handler.model.ErrorInfo;
import com.lbg.epscw.handler.model.ErrorResponse;
import com.lbg.epscw.mortgagesrvc.exception.InvalidUpdateRequestException;
import org.junit.Test;
import org.mockito.Mockito;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.security.authentication.AuthenticationServiceException;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.web.HttpRequestMethodNotSupportedException;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.MissingRequestHeaderException;
import org.springframework.web.servlet.NoHandlerFoundException;

import javax.servlet.http.HttpServletRequest;
import javax.validation.ValidationException;
import java.util.Arrays;

import static com.lbg.epscw.mortgagesrvc.constants.CommonConstants.FREQUENCY;
import static com.lbg.epscw.mortgagesrvc.constants.CommonConstants.LIMIT;
import static org.junit.Assert.assertEquals;
import static org.powermock.api.mockito.PowerMockito.mock;
import static org.powermock.api.mockito.PowerMockito.when;


public class GlobalExceptionHandlerTest {

    private GlobalExceptionHandler handler = new GlobalExceptionHandler();
    public static final String BEST_MATCHING_PATTERN_ATTRIBUTE = "org.springframework.web.servlet.HandlerMapping.bestMatchingPattern";


    @Test
    public void verify_InvalidUpdateRequestException_handler() {
        //given
        InvalidUpdateRequestException exception = mock(InvalidUpdateRequestException.class);
        when(exception.getField()).thenReturn(FREQUENCY);
        when(exception.getErrorType()).thenReturn(LIMIT);
        when(exception.getErrorCode()).thenReturn("BUS.601");
        when(exception.getHttpStatus()).thenReturn(HttpStatus.BAD_REQUEST);
        HttpServletRequest request = Mockito.mock(HttpServletRequest.class);
        when(request.getAttribute(BEST_MATCHING_PATTERN_ATTRIBUTE)).thenReturn("/accounts");
        when(request.getMethod()).thenReturn("GET");

        //when
        ResponseEntity<ErrorResponse> response = handler.handleBaseServiceException(exception, request);
        ErrorResponse errorResponse = response.getBody();
        ErrorInfo error = errorResponse.getErrors().get(0);

        //then
        assertEquals("PNA.MORTGAGE_API.GET_ACCOUNTS.Frequency.Limit", error.getReasonCode());
    }

    @Test
    public void verify_MethodArgumentNotValidException_handler() {
        //given
        MethodArgumentNotValidException methodArgumentNotValidException =
                mock(MethodArgumentNotValidException.class);
        BindingResult bindingResult = mock(BindingResult.class);
        FieldError fieldError1 = mock(FieldError.class);
        when(fieldError1.getField()).thenReturn("Data");
        when(fieldError1.getDefaultMessage()).thenReturn("has Bad value");
        FieldError fieldError2 = mock(FieldError.class);
        when(fieldError2.getField()).thenReturn("Account");
        when(fieldError2.getDefaultMessage()).thenReturn("has Bad value");
        when(methodArgumentNotValidException.getBindingResult()).thenReturn(bindingResult);
        when(bindingResult.getFieldErrors()).thenReturn(Arrays.asList(fieldError1, fieldError2));
        HttpServletRequest request = Mockito.mock(HttpServletRequest.class);
        when(request.getAttribute(BEST_MATCHING_PATTERN_ATTRIBUTE)).thenReturn("/accounts");
        when(request.getMethod()).thenReturn("GET");

        //when
        ResponseEntity<ErrorResponse> response =
                handler.handleException(methodArgumentNotValidException, request);
        ErrorResponse errorResponse = response.getBody();
        ErrorInfo error1 = errorResponse.getErrors().get(0);
        ErrorInfo error2 = errorResponse.getErrors().get(1);

        //then
        assertEquals("PNA.MORTGAGE_API.SYS.001", errorResponse.getCode());
        assertEquals("PNA.MORTGAGE_API.GET_ACCOUNTS.Argument.Invalid", error1.getReasonCode());
        assertEquals("Data has Bad value", error1.getMessage());
        assertEquals("PNA.MORTGAGE_API.GET_ACCOUNTS.Argument.Invalid", error2.getReasonCode());
        assertEquals("Account has Bad value", error2.getMessage());
    }

    @Test
    public void verify_UnrecognizedPropertyException_handler() {
        //given
        UnrecognizedPropertyException exception = mock(UnrecognizedPropertyException.class);
        when(exception.getPropertyName()).thenReturn("AccountId");
        HttpServletRequest request = Mockito.mock(HttpServletRequest.class);
        when(request.getAttribute(BEST_MATCHING_PATTERN_ATTRIBUTE)).thenReturn("/accounts");
        when(request.getMethod()).thenReturn("GET");

        //when
        ResponseEntity<ErrorResponse> response = handler.handleException(exception, request);
        ErrorResponse errorResponse = response.getBody();
        ErrorInfo error = errorResponse.getErrors().get(0);

        //then
        assertEquals("PNA.MORTGAGE_API.GET_ACCOUNTS.Json.Property.Unrecognized", error.getReasonCode());
        assertEquals("PNA.MORTGAGE_API.SYS.001", errorResponse.getCode());
        assertEquals("JSON parse error: Unrecognized field AccountId", error.getMessage());
    }

    @Test
    public void verify_HttpMessageNotReadableException_handler() {
        //given
        HttpMessageNotReadableException exception = mock(HttpMessageNotReadableException.class);
        when(exception.getMessage()).thenReturn("AccountId not readable(class");
        HttpServletRequest request = Mockito.mock(HttpServletRequest.class);
        when(request.getAttribute(BEST_MATCHING_PATTERN_ATTRIBUTE)).thenReturn("/accounts");
        when(request.getMethod()).thenReturn("GET");

        //when
        ResponseEntity<ErrorResponse> response =
                handler.handleException(exception, request);
        ErrorResponse errorResponse = response.getBody();
        ErrorInfo error = errorResponse.getErrors().get(0);

        //then
        assertEquals("PNA.MORTGAGE_API.GET_ACCOUNTS.Message.NotReadable", error.getReasonCode());
        assertEquals("PNA.MORTGAGE_API.SYS.001", errorResponse.getCode());
        assertEquals("AccountId not readable", error.getMessage());
    }

    @Test
    public void verify_AuthenticationServiceException_handler() {
        //given
        AuthenticationServiceException exception = new AuthenticationServiceException("Token missing");
        HttpServletRequest request = Mockito.mock(HttpServletRequest.class);
        when(request.getAttribute(BEST_MATCHING_PATTERN_ATTRIBUTE)).thenReturn("/accounts");
        when(request.getMethod()).thenReturn("GET");

        //when
        ResponseEntity<ErrorResponse> response =
                handler.handleAuthenticationServiceException(exception, request);
        ErrorResponse errorResponse = response.getBody();
        ErrorInfo error = errorResponse.getErrors().get(0);

        //then
        assertEquals("PNA.MORTGAGE_API.GET_ACCOUNTS.Unauthorized.Authentication", error.getReasonCode());
        assertEquals("PNA.MORTGAGE_API.SYS.002", errorResponse.getCode());
        assertEquals("Token missing", error.getMessage());
    }

    @Test
    public void verify_HttpMessageNotReadableException_handler_with_message_type_2() {
        //given
        HttpMessageNotReadableException exception = mock(HttpMessageNotReadableException.class);
        when(exception.getMessage()).thenReturn("Request body cannot be null; for method void test(String s) in Controller");
        HttpServletRequest request = Mockito.mock(HttpServletRequest.class);
        when(request.getAttribute(BEST_MATCHING_PATTERN_ATTRIBUTE)).thenReturn("/accounts");
        when(request.getMethod()).thenReturn("GET");

        //when
        ResponseEntity<ErrorResponse> response =
                handler.handleException(exception, request);
        ErrorResponse errorResponse = response.getBody();
        ErrorInfo error = errorResponse.getErrors().get(0);

        //then
        assertEquals("PNA.MORTGAGE_API.GET_ACCOUNTS.Message.NotReadable", error.getReasonCode());
        assertEquals("PNA.MORTGAGE_API.SYS.001", errorResponse.getCode());
        assertEquals("Request body cannot be null", error.getMessage());
    }


    @Test
    public void verify_HttpMessageNotReadableException_handler_with_message_type_3() {
        //given
        HttpMessageNotReadableException exception = mock(HttpMessageNotReadableException.class);
        when(exception.getMessage()).thenReturn("Required request body is missing: public org.springframework.http.ResponseEntity<com.lbg.epscw.accountsrvc.model.accountParam.ViewAccountDetails> com.lbg.epscw.accountsrvc.controller.VaultController.updateAccount");
        HttpServletRequest request = Mockito.mock(HttpServletRequest.class);
        when(request.getAttribute(BEST_MATCHING_PATTERN_ATTRIBUTE)).thenReturn("/accounts");
        when(request.getMethod()).thenReturn("GET");

        //when
        ResponseEntity<ErrorResponse> response =
                handler.handleException(exception, request);
        ErrorResponse errorResponse = response.getBody();
        ErrorInfo error = errorResponse.getErrors().get(0);

        //then
        assertEquals("PNA.MORTGAGE_API.GET_ACCOUNTS.Message.NotReadable", error.getReasonCode());
        assertEquals("PNA.MORTGAGE_API.SYS.001", errorResponse.getCode());
        assertEquals("Required request body is missing", error.getMessage());
    }

    @Test
    public void verify_IllegalArgumentException_handler() {
        //given
        IllegalArgumentException exception = mock(IllegalArgumentException.class);
        when(exception.getMessage()).thenReturn("Illegal argument");
        HttpServletRequest request = Mockito.mock(HttpServletRequest.class);
        when(request.getAttribute(BEST_MATCHING_PATTERN_ATTRIBUTE)).thenReturn("/accounts");
        when(request.getMethod()).thenReturn("GET");

        //when
        ResponseEntity<ErrorResponse> response = handler.handleException(exception, request);
        ErrorResponse errorResponse = response.getBody();
        ErrorInfo error = errorResponse.getErrors().get(0);

        //then
        assertEquals("PNA.MORTGAGE_API.GET_ACCOUNTS.Runtime.Error", error.getReasonCode());
        assertEquals("PNA.MORTGAGE_API.SYS.001", errorResponse.getCode());
        assertEquals("Illegal argument", error.getMessage());
    }


    @Test
    public void verify_HttpMediaTypeNotSupportedException_handler() {

        //given
        HttpServletRequest request = Mockito.mock(HttpServletRequest.class);
        when(request.getAttribute(BEST_MATCHING_PATTERN_ATTRIBUTE)).thenReturn("/accounts");
        when(request.getMethod()).thenReturn("GET");

        //when
        ResponseEntity<ErrorResponse> response = handler.handleUnsupportedMediaException(request);
        ErrorResponse error = response.getBody();

        //then
        assertEquals("PNA.MORTGAGE_API.SYS.005", error.getCode());
        assertEquals("Media type not supported", error.getMessage());
    }

    @Test
    public void verify_HttpRequestMethodNotSupportedException_handler() {
        //given
        HttpRequestMethodNotSupportedException exception =
                mock(HttpRequestMethodNotSupportedException.class);
        when(exception.getSupportedMethods()).thenReturn(new String[]{"GET"});
        HttpServletRequest request = Mockito.mock(HttpServletRequest.class);
        when(request.getAttribute(BEST_MATCHING_PATTERN_ATTRIBUTE)).thenReturn("/accounts");
        when(request.getMethod()).thenReturn("GET");

        //when
        ResponseEntity<ErrorResponse> response = handler.handleException(exception, request);
        ErrorResponse errorResponse = response.getBody();
        ErrorInfo error = errorResponse.getErrors().get(0);

        //then
        assertEquals("PNA.MORTGAGE_API.GET_ACCOUNTS.Method.NotSupported", error.getReasonCode());
        assertEquals("PNA.MORTGAGE_API.SYS.001", errorResponse.getCode());
        assertEquals("Supported http method for this service is GET", error.getMessage());
    }

    @Test
    public void verify_NoHandlerFoundException_handler() {
        //given
        NoHandlerFoundException exception =
                mock(NoHandlerFoundException.class);
        when(exception.getMessage()).thenReturn("No Handler found for");
        HttpServletRequest request = Mockito.mock(HttpServletRequest.class);
        when(request.getAttribute(BEST_MATCHING_PATTERN_ATTRIBUTE)).thenReturn("/accounts");
        when(request.getMethod()).thenReturn("GET");

        //when
        ResponseEntity<ErrorResponse> response = handler.handleNotFoundException(exception, request);
        ErrorResponse errorResponse = response.getBody();
        ErrorInfo error = errorResponse.getErrors().get(0);

        //then
        assertEquals("PNA.MORTGAGE_API.GET_ACCOUNTS.Handler.NotFound", error.getReasonCode());
        assertEquals("PNA.MORTGAGE_API.SYS.004", errorResponse.getCode());
        assertEquals("No Handler found for", error.getMessage());
    }

    @Test
    public void verify_ValidationException_handler() {
        //given
        Exception reqValidationException = mock(Exception.class);
        when(reqValidationException.getMessage()).thenReturn("Validation failed");
        ValidationException exception = mock(ValidationException.class);
        when(exception.getCause()).thenReturn(reqValidationException);
        HttpServletRequest request = Mockito.mock(HttpServletRequest.class);
        when(request.getAttribute(BEST_MATCHING_PATTERN_ATTRIBUTE)).thenReturn("/accounts");
        when(request.getMethod()).thenReturn("GET");

        //when
        ResponseEntity<ErrorResponse> response = handler.handleException(exception, request);
        ErrorResponse errorResponse = response.getBody();
        ErrorInfo error = errorResponse.getErrors().get(0);

        //then
        assertEquals("PNA.MORTGAGE_API.GET_ACCOUNTS.Validation.Exception", error.getReasonCode());
        assertEquals("PNA.MORTGAGE_API.SYS.001", errorResponse.getCode());
        assertEquals("Validation failed", error.getMessage());
    }

    @Test
    public void verify_RuntimeException_handler() {
        //given
        RuntimeException exception = mock(RuntimeException.class);
        when(exception.getMessage()).thenReturn("Internal server error");
        HttpServletRequest request = Mockito.mock(HttpServletRequest.class);
        when(request.getAttribute(BEST_MATCHING_PATTERN_ATTRIBUTE)).thenReturn("/accounts");
        when(request.getMethod()).thenReturn("GET");

        //when
        ResponseEntity<ErrorResponse> response = handler.handleRuntimeException(exception, request);
        ErrorResponse errorResponse = response.getBody();
        ErrorInfo error = errorResponse.getErrors().get(0);

        //then
        assertEquals("PNA.MORTGAGE_API.GET_ACCOUNTS.Runtime.Error", error.getReasonCode());
        assertEquals("PNA.MORTGAGE_API.SYS.006", errorResponse.getCode());
        assertEquals("Internal server error", error.getMessage());
    }

    @Test
    public void verify_AccessDeniedException_handler() {
        //given
        AccessDeniedException exception = mock(AccessDeniedException.class);
        when(exception.getMessage()).thenReturn("Access denied");
        HttpServletRequest request = Mockito.mock(HttpServletRequest.class);
        when(request.getAttribute(BEST_MATCHING_PATTERN_ATTRIBUTE)).thenReturn("/accounts");
        when(request.getMethod()).thenReturn("GET");

        //when
        ResponseEntity<ErrorResponse> response = handler.handleAccessDeniedException(exception, request);
        ErrorResponse errorResponse = response.getBody();
        ErrorInfo error = errorResponse.getErrors().get(0);

        //then
        assertEquals("PNA.MORTGAGE_API.SYS.003", errorResponse.getCode());
        assertEquals("PNA.MORTGAGE_API.GET_ACCOUNTS.Access.Forbidden", error.getReasonCode());
        assert (error.getMessage().contains("Access denied"));
    }

    @Test
    public void verify_EntitlementValidationException_handler() {
        //given
        EntitlementValidationException exception = mock(EntitlementValidationException.class);
        when(exception.getMessage()).thenReturn("Entitlement Validation Exception");
        HttpServletRequest request = Mockito.mock(HttpServletRequest.class);
        when(request.getAttribute(BEST_MATCHING_PATTERN_ATTRIBUTE)).thenReturn("/accounts");
        when(request.getMethod()).thenReturn("GET");

        //when
        ResponseEntity<ErrorResponse> response = handler.handleException(exception, request);
        ErrorResponse errorResponse = response.getBody();
        ErrorInfo error = errorResponse.getErrors().get(0);

        //then
        assertEquals("PNA.MORTGAGE_API.GET_ACCOUNTS.Runtime.Error", error.getReasonCode());
        assertEquals("PNA.MORTGAGE_API.SYS.001", errorResponse.getCode());
        assertEquals("Entitlement Validation Exception", error.getMessage());
    }

    @Test
    public void verify_AccessValidationException_handler() {
        //given
        AccessValidationException exception = mock(AccessValidationException.class);
        when(exception.getMessage()).thenReturn("Access Validation Exception");
        HttpServletRequest request = Mockito.mock(HttpServletRequest.class);
        when(request.getAttribute(BEST_MATCHING_PATTERN_ATTRIBUTE)).thenReturn("/accounts");
        when(request.getMethod()).thenReturn("GET");

        //when
        ResponseEntity<ErrorResponse> response = handler.handleAccessValidationException(exception, request);
        ErrorResponse errorResponse = response.getBody();
        ErrorInfo error = errorResponse.getErrors().get(0);

        //then
        assertEquals("PNA.MORTGAGE_API.GET_ACCOUNTS.Access.Unauthorised", error.getReasonCode());
        assertEquals("PNA.MORTGAGE_API.SYS.002", errorResponse.getCode());
        assertEquals("Access Validation Exception", error.getMessage());
    }

    @Test
    public void verify_MissingRequestHeaderException_handler() {
        //given
        MissingRequestHeaderException exception = new MissingRequestHeaderException("x-lbg-brand", null);
        HttpServletRequest request = Mockito.mock(HttpServletRequest.class);
        when(request.getAttribute(BEST_MATCHING_PATTERN_ATTRIBUTE)).thenReturn("/accounts");
        when(request.getMethod()).thenReturn("GET");

        //when
        ResponseEntity<ErrorResponse> response = handler.handleException(exception, request);
        ErrorResponse errorResponse = response.getBody();
        ErrorInfo error = errorResponse.getErrors().get(0);

        //then
        assertEquals("PNA.MORTGAGE_API.GET_ACCOUNTS.Header.Missing.x-lbg-brand", error.getReasonCode());
        assertEquals("PNA.MORTGAGE_API.SYS.001", errorResponse.getCode());
        assertEquals("Missing request header 'x-lbg-brand' for method parameter of type String", error.getMessage());
    }

    @Test
    public void verify_RestServiceException_handler() {
        //given
        RestServiceException exception = new RestServiceException(SystemErrors.NOT_FOUND.getErrorCode(), HttpStatus.NOT_FOUND, ".Product.NotFound", "Product not found");
        HttpServletRequest request = Mockito.mock(HttpServletRequest.class);
        when(request.getAttribute(BEST_MATCHING_PATTERN_ATTRIBUTE)).thenReturn("/accounts");
        when(request.getMethod()).thenReturn("GET");

        //when
        ResponseEntity<ErrorResponse> response = handler.handleRestServiceException(exception, request);
        ErrorResponse errorResponse = response.getBody();
        ErrorInfo error = errorResponse.getErrors().get(0);

        //then
        assertEquals("PNA.MORTGAGE_API.SYS.004", errorResponse.getCode());
        assertEquals("PNA.MORTGAGE_API.GET_ACCOUNTS.Product.NotFound", error.getReasonCode());
        assertEquals("Product not found", error.getMessage());
    }


}
