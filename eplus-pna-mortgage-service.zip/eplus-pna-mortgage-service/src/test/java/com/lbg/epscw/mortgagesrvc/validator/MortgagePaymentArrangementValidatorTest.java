package com.lbg.epscw.mortgagesrvc.validator;

import com.lbg.epscw.mortgagesrvc.dto.MortgageAccountInfo;
import com.lbg.epscw.mortgagesrvc.exception.InvalidUpdateRequestException;
import com.lbg.epscw.mortgagesrvc.exception.VaultValidationException;
import com.lbg.epscw.mortgagesrvc.helper.MortgagePaymentArrangementDataHelper;
import com.lbg.epscw.mortgagesrvc.helper.SetupMortgageHelper;
import com.lbg.epscw.mortgagesrvc.model.*;
import com.lbg.epscw.mortgagesrvc.restclient.MortgageAccountInfoRestClient;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.HashMap;
import java.util.Map;

import static org.mockito.ArgumentMatchers.any;
import static org.powermock.api.mockito.PowerMockito.mock;
import static org.powermock.api.mockito.PowerMockito.when;

@RunWith(SpringRunner.class)
public class MortgagePaymentArrangementValidatorTest {

    @Mock
    private MortgageAccountInfoRestClient mortgageAccountInfoRestClient;

    private String accountId="ceabb62f-ee67-85da-fb0d-00415c349f89";


    @Before
    public void setup() {
       mortgageAccountInfoRestClient = mock(MortgageAccountInfoRestClient.class);
    }

    private MortgagePaymentArrangementDataHelper mortgagePaymentArrangementDataHelper = new MortgagePaymentArrangementDataHelper();
    private SetupMortgageHelper setupMortgageHelper = new SetupMortgageHelper();

    @Test(expected = InvalidUpdateRequestException.class)
    public void validate_update_payment_arrangement_request_when_payment_arrangement_not_exist(){
        //given
        PaymentArrangementUpdateRequest paymentArrangementUpdateRequest= mortgagePaymentArrangementDataHelper.buildPaymentArrangementUpdateRequestAmendAmount("100");
        MortgageAccountInfo mortgageAccountInfo= mortgagePaymentArrangementDataHelper.mortgageAccountInfoWithPaymentArrangement(false);
        Map<String,String> reqMap= new HashMap<>();
        MortgagePaymentArrangementValidator mortgagePaymentArrangementValidator = new MortgagePaymentArrangementValidator(mortgageAccountInfoRestClient);
        //when
        when(mortgageAccountInfoRestClient.getMortgageAccountInfo(any(String.class), any())).thenReturn(mortgageAccountInfo);
        mortgagePaymentArrangementValidator.validateUpdatePaymentArrangementRequest(paymentArrangementUpdateRequest, accountId, reqMap);

    }

    @Test(expected = InvalidUpdateRequestException.class)
    public void validate_update_payment_arrangement_request_when_payment_arrangement_exist_with_past_start_date(){
        //given
        PaymentArrangementUpdateRequest paymentArrangementUpdateRequest= mortgagePaymentArrangementDataHelper.buildPaymentArrangementUpdateRequestWithPastStartDate();
        MortgageAccountInfo mortgageAccountInfo= mortgagePaymentArrangementDataHelper.mortgageAccountInfoWithPaymentArrangementWithExpiredEndDate();
        Map<String,String> reqMap= new HashMap<>();
        MortgagePaymentArrangementValidator mortgagePaymentArrangementValidator = new MortgagePaymentArrangementValidator(mortgageAccountInfoRestClient);
        //when
        when(mortgageAccountInfoRestClient.getMortgageAccountInfo(any(String.class), any())).thenReturn(mortgageAccountInfo);
        mortgagePaymentArrangementValidator.validateUpdatePaymentArrangementRequest(paymentArrangementUpdateRequest, accountId, reqMap);
    }

    @Test(expected = InvalidUpdateRequestException.class)
    public void validate_update_payment_arrangement_request_when_payment_arrangement_exist_with_start_date_greater(){
        //given
        PaymentArrangementUpdateRequest paymentArrangementUpdateRequest= mortgagePaymentArrangementDataHelper.buildPaymentArrangementUpdateRequestWithGreaterStartDate();
        MortgageAccountInfo mortgageAccountInfo= mortgagePaymentArrangementDataHelper.mortgageAccountInfoWithPaymentArrangementWithExpiredEndDate();
        Map<String,String> reqMap= new HashMap<>();
        MortgagePaymentArrangementValidator mortgagePaymentArrangementValidator = new MortgagePaymentArrangementValidator(mortgageAccountInfoRestClient);
        //when
        when(mortgageAccountInfoRestClient.getMortgageAccountInfo(any(String.class), any())).thenReturn(mortgageAccountInfo);
        mortgagePaymentArrangementValidator.validateUpdatePaymentArrangementRequest(paymentArrangementUpdateRequest, accountId, reqMap);
    }

    @Test(expected = InvalidUpdateRequestException.class)
    public void validate_update_payment_arrangement_request_when_payment_arrangement_exist_with_past_end_date(){
        //given
        PaymentArrangementUpdateRequest paymentArrangementUpdateRequest= mortgagePaymentArrangementDataHelper.buildPaymentArrangementUpdateRequestWithPastEndDate();
        MortgageAccountInfo mortgageAccountInfo= mortgagePaymentArrangementDataHelper.mortgageAccountInfoWithPaymentArrangementWithExpiredEndDate();
        Map<String,String> reqMap= new HashMap<>();
        MortgagePaymentArrangementValidator mortgagePaymentArrangementValidator = new MortgagePaymentArrangementValidator(mortgageAccountInfoRestClient);
        //when
        when(mortgageAccountInfoRestClient.getMortgageAccountInfo(any(String.class), any())).thenReturn(mortgageAccountInfo);
        mortgagePaymentArrangementValidator.validateUpdatePaymentArrangementRequest(paymentArrangementUpdateRequest, accountId, reqMap);
    }

    @Test(expected = InvalidUpdateRequestException.class)
    public void validate_update_payment_arrangement_request_when_new_end_date_is_after_actual_end_date(){
        //given
        PaymentArrangementUpdateRequest paymentArrangementUpdateRequest= mortgagePaymentArrangementDataHelper.buildPaymentArrangementUpdateRequestWithEndDateAfter();
        MortgageAccountInfo mortgageAccountInfo= mortgagePaymentArrangementDataHelper.mortgageAccountInfoWithPaymentArrangement();
        Map<String,String> reqMap= new HashMap<>();
        MortgagePaymentArrangementValidator mortgagePaymentArrangementValidator = new MortgagePaymentArrangementValidator(mortgageAccountInfoRestClient);
        //when
        when(mortgageAccountInfoRestClient.getMortgageAccountInfo(any(String.class), any())).thenReturn(mortgageAccountInfo);
        mortgagePaymentArrangementValidator.validateUpdatePaymentArrangementRequest(paymentArrangementUpdateRequest, accountId, reqMap);

    }

    @Test(expected = InvalidUpdateRequestException.class)
    public void validate_update_payment_arrangement_request_when_payment_arrangement_exist_with_invalid_type(){
        //gievn
        PaymentArrangementUpdateRequest paymentArrangementUpdateRequest= mortgagePaymentArrangementDataHelper.buildPaymentArrangementUpdateRequestAmendAmount("100");
        MortgageAccountInfo mortgageAccountInfo= mortgagePaymentArrangementDataHelper.mortgageAccountInfoWithInvalidPaymentArrangementType();
        Map<String,String> reqMap= new HashMap<>();
        MortgagePaymentArrangementValidator mortgagePaymentArrangementValidator = new MortgagePaymentArrangementValidator(mortgageAccountInfoRestClient);
        //when
        when(mortgageAccountInfoRestClient.getMortgageAccountInfo(any(String.class), any())).thenReturn(mortgageAccountInfo);
        mortgagePaymentArrangementValidator.validateUpdatePaymentArrangementRequest(paymentArrangementUpdateRequest, accountId, reqMap);

    }


    @Test(expected = InvalidUpdateRequestException.class)
    public void validate_update_payment_arrangement_request_when_account_is_not_sub_account(){
        //given
        PaymentArrangementUpdateRequest paymentArrangementUpdateRequest= mortgagePaymentArrangementDataHelper.buildPaymentArrangementUpdateRequestAmendAmount("100");
        MortgageAccountInfo mortgageAccountInfo= mortgagePaymentArrangementDataHelper.mortgageQueryServiceAccountInfoWithAndWithoutSubaccount(false);
        Map<String,String> reqMap= new HashMap<>();
        MortgagePaymentArrangementValidator mortgagePaymentArrangementValidator = new MortgagePaymentArrangementValidator(mortgageAccountInfoRestClient);
        //when
        when(mortgageAccountInfoRestClient.getMortgageAccountInfo(any(String.class), any())).thenReturn(mortgageAccountInfo);
        mortgagePaymentArrangementValidator.validateUpdatePaymentArrangementRequest(paymentArrangementUpdateRequest, accountId, reqMap);

    }

    @Test
    public void validate_update_payment_arrangement_request_when_account_is_sub_account_and_payment_arrangement_exist(){
        //give
        PaymentArrangementUpdateRequest paymentArrangementUpdateRequest= mortgagePaymentArrangementDataHelper.buildPaymentArrangementUpdateRequestAmendAmount("100");

        MortgageAccountInfo mortgageAccountInfo= mortgagePaymentArrangementDataHelper.mortgageQueryServiceAccountInfoWithAndWithoutSubaccount(true);
        Map<String,String> reqMap= new HashMap<>();
        MortgagePaymentArrangementValidator mortgagePaymentArrangementValidator = new MortgagePaymentArrangementValidator(mortgageAccountInfoRestClient);
        //when
        when(mortgageAccountInfoRestClient.getMortgageAccountInfo(any(String.class), any())).thenReturn(mortgageAccountInfo);
        mortgagePaymentArrangementValidator.validateUpdatePaymentArrangementRequest(paymentArrangementUpdateRequest, accountId, reqMap);

    }

    @Test(expected = InvalidUpdateRequestException.class)
    public void validate_update_payment_arrangement_request_when_end_date_is_past_date(){
        //given
        PaymentArrangementUpdateRequest paymentArrangementUpdateRequest= mortgagePaymentArrangementDataHelper.buildPaymentArrangementUpdateRequestAmendAmountAndEndDate("100", "2020-07-20");
        MortgageAccountInfo mortgageAccountInfo= mortgagePaymentArrangementDataHelper.mortgageQueryServiceAccountInfoWithAndWithoutSubaccount(true);
        Map<String,String> reqMap= new HashMap<>();
        MortgagePaymentArrangementValidator mortgagePaymentArrangementValidator = new MortgagePaymentArrangementValidator(mortgageAccountInfoRestClient);
        //when
        when(mortgageAccountInfoRestClient.getMortgageAccountInfo(any(String.class), any())).thenReturn(mortgageAccountInfo);
        mortgagePaymentArrangementValidator.validateUpdatePaymentArrangementRequest(paymentArrangementUpdateRequest, accountId, reqMap);

    }

    @Test(expected = InvalidUpdateRequestException.class)
    public void validate_update_payment_arrangement_request_when_end_date_is_not_in_correct_format(){
        //given
        PaymentArrangementUpdateRequest paymentArrangementUpdateRequest= mortgagePaymentArrangementDataHelper.buildPaymentArrangementUpdateRequestAmendAmountAndEndDate("100", "2020-07-20");
        MortgageAccountInfo mortgageAccountInfo= mortgagePaymentArrangementDataHelper.mortgageQueryServiceAccountInfoWithAndWithoutSubaccount(true);
        Map<String,String> reqMap= new HashMap<>();
        MortgagePaymentArrangementValidator mortgagePaymentArrangementValidator = new MortgagePaymentArrangementValidator(mortgageAccountInfoRestClient);
        //when
        when(mortgageAccountInfoRestClient.getMortgageAccountInfo(any(String.class), any())).thenReturn(mortgageAccountInfo);
        mortgagePaymentArrangementValidator.validateUpdatePaymentArrangementRequest(paymentArrangementUpdateRequest, accountId, reqMap);

    }

    @Test(expected = VaultValidationException.class)
    public void validate_update_payment_arrangement_request_when_amount_is_not_in_number_format(){
        //given
        PaymentArrangementUpdateRequest paymentArrangementUpdateRequest= mortgagePaymentArrangementDataHelper.buildPaymentArrangementUpdateRequestAmendAmountAndEndDate("1ab", "07/2030");
        MortgageAccountInfo mortgageAccountInfo= mortgagePaymentArrangementDataHelper.mortgageQueryServiceAccountInfoWithAndWithoutSubaccount(true);
        Map<String,String> reqMap= new HashMap<>();
        MortgagePaymentArrangementValidator mortgagePaymentArrangementValidator = new MortgagePaymentArrangementValidator(mortgageAccountInfoRestClient);
        //when
        when(mortgageAccountInfoRestClient.getMortgageAccountInfo(any(String.class), any())).thenReturn(mortgageAccountInfo);
        mortgagePaymentArrangementValidator.validateUpdatePaymentArrangementRequest(paymentArrangementUpdateRequest, accountId, reqMap);

    }

    @Test(expected = VaultValidationException.class)
    public void validate_update_payment_arrangement_request_when_amount_is_negative(){
        //given
        PaymentArrangementUpdateRequest paymentArrangementUpdateRequest= mortgagePaymentArrangementDataHelper.buildPaymentArrangementUpdateRequestAmendAmountAndEndDate("-20", "2020-07-20");
        MortgageAccountInfo mortgageAccountInfo= mortgagePaymentArrangementDataHelper.mortgageQueryServiceAccountInfoWithAndWithoutSubaccount(true);
        Map<String,String> reqMap= new HashMap<>();
        MortgagePaymentArrangementValidator mortgagePaymentArrangementValidator = new MortgagePaymentArrangementValidator(mortgageAccountInfoRestClient);
        //when
        when(mortgageAccountInfoRestClient.getMortgageAccountInfo(any(String.class), any())).thenReturn(mortgageAccountInfo);
        mortgagePaymentArrangementValidator.validateUpdatePaymentArrangementRequest(paymentArrangementUpdateRequest, accountId, reqMap);

    }

    @Test(expected = VaultValidationException.class)
    public void validate_update_payment_arrangement_request_when_amount_is_null(){
        //given
        PaymentArrangementUpdateRequest paymentArrangementUpdateRequest= mortgagePaymentArrangementDataHelper.buildPaymentArrangementUpdateRequestAmendAmountAndEndDate(null, "2020-07-20");
        MortgageAccountInfo mortgageAccountInfo= mortgagePaymentArrangementDataHelper.mortgageQueryServiceAccountInfoWithAndWithoutSubaccount(true);
        Map<String,String> reqMap= new HashMap<>();
        MortgagePaymentArrangementValidator mortgagePaymentArrangementValidator = new MortgagePaymentArrangementValidator(mortgageAccountInfoRestClient);
        //when
        when(mortgageAccountInfoRestClient.getMortgageAccountInfo(any(String.class), any())).thenReturn(mortgageAccountInfo);
        mortgagePaymentArrangementValidator.validateUpdatePaymentArrangementRequest(paymentArrangementUpdateRequest, accountId, reqMap);

    }

    @Test(expected = InvalidUpdateRequestException.class)
    public void validateSetupPaymentArrangement_PaymentArrangementAlreadyExists(){
        PaymentArrangementRequest paymentArrangementRequest= setupMortgageHelper.paymentArrangementRequest();
        MortgageAccountInfo mortgageAccountInfo= setupMortgageHelper.mortgageAccountInfo_ovePaymentMock();
        Map<String,String> reqMap= new HashMap<>();
        MortgagePaymentArrangementValidator mortgagePaymentArrangementValidator = new MortgagePaymentArrangementValidator(mortgageAccountInfoRestClient);
        when(mortgageAccountInfoRestClient.getMortgageAccountInfo(any(String.class),any(Map.class))).thenReturn(mortgageAccountInfo);
        mortgagePaymentArrangementValidator.validateSetupPaymentArrangementRequest(paymentArrangementRequest,accountId,reqMap);

    }

    @Test(expected = InvalidUpdateRequestException.class)
    public void validateSetupPaymentArrangement_InvalidDate(){
        PaymentArrangementRequest paymentArrangementRequest= setupMortgageHelper.paymentArrangementRequest();
        paymentArrangementRequest.setPaymentArrangementStartMonth("12-1997");
        MortgageAccountInfo mortgageAccountInfo= setupMortgageHelper.mortgageAccountInfo_repaymentMock();
        when(mortgageAccountInfoRestClient.getMortgageAccountInfo(any(String.class),any(Map.class))).thenReturn(mortgageAccountInfo);
        paymentArrangementRequest.setPaymentArrangementStartMonth("12-1997");
        Map<String,String> reqMap= new HashMap<>();
        MortgagePaymentArrangementValidator mortgagePaymentArrangementValidator = new MortgagePaymentArrangementValidator(mortgageAccountInfoRestClient);
        mortgagePaymentArrangementValidator.validateSetupPaymentArrangementRequest(paymentArrangementRequest,accountId,reqMap);
    }

    @Test(expected = InvalidUpdateRequestException.class)
    public void validateSetupPaymentArrangement_WithPastStartDate(){
        PaymentArrangementRequest paymentArrangementRequest= setupMortgageHelper.paymentArrangementRequest();
        paymentArrangementRequest.setPaymentArrangementStartMonth("12/2020");
        MortgageAccountInfo mortgageAccountInfo= setupMortgageHelper.mortgageAccountInfo_repaymentMock();
        when(mortgageAccountInfoRestClient.getMortgageAccountInfo(any(String.class),any(Map.class))).thenReturn(mortgageAccountInfo);
        Map<String,String> reqMap= new HashMap<>();
        MortgagePaymentArrangementValidator mortgagePaymentArrangementValidator = new MortgagePaymentArrangementValidator(mortgageAccountInfoRestClient);
        mortgagePaymentArrangementValidator.validateSetupPaymentArrangementRequest(paymentArrangementRequest,accountId,reqMap);
    }

    @Test(expected = InvalidUpdateRequestException.class)
    public void validateSetupPaymentArrangement_WithPastEndDate(){
        PaymentArrangementRequest paymentArrangementRequest= setupMortgageHelper.paymentArrangementRequest();
        paymentArrangementRequest.setPaymentArrangementEndMonth("12/2020");
        MortgageAccountInfo mortgageAccountInfo= setupMortgageHelper.mortgageAccountInfo_repaymentMock();
        when(mortgageAccountInfoRestClient.getMortgageAccountInfo(any(String.class),any(Map.class))).thenReturn(mortgageAccountInfo);
        Map<String,String> reqMap= new HashMap<>();
        MortgagePaymentArrangementValidator mortgagePaymentArrangementValidator = new MortgagePaymentArrangementValidator(mortgageAccountInfoRestClient);
        mortgagePaymentArrangementValidator.validateSetupPaymentArrangementRequest(paymentArrangementRequest,accountId,reqMap);
    }

    @Test(expected = InvalidUpdateRequestException.class)
    public void validateSetupPaymentArrangement_RepaymentAccount(){
        PaymentArrangementRequest paymentArrangementRequest= setupMortgageHelper.paymentArrangementRequest();
        MortgageAccountInfo mortgageAccountInfo= setupMortgageHelper.mortgageAccountInfo_repaymentMock();
        Map<String,String> reqMap= new HashMap<>();
        MortgagePaymentArrangementValidator mortgagePaymentArrangementValidator = new MortgagePaymentArrangementValidator(mortgageAccountInfoRestClient);
        when(mortgageAccountInfoRestClient.getMortgageAccountInfo(any(String.class),any(Map.class))).thenReturn(mortgageAccountInfo);
        mortgagePaymentArrangementValidator.validateSetupPaymentArrangementRequest(paymentArrangementRequest,accountId,reqMap);

    }

    @Test(expected = VaultValidationException.class)
    public void validateSetupPaymentArrangement_AmountNegative(){
        PaymentArrangementRequest paymentArrangementRequest= setupMortgageHelper.paymentArrangementRequest();
        paymentArrangementRequest.setPaymentArrangementAmount("-50");
        Map<String,String> reqMap= new HashMap<>();
        MortgagePaymentArrangementValidator mortgagePaymentArrangementValidator = new MortgagePaymentArrangementValidator(mortgageAccountInfoRestClient);
        mortgagePaymentArrangementValidator.validateSetupPaymentArrangementRequest(paymentArrangementRequest,accountId,reqMap);
    }

    @Test(expected = VaultValidationException.class)
    public void validateSetupPaymentArrangement_AmountInNotCorrectFormat(){
        PaymentArrangementRequest paymentArrangementRequest= setupMortgageHelper.paymentArrangementRequest();
        paymentArrangementRequest.setPaymentArrangementAmount("dollar123");
        Map<String,String> reqMap= new HashMap<>();
        MortgagePaymentArrangementValidator mortgagePaymentArrangementValidator = new MortgagePaymentArrangementValidator(mortgageAccountInfoRestClient);
        mortgagePaymentArrangementValidator.validateSetupPaymentArrangementRequest(paymentArrangementRequest,accountId,reqMap);

    }

    @Test(expected = InvalidUpdateRequestException.class)
    public void validateSetupPaymentArrangement_StartDateGreaterThanEndDate(){
        PaymentArrangementRequest paymentArrangementRequest= setupMortgageHelper.paymentArrangementRequest();
        paymentArrangementRequest.setPaymentArrangementStartMonth("11/2040");
        paymentArrangementRequest.setPaymentArrangementEndMonth("10/2040");
        MortgageAccountInfo mortgageAccountInfo= setupMortgageHelper.mortgageAccountInfo_repaymentMock();
        when(mortgageAccountInfoRestClient.getMortgageAccountInfo(any(String.class),any(Map.class))).thenReturn(mortgageAccountInfo);
        Map<String,String> reqMap= new HashMap<>();
        MortgagePaymentArrangementValidator mortgagePaymentArrangementValidator = new MortgagePaymentArrangementValidator(mortgageAccountInfoRestClient);
        mortgagePaymentArrangementValidator.validateSetupPaymentArrangementRequest(paymentArrangementRequest,accountId,reqMap);

    }

    @Test(expected = InvalidUpdateRequestException.class)
    public void validateSetupPaymentArrangement_StartDateIsPastDate(){
        PaymentArrangementRequest paymentArrangementRequest= setupMortgageHelper.paymentArrangementRequest();
        paymentArrangementRequest.setPaymentArrangementStartMonth("11-2000");
        MortgageAccountInfo mortgageAccountInfo= setupMortgageHelper.mortgageAccountInfo_repaymentMock();
        when(mortgageAccountInfoRestClient.getMortgageAccountInfo(any(String.class),any(Map.class))).thenReturn(mortgageAccountInfo);
        Map<String,String> reqMap= new HashMap<>();
        MortgagePaymentArrangementValidator mortgagePaymentArrangementValidator = new MortgagePaymentArrangementValidator(mortgageAccountInfoRestClient);
        mortgagePaymentArrangementValidator.validateSetupPaymentArrangementRequest(paymentArrangementRequest,accountId,reqMap);

    }

    @Test(expected = InvalidUpdateRequestException.class)
    public void validateSetupPaymentArrangement_EndDateIsPastDate(){
        PaymentArrangementRequest paymentArrangementRequest= setupMortgageHelper.paymentArrangementRequest();
        paymentArrangementRequest.setPaymentArrangementEndMonth("11-2000");
        MortgageAccountInfo mortgageAccountInfo= setupMortgageHelper.mortgageAccountInfo_repaymentMock();
        when(mortgageAccountInfoRestClient.getMortgageAccountInfo(any(String.class),any(Map.class))).thenReturn(mortgageAccountInfo);
        Map<String,String> reqMap= new HashMap<>();
        MortgagePaymentArrangementValidator mortgagePaymentArrangementValidator = new MortgagePaymentArrangementValidator(mortgageAccountInfoRestClient);
        mortgagePaymentArrangementValidator.validateSetupPaymentArrangementRequest(paymentArrangementRequest,accountId,reqMap);

    }

    @Test(expected = InvalidUpdateRequestException.class)
    public void validateSetupPaymentArrangement_UnderPaymentAlreadyExists(){
        PaymentArrangementRequest paymentArrangementRequest= setupMortgageHelper.paymentArrangementRequest();
        MortgageAccountInfo mortgageAccountInfo= setupMortgageHelper.mortgageAccountInfo_underPaymentMock();
        Map<String,String> reqMap= new HashMap<>();
        MortgagePaymentArrangementValidator mortgagePaymentArrangementValidator = new MortgagePaymentArrangementValidator(mortgageAccountInfoRestClient);
        when(mortgageAccountInfoRestClient.getMortgageAccountInfo(any(String.class),any(Map.class))).thenReturn(mortgageAccountInfo);
        mortgagePaymentArrangementValidator.validateSetupPaymentArrangementRequest(paymentArrangementRequest,accountId,reqMap);

    }


    @Test(expected = InvalidUpdateRequestException.class)
    public void validate_cancel_payment_arrangement_when_payment_arrangement_exist_with_past_end_date(){
        //given
        MortgageAccountInfo mortgageAccountInfo= mortgagePaymentArrangementDataHelper.mortgageAccountInfoWithPaymentArrangementWithExpiredEndDate();
        Map<String,String> reqMap= new HashMap<>();
        MortgagePaymentArrangementValidator mortgagePaymentArrangementValidator = new MortgagePaymentArrangementValidator(mortgageAccountInfoRestClient);
        //when
        when(mortgageAccountInfoRestClient.getMortgageAccountInfo(any(String.class), any())).thenReturn(mortgageAccountInfo);
        mortgagePaymentArrangementValidator.validateCancelPaymentArrangement(accountId, reqMap);

    }

    @Test(expected = InvalidUpdateRequestException.class)
    public void validate_cancel_payment_arrangement_when_payment_arrangement_not_exist(){
        //given
        MortgageAccountInfo mortgageAccountInfo= mortgagePaymentArrangementDataHelper.mortgageAccountInfoWithPaymentArrangement(false);
        Map<String,String> reqMap= new HashMap<>();
        MortgagePaymentArrangementValidator mortgagePaymentArrangementValidator = new MortgagePaymentArrangementValidator(mortgageAccountInfoRestClient);
        //when
        when(mortgageAccountInfoRestClient.getMortgageAccountInfo(any(String.class), any())).thenReturn(mortgageAccountInfo);
        mortgagePaymentArrangementValidator.validateCancelPaymentArrangement(accountId, reqMap);

    }

    @Test(expected = InvalidUpdateRequestException.class)
    public void validate_cancel_payment_arrangement_when_account_is_not_sub_account(){
        //given
        MortgageAccountInfo mortgageAccountInfo= mortgagePaymentArrangementDataHelper.mortgageQueryServiceAccountInfoWithAndWithoutSubaccount(false);
        Map<String,String> reqMap= new HashMap<>();
        MortgagePaymentArrangementValidator mortgagePaymentArrangementValidator = new MortgagePaymentArrangementValidator(mortgageAccountInfoRestClient);
        //when
        when(mortgageAccountInfoRestClient.getMortgageAccountInfo(any(String.class), any())).thenReturn(mortgageAccountInfo);
        mortgagePaymentArrangementValidator.validateCancelPaymentArrangement(accountId, reqMap);

    }

    @Test
    public void validate_cancel_payment_arrangement_when_account_is_sub_account_and_payment_arrangement_exist(){
        //give
        MortgageAccountInfo mortgageAccountInfo= mortgagePaymentArrangementDataHelper.mortgageQueryServiceAccountInfoWithAndWithoutSubaccount(true);
        Map<String,String> reqMap= new HashMap<>();
        MortgagePaymentArrangementValidator mortgagePaymentArrangementValidator = new MortgagePaymentArrangementValidator(mortgageAccountInfoRestClient);
        //when
        when(mortgageAccountInfoRestClient.getMortgageAccountInfo(any(String.class), any())).thenReturn(mortgageAccountInfo);
        mortgagePaymentArrangementValidator.validateCancelPaymentArrangement(accountId, reqMap);

    }

    @Test(expected = InvalidUpdateRequestException.class)
    public void validate_cancel_payment_arrangement_when_payment_arrangement_exist_with_invalid_type(){
        //given
        MortgageAccountInfo mortgageAccountInfo= mortgagePaymentArrangementDataHelper.mortgageAccountInfoWithPaymentArrangementAmountType();
        Map<String,String> reqMap= new HashMap<>();
        MortgagePaymentArrangementValidator mortgagePaymentArrangementValidator = new MortgagePaymentArrangementValidator(mortgageAccountInfoRestClient);
        //when
        when(mortgageAccountInfoRestClient.getMortgageAccountInfo(any(String.class), any())).thenReturn(mortgageAccountInfo);
        mortgagePaymentArrangementValidator.validateCancelPaymentArrangement(accountId, reqMap);

    }

    @Test(expected = InvalidUpdateRequestException.class)
    public void validate_cancel_payment_arrangement_when_start_date_is_greater_than_end_date(){
        //given
        MortgageAccountInfo mortgageAccountInfo= mortgagePaymentArrangementDataHelper.mortgageAccountInfoWithStartDateGreaterThanEndDate();
        Map<String,String> reqMap= new HashMap<>();
        MortgagePaymentArrangementValidator mortgagePaymentArrangementValidator = new MortgagePaymentArrangementValidator(mortgageAccountInfoRestClient);
        //when
        when(mortgageAccountInfoRestClient.getMortgageAccountInfo(any(String.class), any())).thenReturn(mortgageAccountInfo);
        mortgagePaymentArrangementValidator.validateCancelPaymentArrangement(accountId, reqMap);

    }

}
