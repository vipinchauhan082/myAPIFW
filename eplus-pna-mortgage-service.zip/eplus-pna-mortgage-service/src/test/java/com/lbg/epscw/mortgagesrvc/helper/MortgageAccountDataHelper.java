package com.lbg.epscw.mortgagesrvc.helper;

import com.lbg.epscw.mortgagesrvc.constants.CommonConstants;
import com.lbg.epscw.mortgagesrvc.dto.MortgageAccountData;
import com.lbg.epscw.mortgagesrvc.dto.MortgageAccountInfo;
import com.lbg.epscw.mortgagesrvc.enums.BenefitsSourceOptions;
import com.lbg.epscw.mortgagesrvc.enums.RepaymentType;
import com.lbg.epscw.mortgagesrvc.model.BenefitsRequest;
import com.lbg.epscw.mortgagesrvc.model.BenefitsResponse;
import com.lbg.epscw.mortgagesrvc.model.MortgageTermReductionResponse;
import com.lbg.epscw.mortgagesrvc.model.VaultMetadataOptionsResponse;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;

@Component
public class MortgageAccountDataHelper {

	public static final String MOCK_ACCOUNT_ID = "1601d0e5-e336-64d9-64ad-89ba6fdc2677";

	public List<MortgageAccountData> buildViewAccountData() {
		return Arrays.asList(getMortgageAccountData());
	}
	
	public MortgageAccountData getMortgageAccountData() {
		MortgageAccountData accountdata = new MortgageAccountData();

		accountdata.setAccountId("1b69ad2f-63b3-c70f-6f52-ee85b97e314d");
		accountdata.setKeyDate("20-09-2020");
		accountdata.setMortgageNumber("2001001210");
		accountdata.setMortgagePrincipal("20000000");
		accountdata.setMortgageType(RepaymentType.INTEREST_ONLY.name());
		accountdata.setProductId("lbg_mortgage");
		accountdata.setTotalTerm("15");
		accountdata.setRemainingTerm("7");
		return accountdata;
	}
	
	public MortgageAccountInfo buildViewAccountInfo() {

		MortgageAccountInfo info = new MortgageAccountInfo();
		info.setMortgageAccountData(buildViewAccountData());
		return info;
	}

	public MortgageTermReductionResponse buildViewMortgageTermReductionResponse(String totalTerm, String remTerm, String redTerm){
		MortgageTermReductionResponse mortgageTermReductionResponse = new MortgageTermReductionResponse();
		mortgageTermReductionResponse.setAccountId("1b69ad2f-63b3-c70f-6f52-ee85b97e314d");
		mortgageTermReductionResponse.setTotalTerm(totalTerm);
		mortgageTermReductionResponse.setRemainingTerm(remTerm);
		mortgageTermReductionResponse.setReducedTerm(redTerm);

		return mortgageTermReductionResponse;
	}

	public VaultMetadataOptionsResponse buildAccountBenefitsTrueUpdateResponse() {
		VaultMetadataOptionsResponse response = new VaultMetadataOptionsResponse();
		response.setAccountId("1601d0e5-e336-64d9-64ad-89ba6fdc2677");
		HashMap<String, String> details = new HashMap<String, String>();
		details.put(CommonConstants.BENEFITS_FLAG,"yes");
		details.put(CommonConstants.BENEFITS_SOURCE, BenefitsSourceOptions.Pinnacle.name());
		response.setDetails(details);
		response.setStatus("ACCOUNT_STATUS_OPEN");
		return response;
	}

	public VaultMetadataOptionsResponse buildAccountBenefitsFalseUpdateResponse() {
		VaultMetadataOptionsResponse response = new VaultMetadataOptionsResponse();
		response.setAccountId("1601d0e5-e336-64d9-64ad-89ba6fdc2677");
		HashMap<String, String> details = new HashMap<String, String>();
		details.put(CommonConstants.BENEFITS_FLAG,"no");
		response.setDetails(details);
		response.setStatus("ACCOUNT_STATUS_OPEN");
		return response;
	}

	public List<String> accountList_mock(){
		return Arrays.asList(MOCK_ACCOUNT_ID);
	}

	public MortgageAccountInfo mortgageAccountInfo_TrueResponseMock() {
		MortgageAccountInfo mortgageAccountInfo = new MortgageAccountInfo();
		List<MortgageAccountData> mortgageAccountDataList = new ArrayList<>();
		MortgageAccountData mortgageAccountData = new MortgageAccountData();
		mortgageAccountData.setAccountId("1601d0e5-e336-64d9-64ad-89ba6fdc2677");
		mortgageAccountData.setProductId("lbg_mortgage_payment");
		mortgageAccountData.setProductFamily("Mortgage Payment");
		mortgageAccountDataList.add(mortgageAccountData);
		mortgageAccountInfo.setMortgageAccountData(mortgageAccountDataList);
		return mortgageAccountInfo;
	}

	public MortgageAccountInfo mortgageAccountInfo_FalseResponseMock() {
		MortgageAccountInfo mortgageAccountInfo = new MortgageAccountInfo();
		List<MortgageAccountData> mortgageAccountDataList = new ArrayList<>();
		MortgageAccountData mortgageAccountData = new MortgageAccountData();
		mortgageAccountData.setAccountId("1601d0e5-e336-64d9-64ad-89ba6fdc2677");
		mortgageAccountData.setProductId("lbg_mortgage");
		mortgageAccountData.setProductFamily("Mortgage");
		mortgageAccountDataList.add(mortgageAccountData);
		mortgageAccountInfo.setMortgageAccountData(mortgageAccountDataList);
		return mortgageAccountInfo;
	}

	public BenefitsRequest mockRequest_TrueBenefits(){
		BenefitsRequest request = new BenefitsRequest();
		request.setIsOnBenefits("yes");
		request.setBenefitsSource(BenefitsSourceOptions.Pinnacle.name());
		return request;
	}

	public BenefitsRequest invalidSourceRequest_TrueBenefits(){
		BenefitsRequest request = new BenefitsRequest();
		request.setIsOnBenefits("yes");
		request.setBenefitsSource("XYZ");
		return request;
	}

	public BenefitsRequest invalidRequest_TrueBenefits(){
		BenefitsRequest request = new BenefitsRequest();
		request.setIsOnBenefits("yes");
		return request;
	}

	public BenefitsRequest mockRequest_FalseBenefits(){
		BenefitsRequest request = new BenefitsRequest();
		request.setIsOnBenefits("no");
		request.setBenefitsSource(BenefitsSourceOptions.Pinnacle.name());
		return request;
	}

	public BenefitsResponse mockResponse_TrueBenefits(){
		BenefitsResponse response = new BenefitsResponse();
		response.setAccountId("1601d0e5-e336-64d9-64ad-89ba6fdc2677");
		HashMap<String, String> details = new HashMap<String, String>();
		details.put(CommonConstants.BENEFITS_FLAG,"yes");
		details.put(CommonConstants.BENEFITS_SOURCE,BenefitsSourceOptions.Pinnacle.name());
		response.setBenefitsDetails(details);
		response.setStatus("ACCOUNT_STATUS_OPEN");
		return response;
	}

	public HttpHeaders getAccountInfoHeaders() {
		HttpHeaders httpHeaders = new HttpHeaders();
		httpHeaders.add("Authorization", "Bearer b2c9119f-09e5-4ac9-9738-9e28b334d3fa");
		httpHeaders.add("x-lbg-internal-system-id", "test");
		httpHeaders.add("x-lbg-brand", "IF");
		httpHeaders.add("x-lbg-txn-correlation-id", "123-456-789-123");
		httpHeaders.setContentType(MediaType.APPLICATION_JSON);
		return httpHeaders;
	}
}
