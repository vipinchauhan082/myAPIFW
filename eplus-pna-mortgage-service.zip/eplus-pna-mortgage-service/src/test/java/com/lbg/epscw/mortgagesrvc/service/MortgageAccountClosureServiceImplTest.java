package com.lbg.epscw.mortgagesrvc.service;

import com.lbg.epscw.handler.exception.RestServiceException;
import com.lbg.epscw.mortgagesrvc.dto.MortgageClosureEligibility;
import com.lbg.epscw.mortgagesrvc.dto.VaultAccountResponse;
import com.lbg.epscw.mortgagesrvc.dto.VaultAccountStatusUpdateRequest;
import com.lbg.epscw.mortgagesrvc.exception.AccountServiceException;
import com.lbg.epscw.mortgagesrvc.exception.CircuitBreakerOpenException;
import com.lbg.epscw.mortgagesrvc.helper.MortgageAccountClosureHelper;
import com.lbg.epscw.mortgagesrvc.model.AccountClosureResponse;
import com.lbg.epscw.mortgagesrvc.model.AccountStatus;
import com.lbg.epscw.mortgagesrvc.restclient.MortgageAccountStatusRestClient;
import com.lbg.epscw.mortgagesrvc.util.MortgageServiceUtil;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.springframework.http.HttpStatus;
import org.springframework.test.context.junit4.SpringRunner;

import static org.junit.Assert.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.powermock.api.mockito.PowerMockito.mock;
import static org.powermock.api.mockito.PowerMockito.when;

@RunWith(SpringRunner.class)
public class MortgageAccountClosureServiceImplTest {

    private MortgageAccountClosureHelper mortgageAccountClosureHelper=new MortgageAccountClosureHelper();

    @Mock
    private MortgageServiceUtil mortgageServiceUtil;

    @Mock
    private MortgageAccountStatusRestClient accountStatusRestClient;

    @Before
    public void setUp() {
        mortgageServiceUtil=mock(MortgageServiceUtil.class);
        accountStatusRestClient=mock(MortgageAccountStatusRestClient.class);
    }

    @Test
    public void close_valid_overarching_account() {
        //given
        MortgageAccountClosureServiceImpl mortgageAccountClosureService= new MortgageAccountClosureServiceImpl(accountStatusRestClient);

        VaultAccountResponse accountClosureVaultResponse = mortgageAccountClosureHelper.buildAccountClosureVaultResponse();

        when(accountStatusRestClient.updateAccountStatus(any(String.class), any(VaultAccountStatusUpdateRequest.class))).thenReturn(accountClosureVaultResponse);
        MortgageClosureEligibility mortgageClosureEligibility=new MortgageClosureEligibility();
        mortgageClosureEligibility.setAccountStatus(AccountStatus.ACCOUNT_STATUS_OPEN.name());
        //when
        AccountClosureResponse response = mortgageAccountClosureService.closeMortgageAccount("b2c9119f-09e5-4ac9-9738-9e28b334d3fa", mortgageClosureEligibility);
        //then
        assertNotNull(response);
        assertEquals("b2c9119f-09e5-4ac9-9738-9e28b334d3fa",response.getAccountId());
    }

    @Test
    public void close_valid_overarching_account_for_status_pending_closure() {
        //given
        MortgageAccountClosureServiceImpl mortgageAccountClosureService= new MortgageAccountClosureServiceImpl(accountStatusRestClient);

        VaultAccountResponse accountClosureVaultResponse = mortgageAccountClosureHelper.buildAccountClosureVaultResponse();

        when(accountStatusRestClient.updateAccountStatus(any(String.class), any(VaultAccountStatusUpdateRequest.class))).thenReturn(accountClosureVaultResponse);
        MortgageClosureEligibility mortgageClosureEligibility=new MortgageClosureEligibility();
        mortgageClosureEligibility.setAccountStatus(AccountStatus.ACCOUNT_STATUS_PENDING_CLOSURE.name());
        //when
        AccountClosureResponse response = mortgageAccountClosureService.closeMortgageAccount("b2c9119f-09e5-4ac9-9738-9e28b334d3fa", mortgageClosureEligibility);
        //then
        assertNotNull(response);
        assertEquals("b2c9119f-09e5-4ac9-9738-9e28b334d3fa",response.getAccountId());
    }


    @Test(expected = CircuitBreakerOpenException.class)
    public void hystrix_test_on_account_closure_service() {
        //when
        MortgageAccountClosureServiceImpl mortgageAccountClosureService= new MortgageAccountClosureServiceImpl(accountStatusRestClient);
        mortgageAccountClosureService
                .fallbackCloseMortgageAccount("f76ca840-2553-d536-1ab8-9fa85c99db05",new MortgageClosureEligibility(),
                        new Exception("Circuit open on update jar name"));
    }


    @Test
    public void overarching_account_closure_returns_null_if_no_data_returned_from_vault_for_status_pending_closure() {

        //given
        MortgageAccountClosureServiceImpl mortgageAccountClosureService= new MortgageAccountClosureServiceImpl(accountStatusRestClient);

        when(accountStatusRestClient.updateAccountStatus(any(String.class), any(VaultAccountStatusUpdateRequest.class))).thenReturn(null);
        MortgageClosureEligibility mortgageClosureEligibility=new MortgageClosureEligibility();
        mortgageClosureEligibility.setAccountStatus(AccountStatus.ACCOUNT_STATUS_PENDING_CLOSURE.name());

        //when
        AccountClosureResponse response = mortgageAccountClosureService.closeMortgageAccount("b2c9119f-09e5-4ac9-9738-9e28b334d3fa", mortgageClosureEligibility);

        //then
        assertEquals(null,response);
    }

    @Test(expected = AccountServiceException.class)
    public void overarching_account_closure_throws_exception_if_error_occurred_at_vault() {

        //given
        MortgageAccountClosureServiceImpl mortgageAccountClosureService= new MortgageAccountClosureServiceImpl(accountStatusRestClient);

        when(accountStatusRestClient.updateAccountStatus(any(String.class), any(VaultAccountStatusUpdateRequest.class))).
                thenThrow(new RestServiceException("400", HttpStatus.BAD_REQUEST,"Invalid","Error"));

        MortgageClosureEligibility mortgageClosureEligibility=new MortgageClosureEligibility();
        mortgageClosureEligibility.setAccountStatus(AccountStatus.ACCOUNT_STATUS_OPEN.name());
        //when
        mortgageAccountClosureService.closeMortgageAccount("b2c9119f-09e5-4ac9-9738-9e28b334d3fa",mortgageClosureEligibility);

    }
}