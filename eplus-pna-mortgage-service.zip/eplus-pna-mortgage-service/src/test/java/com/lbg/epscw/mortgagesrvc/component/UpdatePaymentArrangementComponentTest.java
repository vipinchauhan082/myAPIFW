package com.lbg.epscw.mortgagesrvc.component;

import com.lbg.epscw.entitlement.service.EntitlementValidationServiceImpl;
import com.lbg.epscw.handler.model.ErrorInfo;
import com.lbg.epscw.handler.model.ErrorResponse;
import com.lbg.epscw.mortgagesrvc.helper.ComponentHelper;
import com.lbg.epscw.mortgagesrvc.helper.MortgagePaymentArrangementDataHelper;
import com.lbg.epscw.mortgagesrvc.logger.HystrixContextCopyStrategy;
import com.lbg.epscw.mortgagesrvc.model.PaymentArrangementResponse;
import com.lbg.epscw.mortgagesrvc.model.PaymentArrangementUpdateRequest;
import com.lbg.epscw.mortgagesrvc.service.RestClientService;
import org.apache.commons.lang3.RandomStringUtils;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.context.ApplicationContext;
import org.springframework.http.HttpHeaders;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import java.util.HashMap;

import static org.junit.jupiter.api.Assertions.assertAll;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.powermock.api.mockito.PowerMockito.when;

@Tag("component")
@ExtendWith(SpringExtension.class)
@SpringBootTest
@AutoConfigureMockMvc
public class UpdatePaymentArrangementComponentTest extends WebMVCTest{

    private static final String UPDATE_PAYMENTARRANGEMENT_OPTIONS =
            "/mortgages/b2c9119f-09e5-4ac9-9738-9e28b334d3fa/paymentarrangement/";

    @MockBean
    RestClientService restClientService;

    @MockBean
    private HystrixContextCopyStrategy hystrixContextCopyStrategy;

    @MockBean
    private EntitlementValidationServiceImpl entitlementValidationService;

    @Autowired
    private ApplicationContext context;

    private ComponentHelper componentHelper = new ComponentHelper();

    private MortgagePaymentArrangementDataHelper mortgagePaymentArrangementDataHelper  = new MortgagePaymentArrangementDataHelper();

    @Test
    public void shouldUpdateUpPaymentArrangementOptions() {
        //given
        PaymentArrangementUpdateRequest paymentArrangementRequest = mortgagePaymentArrangementDataHelper.buildPaymentArrangementUpdateRequestAmendAmount("100");
        String payload = componentHelper.writeValueAsString(paymentArrangementRequest);

        when(restClientService.get(any(String.class), any(HashMap.class)))
                .thenReturn(mortgagePaymentArrangementDataHelper.getMortgageQueryServiceResponse());
        when(restClientService.post(any(String.class), any(HashMap.class), any(String.class)))
                .thenReturn(mortgagePaymentArrangementDataHelper.getOverpaymentVaultResponse());

        //when
        MockHttpServletResponse servletResponse = doPUT(UPDATE_PAYMENTARRANGEMENT_OPTIONS,
                payload,
                mortgagePaymentArrangementDataHelper.getAccountInfoHeaders());
        String responseString = componentHelper.getServletResponseAsString(servletResponse);
        PaymentArrangementResponse response = (PaymentArrangementResponse) readObject(responseString, PaymentArrangementResponse.class);
        System.out.println(response);

        //then
        assertAll(
                () -> assertEquals("1601d0e5-e336-64d9-64ad-89ba6fdc2677", response.getAccountId()),
                () -> assertEquals("ACCOUNT_UPDATE_STATUS_PENDING_EXECUTION", response.getStatus())

        );
    }

    @Test
    public void shouldUpdateUpPaymentArrangementOptionsWithValidOverpaymentHavingOnlyStartDate() {
        //given
        PaymentArrangementUpdateRequest paymentArrangementRequest = mortgagePaymentArrangementDataHelper.buildPaymentArrangementUpdateRequestAmendAmount("100");
        String payload = componentHelper.writeValueAsString(paymentArrangementRequest);

        when(restClientService.get(any(String.class), any(HashMap.class)))
                .thenReturn(mortgagePaymentArrangementDataHelper.getMortgageQueryServiceResponseWithStartAndNoEndDate());
        when(restClientService.post(any(String.class), any(HashMap.class), any(String.class)))
                .thenReturn(mortgagePaymentArrangementDataHelper.getOverpaymentVaultResponse());

        //when
        MockHttpServletResponse servletResponse = doPUT(UPDATE_PAYMENTARRANGEMENT_OPTIONS,
                payload,
                mortgagePaymentArrangementDataHelper.getAccountInfoHeaders());
        String responseString = componentHelper.getServletResponseAsString(servletResponse);
        PaymentArrangementResponse response = (PaymentArrangementResponse) readObject(responseString, PaymentArrangementResponse.class);

        //then
        assertAll(
                () -> assertEquals("1601d0e5-e336-64d9-64ad-89ba6fdc2677", response.getAccountId()),
                () -> assertEquals("ACCOUNT_UPDATE_STATUS_PENDING_EXECUTION", response.getStatus())

        );
    }


    @Test
    public void shouldNotAllowUpdatePaymentArrangementOptionsIfNotSubAccount() {
        //given
        PaymentArrangementUpdateRequest paymentArrangementRequest = mortgagePaymentArrangementDataHelper.buildPaymentArrangementUpdateRequestAmendAmount("100");
        String payload = componentHelper.writeValueAsString(paymentArrangementRequest);

        when(restClientService.get(any(String.class), any(HashMap.class)))
                .thenReturn(mortgagePaymentArrangementDataHelper.getMortgageQueryServiceResponseWithNoSubAccount());

        //when
        MockHttpServletResponse servletResponse = doPUT(UPDATE_PAYMENTARRANGEMENT_OPTIONS,
                payload,
                mortgagePaymentArrangementDataHelper.getAccountInfoHeaders());
        String responseString = componentHelper.getServletResponseAsString(servletResponse);
        ErrorResponse errorResponse = (ErrorResponse) readObject(responseString, ErrorResponse.class);
        ErrorInfo errorInfo = errorResponse.getErrors().get(0);

        //then
        assertAll(
                () -> assertEquals(400, servletResponse.getStatus()),
                () -> assertEquals("PNA.MORTGAGE_API.BUS.601", errorResponse.getCode()),
                () -> assertEquals("Invalid Update Request", errorResponse.getMessage()),
                () -> assertEquals("PNA.MORTGAGE_API.PUT_MORTGAGES_PAYMENTARRANGEMENT.Mortgage.SubAccount", errorInfo.getReasonCode())

        );
    }

    @Test
    public void shouldNotAllowUpdateUpPaymentArrangementOptionsWithoutPaymentArrangementExist() {
        //given
        PaymentArrangementUpdateRequest paymentArrangementRequest = mortgagePaymentArrangementDataHelper.buildPaymentArrangementUpdateRequestAmendAmount("100");
        String payload = componentHelper.writeValueAsString(paymentArrangementRequest);

        when(restClientService.get(any(String.class), any(HashMap.class)))
                .thenReturn(mortgagePaymentArrangementDataHelper.getMortgageQueryServiceResponseWithNoOverPayment());

        //when
        MockHttpServletResponse servletResponse = doPUT(UPDATE_PAYMENTARRANGEMENT_OPTIONS,
                payload,
                mortgagePaymentArrangementDataHelper.getAccountInfoHeaders());
        String responseString = componentHelper.getServletResponseAsString(servletResponse);
        ErrorResponse errorResponse = (ErrorResponse) readObject(responseString, ErrorResponse.class);
        ErrorInfo errorInfo = errorResponse.getErrors().get(0);

        //then
        assertAll(
                () -> assertEquals(400, servletResponse.getStatus()),
                () -> assertEquals("PNA.MORTGAGE_API.BUS.601", errorResponse.getCode()),
                () -> assertEquals("Invalid Update Request", errorResponse.getMessage()),
                () -> assertEquals("PNA.MORTGAGE_API.PUT_MORTGAGES_PAYMENTARRANGEMENT.Invalid.PaymentArrangementMonth" +
                        "", errorInfo.getReasonCode())

        );
    }

    @Test
    public void shouldNotAllowUpdateUpPaymentArrangementOptionsOnInactiveOverpaymentHavingNoStartEndDate() {
        //given
        PaymentArrangementUpdateRequest paymentArrangementRequest = mortgagePaymentArrangementDataHelper.buildPaymentArrangementUpdateRequestAmendAmount("100");
        String payload = componentHelper.writeValueAsString(paymentArrangementRequest);

        when(restClientService.get(any(String.class), any(HashMap.class)))
                .thenReturn(mortgagePaymentArrangementDataHelper.getMortgageQueryServiceResponseWithNoStartAndEndDate());

        //when
        MockHttpServletResponse servletResponse = doPUT(UPDATE_PAYMENTARRANGEMENT_OPTIONS,
                payload,
                mortgagePaymentArrangementDataHelper.getAccountInfoHeaders());
        String responseString = componentHelper.getServletResponseAsString(servletResponse);
        ErrorResponse errorResponse = (ErrorResponse) readObject(responseString, ErrorResponse.class);
        ErrorInfo errorInfo = errorResponse.getErrors().get(0);

        //then
        assertAll(
                () -> assertEquals(400, servletResponse.getStatus()),
                () -> assertEquals("PNA.MORTGAGE_API.BUS.601", errorResponse.getCode()),
                () -> assertEquals("Invalid Update Request", errorResponse.getMessage()),
                () -> assertEquals("PNA.MORTGAGE_API.PUT_MORTGAGES_PAYMENTARRANGEMENT.Invalid.PaymentArrangementMonth", errorInfo.getReasonCode())

        );
    }

    @Test
    public void shouldNotAllowUpdateUpPaymentArrangementOptionsOnInvalidOverpaymentHavingPastEndDate() {
        //given
        PaymentArrangementUpdateRequest paymentArrangementRequest = mortgagePaymentArrangementDataHelper.buildPaymentArrangementUpdateRequestAmendAmount("100");
        String payload = componentHelper.writeValueAsString(paymentArrangementRequest);

        when(restClientService.get(any(String.class), any(HashMap.class)))
                .thenReturn(mortgagePaymentArrangementDataHelper.getMortgageQueryServiceResponseWithPastEndDate());

        //when
        MockHttpServletResponse servletResponse = doPUT(UPDATE_PAYMENTARRANGEMENT_OPTIONS,
                payload,
                mortgagePaymentArrangementDataHelper.getAccountInfoHeaders());
        String responseString = componentHelper.getServletResponseAsString(servletResponse);
        ErrorResponse errorResponse = (ErrorResponse) readObject(responseString, ErrorResponse.class);
        ErrorInfo errorInfo = errorResponse.getErrors().get(0);

        //then
        assertAll(
                () -> assertEquals(400, servletResponse.getStatus()),
                () -> assertEquals("PNA.MORTGAGE_API.BUS.601", errorResponse.getCode()),
                () -> assertEquals("Invalid Update Request", errorResponse.getMessage()),
                () -> assertEquals("PNA.MORTGAGE_API.PUT_MORTGAGES_PAYMENTARRANGEMENT.Invalid.PaymentArrangementMonth", errorInfo.getReasonCode())

        );
    }

    @Test
    public void shouldNotAllowUpdateUpPaymentArrangementOptionsOnInvalidOverpaymentWithInvalidType() {
        //given
        PaymentArrangementUpdateRequest paymentArrangementRequest = mortgagePaymentArrangementDataHelper.buildPaymentArrangementUpdateRequestAmendAmount("100");
        String payload = componentHelper.writeValueAsString(paymentArrangementRequest);

        when(restClientService.get(any(String.class), any(HashMap.class)))
                .thenReturn(mortgagePaymentArrangementDataHelper.getMortgageQueryServiceResponseWithInvalidOverpaymentType());

        //when
        MockHttpServletResponse servletResponse = doPUT(UPDATE_PAYMENTARRANGEMENT_OPTIONS,
                payload,
                mortgagePaymentArrangementDataHelper.getAccountInfoHeaders());
        String responseString = componentHelper.getServletResponseAsString(servletResponse);
        ErrorResponse errorResponse = (ErrorResponse) readObject(responseString, ErrorResponse.class);
        ErrorInfo errorInfo = errorResponse.getErrors().get(0);

        //then
        assertAll(
                () -> assertEquals(400, servletResponse.getStatus()),
                () -> assertEquals("PNA.MORTGAGE_API.SYS.001", errorResponse.getCode()),
                () -> assertEquals("Bad Request", errorResponse.getMessage()),
                () -> assertEquals("PNA.MORTGAGE_API.PUT_MORTGAGES_PAYMENTARRANGEMENT.Invalid.TYPE", errorInfo.getReasonCode())
        );
    }

    @Test
    public void shouldReturnErrorForUpdateWhenEndDateIsPastDate() {
        //given
        PaymentArrangementUpdateRequest paymentArrangementRequest = mortgagePaymentArrangementDataHelper.buildPaymentArrangementUpdateRequestAmendAmount("100");
        paymentArrangementRequest.setPaymentArrangementEndMonth("08/2018");
        String payload = componentHelper.writeValueAsString(paymentArrangementRequest);
        when(restClientService.get(any(String.class), any(HashMap.class)))
                .thenReturn(mortgagePaymentArrangementDataHelper.getMortgageQueryServiceResponse());

        //when
        MockHttpServletResponse servletResponse = doPUT(UPDATE_PAYMENTARRANGEMENT_OPTIONS,
                payload,
                mortgagePaymentArrangementDataHelper.getAccountInfoHeaders());
        String responseString = componentHelper.getServletResponseAsString(servletResponse);
        ErrorResponse errorResponse = (ErrorResponse) readObject(responseString, ErrorResponse.class);
        ErrorInfo errorInfo = errorResponse.getErrors().get(0);

        //then
        assertAll(
                () -> assertEquals(400, servletResponse.getStatus()),
                () -> assertEquals("PNA.MORTGAGE_API.BUS.601", errorResponse.getCode()),
                () -> assertEquals("Invalid Update Request", errorResponse.getMessage()),
                () -> assertEquals("PNA.MORTGAGE_API.PUT_MORTGAGES_PAYMENTARRANGEMENT.Date.PastDate", errorInfo.getReasonCode())

        );

    }

    @Test
    public void shouldReturnErrorForUpdateWhenDateFormatIsInvalid() {
        //given
        PaymentArrangementUpdateRequest paymentArrangementRequest = mortgagePaymentArrangementDataHelper.buildPaymentArrangementUpdateRequestAmendAmount("100");
        paymentArrangementRequest.setPaymentArrangementEndMonth("2018-18-10");
        String payload = componentHelper.writeValueAsString(paymentArrangementRequest);
        when(restClientService.get(any(String.class), any(HashMap.class)))
                .thenReturn(mortgagePaymentArrangementDataHelper.getMortgageQueryServiceResponse());

        //when
        MockHttpServletResponse servletResponse = doPUT(UPDATE_PAYMENTARRANGEMENT_OPTIONS,
                payload,
                mortgagePaymentArrangementDataHelper.getAccountInfoHeaders());
        String responseString = componentHelper.getServletResponseAsString(servletResponse);
        ErrorResponse errorResponse = (ErrorResponse) readObject(responseString, ErrorResponse.class);
        ErrorInfo errorInfo = errorResponse.getErrors().get(0);

        //then
        assertAll(
                () -> assertEquals(400, servletResponse.getStatus()),
                () -> assertEquals("PNA.MORTGAGE_API.BUS.601", errorResponse.getCode()),
                () -> assertEquals("Invalid Update Request", errorResponse.getMessage()),
                () -> assertEquals("PNA.MORTGAGE_API.PUT_MORTGAGES_PAYMENTARRANGEMENT.Date.InvalidDateFormat", errorInfo.getReasonCode())

        );

    }


    @Test
    public void shouldReturnErrorForUpdateWhenAmountIsNull() {
        //given
        PaymentArrangementUpdateRequest paymentArrangementRequest = mortgagePaymentArrangementDataHelper.buildPaymentArrangementUpdateRequestAmendAmount("");
        String payload = componentHelper.writeValueAsString(paymentArrangementRequest);

        //when
        MockHttpServletResponse servletResponse = doPUT(UPDATE_PAYMENTARRANGEMENT_OPTIONS,
                payload,
                mortgagePaymentArrangementDataHelper.getAccountInfoHeaders());
        String responseString = componentHelper.getServletResponseAsString(servletResponse);
        ErrorResponse errorResponse = (ErrorResponse) readObject(responseString, ErrorResponse.class);
        ErrorInfo errorInfo = errorResponse.getErrors().get(0);

        //then
        assertAll(
                () -> assertEquals(400, servletResponse.getStatus()),
                () -> assertEquals("PNA.MORTGAGE_API.SYS.001", errorResponse.getCode()),
                () -> assertEquals("Bad Request", errorResponse.getMessage())

        );

    }

    @Test
    public void shouldReturnErrorForUpdateWhenAmountIsNotInNumberFormat() {
        //given
        PaymentArrangementUpdateRequest paymentArrangementRequest = mortgagePaymentArrangementDataHelper.buildPaymentArrangementUpdateRequestAmendAmount("abc");
        String payload = componentHelper.writeValueAsString(paymentArrangementRequest);

        //when
        MockHttpServletResponse servletResponse = doPUT(UPDATE_PAYMENTARRANGEMENT_OPTIONS,
                payload,
                mortgagePaymentArrangementDataHelper.getAccountInfoHeaders());
        String responseString = componentHelper.getServletResponseAsString(servletResponse);
        ErrorResponse errorResponse = (ErrorResponse) readObject(responseString, ErrorResponse.class);
        ErrorInfo errorInfo = errorResponse.getErrors().get(0);

        //then
        assertAll(
                () -> assertEquals(400, servletResponse.getStatus()),
                () -> assertEquals("PNA.MORTGAGE_API.SYS.001", errorResponse.getCode()),
                () -> assertEquals("Bad Request", errorResponse.getMessage()),
                () -> assertEquals("PNA.MORTGAGE_API.PUT_MORTGAGES_PAYMENTARRANGEMENT.Amount.NumberFormat", errorInfo.getReasonCode())

        );

    }

    @Test
    public void shouldReturnErrorForUpdateWhenAmountIsNegative() {
        //given
        PaymentArrangementUpdateRequest paymentArrangementRequest = mortgagePaymentArrangementDataHelper.buildPaymentArrangementUpdateRequestAmendAmount("-2.000");
        String payload = componentHelper.writeValueAsString(paymentArrangementRequest);

        //when
        MockHttpServletResponse servletResponse = doPUT(UPDATE_PAYMENTARRANGEMENT_OPTIONS,
                payload,
                mortgagePaymentArrangementDataHelper.getAccountInfoHeaders());
        String responseString = componentHelper.getServletResponseAsString(servletResponse);
        ErrorResponse errorResponse = (ErrorResponse) readObject(responseString, ErrorResponse.class);
        ErrorInfo errorInfo = errorResponse.getErrors().get(0);

        //then
        assertAll(
                () -> assertEquals(400, servletResponse.getStatus()),
                () -> assertEquals("PNA.MORTGAGE_API.SYS.001", errorResponse.getCode()),
                () -> assertEquals("Bad Request", errorResponse.getMessage()),
                () -> assertEquals("PNA.MORTGAGE_API.PUT_MORTGAGES_PAYMENTARRANGEMENT.Amount.Negative", errorInfo.getReasonCode())

        );

    }

    @Test
    public void shouldReturnErrorForUpdateWhenAccountIdIsMoreThan36Chars() {
        //given
        PaymentArrangementUpdateRequest paymentArrangementRequest = mortgagePaymentArrangementDataHelper.buildPaymentArrangementUpdateRequestAmendAmount("100");
        String payload = componentHelper.writeValueAsString(paymentArrangementRequest);

        //when
        MockHttpServletResponse servletResponse = doPUT("/mortgages/"+RandomStringUtils.random(50)+"/paymentarrangement",
                payload,
                mortgagePaymentArrangementDataHelper.getAccountInfoHeaders());
        String responseString = componentHelper.getServletResponseAsString(servletResponse);
        ErrorResponse errorResponse = (ErrorResponse) readObject(responseString, ErrorResponse.class);
        ErrorInfo errorInfo = errorResponse.getErrors().get(0);

        //then
        assertAll(
                () -> assertEquals(400, servletResponse.getStatus()),
                () -> assertEquals("PNA.MORTGAGE_API.SYS.001", errorResponse.getCode()),
                () -> assertEquals("Bad Request", errorResponse.getMessage()),
                () -> assertEquals("AccountId should be max 36 characters", errorInfo.getMessage())
        );
    }

    @Test
    public void shouldReturnErrorForUpdateWhenAccountIdIsLessThan36Chars() {
        //given
        PaymentArrangementUpdateRequest paymentArrangementRequest = mortgagePaymentArrangementDataHelper.buildPaymentArrangementUpdateRequestAmendAmount("100");
        String payload = componentHelper.writeValueAsString(paymentArrangementRequest);

        //when
        MockHttpServletResponse servletResponse = doPUT("/mortgages/"+RandomStringUtils.random(5)+"/paymentarrangement",
                payload,
                mortgagePaymentArrangementDataHelper.getAccountInfoHeaders());
        String responseString = componentHelper.getServletResponseAsString(servletResponse);
        ErrorResponse errorResponse = (ErrorResponse) readObject(responseString, ErrorResponse.class);
        ErrorInfo errorInfo = errorResponse.getErrors().get(0);

        //then
        assertAll(
                () -> assertEquals(400, servletResponse.getStatus()),
                () -> assertEquals("PNA.MORTGAGE_API.SYS.001", errorResponse.getCode()),
                () -> assertEquals("Bad Request", errorResponse.getMessage()),
                () -> assertEquals("PNA.MORTGAGE_API.PUT_MORTGAGES_PAYMENTARRANGEMENT.Param.Invalid", errorInfo.getReasonCode()),
                () -> assertEquals("AccountId should be min 36 characters", errorInfo.getMessage())
        );
    }

    @Test
    public void shouldReturnErrorForUpdateWhenCorrelationIdIsGreaterThanFortyCharacters() {
        //given
        PaymentArrangementUpdateRequest paymentArrangementRequest = mortgagePaymentArrangementDataHelper.buildPaymentArrangementUpdateRequestAmendAmount("100");
        String payload = componentHelper.writeValueAsString(paymentArrangementRequest);
        HttpHeaders accountInfoHeaders = mortgagePaymentArrangementDataHelper.getAccountInfoHeaders();
        accountInfoHeaders.set("x-lbg-txn-correlation-id", RandomStringUtils.random(50));
        //when
        MockHttpServletResponse servletResponse = doPUT(UPDATE_PAYMENTARRANGEMENT_OPTIONS,
                payload,
                accountInfoHeaders);
        String responseString = componentHelper.getServletResponseAsString(servletResponse);
        ErrorResponse errorResponse = (ErrorResponse) readObject(responseString, ErrorResponse.class);
        ErrorInfo errorInfo = errorResponse.getErrors().get(0);

        //then
        assertAll(
                () -> assertEquals(400, servletResponse.getStatus()),
                () -> assertEquals("PNA.MORTGAGE_API.SYS.001", errorResponse.getCode()),
                () -> assertEquals("Bad Request", errorResponse.getMessage()),
                () -> assertEquals("PNA.MORTGAGE_API.PUT_MORTGAGES_PAYMENTARRANGEMENT.Header.Invalid", errorInfo.getReasonCode()),
                () -> assertEquals("x-lbg-txn-correlation-id size should be between 10 and 40", errorInfo.getMessage())
        );
    }

    @Test
    public void shouldReturnErrorForUpdateWhenCorrelationIdIsLessThanTenCharacters() {
        //given
        PaymentArrangementUpdateRequest paymentArrangementRequest = mortgagePaymentArrangementDataHelper.buildPaymentArrangementUpdateRequestAmendAmount("100");
        String payload = componentHelper.writeValueAsString(paymentArrangementRequest);
        HttpHeaders accountInfoHeaders = mortgagePaymentArrangementDataHelper.getAccountInfoHeaders();
        accountInfoHeaders.set("x-lbg-txn-correlation-id", RandomStringUtils.random(9));
        //when
        MockHttpServletResponse servletResponse = doPUT(UPDATE_PAYMENTARRANGEMENT_OPTIONS,
                payload,
                accountInfoHeaders);
        String responseString = componentHelper.getServletResponseAsString(servletResponse);
        ErrorResponse errorResponse = (ErrorResponse) readObject(responseString, ErrorResponse.class);
        ErrorInfo errorInfo = errorResponse.getErrors().get(0);

        //then
        assertAll(
                () -> assertEquals(400, servletResponse.getStatus()),
                () -> assertEquals("PNA.MORTGAGE_API.SYS.001", errorResponse.getCode()),
                () -> assertEquals("Bad Request", errorResponse.getMessage()),
                () -> assertEquals("PNA.MORTGAGE_API.PUT_MORTGAGES_PAYMENTARRANGEMENT.Header.Invalid", errorInfo.getReasonCode()),
                () -> assertEquals("x-lbg-txn-correlation-id size should be between 10 and 40", errorInfo.getMessage())
        );
    }

    @Test
    public void shouldReturnErrorForUpdateWhenCorrelationIdIsMissing() {
        //given
        PaymentArrangementUpdateRequest paymentArrangementRequest = mortgagePaymentArrangementDataHelper.buildPaymentArrangementUpdateRequestAmendAmount("100");
        String payload = componentHelper.writeValueAsString(paymentArrangementRequest);
        HttpHeaders accountInfoHeaders = mortgagePaymentArrangementDataHelper.getAccountInfoHeaders();
        accountInfoHeaders.remove("x-lbg-txn-correlation-id");
        //when
        MockHttpServletResponse servletResponse = doPUT(UPDATE_PAYMENTARRANGEMENT_OPTIONS,
                payload,
                accountInfoHeaders);
        String responseString = componentHelper.getServletResponseAsString(servletResponse);
        ErrorResponse errorResponse = (ErrorResponse) readObject(responseString, ErrorResponse.class);
        ErrorInfo errorInfo = errorResponse.getErrors().get(0);

        //then
        assertAll(
                () -> assertEquals(400, servletResponse.getStatus()),
                () -> assertEquals("PNA.MORTGAGE_API.SYS.001", errorResponse.getCode()),
                () -> assertEquals("Bad Request", errorResponse.getMessage()),
                () -> assertEquals("PNA.MORTGAGE_API.PUT_MORTGAGES_PAYMENTARRANGEMENT.Header.Missing.x-lbg-txn-correlation-id", errorInfo.getReasonCode()),
                () -> assertEquals("Missing request header x-lbg-txn-correlation-id for method parameter of type String", errorInfo.getMessage())
        );
    }

    @Test
    public void shouldReturnErrorForUpdateWhenBrandIsIncorrect() {
        //given
        PaymentArrangementUpdateRequest paymentArrangementRequest = mortgagePaymentArrangementDataHelper.buildPaymentArrangementUpdateRequestAmendAmount("100");
        String payload = componentHelper.writeValueAsString(paymentArrangementRequest);
        HttpHeaders accountInfoHeaders = mortgagePaymentArrangementDataHelper.getAccountInfoHeaders();
        accountInfoHeaders.set("x-lbg-brand", "xxx");
        //when
        MockHttpServletResponse servletResponse = doPUT(UPDATE_PAYMENTARRANGEMENT_OPTIONS,
                payload,
                accountInfoHeaders);
        String responseString = componentHelper.getServletResponseAsString(servletResponse);
        ErrorResponse errorResponse = (ErrorResponse) readObject(responseString, ErrorResponse.class);
        ErrorInfo errorInfo = errorResponse.getErrors().get(0);

        //then
        assertAll(
                () -> assertEquals(400, servletResponse.getStatus()),
                () -> assertEquals("PNA.MORTGAGE_API.SYS.001", errorResponse.getCode()),
                () -> assertEquals("Bad Request", errorResponse.getMessage()),
                () -> assertEquals("PNA.MORTGAGE_API.PUT_MORTGAGES_PAYMENTARRANGEMENT.Header.Invalid", errorInfo.getReasonCode()),
                () -> assertEquals("Invalid enum value for type x-lbg-brand", errorInfo.getMessage())
        );
    }

    @Test
    public void shouldReturnErrorForUpdateWhenBrandIsMissing() {
        //given
        PaymentArrangementUpdateRequest paymentArrangementRequest = mortgagePaymentArrangementDataHelper.buildPaymentArrangementUpdateRequestAmendAmount("100");
        String payload = componentHelper.writeValueAsString(paymentArrangementRequest);
        HttpHeaders accountInfoHeaders = mortgagePaymentArrangementDataHelper.getAccountInfoHeaders();
        accountInfoHeaders.remove("x-lbg-brand");
        //when
        MockHttpServletResponse servletResponse = doPUT(UPDATE_PAYMENTARRANGEMENT_OPTIONS,
                payload,
                accountInfoHeaders);
        String responseString = componentHelper.getServletResponseAsString(servletResponse);
        ErrorResponse errorResponse = (ErrorResponse) readObject(responseString, ErrorResponse.class);
        ErrorInfo errorInfo = errorResponse.getErrors().get(0);

        //then
        assertAll(
                () -> assertEquals(400, servletResponse.getStatus()),
                () -> assertEquals("PNA.MORTGAGE_API.SYS.001", errorResponse.getCode()),
                () -> assertEquals("Bad Request", errorResponse.getMessage()),
                () -> assertEquals("Missing request header 'x-lbg-brand' for method parameter of type String", errorInfo.getMessage())
        );
    }

    @Test
    public void shouldReturnErrorForEmptyJson() {
        //given
        //when
        MockHttpServletResponse servletResponse = doPUT(UPDATE_PAYMENTARRANGEMENT_OPTIONS,
                "{}",
                mortgagePaymentArrangementDataHelper.getAccountInfoHeaders());
        String responseString = componentHelper.getServletResponseAsString(servletResponse);
        ErrorResponse errorResponse = (ErrorResponse) readObject(responseString, ErrorResponse.class);
        ErrorInfo errorInfo = errorResponse.getErrors().get(0);

        //then
        assertAll(
                () -> assertEquals(400, servletResponse.getStatus()),
                () -> assertEquals("PNA.MORTGAGE_API.SYS.001", errorResponse.getCode()),
                () -> assertEquals("Bad Request", errorResponse.getMessage())

        );
    }

    @Test
    public void shouldReturnErrorForEmptyRequestBody() {
        //given
        //when
        MockHttpServletResponse servletResponse = doPUT(UPDATE_PAYMENTARRANGEMENT_OPTIONS,
                "",
                mortgagePaymentArrangementDataHelper.getAccountInfoHeaders());
        String responseString = componentHelper.getServletResponseAsString(servletResponse);
        ErrorResponse errorResponse = (ErrorResponse) readObject(responseString, ErrorResponse.class);
        ErrorInfo errorInfo = errorResponse.getErrors().get(0);

        //then
        assertAll(
                () -> assertEquals(400, servletResponse.getStatus()),
                () -> assertEquals("PNA.MORTGAGE_API.SYS.001", errorResponse.getCode()),
                () -> assertEquals("Bad Request", errorResponse.getMessage())

        );
    }


}
