package com.lbg.epscw.mortgagesrvc.restclient;


import com.lbg.epscw.mortgagesrvc.model.Asset;
import com.lbg.epscw.mortgagesrvc.model.ValuationCriteria;
import org.junit.Before;
import org.junit.Test;

import static com.lbg.epscw.mortgagesrvc.helper.MortgagePortingHelper.*;
import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.CoreMatchers.notNullValue;
import static org.hamcrest.MatcherAssert.assertThat;
import static com.lbg.epscw.mortgagesrvc.enums.ApplicationPurpose.PORTING;


public class MortgagePortingApplicationAssetRestClientStubTest {

    private MortgagePortingApplicationAssetRestClientStub underTest;

    @Before
    public void setup() {
        underTest = new MortgagePortingApplicationAssetRestClientStub();
    }

    @Test
    public void create_and_retrieve_asset_from_stub() {
        Asset asset = createAsset();

        Asset actual = underTest.getAssetByApplication(APPLICATION_NUMBER);

        assertThat(actual.getAssetId(), is(notNullValue()));
        assertThat(actual.getApplicationId(), is(APPLICATION_NUMBER));
        assertThat(actual.getCustomerId(), is(CUSTOMER_ID));
        assertThat(actual.getSecondCustomerId(), is(SECOND_CUSTOMER_ID));
        assertThat(actual.getMortgageNumber(), is(EXISTING_MORTGAGE_NUMBER));
        assertThat(actual.getPurpose(), is(PORTING));
        assertThat(actual.getNumberOfDependents(), is(1));

        asset = underTest.getAsset(asset.getAssetId());

        assertThat(asset, is(notNullValue()));
    }

    @Test
    public void update_asset_of_stub() {
        Asset asset = createAsset();
        asset.setValuationCriteria(ValuationCriteria.builder().subsidence(false).build());

        Asset actual = underTest.updateAsset(asset.getAssetId(), asset);

        assertThat(actual.getAssetId(), is(notNullValue()));
        assertThat(actual.getApplicationId(), is(APPLICATION_NUMBER));
        assertThat(actual.getCustomerId(), is(CUSTOMER_ID));
        assertThat(actual.getSecondCustomerId(), is(SECOND_CUSTOMER_ID));
        assertThat(actual.getMortgageNumber(), is(EXISTING_MORTGAGE_NUMBER));
        assertThat(actual.getPurpose(), is(PORTING));
        assertThat(actual.getNumberOfDependents(), is(1));

        asset = underTest.getAsset(asset.getAssetId());

        assertThat(asset, is(notNullValue()));
        assertThat(asset.getValuationCriteria(), is(notNullValue()));
    }

    private Asset createAsset() {
        return underTest.createAsset(APPLICATION_NUMBER, Asset.builder().customerId(CUSTOMER_ID)
                .secondCustomerId(SECOND_CUSTOMER_ID)
                .mortgageNumber(EXISTING_MORTGAGE_NUMBER)
                .purpose(PORTING)
                .numberOfDependents(1)
                .build());
    }
}