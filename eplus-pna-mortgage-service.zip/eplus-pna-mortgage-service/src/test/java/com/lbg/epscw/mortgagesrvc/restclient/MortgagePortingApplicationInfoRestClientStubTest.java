package com.lbg.epscw.mortgagesrvc.restclient;

import com.lbg.epscw.mortgagesrvc.helper.MortgagePortingHelper;
import com.lbg.epscw.mortgagesrvc.model.MortgageApplicationInfo;
import org.junit.Before;
import org.junit.Test;

import java.util.Optional;

import static com.lbg.epscw.mortgagesrvc.enums.ApplicationPurpose.PORTING;
import static com.lbg.epscw.mortgagesrvc.helper.MortgagePortingHelper.*;
import static com.lbg.epscw.mortgagesrvc.model.MortgagePortingApplicationStatus.APPROVED;
import static com.lbg.epscw.mortgagesrvc.model.MortgagePortingApplicationStatus.OPEN;
import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.CoreMatchers.notNullValue;
import static org.hamcrest.MatcherAssert.assertThat;


public class MortgagePortingApplicationInfoRestClientStubTest {
    private final MortgagePortingHelper helper = new MortgagePortingHelper();
    private MortgagePortingApplicationInfoRestClientStub underTest;

    @Before
    public void setup() {
        underTest = new MortgagePortingApplicationInfoRestClientStub();
    }

    @Test
    public void create_application_succeeds() {
        Optional<MortgageApplicationInfo> optional = underTest.createMortgageApplication(NEW_MORTGAGE_NUMBER, helper.createApplicationPayloadBuilder().build());
        MortgageApplicationInfo applicationInfo = optional.get();
        applicationInfo = underTest.getApplicationInfo(applicationInfo.getApplicationNumber());

        assertThat(applicationInfo.getApplicationNumber(), is(notNullValue()));
        assertThat(applicationInfo.getStatus(), is(OPEN));
        assertThat(applicationInfo.getPreviousMortgageNumber(), is(EXISTING_MORTGAGE_NUMBER));
        assertThat(applicationInfo.getCustomerId(), is(CUSTOMER_ID));
        assertThat(applicationInfo.getSecondCustomerId(), is(SECOND_CUSTOMER_ID));
        assertThat(applicationInfo.getPurpose(), is(PORTING.name()));
        assertThat(applicationInfo.getNumberOfDependents(), is(0));
    }

    @Test
    public void update_application_succeeds() {
        Optional<MortgageApplicationInfo> optional = underTest.createMortgageApplication(NEW_MORTGAGE_NUMBER, helper.createApplicationPayloadBuilder().build());
        MortgageApplicationInfo applicationInfo = optional.get();
        MortgageApplicationInfo response = underTest.updateApplication(applicationInfo.getApplicationNumber(), MortgageApplicationInfo.builder().status(APPROVED).build());

        assertThat(applicationInfo.getStatus(), is(OPEN));
        assertThat(response.getStatus(), is(APPROVED));
    }
}