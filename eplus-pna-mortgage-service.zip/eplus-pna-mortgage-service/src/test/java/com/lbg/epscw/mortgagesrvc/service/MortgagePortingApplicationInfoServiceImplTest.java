package com.lbg.epscw.mortgagesrvc.service;

import com.lbg.epscw.mortgagesrvc.helper.MortgagePortingApplicationHelper;
import com.lbg.epscw.mortgagesrvc.model.MortgageApplicationInfo;
import com.lbg.epscw.mortgagesrvc.restclient.MortgagePortingApplicationInfoRestClient;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.test.context.junit4.SpringRunner;

import static com.lbg.epscw.mortgagesrvc.model.MortgagePortingApplicationStatus.OPEN;
import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.CoreMatchers.notNullValue;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.powermock.api.mockito.PowerMockito.when;

@RunWith(SpringRunner.class)
public class MortgagePortingApplicationInfoServiceImplTest {


    @Mock
    private MortgagePortingApplicationInfoRestClient mortgagePortingApplicationInfoRestClient;

    @InjectMocks
    MortgagePortingApplicationInfoServiceImpl mortgagePortingApplicationInfoServiceImpl;

    private MortgagePortingApplicationHelper mortgagePortingApplicationHelper = new MortgagePortingApplicationHelper();

    @Test
    public void testGetApplicationInfo(){

        when(mortgagePortingApplicationInfoRestClient.getApplicationInfo(any(String.class))).
                thenReturn(mortgagePortingApplicationHelper.getMortgagePortingApplicationDetails());
        MortgageApplicationInfo applicationInfo = mortgagePortingApplicationInfoServiceImpl.getApplicationInfo("ApplicationNumber");

        assertThat(applicationInfo.getApplicationNumber(), is(notNullValue()));
        assertThat(applicationInfo.getStatus(), is(OPEN));

    }


}
