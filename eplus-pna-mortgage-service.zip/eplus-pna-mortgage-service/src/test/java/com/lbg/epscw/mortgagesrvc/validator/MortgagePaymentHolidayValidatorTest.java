package com.lbg.epscw.mortgagesrvc.validator;

import com.lbg.epscw.mortgagesrvc.dto.MortgageAccountInfo;
import com.lbg.epscw.mortgagesrvc.dto.PaymentHolidayEligibility;
import com.lbg.epscw.mortgagesrvc.exception.MortgageValidationException;
import com.lbg.epscw.mortgagesrvc.helper.MortgagePaymentHolidayHelper;
import com.lbg.epscw.mortgagesrvc.model.PaymentHolidayRequest;
import com.lbg.epscw.mortgagesrvc.restclient.MortgageAccountInfoRestClient;
import com.lbg.epscw.mortgagesrvc.restclient.MortgagePaymentHolidayEligibilityRestClient;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.HashMap;
import java.util.Map;

import static org.mockito.ArgumentMatchers.any;
import static org.powermock.api.mockito.PowerMockito.mock;
import static org.powermock.api.mockito.PowerMockito.when;

@RunWith(SpringRunner.class)
public class MortgagePaymentHolidayValidatorTest {

    @Mock
    private PaymentHolidayRequest paymentHolidayRequest;

    @Mock
    private MortgageAccountInfoRestClient mortgageAccountInfoRestClient;

    @Mock
    private MortgagePaymentHolidayEligibilityRestClient mortgagePaymentHolidayEligibilityRestClient;

    @Before
    public void setup() {
        mortgageAccountInfoRestClient = mock(MortgageAccountInfoRestClient.class);
        mortgagePaymentHolidayEligibilityRestClient = mock(MortgagePaymentHolidayEligibilityRestClient.class);
    }

    private final MortgagePaymentHolidayHelper mortgagePaymentHolidayHelper = new MortgagePaymentHolidayHelper();

    @Test
    public void shouldValidateAddPaymentHolidayRequestWhenAccountIsEligible() {
        when(paymentHolidayRequest.getStartMonthYear()).thenReturn("10/2021");
        when(paymentHolidayRequest.getEndMonthYear()).thenReturn("11/2021");
        //given
        PaymentHolidayEligibility paymentHolidayEligibility = mortgagePaymentHolidayHelper.buildPaymentHolidayEligibilityInfo(true);
        MortgagePaymentHolidayValidator mortgagePaymentHolidayValidator = new MortgagePaymentHolidayValidator(mortgageAccountInfoRestClient, mortgagePaymentHolidayEligibilityRestClient);
        when(mortgagePaymentHolidayEligibilityRestClient.getMortgagePaymentHolidayEligibility(any(String.class),any(String.class),any(String.class), any(Map.class))).thenReturn(paymentHolidayEligibility);
        mortgagePaymentHolidayValidator.validateAddPaymentHolidayRequest(paymentHolidayRequest, "144a38f3-a7b3-a3aa-d656-ff98fbaaa565", new HashMap<>());
    }

    @Test(expected = MortgageValidationException.class)
    public void shouldValidateAddPaymentHolidayRequestWhenAccountIsNotEligible() {
        when(paymentHolidayRequest.getStartMonthYear()).thenReturn("10/2021");
        when(paymentHolidayRequest.getEndMonthYear()).thenReturn("11/2021");
        //given
        PaymentHolidayEligibility paymentHolidayEligibility = mortgagePaymentHolidayHelper.buildPaymentHolidayEligibilityInfo(false);
        MortgagePaymentHolidayValidator mortgagePaymentHolidayValidator = new MortgagePaymentHolidayValidator(mortgageAccountInfoRestClient, mortgagePaymentHolidayEligibilityRestClient);
        when(mortgagePaymentHolidayEligibilityRestClient.getMortgagePaymentHolidayEligibility(any(String.class),any(String.class),any(String.class), any(Map.class))).thenReturn(paymentHolidayEligibility);
        mortgagePaymentHolidayValidator.validateAddPaymentHolidayRequest(paymentHolidayRequest, "144a38f3-a7b3-a3aa-d656-ff98fbaaa565", new HashMap<>());
    }

    @Test
    public void shouldValidateCancelPaymentHolidayRequest() {
        when(paymentHolidayRequest.getStartMonthYear()).thenReturn("03/2021");
        MortgageAccountInfo mortgageAccountInfo = mortgagePaymentHolidayHelper.mortgageAccountInfo_mortgagePaymentHolidayMock();
        MortgagePaymentHolidayValidator mortgagePaymentHolidayValidator = new MortgagePaymentHolidayValidator(mortgageAccountInfoRestClient, mortgagePaymentHolidayEligibilityRestClient);
        when(mortgageAccountInfoRestClient.getMortgageAccountInfo(any(String.class), any(Map.class))).thenReturn(mortgageAccountInfo);
        //given
        mortgagePaymentHolidayValidator.validateCancelPaymentHolidayRequest(paymentHolidayRequest, "144a38f3-a7b3-a3aa-d656-ff98fbaaa565", new HashMap<>());
    }

    @Test(expected = MortgageValidationException.class)
    public void shouldThrowExceptionWhenInvalidMonthAndYearAdd() {
        when(paymentHolidayRequest.getStartMonthYear()).thenReturn("12/2021");
        when(paymentHolidayRequest.getEndMonthYear()).thenReturn("11/2021");
        //given
        MortgagePaymentHolidayValidator mortgagePaymentHolidayValidator = new MortgagePaymentHolidayValidator(mortgageAccountInfoRestClient, mortgagePaymentHolidayEligibilityRestClient);
        mortgagePaymentHolidayValidator.validateAddPaymentHolidayRequest(paymentHolidayRequest, "144a38f3-a7b3-a3aa-d656-ff98fbaaa565", new HashMap<>());
    }

    @Test(expected = MortgageValidationException.class)
    public void shouldThrowExceptionWhenStartMonthAndYearIsInPast() {
        when(paymentHolidayRequest.getStartMonthYear()).thenReturn("02/2020");
        //given
        MortgagePaymentHolidayValidator mortgagePaymentHolidayValidator = new MortgagePaymentHolidayValidator(mortgageAccountInfoRestClient, mortgagePaymentHolidayEligibilityRestClient);
        mortgagePaymentHolidayValidator.validateAddPaymentHolidayRequest(paymentHolidayRequest, "144a38f3-a7b3-a3aa-d656-ff98fbaaa565", new HashMap<>());
    }

    @Test(expected = MortgageValidationException.class)
    public void shouldThrowExceptionWhenStartAndEndMonthNotConsecutiveForSameYear() {
        when(paymentHolidayRequest.getStartMonthYear()).thenReturn("04/2021");
        when(paymentHolidayRequest.getEndMonthYear()).thenReturn("06/2021");
        //given
        MortgagePaymentHolidayValidator mortgagePaymentHolidayValidator = new MortgagePaymentHolidayValidator(mortgageAccountInfoRestClient, mortgagePaymentHolidayEligibilityRestClient);
        mortgagePaymentHolidayValidator.validateAddPaymentHolidayRequest(paymentHolidayRequest, "144a38f3-a7b3-a3aa-d656-ff98fbaaa565", new HashMap<>());
    }

    @Test(expected = MortgageValidationException.class)
    public void shouldThrowExceptionWhenInvalidStartAndEndMonthForConsecutiveYear() {
        when(paymentHolidayRequest.getStartMonthYear()).thenReturn("11/2021");
        when(paymentHolidayRequest.getEndMonthYear()).thenReturn("03/2022");
        //given
        MortgagePaymentHolidayValidator mortgagePaymentHolidayValidator = new MortgagePaymentHolidayValidator(mortgageAccountInfoRestClient, mortgagePaymentHolidayEligibilityRestClient);
        mortgagePaymentHolidayValidator.validateAddPaymentHolidayRequest(paymentHolidayRequest, "144a38f3-a7b3-a3aa-d656-ff98fbaaa565", new HashMap<>());
    }

    @Test(expected = MortgageValidationException.class)
    public void shouldThrowExceptionWhenNonConsecutiveYear() {
        when(paymentHolidayRequest.getStartMonthYear()).thenReturn("11/2021");
        when(paymentHolidayRequest.getEndMonthYear()).thenReturn("03/2023");
        //given
        MortgagePaymentHolidayValidator mortgagePaymentHolidayValidator = new MortgagePaymentHolidayValidator(mortgageAccountInfoRestClient, mortgagePaymentHolidayEligibilityRestClient);
        mortgagePaymentHolidayValidator.validateAddPaymentHolidayRequest(paymentHolidayRequest, "144a38f3-a7b3-a3aa-d656-ff98fbaaa565", new HashMap<>());
    }

    @Test(expected = MortgageValidationException.class)
    public void shouldThrowExceptionWhenInvalidMonthAndYearCancel() {
        when(paymentHolidayRequest.getStartMonthYear()).thenReturn("12/2021");
        when(paymentHolidayRequest.getEndMonthYear()).thenReturn("11/2021");
        //given
        MortgagePaymentHolidayValidator mortgagePaymentHolidayValidator = new MortgagePaymentHolidayValidator(mortgageAccountInfoRestClient, mortgagePaymentHolidayEligibilityRestClient);
        mortgagePaymentHolidayValidator.validateCancelPaymentHolidayRequest(paymentHolidayRequest, "144a38f3-a7b3-a3aa-d656-ff98fbaaa565", new HashMap<>());
    }

    @Test(expected = MortgageValidationException.class)
    public void shouldThrowExceptionWhenPaymentHolidayDoesNotExist() {
        when(paymentHolidayRequest.getStartMonthYear()).thenReturn("10/2021");
        when(paymentHolidayRequest.getEndMonthYear()).thenReturn("11/2021");
        MortgageAccountInfo mortgageAccountInfo = mortgagePaymentHolidayHelper.mortgageAccountInfo_mortgagePaymentHolidayMock();
        MortgagePaymentHolidayValidator mortgagePaymentHolidayValidator = new MortgagePaymentHolidayValidator(mortgageAccountInfoRestClient, mortgagePaymentHolidayEligibilityRestClient);
        when(mortgageAccountInfoRestClient.getMortgageAccountInfo(any(String.class), any(Map.class))).thenReturn(mortgageAccountInfo);
        //given
        mortgagePaymentHolidayValidator.validateCancelPaymentHolidayRequest(paymentHolidayRequest, "144a38f3-a7b3-a3aa-d656-ff98fbaaa565", new HashMap<>());
    }

    @Test(expected = MortgageValidationException.class)
    public void shouldThrowExceptionWhenPaymentHolidayNotEligible() {
        when(paymentHolidayRequest.getStartMonthYear()).thenReturn("05/2021");
        when(paymentHolidayRequest.getEndMonthYear()).thenReturn("06/2021");
        MortgageAccountInfo mortgageAccountInfo = mortgagePaymentHolidayHelper.mortgageAccountInfo_mortgagePaymentHolidayMockforEligibile();
        MortgagePaymentHolidayValidator mortgagePaymentHolidayValidator = new MortgagePaymentHolidayValidator(mortgageAccountInfoRestClient, mortgagePaymentHolidayEligibilityRestClient);
        when(mortgageAccountInfoRestClient.getMortgageAccountInfo(any(String.class), any(Map.class))).thenReturn(mortgageAccountInfo);
        //given
        mortgagePaymentHolidayValidator.validateCancelPaymentHolidayRequest(paymentHolidayRequest, "144a38f3-a7b3-a3aa-d656-ff98fbaaa565", new HashMap<>());
    }

    @Test(expected = MortgageValidationException.class)
    public void shouldThrowExceptionWhenAllPaymentHolidayDoesNotExist() {
        when(paymentHolidayRequest.getStartMonthYear()).thenReturn("11/2021");
        when(paymentHolidayRequest.getEndMonthYear()).thenReturn("01/2022");
        MortgageAccountInfo mortgageAccountInfo = mortgagePaymentHolidayHelper.mortgageAccountInfo_mortgagePaymentHolidayMock();
        MortgagePaymentHolidayValidator mortgagePaymentHolidayValidator = new MortgagePaymentHolidayValidator(mortgageAccountInfoRestClient, mortgagePaymentHolidayEligibilityRestClient);
        when(mortgageAccountInfoRestClient.getMortgageAccountInfo(any(String.class), any(Map.class))).thenReturn(mortgageAccountInfo);
        //given
        mortgagePaymentHolidayValidator.validateCancelPaymentHolidayRequest(paymentHolidayRequest, "144a38f3-a7b3-a3aa-d656-ff98fbaaa565", new HashMap<>());
    }
}