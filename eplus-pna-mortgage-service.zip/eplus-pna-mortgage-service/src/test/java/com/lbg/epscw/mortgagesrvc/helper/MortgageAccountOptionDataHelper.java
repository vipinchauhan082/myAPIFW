package com.lbg.epscw.mortgagesrvc.helper;

import com.lbg.epscw.mortgagesrvc.enums.MortgageOptionInstructionEnum;
import com.lbg.epscw.mortgagesrvc.enums.RepaymentType;
import com.lbg.epscw.mortgagesrvc.model.*;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;

import java.util.EnumMap;
import java.util.HashMap;
import java.util.Map;

@Component
public class MortgageAccountOptionDataHelper {
	
    public HttpHeaders getAccountInfoHeaders() {
        HttpHeaders httpHeaders = new HttpHeaders();
        httpHeaders.add("Authorization", "Bearer 1601d0e5-e336-64d9-64ad-89ba6fdc2677");
        httpHeaders.add("x-lbg-internal-system-id", "test");
        httpHeaders.add("x-lbg-brand", "IF");
        httpHeaders.add("x-lbg-txn-correlation-id", "123-456-789-123");
        httpHeaders.setContentType(MediaType.APPLICATION_JSON);
        return httpHeaders;
    }

	public AccountOptionsUpdateResponse buildAccountOptionsUpdateResponse(String paramName, String paramValue) {
		AccountOptionsUpdateResponse response = new AccountOptionsUpdateResponse();
		response.setAccountId("1601d0e5-e336-64d9-64ad-89ba6fdc2677");
		InstanceParamValsUpdate instanceParamValsUpdate = new InstanceParamValsUpdate();
		HashMap<String, String> instanceParamMap = new HashMap<String, String>();
		instanceParamMap.put(paramName,paramValue);
		instanceParamValsUpdate.setInstanceParamVals(instanceParamMap);
		response.setInstanceParamValsUpdate(instanceParamValsUpdate);
		response.setStatus("ACCOUNT_UPDATE_STATUS_PENDING_EXECUTION");
		return response;
	}
	
	public MortgageOptionsUpdateResponse buildMortgageOptionsUpdateResponse(String paramName, String paramValue) {
		MortgageOptionsUpdateResponse response = new MortgageOptionsUpdateResponse();
		Map<String, String> instanceParamVals = new HashMap<>();
		instanceParamVals.put(paramName,paramValue);
		response.setInstanceParamVals(instanceParamVals);
		response.setAccountId("1601d0e5-e336-64d9-64ad-89ba6fdc2677");
		response.setStatus("ACCOUNT_UPDATE_STATUS_PENDING_EXECUTION");
		return response;
	}
	
	public AccountOptionsUpdateRequest buildAccountOptionsUpdateRequestForMortgageTerm( MortgageOptionInstructionEnum optionEnum ,String param) {
		AccountOptionsUpdateRequest request = new AccountOptionsUpdateRequest();
		EnumMap<MortgageOptionInstructionEnum, String> accountOptions = new EnumMap<MortgageOptionInstructionEnum, String>(MortgageOptionInstructionEnum.class);
		accountOptions.put(optionEnum,param);
		request.setRepaymentScheduleParamVals(accountOptions);
		return request;
	}

	public AccountOptionsUpdateRequest buildAccountOptionsUpdateRequest() {
		AccountOptionsUpdateRequest request = new AccountOptionsUpdateRequest();
		request.setLoanAmount("1000");
		request.setTotalTerm("8");
		request.setRepaymentType(RepaymentType.CAPITAL_REPAYMENT.name());

		EnumMap<MortgageOptionInstructionEnum, String> accountOptions = new EnumMap<MortgageOptionInstructionEnum, String>(MortgageOptionInstructionEnum.class);
		accountOptions.put(MortgageOptionInstructionEnum.RepaymentType,"CAPITAL_REPAYMENT");
		request.setRepaymentScheduleParamVals(accountOptions);
		return request;
	}

	public MortgageOptionsUpdateResponse buildMortgageOptionsUpdateResponse() {
		MortgageOptionsUpdateResponse response = new MortgageOptionsUpdateResponse();
		Map<String, String> instanceParamVals = new HashMap<>();
		instanceParamVals.put("TotalTerm","8");
		instanceParamVals.put("RepaymentType","CAPITAL_REPAYMENT");
		instanceParamVals.put("LoanAmount","1000");

		response.setInstanceParamVals(instanceParamVals);
		response.setAccountId("1601d0e5-e336-64d9-64ad-89ba6fdc2677");
		response.setStatus("ACCOUNT_UPDATE_STATUS_PENDING_EXECUTION");
		return response;
	}
	
	public AccountOptionsUpdateRequest buildAccountOptionsUpdateRequestForMortgageType(String param) {
		AccountOptionsUpdateRequest request = new AccountOptionsUpdateRequest();
		EnumMap<MortgageOptionInstructionEnum, String> accoutOptions = new EnumMap<MortgageOptionInstructionEnum, String>(MortgageOptionInstructionEnum.class);
		accoutOptions.put(MortgageOptionInstructionEnum.RepaymentType,param);
		request.setRepaymentScheduleParamVals(accoutOptions);
		return request;
	}

	public AccountOptionsUpdateRequest buildAccountOptionsUpdateRequeste() {
		AccountOptionsUpdateRequest request = new AccountOptionsUpdateRequest();
		request.setRepaymentType(RepaymentType.CAPITAL_REPAYMENT.name());
		request.setLoanAmount("1000");
		return request;
	}

	public VaultAccountOptionsUpdateRequest buildVaultAccountOptionsUpdateRequest(String value, String key) {
		AccountUpdate accountUpdate = new AccountUpdate();
		accountUpdate.setAccountId("1601d0e5-e336-64d9-64ad-89ba6fdc2677");
		Map<String, String> vaultInstanceParamsMap = new HashMap<>();
		vaultInstanceParamsMap.put(key, value);
		InstanceParamValsUpdate paramsValUpdate = new InstanceParamValsUpdate();
		paramsValUpdate.setInstanceParamVals(vaultInstanceParamsMap);
		accountUpdate.setInstanceParamValsUpdate(paramsValUpdate);

		VaultAccountOptionsUpdateRequest vaultRequest = new VaultAccountOptionsUpdateRequest();
		vaultRequest.setItems(accountUpdate);
		vaultRequest.setRequestId("dummy-correlation-id");
		
		return vaultRequest;
	}
}
