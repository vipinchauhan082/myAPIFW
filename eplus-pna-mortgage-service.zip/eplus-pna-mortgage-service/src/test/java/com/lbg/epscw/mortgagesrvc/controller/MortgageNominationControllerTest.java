package com.lbg.epscw.mortgagesrvc.controller;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.lbg.epscw.mortgagesrvc.exception.MortgageServiceException;
import com.lbg.epscw.mortgagesrvc.helper.MortgageNominationHelper;
import com.lbg.epscw.mortgagesrvc.model.Channel;
import com.lbg.epscw.mortgagesrvc.model.NominationRequest;
import com.lbg.epscw.mortgagesrvc.model.NominationResponse;
import com.lbg.epscw.mortgagesrvc.service.MortgageNominationService;
import com.lbg.epscw.mortgagesrvc.util.MortgageServiceUtil;
import com.lbg.epscw.mortgagesrvc.validator.NominationServiceValidator;
import lombok.extern.flogger.Flogger;
import org.apache.commons.lang.RandomStringUtils;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit4.SpringRunner;

import javax.validation.ConstraintViolationException;
import java.util.HashMap;

import static org.junit.Assert.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.powermock.api.mockito.PowerMockito.doNothing;
import static org.powermock.api.mockito.PowerMockito.when;

@Flogger
@RunWith(SpringRunner.class)
@WebMvcTest(controllers = { MortgageServiceUtil.class, MortgageNominationController.class })
public class MortgageNominationControllerTest {

    @MockBean
    private MortgageNominationService mortgageNominationService;

    @MockBean
    private NominationServiceValidator nominationServiceValidator;

    @Autowired
    private MortgageNominationController mortgageNominationController;

    private final MortgageNominationHelper mortgageNominationHelper = new MortgageNominationHelper();

    public static final String ACCOUNT_ID = "f76ca840-2553-d536-1ab8-9fa85c99db05";

    @Test
    public void addMortgageNomination() throws JsonProcessingException {
        //given
        doNothing().when(nominationServiceValidator).validateNominationRequest(any(NominationRequest.class), any(String.class), any(HashMap.class));
        when(mortgageNominationService.addNomination(any(NominationRequest.class), any(String.class)))
                .thenReturn(mortgageNominationHelper.getMockUpdateNominationResponse());

        //when
        ResponseEntity<NominationResponse> responseEntity = mortgageNominationController.addMortgageNomination(
                "IF", Channel.DIGITAL.name(), "123-456-789-12", null, "ALL", new HashMap<String, String>(),
                mortgageNominationHelper.getNominationRequest(),
                ACCOUNT_ID
        );
        NominationResponse response = responseEntity.getBody();
        //then
        assertEquals("f76ca840-2553-d536-1ab8-9fa85c99db05", response.getAccountId());
        assertEquals("ACCOUNT_UPDATE_STATUS_PENDING_EXECUTION", response.getStatus());
        assertEquals("90e804ab-5dad-7f7c-1d71-ab914545ebcc", response.getAdditionalDetails().get("NominatedAdhocOverpaymentAccount"));

    }

    @Test
    public void updateMortgageNomination() throws JsonProcessingException {
        //given
        doNothing().when(nominationServiceValidator).validateNominationRequest(any(NominationRequest.class), any(String.class), any(HashMap.class));
        when(mortgageNominationService.updateNomination(any(NominationRequest.class), any(String.class)))
                .thenReturn(mortgageNominationHelper.getMockUpdateNominationResponse());

        //when
        ResponseEntity<NominationResponse> responseEntity = mortgageNominationController.updateMortgageNomination(
                "IF",Channel.DIGITAL.name(), "123-456-789-12", null, "ALL", new HashMap<String, String>(),
                mortgageNominationHelper.getNominationRequest(),
                ACCOUNT_ID
        );
        NominationResponse response = responseEntity.getBody();
        log.atInfo().log(new ObjectMapper().writeValueAsString(response));
        //then
        assertEquals("f76ca840-2553-d536-1ab8-9fa85c99db05", response.getAccountId());
        assertEquals("ACCOUNT_UPDATE_STATUS_PENDING_EXECUTION", response.getStatus());
        assertEquals("90e804ab-5dad-7f7c-1d71-ab914545ebcc", response.getAdditionalDetails().get("NominatedAdhocOverpaymentAccount"));

    }

    @Test
    public void deleteMortgageNomination() throws JsonProcessingException {
        //given
        doNothing().when(nominationServiceValidator).validateNominationRequest(any(NominationRequest.class), any(String.class), any(HashMap.class));
        when(mortgageNominationService.deleteNomination(any(String.class)))
                .thenReturn(mortgageNominationHelper.getMockDeleteNominationResponse());

        //when
        ResponseEntity<NominationResponse> responseEntity = mortgageNominationController.deleteMortgageNomination(
                "IF",Channel.DIGITAL.name(), "123-456-789-12", null, "ALL", new HashMap<String, String>(),
                ACCOUNT_ID
        );
        NominationResponse response = responseEntity.getBody();
        log.atInfo().log(new ObjectMapper().writeValueAsString(response));
        //then
        assertEquals("f76ca840-2553-d536-1ab8-9fa85c99db05", response.getAccountId());
        assertEquals("ACCOUNT_UPDATE_STATUS_PENDING_EXECUTION", response.getStatus());
        assertEquals("", response.getAdditionalDetails().get("NominatedAdhocOverpaymentAccount"));

    }

    @Test(expected = MortgageServiceException.class)
    public void shouldThrowExceptionWhenUpdateServiceMethodReturnsNull() {
        //given
        when(mortgageNominationService.updateNomination(any(NominationRequest.class), any(String.class))).thenReturn(null);

        //when
        mortgageNominationController.updateMortgageNomination(
                "IF",Channel.DIGITAL.name(), "123-456-789-12", null, "ALL", new HashMap<String, String>(),
                mortgageNominationHelper.getNominationRequest(),
                ACCOUNT_ID
        );
    }

    @Test(expected = MortgageServiceException.class)
    public void shouldThrowExceptionWhenAddServiceMethodReturnsNull() {
        //given
        when(mortgageNominationService.addNomination(any(NominationRequest.class), any(String.class))).thenReturn(null);

        //when
        mortgageNominationController.addMortgageNomination(
                "IF",Channel.DIGITAL.name(),"123-456-789-12", null, "ALL", new HashMap<String, String>(),
                mortgageNominationHelper.getNominationRequest(),
                ACCOUNT_ID
        );
    }

    @Test(expected = MortgageServiceException.class)
    public void shouldThrowExceptionWhenDeleteServiceMethodReturnsNull() {
        //given
        when(mortgageNominationService.deleteNomination(any(String.class))).thenReturn(null);

        //when
        mortgageNominationController.deleteMortgageNomination(
                "IF",Channel.DIGITAL.name(), "123-456-789-12", null, "ALL", new HashMap<String, String>(),
                ACCOUNT_ID
        );
    }

    @Test(expected = ConstraintViolationException.class)
    public void shouldThrowExceptionWhenAccountIdLengthIsSmall() {
        //when
        mortgageNominationController.updateMortgageNomination(
                "IF",Channel.DIGITAL.name(), "123-456-789-12", null, "ALL", new HashMap<String, String>(),
                mortgageNominationHelper.getNominationRequest(),
                ACCOUNT_ID.substring(5)
        );
    }

    @Test(expected = ConstraintViolationException.class)
    public void shouldThrowExceptionWhenAccountIdLengthIsLong() {
        //when
        mortgageNominationController.updateMortgageNomination(
                "IF",Channel.DIGITAL.name(), "123-456-789-12", null, "ALL", new HashMap<String, String>(),
                mortgageNominationHelper.getNominationRequest(),
                ACCOUNT_ID.concat("123")
        );
    }

    @Test(expected = ConstraintViolationException.class)
    public void shouldThrowExceptionWhenAccountIdLengthIsEmpty() {
        //when
        mortgageNominationController.updateMortgageNomination(
                "IF",Channel.DIGITAL.name(), "123-456-789-12", null, "ALL", new HashMap<String, String>(),
                mortgageNominationHelper.getNominationRequest(),
                ""
        );
    }

    @Test(expected = ConstraintViolationException.class)
    public void shouldThrowExceptionWhenAccountIdLengthIsNull() {
        //when
        mortgageNominationController.updateMortgageNomination(
                "IF",Channel.DIGITAL.name(), "123-456-789-12", null, "ALL", new HashMap<String, String>(),
                mortgageNominationHelper.getNominationRequest(),
                null
        );
    }

    @Test(expected = ConstraintViolationException.class)
    public void shouldThrowExceptionWhenBrandHeaderIsNull() {
        //when
        mortgageNominationController.updateMortgageNomination(
                null,Channel.DIGITAL.name(),"123-456-789-12", null, "ALL", new HashMap<String, String>(),
                mortgageNominationHelper.getNominationRequest(),
                ACCOUNT_ID
        );
    }

    @Test(expected = ConstraintViolationException.class)
    public void shouldThrowExceptionWhenBrandHeaderIsInvalid() {
        //when
        mortgageNominationController.updateMortgageNomination(
                "IFF",Channel.DIGITAL.name(), "123-456-789-12", null, "ALL", new HashMap<String, String>(),
                mortgageNominationHelper.getNominationRequest(),
                ACCOUNT_ID
        );
    }

    @Test(expected = ConstraintViolationException.class)
    public void shouldThrowExceptionWhenCorrelationIdIsNull() {
        //when
        mortgageNominationController.updateMortgageNomination(
                "IF",Channel.DIGITAL.name(), null, null, "ALL", new HashMap<String, String>(),
                mortgageNominationHelper.getNominationRequest(),
                ACCOUNT_ID
        );
    }

    @Test(expected = ConstraintViolationException.class)
    public void shouldThrowExceptionWhenCorrelationIdIsEmpty() {
        //when
        mortgageNominationController.updateMortgageNomination(
                "IF",Channel.DIGITAL.name(), "", null, "ALL", new HashMap<String, String>(),
                mortgageNominationHelper.getNominationRequest(),
                ACCOUNT_ID
        );
    }

    @Test(expected = ConstraintViolationException.class)
    public void shouldThrowExceptionWhenCorrelationIdIsSmall() {
        //when
        mortgageNominationController.updateMortgageNomination(
                "IF",Channel.DIGITAL.name(), "123-456", null, "ALL", new HashMap<String, String>(),
                mortgageNominationHelper.getNominationRequest(),
                ACCOUNT_ID
        );
    }

    @Test(expected = ConstraintViolationException.class)
    public void shouldThrowExceptionWhenCorrelationIdIsLong() {
        //when
        mortgageNominationController.updateMortgageNomination(
                "IF",Channel.DIGITAL.name(), RandomStringUtils.random(50), null, "ALL", new HashMap<String, String>(),
                mortgageNominationHelper.getNominationRequest(),
                ACCOUNT_ID
        );
    }
}