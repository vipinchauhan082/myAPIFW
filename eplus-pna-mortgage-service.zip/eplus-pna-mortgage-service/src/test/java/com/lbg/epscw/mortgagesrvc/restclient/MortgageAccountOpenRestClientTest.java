package com.lbg.epscw.mortgagesrvc.restclient;


import com.lbg.epscw.mortgagesrvc.dto.*;
import com.lbg.epscw.mortgagesrvc.exception.MortgageServiceException;

import com.lbg.epscw.mortgagesrvc.dto.AccountCreationResponse;

import com.lbg.epscw.mortgagesrvc.helper.AccountCreationHelper;
import com.lbg.epscw.mortgagesrvc.model.AccountOpenRequest;
import com.lbg.epscw.mortgagesrvc.service.RestClientService;
import com.lbg.epscw.mortgagesrvc.util.MortgageServiceUtil;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.internal.util.reflection.FieldSetter;
import org.powermock.modules.junit4.PowerMockRunner;

import org.springframework.http.MediaType;


import java.util.HashMap;
import java.util.Map;




import static org.junit.Assert.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.powermock.api.mockito.PowerMockito.when;

@RunWith(PowerMockRunner.class)
public class MortgageAccountOpenRestClientTest {

    @Mock
    RestClientService restClientService;

    @Mock
    MortgageServiceUtil mortgageServiceUtil;

    @InjectMocks
    private MortgageAccountOpenRestClient mortgageAccountOpenRestClient;



    @Test
    public void subAccountShouldBeCreatedForCaptialzationOfArrears() throws NoSuchFieldException {

        FieldSetter.setField(mortgageAccountOpenRestClient,
                mortgageAccountOpenRestClient.getClass().getDeclaredField("mortgageAccountOpenEndpoint"),"mortgageAccountCreationEndpoint");

        when(mortgageServiceUtil.writeObjectAsString(any(AccountOpenRequest.class)))
                .thenReturn("");

        when(mortgageServiceUtil.readObject(any(String.class), any(Class.class)))
                .thenReturn(AccountCreationHelper.buildCreateAccountResponse());

        when(restClientService.post(Mockito.any(),Mockito.any(),Mockito.any())).thenReturn("");

        AccountCreationResponse mortgageAccount = mortgageAccountOpenRestClient.createMortgageAccount(new AccountOpenRequest(), new HashMap<>());

        assertEquals("ACCOUNT_STATUS_OPEN",mortgageAccount.getStatus());
        assertEquals("lbg_mortgage",mortgageAccount.getProductId());
        assertEquals("mortgage", mortgageAccount.getProductName());

    }



    @Test
    public void create_payment_device_link() throws NoSuchFieldException {
        //given


        FieldSetter.setField(mortgageAccountOpenRestClient,
                mortgageAccountOpenRestClient.getClass().getDeclaredField("createPaymentDeviceLinkEndPoint"), "");

        when(mortgageServiceUtil.fetchDefaultVaultHeaders())
                .thenReturn(account_open_headers());

        when(mortgageServiceUtil.writeObjectAsString(any(BankAccountRequest.class))).thenReturn("");

        when(mortgageServiceUtil.readObject(any(String.class), any(Class.class)))
                .thenReturn(bankAccountResponse());


        when(restClientService.post(Mockito.any(),Mockito.any(),Mockito.any())).thenReturn(
                        "");

        AccountCreationResponse accountCreationResponse =
                AccountCreationHelper.buildCreateAccountResponse();
        accountCreationResponse.setAccountNumber("44656030");
        accountCreationResponse.setExternalAccountId("2bfa8d5a-60c2-4560-b7e4-76578aa76244");
        accountCreationResponse.setSortCode("119120");

        //when
        mortgageAccountOpenRestClient.createPaymentDeviceLink(accountCreationResponse);

        //then
        assertEquals("id1",
                accountCreationResponse.getInternalAccountId());
        assertEquals("mortgage", accountCreationResponse.getProductName());
        assertEquals("ACCOUNT_STATUS_OPEN", accountCreationResponse.getStatus());
        assertEquals("44656030", accountCreationResponse.getAccountNumber());
        assertEquals("2bfa8d5a-60c2-4560-b7e4-76578aa76244",
                accountCreationResponse.getExternalAccountId());
        assertEquals("119120", accountCreationResponse.getSortCode());
    }

    @Test(expected = MortgageServiceException.class)
    public void vault_fails_to_create_payment_device_link() throws NoSuchFieldException {
        //given


        FieldSetter.setField(mortgageAccountOpenRestClient,
                mortgageAccountOpenRestClient.getClass().getDeclaredField("createPaymentDeviceLinkEndPoint"), "");

        when(mortgageServiceUtil.fetchDefaultVaultHeaders())
                .thenReturn(account_open_headers());

        when(mortgageServiceUtil.writeObjectAsString(any(BankAccountRequest.class))).thenReturn("");

        when(mortgageServiceUtil.readObject(any(String.class), any(Class.class)))
                //.thenReturn(new PaymentDeviceLinkResponse());
                .thenReturn(new BankAccountResponse());
        when(restClientService.post(Mockito.any(),Mockito.any(),Mockito.any())).thenReturn(
                "");

        AccountCreationResponse accountCreationResponse =
                AccountCreationHelper.buildCreateAccountResponse();
        accountCreationResponse.setAccountNumber("44656030");
        accountCreationResponse.setExternalAccountId("2bfa8d5a-60c2-4560-b7e4-76578aa76244");
        accountCreationResponse.setSortCode("119120");

        //when
        mortgageAccountOpenRestClient.createPaymentDeviceLink(accountCreationResponse);
    }


    @Test
    public void generate_accountNo_From_vault() throws NoSuchFieldException {

        FieldSetter.setField(mortgageAccountOpenRestClient,
                mortgageAccountOpenRestClient.getClass().getDeclaredField("createExternalAccountEndPoint"), "");

        when(restClientService.post(Mockito.any(),Mockito.any(),Mockito.any())).thenReturn(
                "");

        VaultAccountNumberGenerationResponse vaultAccountNumberGenerationResponse = new VaultAccountNumberGenerationResponse();
        AccountCreationResponse accountCreationResponse =
                AccountCreationHelper.buildCreateAccountResponse();
        vaultAccountNumberGenerationResponse.setAccountNumber("44656030");
        vaultAccountNumberGenerationResponse.setId("2bfa8d5a-60c2-4560-b7e4-76578aa76244");
        vaultAccountNumberGenerationResponse.setSortCode("119120");

        when(mortgageServiceUtil.fetchDefaultVaultHeaders())
                .thenReturn(account_open_headers());

        when(mortgageServiceUtil.writeObjectAsString(any(ExternalAccountOpenRequest.class))).thenReturn("");

        when(mortgageServiceUtil.readObject(any(String.class), any(Class.class)))
                .thenReturn(vaultAccountNumberGenerationResponse);

        mortgageAccountOpenRestClient.generateAccountNoFromVault(accountCreationResponse);

        assertEquals("id1",
                accountCreationResponse.getInternalAccountId());
        assertEquals("mortgage", accountCreationResponse.getProductName());
        assertEquals("ACCOUNT_STATUS_OPEN", accountCreationResponse.getStatus());
        assertEquals("44656030", accountCreationResponse.getAccountNumber());
        assertEquals("2bfa8d5a-60c2-4560-b7e4-76578aa76244",
                accountCreationResponse.getExternalAccountId());
        assertEquals("119120", accountCreationResponse.getSortCode());
    }


    @Test(expected = MortgageServiceException.class)
    public void vault_fails_to_generate_accountNo_From_vault() throws NoSuchFieldException {

        FieldSetter.setField(mortgageAccountOpenRestClient,
                mortgageAccountOpenRestClient.getClass().getDeclaredField("createExternalAccountEndPoint"), "");

        when(restClientService.post(Mockito.any(),Mockito.any(),Mockito.any())).thenReturn(
                "");

        VaultAccountNumberGenerationResponse vaultAccountNumberGenerationResponse = new VaultAccountNumberGenerationResponse();
        AccountCreationResponse accountCreationResponse =
                AccountCreationHelper.buildCreateAccountResponse();


        when(mortgageServiceUtil.fetchDefaultVaultHeaders())
                .thenReturn(account_open_headers());

        when(mortgageServiceUtil.writeObjectAsString(any(ExternalAccountOpenRequest.class))).thenReturn("");

        when(mortgageServiceUtil.readObject(any(String.class), any(Class.class)))
                .thenReturn(vaultAccountNumberGenerationResponse);

        mortgageAccountOpenRestClient.generateAccountNoFromVault(accountCreationResponse);

    }

    public BankAccountResponse bankAccountResponse() {
        BankAccountResponse bankAccountResponse = new BankAccountResponse();
        bankAccountResponse.setId("470292e9-5da7-4a08-b8d2-41482009dfcb");
        RoutingAddress routingAddress = new RoutingAddress();
        routingAddress.setBankIdCode("GBDSC");
        routingAddress.setBankId("119160");
        routingAddress.setAccountNumber("35421338");
        bankAccountResponse.setRoutingAddress(routingAddress);

        return bankAccountResponse;
    }


    public Map<String, String> account_open_headers() {
        Map<String, String> headers = new HashMap<String, String>();
        headers.put("Authorization", "Bearer 12424234");
        headers.put("x-lbg-brand", "IF");
        headers.put("x-lbg-txn-correlation-id", "123-456-789");
        headers.put("Content-Type", MediaType.APPLICATION_JSON_VALUE);
        return headers;
    }

}
