package com.lbg.epscw.mortgagesrvc.controller;

import com.lbg.epscw.mortgagesrvc.dto.AccountCreationResponse;
import com.lbg.epscw.mortgagesrvc.exception.MortgageServiceException;
import com.lbg.epscw.mortgagesrvc.helper.MortgageAccountDataHelper;
import com.lbg.epscw.mortgagesrvc.model.AccountOpenRequest;
import com.lbg.epscw.mortgagesrvc.model.BenefitsRequest;
import com.lbg.epscw.mortgagesrvc.model.BenefitsResponse;
import com.lbg.epscw.mortgagesrvc.model.Channel;
import com.lbg.epscw.mortgagesrvc.service.MortgageAccountService;
import com.lbg.epscw.mortgagesrvc.helper.AccountCreationHelper;
import com.lbg.epscw.mortgagesrvc.util.MortgageServiceUtil;
import com.lbg.epscw.mortgagesrvc.validator.MortgageSubAccountValidator;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit4.SpringRunner;

import javax.validation.ConstraintViolationException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static org.junit.Assert.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.powermock.api.mockito.PowerMockito.doNothing;
import static org.powermock.api.mockito.PowerMockito.when;

@RunWith(SpringRunner.class)
@WebMvcTest(controllers = { MortgageServiceUtil.class, MortgageAccountController.class })
public class MortgageAccountControllerTest {

    @MockBean
    private MortgageAccountService mortgageAccountService;

    @MockBean
    private MortgageSubAccountValidator validator;

    @Autowired
    private MortgageServiceUtil mortgageServiceUtil;

    @Autowired
    private MortgageAccountController subAccountController;

    private MortgageAccountDataHelper helper = new MortgageAccountDataHelper();

    @Test
    public void testCreateAccountMortgage(){

        //Given
        doNothing().when(validator).validateSubAccountOpening(any(AccountOpenRequest.class));
        when(mortgageAccountService.openAccount(any(AccountOpenRequest.class), any(Map.class)))
                .thenReturn(AccountCreationHelper.buildCreateAccountResponse());

        //When
        ResponseEntity<AccountCreationResponse> response = subAccountController.createAccount("IF", Channel.DIGITAL.name(), "123-456-789-12", "Bearer 122", "ALL", new HashMap<String, String>(),
                AccountCreationHelper.generateAccountOpenRequestMortgage());
        //Then
        assertEquals(HttpStatus.OK,response.getStatusCode());

    }

    @Test(expected = ConstraintViolationException.class)
    public void testCreateAccountMortgageWithNoBrand(){

        //Given
        doNothing().when(validator).validateSubAccountOpening(any(AccountOpenRequest.class));
        when(mortgageAccountService.openAccount(any(AccountOpenRequest.class), any(Map.class)))
                .thenReturn(AccountCreationHelper.buildCreateAccountResponse());

        //When
        ResponseEntity<AccountCreationResponse> response = subAccountController.createAccount(null, Channel.DIGITAL.name(), "123-456-789-12", "Bearer 122", "ALL", new HashMap<String, String>(),
                AccountCreationHelper.generateAccountOpenRequestMortgage());
    }

    @Test
    public void setBenefitsDetails_success(){

        doNothing().when(validator).validateBenefitRequest(any(BenefitsRequest.class));
        when(validator.validateForOverarchingAccount(any(String.class),any(HashMap.class))).
                thenReturn(helper.accountList_mock());
        when(mortgageAccountService.updateAccountBenefitsDetails(any(List.class),any(BenefitsRequest.class))).
                thenReturn(helper.mockResponse_TrueBenefits());

        ResponseEntity<BenefitsResponse> responseEntity = subAccountController.setBenefitsDetails(
                "IF", Channel.DIGITAL.name(), "123-456-789-12", null, "ALL", new HashMap<String, String>(),
                helper.mockRequest_TrueBenefits(), MortgageAccountDataHelper.MOCK_ACCOUNT_ID);
        BenefitsResponse response = responseEntity.getBody();

        assertEquals(MortgageAccountDataHelper.MOCK_ACCOUNT_ID, response.getAccountId());
        assertEquals(2, response.getBenefitsDetails().size());

    }

    @Test(expected = MortgageServiceException.class)
    public void setBenefitsDetails_throwException(){
        doNothing().when(validator).validateBenefitRequest(any(BenefitsRequest.class));
        when(validator.validateForOverarchingAccount(any(String.class),any(HashMap.class))).
                thenReturn(helper.accountList_mock());
        when(mortgageAccountService.updateAccountBenefitsDetails(any(List.class),any(BenefitsRequest.class))).
                thenReturn(null);

        ResponseEntity<BenefitsResponse> responseEntity = subAccountController.setBenefitsDetails(
                "IF", Channel.DIGITAL.name(), "123-456-789-12", null, "ALL", new HashMap<String, String>(),
                helper.mockRequest_TrueBenefits(), MortgageAccountDataHelper.MOCK_ACCOUNT_ID);
    }

}
