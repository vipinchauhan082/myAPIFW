package com.lbg.epscw.mortgagesrvc.service;

import static org.junit.Assert.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.powermock.api.mockito.PowerMockito.mock;
import static org.powermock.api.mockito.PowerMockito.when;

import java.util.HashMap;
import java.util.function.Function;
import java.util.function.Predicate;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.reactive.function.BodyInserter;
import org.springframework.web.reactive.function.client.WebClient;

import com.lbg.epscw.mortgagesrvc.util.MortgageServiceUtil;


@RunWith(SpringRunner.class)
public class RestClientServiceImplTest {

    @Mock
    private WebClient.Builder builder;

    @Mock
    private MortgageServiceUtil vaultUtil;

    @Mock
    private RestTemplate restTemplate;

    @InjectMocks
    private RestClientServiceImpl restService = new RestClientServiceImpl(restTemplate);

    @Test
    public void Verify_get_call() {
        //given
        // Mock for responseSpec private method
        WebClient.ResponseSpec webClientResponseSpec = mock(WebClient.ResponseSpec.class);

        reactor.core.publisher.Mono<Object> mono = mock(reactor.core.publisher.Mono.class);
        when(webClientResponseSpec.onStatus(any(Predicate.class), any(Function.class)))
            .thenReturn(webClientResponseSpec);
        when(webClientResponseSpec.bodyToMono(any(Class.class))).thenReturn(mono);
        when(mono.block()).thenReturn("Success");
        ResponseEntity<String> responseEntity = mock(ResponseEntity.class);
        Mockito.when(restTemplate.exchange(
                eq("/getBalance"),
                eq(HttpMethod.GET), any(HttpEntity.class),
                eq(String.class))).thenReturn(responseEntity);
        when(responseEntity.getStatusCode()).thenReturn(HttpStatus.OK);
        when(responseEntity.getBody()).thenReturn("Success");

        // mock for addHeaders
        WebClient webClient = mock(WebClient.class);

        WebClient.RequestHeadersUriSpec requestHeadersUriSpec =

            mock(WebClient.RequestHeadersUriSpec.class);
        when(webClient.get()).thenReturn(requestHeadersUriSpec);

        WebClient.RequestHeadersSpec headersSpec = mock(WebClient.RequestHeadersSpec.class);
        when(headersSpec.retrieve()).thenReturn(webClientResponseSpec);
        when(requestHeadersUriSpec.uri(any(String.class))).thenReturn(headersSpec);

        when(builder.build()).thenReturn(webClient);
        //when
        String response = restService.get("/getBalance", new HashMap<String, String>());

        //then
        assertEquals("Success", response);
    }

    @Test
    public void Verify_post_call() {
        //given
        // Mock for responseSpec private method
        WebClient.ResponseSpec webClientResponseSpec = mock(WebClient.ResponseSpec.class);
        reactor.core.publisher.Mono<Object> mono = mock(reactor.core.publisher.Mono.class);
        when(webClientResponseSpec.onStatus(any(Predicate.class), any(Function.class)))
            .thenReturn(webClientResponseSpec);
        when(webClientResponseSpec.bodyToMono(any(Class.class))).thenReturn(mono);
        when(mono.block()).thenReturn("Success");

        // mock for addHeaders
        WebClient webClient = mock(WebClient.class);
        when(builder.build()).thenReturn(webClient);

        WebClient.RequestBodyUriSpec requestBodyUriSpec = mock(WebClient.RequestBodyUriSpec.class);
        when(webClient.post()).thenReturn(requestBodyUriSpec);

        WebClient.RequestBodySpec uri = mock(WebClient.RequestBodySpec.class);
        when(requestBodyUriSpec.uri(any(String.class))).thenReturn(uri);
        WebClient.RequestHeadersSpec headersSpec = mock(WebClient.RequestHeadersSpec.class);
        when(headersSpec.retrieve()).thenReturn(webClientResponseSpec);
        when(uri.body(any(BodyInserter.class))).thenReturn(headersSpec);

        ResponseEntity<String> responseEntity = mock(ResponseEntity.class);
        Mockito.when(restTemplate.exchange(
                eq("/entitlements"),
                eq(HttpMethod.POST), any(HttpEntity.class),
                eq(String.class))).thenReturn(responseEntity);
        when(responseEntity.getStatusCode()).thenReturn(HttpStatus.OK);
        when(responseEntity.getBody()).thenReturn("Success");

        //when
        String response =
            restService.post("/entitlements", new HashMap<String, String>(), new String());

        //then
        assertEquals("Success", response);
    }

    @Test
    public void Verify_put_call() {
        //given
        // Mock for responseSpec private method
        WebClient.ResponseSpec webClientResponseSpec = mock(WebClient.ResponseSpec.class);
        reactor.core.publisher.Mono<Object> mono = mock(reactor.core.publisher.Mono.class);
        when(webClientResponseSpec.onStatus(any(Predicate.class), any(Function.class)))
            .thenReturn(webClientResponseSpec);
        when(webClientResponseSpec.bodyToMono(any(Class.class))).thenReturn(mono);
        when(mono.block()).thenReturn("Success");

        // mock for addHeaders
        WebClient webClient = mock(WebClient.class);
        when(builder.build()).thenReturn(webClient);

        WebClient.RequestBodyUriSpec requestBodyUriSpec = mock(WebClient.RequestBodyUriSpec.class);
        when(webClient.put()).thenReturn(requestBodyUriSpec);

        WebClient.RequestBodySpec uri = mock(WebClient.RequestBodySpec.class);
        when(requestBodyUriSpec.uri(any(String.class))).thenReturn(uri);
        WebClient.RequestHeadersSpec headersSpec = mock(WebClient.RequestHeadersSpec.class);
        when(headersSpec.retrieve()).thenReturn(webClientResponseSpec);
        when(uri.body(any(BodyInserter.class))).thenReturn(headersSpec);

        ResponseEntity<String> responseEntity = mock(ResponseEntity.class);
        Mockito.when(restTemplate.exchange(
                eq("/entitlements"),
                eq(HttpMethod.PUT), any(HttpEntity.class),
                eq(String.class))).thenReturn(responseEntity);
        when(responseEntity.getStatusCode()).thenReturn(HttpStatus.OK);
        when(responseEntity.getBody()).thenReturn("Success");

        //when
        String response = restService.put(
            "/entitlements",
            new HashMap<String, String>(), new String());

        //then
        assertEquals("Success", response);
    }

}