package com.lbg.epscw.mortgagesrvc.validator;

import com.lbg.epscw.mortgagesrvc.model.MortgageApplicationInfo;
import com.lbg.epscw.mortgagesrvc.model.MortgagePortingApplicationStatus;
import org.junit.Before;
import org.junit.Test;

import java.util.List;

import static com.lbg.epscw.mortgagesrvc.model.MortgagePortingApplicationStatus.APPROVED;
import static java.util.Collections.singletonList;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;

public class MortgageAssetValidatorTest {

    private MortgagePortingApplicationValidator applicationValidator;

    private MortgageAssetValidator underTest;

    @Before
    public void setUp() {
        applicationValidator = mock(MortgagePortingApplicationValidator.class);
        underTest = new MortgageAssetValidator(applicationValidator);
    }

    @Test
    public void validate() {
        MortgageApplicationInfo applicationInfo = MortgageApplicationInfo.builder().build();
        List<MortgagePortingApplicationStatus> statuses = singletonList(APPROVED);

        underTest.validate(applicationInfo, statuses);
        verify(applicationValidator).validateCurrentState(applicationInfo, statuses);
    }
}