package com.lbg.epscw.mortgagesrvc.component;

import com.lbg.epscw.entitlement.service.EntitlementValidationServiceImpl;
import com.lbg.epscw.handler.model.ErrorInfo;
import com.lbg.epscw.mortgagesrvc.helper.ComponentHelper;
import com.lbg.epscw.mortgagesrvc.helper.MortgagePortingHelper;
import com.lbg.epscw.mortgagesrvc.logger.HystrixContextCopyStrategy;
import com.lbg.epscw.mortgagesrvc.model.MortgageApplicationInfo;
import com.lbg.epscw.mortgagesrvc.model.MortgagePortingApplicationStatus;
import com.lbg.epscw.mortgagesrvc.model.PortingApplicationStatusResponse;
import com.lbg.epscw.mortgagesrvc.restclient.MortgagePortingApplicationInfoRestClient;
import com.lbg.epscw.mortgagesrvc.service.MortgagePortingFulfilmentService;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpHeaders;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import static com.google.api.client.http.HttpStatusCodes.STATUS_CODE_BAD_REQUEST;
import static com.lbg.epscw.mortgagesrvc.helper.MortgagePortingHelper.FULFILMENT_DECISION_ENDPOINT;
import static com.lbg.epscw.mortgagesrvc.model.MortgagePortingApplicationStatus.*;
import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;
import static org.springframework.mock.web.MockHttpServletResponse.SC_BAD_REQUEST;
import static org.springframework.mock.web.MockHttpServletResponse.SC_OK;

@Tag("component")
@ExtendWith(SpringExtension.class)
@SpringBootTest
@AutoConfigureMockMvc
public class MortgagePortingFulfilmentDecisionComponentTest extends WebMVCTest {

    private final MortgagePortingHelper helper = new MortgagePortingHelper();
    private final ComponentHelper componentHelper = new ComponentHelper();

    @MockBean
    private MortgagePortingApplicationInfoRestClient restClient;

    @MockBean
    private EntitlementValidationServiceImpl entitlement;
    @MockBean
    private HystrixContextCopyStrategy hystrixContextCopyStrategy;

    @MockBean
    private MortgagePortingFulfilmentService service;


    @Test
    public void success_when_mortgage_porting_application_has_valid_state() {
        // Given
        when(restClient.getApplicationInfo(anyString())).thenReturn(MortgageApplicationInfo.builder().status(VALUATION_RECEIVED).build());
        when(service.fulfilApplication(anyString(),any())).thenReturn(PortingApplicationStatusResponse.builder().applicationNumber("1234").status(OFFERED).build());

        // When
        String payload = helper.actionPayload(OFFERED.name());
        HttpHeaders headers = helper.getAccountInfoHeaders();
        MockHttpServletResponse response = doPOST(FULFILMENT_DECISION_ENDPOINT, payload, headers);

        String responseString = componentHelper.getServletResponseAsString(response);
        PortingApplicationStatusResponse actual = readObject(responseString, PortingApplicationStatusResponse.class);

        // Then
        assertThat(response.getStatus(), is(SC_OK));
        assertThat(actual.getStatus(), is(OFFERED));
    }

    @Test
    public void reject_verification_when_application_invalid_status() {
        assertThatInvalidStatusThrowsError(OPEN, OFFERED);
        assertThatInvalidStatusThrowsError(OPEN, REPROCESS);
        assertThatInvalidStatusThrowsError(SUBMITTED, OFFERED);
        assertThatInvalidStatusThrowsError(SUBMITTED, REPROCESS);
        assertThatInvalidStatusThrowsError(WELCOME_PACK_RECEIVED, OFFERED);
        assertThatInvalidStatusThrowsError(WELCOME_PACK_RECEIVED, REPROCESS);
        assertThatInvalidStatusThrowsError(APPROVED_WITH_CONDITIONS, OFFERED);
        assertThatInvalidStatusThrowsError(APPROVED_WITH_CONDITIONS, REPROCESS);
        assertThatInvalidStatusThrowsError(REPROCESS, OFFERED);
        assertThatInvalidStatusThrowsError(REPROCESS, REPROCESS);
        assertThatInvalidStatusThrowsError(OFFERED, OFFERED);
        assertThatInvalidStatusThrowsError(OFFERED, REPROCESS);
        assertThatInvalidStatusThrowsError(FUNDS_RELEASED, OFFERED);
        assertThatInvalidStatusThrowsError(FUNDS_RELEASED, REPROCESS);
    }

    private void assertThatInvalidStatusThrowsError(MortgagePortingApplicationStatus fromStatus, MortgagePortingApplicationStatus toStatus) {
        //given
        when(restClient.getApplicationInfo(anyString())).thenReturn(MortgageApplicationInfo.builder().status(fromStatus).build());
        //when
        String payload = helper.actionPayload(toStatus.name());
        HttpHeaders headers = helper.getAccountInfoHeaders();
        MockHttpServletResponse response = doPOST(FULFILMENT_DECISION_ENDPOINT, payload, headers);
        ErrorInfo error = readErrorInfo(componentHelper.getServletResponseAsString(response));
        //then
        assertThat(response.getStatus(), is(SC_BAD_REQUEST));
        assertEquals("PNA.MORTGAGE_API.POST_MORTGAGES_APPLICATION_FULFILMENT_DECISION.MortgagePortingApplication.InvalidStatus", error.getReasonCode());
        assertEquals("Invalid Data", error.getMessage());
    }

    @Test
    public void return_error_when_application_id_is_invalid() {
        //given
        String payload = helper.actionPayload(OFFERED.name());

        //when
        MockHttpServletResponse response = doPOST("/mortgages/application/invalid/fulfilment-decision", payload, helper.getAccountInfoHeaders());
        ErrorInfo error = readErrorInfo(componentHelper.getServletResponseAsString(response));

        //then
        assertThat(response.getStatus(), is(STATUS_CODE_BAD_REQUEST));
        assertEquals("PNA.MORTGAGE_API.POST_MORTGAGES_APPLICATION_FULFILMENT_DECISION.Param.Invalid", error.getReasonCode());
        assertEquals("Invalid application number", error.getMessage());
    }

    @Test
    public void throws_exception_when_correlationId_is_missing() {
        //given
        HttpHeaders headers = helper.getAccountInfoHeaders();
        headers.remove("x-lbg-txn-correlation-id");

        // when
        String payload = helper.actionPayload(APPROVED.name());
        MockHttpServletResponse response = doPOST(FULFILMENT_DECISION_ENDPOINT, payload, headers);
        ErrorInfo error = readErrorInfo(componentHelper.getServletResponseAsString(response));

        // then
        assertEquals(400, response.getStatus());
        assertEquals("PNA.MORTGAGE_API.POST_MORTGAGES_APPLICATION_FULFILMENT_DECISION.Header.Missing.x-lbg-txn-correlation-id", error.getReasonCode());
        assertEquals("Missing request header x-lbg-txn-correlation-id for method parameter of type String", error.getMessage());
    }

    @Test
    public void throws_exception_when_state_is_not_offered_or_reprocess() {
        //given
        HttpHeaders headers = helper.getAccountInfoHeaders();

        // when
        String payload = helper.actionPayload(APPROVED.name());
        MockHttpServletResponse response = doPOST(FULFILMENT_DECISION_ENDPOINT, payload, headers);
        ErrorInfo error = readErrorInfo(componentHelper.getServletResponseAsString(response));

        // then
        assertEquals(400, response.getStatus());
        assertEquals("PNA.MORTGAGE_API.POST_MORTGAGES_APPLICATION_FULFILMENT_DECISION.Argument.Invalid", error.getReasonCode());
        assertEquals("Action is not a valid. Must be OFFERED or REPROCESS", error.getMessage());
    }

    @Test
    public void throws_exception_when_brand_is_missing() {
        //given
        HttpHeaders headers = helper.getAccountInfoHeaders();
        headers.remove("x-lbg-brand");

        // when
        String payload = helper.actionPayload(APPROVED.name());
        MockHttpServletResponse response = doPOST(FULFILMENT_DECISION_ENDPOINT, payload, headers);
        ErrorInfo error = readErrorInfo(componentHelper.getServletResponseAsString(response));

        // then
        assertEquals(400, response.getStatus());
        assertEquals("PNA.MORTGAGE_API.POST_MORTGAGES_APPLICATION_FULFILMENT_DECISION.Header.Missing.x-lbg-brand", error.getReasonCode());
        assertEquals("Missing request header 'x-lbg-brand' for method parameter of type String", error.getMessage());
    }

    @Test
    public void throws_exception_when_channel_is_missing() {
        //given
        HttpHeaders headers = helper.getAccountInfoHeaders();
        headers.remove("x-lbg-channel");

        // when
        String payload = helper.actionPayload(APPROVED.name());
        MockHttpServletResponse response = doPOST(FULFILMENT_DECISION_ENDPOINT, payload, headers);
        ErrorInfo error = readErrorInfo(componentHelper.getServletResponseAsString(response));

        // then
        assertEquals(400, response.getStatus());
        assertEquals("PNA.MORTGAGE_API.POST_MORTGAGES_APPLICATION_FULFILMENT_DECISION.Header.Missing.x-lbg-channel", error.getReasonCode());
        assertEquals("Missing request header 'x-lbg-channel' for method parameter of type String", error.getMessage());
    }

    @Test
    public void throws_exception_when_brand_name_is_invalid() {
        //given
        HttpHeaders headers = helper.getAccountInfoHeaders();
        headers.set("x-lbg-brand", "invalid");

        // when
        String payload = helper.actionPayload(OFFERED.name());
        MockHttpServletResponse response = doPOST(FULFILMENT_DECISION_ENDPOINT, payload, headers);
        ErrorInfo error = readErrorInfo(componentHelper.getServletResponseAsString(response));

        // then
        assertEquals(400, response.getStatus());
        assertEquals("PNA.MORTGAGE_API.POST_MORTGAGES_APPLICATION_FULFILMENT_DECISION.Header.Invalid", error.getReasonCode());
        assertEquals("Invalid enum value for type x-lbg-brand", error.getMessage());
    }
}
