package com.lbg.epscw.mortgagesrvc.component;

import com.lbg.epscw.entitlement.service.EntitlementValidationServiceImpl;
import com.lbg.epscw.handler.model.ErrorInfo;
import com.lbg.epscw.mortgagesrvc.helper.ComponentHelper;
import com.lbg.epscw.mortgagesrvc.helper.MortgagePortingHelper;
import com.lbg.epscw.mortgagesrvc.logger.HystrixContextCopyStrategy;
import com.lbg.epscw.mortgagesrvc.model.ApplicationMortgageDetailsUpdateRequest;
import com.lbg.epscw.mortgagesrvc.model.MortgageApplicationInfo;
import com.lbg.epscw.mortgagesrvc.restclient.MortgageAccountInfoRestClient;
import com.lbg.epscw.mortgagesrvc.restclient.MortgagePortingApplicationInfoRestClient;
import com.lbg.epscw.mortgagesrvc.service.RestClientService;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.context.ApplicationContext;
import org.springframework.http.HttpHeaders;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import static com.google.api.client.http.HttpStatusCodes.STATUS_CODE_BAD_REQUEST;
import static com.lbg.epscw.mortgagesrvc.helper.MortgagePortingHelper.APPLICATION_NUMBER;
import static com.lbg.epscw.mortgagesrvc.helper.MortgagePortingHelper.PORTING_SUBACCOUNT_DETAILS_INFO_ENDPOINT;
import static com.lbg.epscw.mortgagesrvc.model.MortgagePortingApplicationStatus.APPROVED;
import static com.lbg.epscw.mortgagesrvc.model.MortgagePortingApplicationStatus.OPEN;
import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.when;

@Tag("component")
@ExtendWith(SpringExtension.class)
@SpringBootTest
@AutoConfigureMockMvc
public class MortgagePortingSubAccountDetailsComponentTest extends WebMVCTest {

    private final MortgagePortingHelper portingHelper = new MortgagePortingHelper();
    private final ComponentHelper componentHelper = new ComponentHelper();

    @MockBean
    RestClientService restClientService;

    @MockBean
    private HystrixContextCopyStrategy hystrixContextCopyStrategy;

    @MockBean
    private EntitlementValidationServiceImpl entitlementValidationService;

    @MockBean
    private MortgagePortingApplicationInfoRestClient mortgagePortingApplicationInfoRestClient;

    @MockBean
    private MortgageAccountInfoRestClient mortgageAccountInfoRestClient;

    @Autowired
    private ApplicationContext context;


    @Test
    public void throws_exception_when_application_not_in_allowed_status() {
        //given
        HttpHeaders headers = portingHelper.getAccountInfoHeaders();


        // when
        ApplicationMortgageDetailsUpdateRequest applicationMortgageDetailsUpdateRequest = portingHelper.
                applicationMortgageDetailsUpdateRequestPayload();

        applicationMortgageDetailsUpdateRequest.getSubAccountDetails().get(0).setLoanAmount("800");

        String payload = componentHelper.writeValueAsString(applicationMortgageDetailsUpdateRequest);


        MortgageApplicationInfo mortgageApplicationInfo = portingHelper.mortgageApplicationInfoWithStatus(APPROVED.name());
        when(mortgagePortingApplicationInfoRestClient.getApplicationInfo(anyString())).thenReturn(mortgageApplicationInfo);

        MockHttpServletResponse response = doPUT(PORTING_SUBACCOUNT_DETAILS_INFO_ENDPOINT, payload, headers);
        ErrorInfo error = readErrorInfo(componentHelper.getServletResponseAsString(response));

        // then
        assertEquals(400, response.getStatus());
        assertEquals("PNA.MORTGAGE_API.PUT_MORTGAGES_APPLICATION_MORTGAGE_INFO.MortgageDetailsInfo.InvalidStatus", error.getReasonCode());
        assertEquals("Application is not in required status", error.getMessage());
    }


    @Test
    public void throws_exception_when_application_loan_amount_greater_than_subaccount_loan_amount() {
        //given
        HttpHeaders headers = portingHelper.getAccountInfoHeaders();


        // when
        ApplicationMortgageDetailsUpdateRequest applicationMortgageDetailsUpdateRequest = portingHelper.
                applicationMortgageDetailsUpdateRequestPayload();

        applicationMortgageDetailsUpdateRequest.getSubAccountDetails().get(0).setLoanAmount("800");

        String payload = componentHelper.writeValueAsString(applicationMortgageDetailsUpdateRequest);


        MortgageApplicationInfo mortgageApplicationInfo = portingHelper.mortgageApplicationInfoWithStatus(OPEN.name());
        when(mortgagePortingApplicationInfoRestClient.getApplicationInfo(anyString())).thenReturn(mortgageApplicationInfo);

        MockHttpServletResponse response = doPUT(PORTING_SUBACCOUNT_DETAILS_INFO_ENDPOINT, payload, headers);
        ErrorInfo error = readErrorInfo(componentHelper.getServletResponseAsString(response));

        // then
        assertEquals(400, response.getStatus());
        assertEquals("PNA.MORTGAGE_API.PUT_MORTGAGES_APPLICATION_MORTGAGE_INFO.MortgageDetailsInfo.InvalidBorrowingAmount", error.getReasonCode());
        assertEquals("Invalid Borrowing Amount", error.getMessage());
    }


    @Test
    public void throws_exception_when_application_product_id_does_not_match() {
        //given
        HttpHeaders headers = portingHelper.getAccountInfoHeaders();


        // when
        ApplicationMortgageDetailsUpdateRequest applicationMortgageDetailsUpdateRequest = portingHelper.
                applicationMortgageDetailsUpdateRequestPayload();

        applicationMortgageDetailsUpdateRequest.getSubAccountDetails().get(0).setProductId("if_mortgage");


        String payload = componentHelper.writeValueAsString(applicationMortgageDetailsUpdateRequest);


        MortgageApplicationInfo mortgageApplicationInfo = portingHelper.mortgageApplicationInfoWithStatus(OPEN.name());
        mortgageApplicationInfo.setPreviousMortgageNumber("mortgageNumber");
        when(mortgagePortingApplicationInfoRestClient.getApplicationInfo(anyString())).thenReturn(mortgageApplicationInfo);

        when(mortgageAccountInfoRestClient.getMortgageInfoByMortgageNumber(anyString(),anyMap())).thenReturn(portingHelper.buildMortgageAccountInfo(false));

        MockHttpServletResponse response = doPUT(PORTING_SUBACCOUNT_DETAILS_INFO_ENDPOINT, payload, headers);
        ErrorInfo error = readErrorInfo(componentHelper.getServletResponseAsString(response));

        // then
        assertEquals(400, response.getStatus());
        assertEquals("PNA.MORTGAGE_API.PUT_MORTGAGES_APPLICATION_MORTGAGE_INFO.MortgageDetailsInfo.InvalidProductId", error.getReasonCode());
        assertEquals("Invalid ProductId", error.getMessage());
    }


    @Test
    public void application_update_mortgage_info() {
        //given
        HttpHeaders headers = portingHelper.getAccountInfoHeaders();


        // when
        ApplicationMortgageDetailsUpdateRequest applicationMortgageDetailsUpdateRequest = portingHelper.
                applicationMortgageDetailsUpdateRequestPayload();


        applicationMortgageDetailsUpdateRequest.getSubAccountDetails().get(0).setProductId("lbg_mortgage_repayment");

        String payload = componentHelper.writeValueAsString(applicationMortgageDetailsUpdateRequest);


        MortgageApplicationInfo mortgageApplicationInfo = portingHelper.mortgageApplicationInfoWithStatus(OPEN.name());
        mortgageApplicationInfo.setPreviousMortgageNumber("mortgageNumber");
        when(mortgagePortingApplicationInfoRestClient.getApplicationInfo(anyString())).thenReturn(mortgageApplicationInfo);

        when(mortgagePortingApplicationInfoRestClient.updateApplication(anyString(), any(MortgageApplicationInfo.class))).thenReturn(mortgageApplicationInfo);

        when(mortgageAccountInfoRestClient.getMortgageInfoByMortgageNumber(anyString(),anyMap())).thenReturn(portingHelper.buildMortgageAccountInfo(false));

        MockHttpServletResponse response = doPUT(PORTING_SUBACCOUNT_DETAILS_INFO_ENDPOINT, payload, headers);
        String responseString = componentHelper.getServletResponseAsString(response);
        MortgageApplicationInfo actual = readObject(responseString, MortgageApplicationInfo.class);

        //then
        assertThat(response.getStatus(), is(200));
        assertThat(actual.getApplicationNumber(), is(APPLICATION_NUMBER));
        assertThat(actual.getStatus(), is(OPEN));
    }


    @Test
    public void application_update_mortgage_info_for_nultiple_sub_account() {
        //given
        HttpHeaders headers = portingHelper.getAccountInfoHeaders();


        // when
        ApplicationMortgageDetailsUpdateRequest applicationMortgageDetailsUpdateRequest = portingHelper.
                applicationMortgageDetailsWithMultipleSubAccountUpdateRequestPayload();


        applicationMortgageDetailsUpdateRequest.getSubAccountDetails().get(0).setProductId("lbg_mortgage_repayment");
        applicationMortgageDetailsUpdateRequest.getSubAccountDetails().get(1).setProductId("lbg_mortgage_repayment");

        String payload = componentHelper.writeValueAsString(applicationMortgageDetailsUpdateRequest);


        MortgageApplicationInfo mortgageApplicationInfo = portingHelper.mortgageApplicationInfoWithStatus(OPEN.name());
        mortgageApplicationInfo.setPreviousMortgageNumber("mortgageNumber");
        when(mortgagePortingApplicationInfoRestClient.getApplicationInfo(anyString())).thenReturn(mortgageApplicationInfo);

        when(mortgagePortingApplicationInfoRestClient.updateApplication(anyString(), any(MortgageApplicationInfo.class))).thenReturn(mortgageApplicationInfo);

        when(mortgageAccountInfoRestClient.getMortgageInfoByMortgageNumber(anyString(),anyMap())).thenReturn(portingHelper.buildMortgageAccountInfo(false));

        MockHttpServletResponse response = doPUT(PORTING_SUBACCOUNT_DETAILS_INFO_ENDPOINT, payload, headers);
        String responseString = componentHelper.getServletResponseAsString(response);
        MortgageApplicationInfo actual = readObject(responseString, MortgageApplicationInfo.class);

        //then
        assertThat(response.getStatus(), is(200));
        assertThat(actual.getApplicationNumber(), is(APPLICATION_NUMBER));
        assertThat(actual.getStatus(), is(OPEN));
    }

    @Test
    public void throws_exception_when_brand_is_missing() {

        HttpHeaders headers = portingHelper.getAccountInfoHeaders();
        headers.remove("x-lbg-brand");

        // when
        ApplicationMortgageDetailsUpdateRequest applicationMortgageDetailsUpdateRequest = portingHelper.
                applicationMortgageDetailsWithMultipleSubAccountUpdateRequestPayload();


        applicationMortgageDetailsUpdateRequest.getSubAccountDetails().get(0).setProductId("lbg_mortgage_repayment");
        applicationMortgageDetailsUpdateRequest.getSubAccountDetails().get(1).setProductId("lbg_mortgage_repayment");

        String payload = componentHelper.writeValueAsString(applicationMortgageDetailsUpdateRequest);


        MortgageApplicationInfo mortgageApplicationInfo = portingHelper.mortgageApplicationInfoWithStatus(OPEN.name());
        mortgageApplicationInfo.setPreviousMortgageNumber("mortgageNumber");
        when(mortgagePortingApplicationInfoRestClient.getApplicationInfo(anyString())).thenReturn(mortgageApplicationInfo);

        when(mortgagePortingApplicationInfoRestClient.updateApplication(anyString(), any(MortgageApplicationInfo.class))).thenReturn(mortgageApplicationInfo);

        when(mortgageAccountInfoRestClient.getMortgageInfoByMortgageNumber(anyString(),anyMap())).thenReturn(portingHelper.buildMortgageAccountInfo(false));

        MockHttpServletResponse response = doPUT(PORTING_SUBACCOUNT_DETAILS_INFO_ENDPOINT, payload, headers);
        ErrorInfo error = readErrorInfo(componentHelper.getServletResponseAsString(response));

        // then
        assertEquals(STATUS_CODE_BAD_REQUEST, response.getStatus());
        assertEquals("PNA.MORTGAGE_API.PUT_MORTGAGES_APPLICATION_MORTGAGE_INFO.Header.Missing.x-lbg-brand", error.getReasonCode());
        assertEquals("Missing request header 'x-lbg-brand' for method parameter of type String", error.getMessage());
    }

    @Test
    public void throws_exception_when_channel_is_missing() {

        HttpHeaders headers = portingHelper.getAccountInfoHeaders();
        headers.remove("x-lbg-channel");

        // when
        ApplicationMortgageDetailsUpdateRequest applicationMortgageDetailsUpdateRequest = portingHelper.
                applicationMortgageDetailsWithMultipleSubAccountUpdateRequestPayload();


        applicationMortgageDetailsUpdateRequest.getSubAccountDetails().get(0).setProductId("lbg_mortgage_repayment");
        applicationMortgageDetailsUpdateRequest.getSubAccountDetails().get(1).setProductId("lbg_mortgage_repayment");

        String payload = componentHelper.writeValueAsString(applicationMortgageDetailsUpdateRequest);


        MortgageApplicationInfo mortgageApplicationInfo = portingHelper.mortgageApplicationInfoWithStatus(OPEN.name());
        mortgageApplicationInfo.setPreviousMortgageNumber("mortgageNumber");
        when(mortgagePortingApplicationInfoRestClient.getApplicationInfo(anyString())).thenReturn(mortgageApplicationInfo);

        when(mortgagePortingApplicationInfoRestClient.updateApplication(anyString(), any(MortgageApplicationInfo.class))).thenReturn(mortgageApplicationInfo);

        when(mortgageAccountInfoRestClient.getMortgageInfoByMortgageNumber(anyString(),anyMap())).thenReturn(portingHelper.buildMortgageAccountInfo(false));

        MockHttpServletResponse response = doPUT(PORTING_SUBACCOUNT_DETAILS_INFO_ENDPOINT, payload, headers);

        ErrorInfo error = readErrorInfo(componentHelper.getServletResponseAsString(response));

        // then
        assertEquals(STATUS_CODE_BAD_REQUEST, response.getStatus());
        assertEquals("PNA.MORTGAGE_API.PUT_MORTGAGES_APPLICATION_MORTGAGE_INFO.Header.Missing.x-lbg-channel", error.getReasonCode());
        assertEquals("Missing request header 'x-lbg-channel' for method parameter of type String", error.getMessage());
    }

    @Test
    public void throws_exception_when_correlationId_is_missing() {

        HttpHeaders headers = portingHelper.getAccountInfoHeaders();
        headers.remove("x-lbg-txn-correlation-id");

        // when
        ApplicationMortgageDetailsUpdateRequest applicationMortgageDetailsUpdateRequest = portingHelper.
                applicationMortgageDetailsWithMultipleSubAccountUpdateRequestPayload();


        applicationMortgageDetailsUpdateRequest.getSubAccountDetails().get(0).setProductId("lbg_mortgage_repayment");
        applicationMortgageDetailsUpdateRequest.getSubAccountDetails().get(1).setProductId("lbg_mortgage_repayment");

        String payload = componentHelper.writeValueAsString(applicationMortgageDetailsUpdateRequest);


        MortgageApplicationInfo mortgageApplicationInfo = portingHelper.mortgageApplicationInfoWithStatus(OPEN.name());
        mortgageApplicationInfo.setPreviousMortgageNumber("mortgageNumber");
        when(mortgagePortingApplicationInfoRestClient.getApplicationInfo(anyString())).thenReturn(mortgageApplicationInfo);

        when(mortgagePortingApplicationInfoRestClient.updateApplication(anyString(), any(MortgageApplicationInfo.class))).thenReturn(mortgageApplicationInfo);

        when(mortgageAccountInfoRestClient.getMortgageInfoByMortgageNumber(anyString(),anyMap())).thenReturn(portingHelper.buildMortgageAccountInfo(false));

        MockHttpServletResponse response = doPUT(PORTING_SUBACCOUNT_DETAILS_INFO_ENDPOINT, payload, headers);
        ErrorInfo error = readErrorInfo(componentHelper.getServletResponseAsString(response));

        // then
        assertEquals(STATUS_CODE_BAD_REQUEST, response.getStatus());
        assertEquals("PNA.MORTGAGE_API.PUT_MORTGAGES_APPLICATION_MORTGAGE_INFO.Header.Missing.x-lbg-txn-correlation-id", error.getReasonCode());
        assertEquals("Missing request header x-lbg-txn-correlation-id for method parameter of type String", error.getMessage());
    }

    @Test
    public void throws_exception_when_brand_name_is_invalid() {

        HttpHeaders headers = portingHelper.getAccountInfoHeaders();
        headers.set("x-lbg-brand", "invalid");

        // when
        ApplicationMortgageDetailsUpdateRequest applicationMortgageDetailsUpdateRequest = portingHelper.
                applicationMortgageDetailsWithMultipleSubAccountUpdateRequestPayload();


        applicationMortgageDetailsUpdateRequest.getSubAccountDetails().get(0).setProductId("lbg_mortgage_repayment");
        applicationMortgageDetailsUpdateRequest.getSubAccountDetails().get(1).setProductId("lbg_mortgage_repayment");

        String payload = componentHelper.writeValueAsString(applicationMortgageDetailsUpdateRequest);


        MortgageApplicationInfo mortgageApplicationInfo = portingHelper.mortgageApplicationInfoWithStatus(OPEN.name());
        mortgageApplicationInfo.setPreviousMortgageNumber("mortgageNumber");
        when(mortgagePortingApplicationInfoRestClient.getApplicationInfo(anyString())).thenReturn(mortgageApplicationInfo);

        when(mortgagePortingApplicationInfoRestClient.updateApplication(anyString(), any(MortgageApplicationInfo.class))).thenReturn(mortgageApplicationInfo);

        when(mortgageAccountInfoRestClient.getMortgageInfoByMortgageNumber(anyString(),anyMap())).thenReturn(portingHelper.buildMortgageAccountInfo(false));

        MockHttpServletResponse response = doPUT(PORTING_SUBACCOUNT_DETAILS_INFO_ENDPOINT, payload, headers);
        ErrorInfo error = readErrorInfo(componentHelper.getServletResponseAsString(response));

        // then
        assertEquals(STATUS_CODE_BAD_REQUEST, response.getStatus());
        assertEquals("PNA.MORTGAGE_API.PUT_MORTGAGES_APPLICATION_MORTGAGE_INFO.Header.Invalid", error.getReasonCode());
        assertEquals("Invalid enum value for type x-lbg-brand", error.getMessage());
    }
}
