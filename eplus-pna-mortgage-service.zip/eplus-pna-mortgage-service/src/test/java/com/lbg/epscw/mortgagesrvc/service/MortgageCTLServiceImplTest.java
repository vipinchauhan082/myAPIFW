package com.lbg.epscw.mortgagesrvc.service;

import com.lbg.epscw.mortgagesrvc.exception.CircuitBreakerOpenException;
import com.lbg.epscw.mortgagesrvc.helper.MortgageCTLHelper;
import com.lbg.epscw.mortgagesrvc.model.*;
import com.lbg.epscw.mortgagesrvc.restclient.MortgageMetadataRestClient;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.HashMap;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.powermock.api.mockito.PowerMockito.when;

@RunWith(SpringRunner.class)
public class MortgageCTLServiceImplTest {

    public static final String MOCK_ACCOUNT_ID = "f76ca840-2553-d536-1ab8-9fa85c99db05";

    @Mock
    private MortgageMetadataRestClient restClient;

    @InjectMocks
    private MortgageCTLServiceImpl mortgageCtlService;

    private final MortgageCTLHelper ctlHelper = new MortgageCTLHelper();

    @Test
    public void addCTL() {
        //given
        when(restClient.updateMetadataOptions(anyString(), any(VaultMetadataOptionsRequest.class)))
                .thenReturn(ctlHelper.buildAccountCtlVaultResponse());
        System.out.println(ctlHelper.buildAccountCtlVaultResponse().toString());

        //when
        MortgageCTLResponse response =
                mortgageCtlService.addConsentToLease(new MortgageCTLRequest(), "b2c9119f-09e5-4ac9-9738-9e28b334d3fa");

        //then
        assertEquals("b2c9119f-09e5-4ac9-9738-9e28b334d3fa", response.getAccountId());
        assertEquals("ACCOUNT_STATUS_OPEN", response.getStatus());
        assertNotNull(response.getDetails());
        System.out.println(response.toString());
        assertEquals("true", response.getDetails().get(CTLOptions.CTL_INDICATOR.getInternalName()));
        assertEquals("20/12/2020", response.getDetails().get(CTLOptions.CTL_START_DATE.getInternalName()));
    }

    @Test
    public void updateCTL() {
        //given
        when(restClient.updateMetadataOptions(anyString(), any(VaultMetadataOptionsRequest.class)))
                .thenReturn(ctlHelper.buildAccountCtlVaultResponse());;

        //when
        MortgageCTLResponse response =
                mortgageCtlService.cancelConsentToLease("b2c9119f-09e5-4ac9-9738-9e28b334d3fa", null);

        //then
        assertEquals("b2c9119f-09e5-4ac9-9738-9e28b334d3fa", response.getAccountId());
        assertEquals("ACCOUNT_STATUS_OPEN", response.getStatus());
        assertNotNull(response.getDetails());
        assertEquals("true", response.getDetails().get(CTLOptions.CTL_INDICATOR.getInternalName()));
        assertEquals("20/12/2020", response.getDetails().get(CTLOptions.CTL_START_DATE.getInternalName()));
    }

    @Test(expected = CircuitBreakerOpenException.class)
    public void shouldThrowHystrixExceptionForFallbackUpdateCTL() {
        //then
        mortgageCtlService.fallbackCancelConsentToLease(
                MOCK_ACCOUNT_ID, new HashMap<>(), new Exception("Circuit open on update ctl"));
    }

    @Test(expected = CircuitBreakerOpenException.class)
    public void shouldThrowHystrixExceptionForFallbackAddCTL() {
        //then
        mortgageCtlService.fallbackAddConsentToLease(new MortgageCTLRequest(),
                MOCK_ACCOUNT_ID, new Exception("Circuit open on add ctl"));
    }

}