package com.lbg.epscw.mortgagesrvc.validator;


import com.lbg.epscw.handler.exception.system.SystemBadRequestException;
import com.lbg.epscw.mortgagesrvc.exception.InvalidUpdateRequestException;
import com.lbg.epscw.mortgagesrvc.helper.AccountCreationHelper;
import com.lbg.epscw.mortgagesrvc.helper.MortgageAccountDataHelper;
import com.lbg.epscw.mortgagesrvc.model.BenefitsRequest;
import com.lbg.epscw.mortgagesrvc.restclient.MortgageAccountInfoRestClient;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.HashMap;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.powermock.api.mockito.PowerMockito.mock;
import static org.powermock.api.mockito.PowerMockito.when;

@RunWith(SpringRunner.class)
public class MortgageSubAccountValidatorTests {

    @Mock
    private MortgageAccountInfoRestClient mortgageAccountInfoRestClient;

    private MortgageAccountDataHelper helper = new MortgageAccountDataHelper();

    @Before
    public void setup() {
        mortgageAccountInfoRestClient = mock(MortgageAccountInfoRestClient.class);
    }


    @Test(expected= SystemBadRequestException.class)
    public void testValidate(){
        MortgageSubAccountValidator mortgageSubAccountValidator = new MortgageSubAccountValidator(mortgageAccountInfoRestClient) ;
        mortgageSubAccountValidator.validateSubAccountOpening(AccountCreationHelper.generateBadRequestOneMissing());
    }

    @Test(expected= SystemBadRequestException.class)
    public void testValidateMulti(){
        MortgageSubAccountValidator mortgageSubAccountValidator = new MortgageSubAccountValidator(mortgageAccountInfoRestClient) ;
        mortgageSubAccountValidator.validateSubAccountOpening(AccountCreationHelper.generateBadRequestMultiMissing());
    }

    @Test(expected = InvalidUpdateRequestException.class)
    public void validateBenefitRequest_throwException_invalidRequest(){
        MortgageSubAccountValidator mortgageSubAccountValidator = new MortgageSubAccountValidator(mortgageAccountInfoRestClient) ;
        mortgageSubAccountValidator.validateBenefitRequest(helper.invalidRequest_TrueBenefits());
    }

    @Test
    public void validateBenefitRequest_correctsRequest(){
        MortgageSubAccountValidator mortgageSubAccountValidator = new MortgageSubAccountValidator(mortgageAccountInfoRestClient) ;
        BenefitsRequest request = helper.mockRequest_FalseBenefits();
        mortgageSubAccountValidator.validateBenefitRequest(request);

        assertEquals("",request.getBenefitsSource());
    }

    @Test
    public void validateForOverarchingAccount_success(){

        when(mortgageAccountInfoRestClient.getMortgageAccountInfo(any(String.class),any(HashMap.class))).
                thenReturn(helper.mortgageAccountInfo_TrueResponseMock());

        MortgageSubAccountValidator mortgageSubAccountValidator = new MortgageSubAccountValidator(mortgageAccountInfoRestClient) ;
        List<String> accountList= mortgageSubAccountValidator.validateForOverarchingAccount(MortgageAccountDataHelper.MOCK_ACCOUNT_ID,new HashMap<>());

        assertEquals(1,accountList.size());

    }

    @Test(expected = InvalidUpdateRequestException.class)
    public void validateForOverarchingAccount_throwException_invalidAccountId(){

        when(mortgageAccountInfoRestClient.getMortgageAccountInfo(any(String.class),any(HashMap.class))).
                thenReturn(helper.mortgageAccountInfo_FalseResponseMock());

        MortgageSubAccountValidator mortgageSubAccountValidator = new MortgageSubAccountValidator(mortgageAccountInfoRestClient) ;
        mortgageSubAccountValidator.validateForOverarchingAccount(MortgageAccountDataHelper.MOCK_ACCOUNT_ID,new HashMap<>());
    }

}
