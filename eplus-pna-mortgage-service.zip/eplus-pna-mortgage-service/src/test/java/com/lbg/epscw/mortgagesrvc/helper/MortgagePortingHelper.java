package com.lbg.epscw.mortgagesrvc.helper;

import com.lbg.epscw.mortgagesrvc.dto.MortgageAccountData;
import com.lbg.epscw.mortgagesrvc.dto.MortgageAccountInfo;
import com.lbg.epscw.mortgagesrvc.dto.MortgagePortingApplicationSubAccountDetails;
import com.lbg.epscw.mortgagesrvc.dto.VaultAccountResponse;
import com.lbg.epscw.mortgagesrvc.model.*;
import com.lbg.epscw.mortgagesrvc.model.CreatePortingApplicationRequest.CreatePortingApplicationRequestBuilder;
import com.lbg.epscw.mortgagesrvc.model.SolicitorDocReceivedRequest.SolicitorDocReceivedRequestBuilder;
import com.lbg.epscw.mortgagesrvc.model.DirectDebitDetailsRequest.DirectDebitDetailsRequestBuilder;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static com.lbg.epscw.mortgagesrvc.constants.CommonConstants.*;
import static com.lbg.epscw.mortgagesrvc.constants.CommonConstants.MORTGAGE_PAYMENT;
import static com.lbg.epscw.mortgagesrvc.dto.MortgageAccountInfo.builder;
import static com.lbg.epscw.mortgagesrvc.enums.ApplicationPurpose.PORTING;
import static com.lbg.epscw.mortgagesrvc.enums.SolicitorAccountSchema.SORT_CODE_ACCOUNT_NUMBER;
import static com.lbg.epscw.mortgagesrvc.model.Channel.TELEPHONE;
import static com.lbg.epscw.mortgagesrvc.model.PortingUpdateSolicitorInfoRequest.PortingUpdateSolicitorInfoRequestBuilder;
import static java.lang.String.format;
import static java.util.Collections.singletonList;
import static java.util.UUID.randomUUID;

public class MortgagePortingHelper {
    public static final String ACCOUNT_ID = "b2c9119f-09e5-4ac9-9738-9e28b334d3fa";
    public static final String APPLICATION_NUMBER = "f47a9d52-9f2e-4a80-8bde-d9970009e1b3";
    public static final String ASSET_NUMBER = "2b380525-5694-48fe-97c9-bedbeb60d9b5";
    public static final String EXISTING_MORTGAGE_NUMBER = "e36ce475-db19-48e2-b8cb-48ec8ca31832";
    public static final String NEW_MORTGAGE_NUMBER = "7aa337e0-f94b-4470-b347-c31abdb0f8da";
    public static final String CREATE_APPLICATION_ENDPOINT = "/mortgages/application";
    public static final String CREDIT_DECISION_ENDPOINT = format("/mortgages/application/%s/credit-decision", APPLICATION_NUMBER);
    public static final String ASSET_VALUATION_ENDPOINT = format("/mortgages/application/%s/asset-valuation", APPLICATION_NUMBER);
    public static final String ASSET_VALUATION_ENDPOINT_INCORRECT_APPLICATION_NUMBER = format("/mortgages/application/%s/asset-valuation", "APPLICATION_NUMBER");
    public static final String DIRECT_DEBIT_ENDPOINT = format("/mortgages/application/%s/direct-debit", APPLICATION_NUMBER);
    public static final String FULFILMENT_DECISION_ENDPOINT = format("/mortgages/application/%s/fulfilment-decision", APPLICATION_NUMBER);
    public static final String SOLICITOR_INFO_ENDPOINT = format("/mortgages/application/%s/solicitor-info", APPLICATION_NUMBER);
    public static final String SOLICITOR_DOC_RECEIVED_ENDPOINT = format("/mortgages/application/%s/solicitor-doc-received", ACCOUNT_ID);
    public static final String WELCOME_PACK_ACTION_ENDPOINT = format("/mortgages/application/%s/welcome-pack-received", APPLICATION_NUMBER);
    public static final String BRAND = "IF";
    public static final String CHANNEL = TELEPHONE.name();
    public static final String CORRELATION_ID = "5a79b5f2-457b-4627-8fa2-1d235734d269";
    public static final String JWT = "Bearer VALID_STATIC_TOKEN";
    public static final String INTERNAL_SYS_ID = "5a79b5f2-457b-4627-8fa2-1d235734d263";
    public static final String CUSTOMER_ID = "0cb743e2-a6ba-4cf0-a413-b2f8e3b2ad00";
    public static final String SECOND_CUSTOMER_ID = "bfdf3286-1957-4767-b248-eae5cc70830d";
    public static final String SOLICITOR_PANEL_NUMBER = "ad1f10c4-65a5-4944-9a48-25fa2d8c12c3";
    public static final String TITLE_DEED_NUMBER = "b380fb5d-f141-442f-aa84-0899acf57824";

    public static final String PORTING_SUBACCOUNT_DETAILS_INFO_ENDPOINT = format("/mortgages/application/%s/mortgage-info", APPLICATION_NUMBER);


    public AccountPortingStatusResponse buildAccountStatusUpdateResponse() {
        AccountPortingStatusResponse accountPortingStatusResponse = new AccountPortingStatusResponse();
        accountPortingStatusResponse.setAccountId(ACCOUNT_ID);
        accountPortingStatusResponse.setStatus(AccountStatus.ACCOUNT_STATUS_OPEN.name());
        return accountPortingStatusResponse;
    }

    public List<AccountPortingStatusResponse> buildAccountStatusUpdateListResponse() {
        List<AccountPortingStatusResponse> accountPortingStatusResponses = new ArrayList<>();
        AccountPortingStatusResponse accountPortingStatusResponse = new AccountPortingStatusResponse();
        accountPortingStatusResponse.setAccountId(ACCOUNT_ID);
        accountPortingStatusResponse.setStatus(AccountStatus.ACCOUNT_STATUS_OPEN.name());
        accountPortingStatusResponses.add(accountPortingStatusResponse);
        return accountPortingStatusResponses;
    }

    public MortgageAccountInfo buildMortgageAccountInfo(boolean b) {
        MortgageAccountInfo mortgageAccountInfo = new MortgageAccountInfo();
        MortgageAccountData mortgageAccountData = new MortgageAccountData();
        mortgageAccountData.setAccountId("b2c9119f-09e5-4ac9-9738-9e28b334d3fa");
        mortgageAccountData.setProductFamily("Mortgage");
        mortgageAccountData.setStatus(b ? AccountStatus.ACCOUNT_STATUS_PENDING.name() : AccountStatus.ACCOUNT_STATUS_OPEN.name());
        mortgageAccountData.setProductId(PRODUCT_ID_LBG_MORTGAGE_REPAYMENT);
        mortgageAccountData.setProductFamily(MORTGAGE_FAMILY);
        List<MortgageAccountData> mortgageAccountDataList = new ArrayList<>();
        mortgageAccountDataList.add(mortgageAccountData);
        mortgageAccountInfo.setMortgageAccountData(mortgageAccountDataList);
        return mortgageAccountInfo;
    }

    public MortgageAccountInfo buildMortgageAccountInfoWithSubAccount(boolean b) {
        MortgageAccountInfo mortgageAccountInfo = new MortgageAccountInfo();
        MortgageAccountData mortgageAccountData = new MortgageAccountData();
        mortgageAccountData.setAccountId("b2c9119f-09e5-4ac9-9738-9e28b334d3fa");
        mortgageAccountData.setProductFamily("Mortgage");
        mortgageAccountData.setStatus(b ? AccountStatus.ACCOUNT_STATUS_PENDING.name() : AccountStatus.ACCOUNT_STATUS_OPEN.name());
        mortgageAccountData.setProductId(PRODUCT_ID_LBG_MORTGAGE_REPAYMENT);
        mortgageAccountData.setProductFamily(MORTGAGE_PAYMENT_FAMILY);
        List<MortgageAccountData> mortgageAccountDataList = new ArrayList<>();
        mortgageAccountDataList.add(mortgageAccountData);
        MortgageAccountData mortgageAccountData1 = new MortgageAccountData();
        mortgageAccountData1.setAccountId("b2c9119f-09e5-4ac9-9738-9e28b334d4ty");
        mortgageAccountData1.setStatus(b ? AccountStatus.ACCOUNT_STATUS_PENDING.name() : AccountStatus.ACCOUNT_STATUS_OPEN.name());
        mortgageAccountData1.setProductId(PRODUCT_ID_LBG_MORTGAGE);
        mortgageAccountData1.setProductFamily(MORTGAGE_FAMILY);
        mortgageAccountDataList.add(mortgageAccountData1);

        mortgageAccountInfo.setMortgageAccountData(mortgageAccountDataList);
        return mortgageAccountInfo;
    }

    public MortgageAccountInfo buildMortgageAccountInfoWithMultipleSubAccount(boolean b) {
        MortgageAccountInfo mortgageAccountInfo = new MortgageAccountInfo();
        MortgageAccountData mortgageAccountData = new MortgageAccountData();
        mortgageAccountData.setAccountId("b2c9119f-09e5-4ac9-9738-9e28b334d3fa");
        mortgageAccountData.setStatus(b ? AccountStatus.ACCOUNT_STATUS_PENDING.name() : AccountStatus.ACCOUNT_STATUS_OPEN.name());
        mortgageAccountData.setProductId(PRODUCT_ID_LBG_MORTGAGE_REPAYMENT);
        mortgageAccountData.setProductFamily(MORTGAGE_PAYMENT_FAMILY);
        List<MortgageAccountData> mortgageAccountDataList = new ArrayList<>();
        mortgageAccountDataList.add(mortgageAccountData);
        for(int i=0;i<4;i++) {
            MortgageAccountData mortgageAccountData1 = new MortgageAccountData();
            mortgageAccountData1.setAccountId("b2c9119f-09e5-4ac9-9738-9e28b334d4t"+i);
            mortgageAccountData1.setStatus(b ? AccountStatus.ACCOUNT_STATUS_PENDING.name() : AccountStatus.ACCOUNT_STATUS_OPEN.name());
            mortgageAccountData1.setProductId(PRODUCT_ID_LBG_MORTGAGE);
            mortgageAccountData1.setProductFamily(MORTGAGE_FAMILY);
            mortgageAccountDataList.add(mortgageAccountData1);
        }

        mortgageAccountInfo.setMortgageAccountData(mortgageAccountDataList);
        return mortgageAccountInfo;
    }

    public VaultAccountResponse buildAccountStatusUpdateVaultResponse() {
        VaultAccountResponse response = new VaultAccountResponse();
        response.setAccountId("b2c9119f-09e5-4ac9-9738-9e28b334d3fa");
        response.setStatus(AccountStatus.ACCOUNT_STATUS_CANCELLED.name());
        return response;
    }

    public VaultAccountResponse buildAccountStatusUpdateVaultResponse1() {
        VaultAccountResponse response = new VaultAccountResponse();
        response.setAccountId("b2c9119f-09e5-4ac9-9738-9e28b334d4ty");
        response.setStatus(AccountStatus.ACCOUNT_STATUS_CANCELLED.name());
        return response;
    }

    public String getMortgageInfoServiceResponse() {
        return "{\n" +
                "    \"Data\": [\n" +
                "        {\n" +
                "            \"mortgageNumber\": \"number_1112\",\n" +
                "            \"mortgagePrincipal\": \"4000\",\n" +
                "            \"keyDate\": \"7\",\n" +
                "            \"mortgageType\": \"INTEREST_ONLY\",\n" +
                "            \"accountStatus\": \"ACCOUNT_STATUS_PENDING\",\n" +
                "            \"totalTerm\": \"24\",\n" +
                "            \"productId\": \"lbg_mortgage\",\n" +
                "            \"productFamily\": \"Mortgage\",\n" +
                "            \"accountId\": \"1601d0e5-e336-64d9-64ad-89ba6fdc2677\"\n" +
                "        },\n" +
                "        {\n" +
                "            \"mortgageNumber\": \"number_1112\",\n" +
                "            \"productId\": \"lbg_mortgage_repayment\",\n" +
                "            \"accountStatus\": \"ACCOUNT_STATUS_PENDING\",\n" +
                "            \"productFamily\": \"Mortgage Payment\",\n" +
                "            \"accountId\": \"f76ca840-2553-d536-1ab8-9fa85c99db05\"\n" +
                "        }\n" +
                "    ]\n" +
                "}";
    }

    public String getMortgageInfoServiceResponseWithPendingClosureStatus() {
        return "{\n" +
                "    \"Data\": [\n" +
                "        {\n" +
                "            \"mortgageNumber\": \"number_1112\",\n" +
                "            \"productId\": \"lbg_mortgage_repayment\",\n" +
                "            \"accountStatus\": \"ACCOUNT_STATUS_PENDING_CLOSURE\",\n" +
                "            \"productFamily\": \"Mortgage Payment\",\n" +
                "            \"accountId\": \"b2c9119f-09e5-4ac9-9738-9e28b334d3fa\"\n" +
                "        }\n" +
                "    ]\n" +
                "}";
    }


    public String getAccountStatusUpdateVaultResponseSubAccount() {
        return "{\n" +
                "    \"id\": \"1601d0e5-e336-64d9-64ad-89ba6fdc2677\",\n" +
                "    \"status\": \"ACCOUNT_STATUS_OPEN\"\n" +
                "}";

    }

    public String getAccountStatusUpdateVaultResponseSubAccountWithStatusCancelled() {
        return "{\n" +
                "    \"id\": \"1601d0e5-e336-64d9-64ad-89ba6fdc2677\",\n" +
                "    \"status\": \"ACCOUNT_STATUS_CANCELLED\"\n" +
                "}";

    }

    public String getAccountStatusUpdateVaultResponseRepaymentAccount() {
        return "{\n" +
                "    \"id\": \"f76ca840-2553-d536-1ab8-9fa85c99db05\",\n" +
                "    \"status\": \"ACCOUNT_STATUS_OPEN\"\n" +
                "}";
    }

    public String getAccountStatusUpdateVaultResponseRepaymentAccountWithStatusCancelled() {
        return "{\n" +
                "    \"id\": \"f76ca840-2553-d536-1ab8-9fa85c99db05\",\n" +
                "    \"status\": \"ACCOUNT_STATUS_CANCELLED\"\n" +
                "}";
    }

    public CreatePortingApplicationRequestBuilder createApplicationPayloadBuilder() {
        return CreatePortingApplicationRequest.builder()
                .customerId(CUSTOMER_ID)
                .secondCustomerId(SECOND_CUSTOMER_ID)
                .previousMortgageNumber(EXISTING_MORTGAGE_NUMBER)
                .purpose(PORTING.name())
                .numberOfDependents(0);
    }

    public DirectDebitDetailsRequestBuilder updateDirectDebitPayloadBuilder() {
        return DirectDebitDetailsRequest.builder().mainAccountHolder("James")
                .secondAccountHolder("MIl")
                .schemeName("SortCodeAccountNumber")
                .identification("80200110203348");
    }

    public PortingUpdateSolicitorInfoRequestBuilder updateSolicitorInfoPayloadBuilder() {
        return PortingUpdateSolicitorInfoRequest.builder()
                .solicitorPanelNumber(SOLICITOR_PANEL_NUMBER)
                .solicitorCompanyName("Acme Sol Inc")
                .solicitorAddressLine01("123 Solicitor Road")
                .solicitorAddressLine02("Line 02")
                .solicitorAddressLine03("Line 03")
                .solicitorAddressLine04("Line 04")
                .solicitorAddressLine05("Line 05")
                .solicitorCity("London")
                .stateOrProvince("London")
                .solicitorCountryCode("UK")
                .identification("01020312345678")
                .schemaName(SORT_CODE_ACCOUNT_NUMBER.name());
    }

    public String actionPayload(String action) {
        return format("{\"action\": \"%s\"}", action);
    }

    public String creditDecisionPayload(String state) {
        return format("{\"action\": \"%s\", \"notes\" : \"Lorem ipsum\"}", state);
    }

    public String directDebitPayload() {
        return format("{\"MainAccountHolder\": \"James\", \"SecondAccountHolder\" : \"Miller\",\"SchemeName\" : \"SortCodeAccountNumber\",\"Identification\" : \"80200110203348\"}");
    }

    public String directDebitPayloadSchemeNameNotExpected(String schemeName) {
        return format("{\"MainAccountHolder\": \"James\", \"SecondAccountHolder\" : \"Miller\",\"SchemeName\" : \"%s\",\"Identification\" : \"80200110203348\"}", schemeName);
    }

    public ApplicationMortgageDetailsUpdateRequest applicationMortgageDetailsUpdateRequestPayload(){
        ApplicationMortgageDetailsUpdateRequest applicationMortgageDetailsUpdateRequest = new ApplicationMortgageDetailsUpdateRequest();
        applicationMortgageDetailsUpdateRequest.setPurchasePrice("1200");
        applicationMortgageDetailsUpdateRequest.setTotalBorrowingAmount("1000");

        List<ApplicationMortgageDetails> subAccountDetails = new ArrayList<>();

        ApplicationMortgageDetails subAccount = new ApplicationMortgageDetails();
        subAccount.setLoanAmount("1000");
        subAccount.setTotalTerm("5");
        subAccount.setProductId("lbg_mortgage");
        subAccount.setInterestRate("11");
        subAccount.setSubAccountSeqId("sub_account_1");
        subAccountDetails.add(subAccount);

        applicationMortgageDetailsUpdateRequest.setSubAccountDetails(subAccountDetails);
        return applicationMortgageDetailsUpdateRequest;
    }

    public ApplicationMortgageDetailsUpdateRequest applicationMortgageDetailsWithMultipleSubAccountUpdateRequestPayload(){
        ApplicationMortgageDetailsUpdateRequest applicationMortgageDetailsUpdateRequest = new ApplicationMortgageDetailsUpdateRequest();
        applicationMortgageDetailsUpdateRequest.setPurchasePrice("1200");
        applicationMortgageDetailsUpdateRequest.setTotalBorrowingAmount("2000");

        List<ApplicationMortgageDetails> subAccountDetails = new ArrayList<>();

        ApplicationMortgageDetails subAccount = new ApplicationMortgageDetails();
        subAccount.setLoanAmount("1000");
        subAccount.setTotalTerm("5");
        subAccount.setProductId("lbg_mortgage");
        subAccount.setInterestRate("11");
        subAccount.setSubAccountSeqId("sub_account_1");
        subAccountDetails.add(subAccount);

        ApplicationMortgageDetails subAccount1 = new ApplicationMortgageDetails();
        subAccount1.setLoanAmount("1000");
        subAccount1.setTotalTerm("5");
        subAccount1.setProductId("lbg_mortgage");
        subAccount1.setInterestRate("11");
        subAccount1.setSubAccountSeqId("sub_account_2");
        subAccountDetails.add(subAccount1);

        applicationMortgageDetailsUpdateRequest.setSubAccountDetails(subAccountDetails);
        return applicationMortgageDetailsUpdateRequest;
    }

    public SolicitorDocReceivedRequestBuilder solicitorDocPayload() {
        return SolicitorDocReceivedRequest.builder().completionDate(LocalDate.now()).titleDeedNumber(TITLE_DEED_NUMBER);
    }



    public String assetValuationPayload() {
        return "{\"OriginalValuation\" : \"10000\", \"OtherComments\" : \"No Comments\", " +
                "\"DateOriginalValuation\" : \"23-05-2020\", \"AmountValueAfterImprovement\" : " +
                "\"10000\", \"InsuranceValuationAmount\" : \"10000\"}";
    }

    public String assetValuationPayloadWithoutOriginalValuation() {
        return "{\"OtherComments\" : \"No Comments\", " +
                "\"DateOriginalValuation\" : \"23-05-2020\", \"AmountValueAfterImprovement\" : " +
                "\"10000\", \"InsuranceValuationAmount\" : \"10000\"}";
    }

    public String assetValuationPayloadWithoutDateOriginalValuation() {
        return "{\"OriginalValuation\" : \"10000\", \"OtherComments\" : \"No Comments\", " +
                "\"AmountValueAfterImprovement\" : " +
                "\"10000\", \"InsuranceValuationAmount\" : \"10000\"}";
    }

    public String assetValuationPayloadWithoutAmountValueAfterImprovement() {
        return "{\"OriginalValuation\" : \"10000\", \"OtherComments\" : \"No Comments\", " +
                "\"DateOriginalValuation\" : \"23-05-2020\"" +
                ", \"InsuranceValuationAmount\" : \"10000\"}";
    }

    public String assetValuationPayloadWithoutInsuranceValuationAmount() {
        return "{\"OriginalValuation\" : \"10000\", \"OtherComments\" : \"No Comments\", " +
                "\"DateOriginalValuation\" : \"23-05-2020\", \"AmountValueAfterImprovement\" : " +
                "\"10000\"}";
    }

    public MortgageAccountInfo mortgageAccountInfoWithStatus(String status, String customerId) {
        MortgageAccountData accountData = MortgageAccountData.builder()
                .accountId(ACCOUNT_ID)
                .mortgageNumber(EXISTING_MORTGAGE_NUMBER)
                .productFamily(MORTGAGE_PAYMENT)
                .status(status)
                .stakeholderId(customerId)
                .build();
        return builder().mortgageAccountData(singletonList(accountData)).build();
    }

    public MortgageApplicationInfo mortgageApplicationInfoWithStatus(String status) {
        return MortgageApplicationInfo.builder()
                .applicationNumber(APPLICATION_NUMBER)
                .status(MortgagePortingApplicationStatus.valueOf(status))
                .build();
    }

    public HttpHeaders getAccountInfoHeaders() {
        HttpHeaders httpHeaders = new HttpHeaders();
        httpHeaders.add("Authorization", "Bearer b2c9119f-09e5-4ac9-9738-9e28b334d3fa");
        httpHeaders.add("x-lbg-internal-system-id", "test");
        httpHeaders.add("x-lbg-brand", "IF");
        httpHeaders.add("x-lbg-channel", TELEPHONE.name());
        httpHeaders.add("x-lbg-txn-correlation-id", "123-456-789-123");
        httpHeaders.setContentType(MediaType.APPLICATION_JSON);
        return httpHeaders;
    }

    public AccountStatusUpdateRequest buildAccountStatusUpdateRequestWithOnlyOverarchingAndCancelStatus(){
        AccountStatusUpdateRequest accountStatusUpdateRequest = new AccountStatusUpdateRequest();
        accountStatusUpdateRequest.setOverarchingAccount("b2c9119f-09e5-4ac9-9738-9e28b334d3fa");
        accountStatusUpdateRequest.setAccountStatus(AccountStatus.ACCOUNT_STATUS_CANCELLED);
        return accountStatusUpdateRequest;
    }


    public AccountStatusUpdateRequest buildAccountStatusUpdateRequestWithOverarchingSubAccountAndCancelStatus(){
        AccountStatusUpdateRequest accountStatusUpdateRequest = new AccountStatusUpdateRequest();
        accountStatusUpdateRequest.setOverarchingAccount("b2c9119f-09e5-4ac9-9738-9e28b334d3fa");
        accountStatusUpdateRequest.setAccountStatus(AccountStatus.ACCOUNT_STATUS_CANCELLED);
        accountStatusUpdateRequest.setSubAccountIds(Arrays.asList("b2c9119f-09e5-4ac9-9738-9e28b334d4ty"));
        return accountStatusUpdateRequest;
    }

    public AccountStatusUpdateRequest buildAccountStatusUpdateRequestWithOverarchingSubAccountAndOpenStatus(){
        AccountStatusUpdateRequest accountStatusUpdateRequest = new AccountStatusUpdateRequest();
        accountStatusUpdateRequest.setOverarchingAccount("b2c9119f-09e5-4ac9-9738-9e28b334d3fa");
        accountStatusUpdateRequest.setAccountStatus(AccountStatus.ACCOUNT_STATUS_OPEN);
        accountStatusUpdateRequest.setSubAccountIds(Arrays.asList("b2c9119f-09e5-4ac9-9738-9e28b334d4ty"));
        return accountStatusUpdateRequest;
    }

    public AccountStatusUpdateRequest buildAccountStatusUpdateRequestWithOverarchingPartialSubAccountAndCancelStatus(){
        AccountStatusUpdateRequest accountStatusUpdateRequest = new AccountStatusUpdateRequest();
        accountStatusUpdateRequest.setOverarchingAccount("b2c9119f-09e5-4ac9-9738-9e28b334d3fa");
        accountStatusUpdateRequest.setAccountStatus(AccountStatus.ACCOUNT_STATUS_CANCELLED);
        accountStatusUpdateRequest.setSubAccountIds(Arrays.asList("b2c9119f-09e5-4ac9-9738-9e28b334d4t0","b2c9119f-09e5-4ac9-9738-9e28b334d4t1"));
        return accountStatusUpdateRequest;
    }

    public AccountStatusUpdateRequest buildAccountStatusUpdateRequestWithPendingStatus(){
        AccountStatusUpdateRequest accountStatusUpdateRequest = new AccountStatusUpdateRequest();
        accountStatusUpdateRequest.setOverarchingAccount("b2c9119f-09e5-4ac9-9738-9e28b334d3fa");
        accountStatusUpdateRequest.setAccountStatus(AccountStatus.ACCOUNT_STATUS_PENDING);
        return accountStatusUpdateRequest;
    }

    public AccountStatusUpdateRequest buildAccountStatusUpdateRequestWithOverarchingAndSubAccountAndStatusOpen(){
        AccountStatusUpdateRequest accountStatusUpdateRequest = new AccountStatusUpdateRequest();
        accountStatusUpdateRequest.setOverarchingAccount("1601d0e5-e336-64d9-64ad-89ba6fdc2677");
        accountStatusUpdateRequest.setAccountStatus(AccountStatus.ACCOUNT_STATUS_OPEN);
        accountStatusUpdateRequest.setSubAccountIds(Arrays.asList("f76ca840-2553-d536-1ab8-9fa85c99db05"));
        return accountStatusUpdateRequest;
    }

    public AccountStatusUpdateRequest buildAccountStatusUpdateRequestWithOverarchingAndSubAccountAndStatusCancel(){
        AccountStatusUpdateRequest accountStatusUpdateRequest = new AccountStatusUpdateRequest();
        accountStatusUpdateRequest.setOverarchingAccount("1601d0e5-e336-64d9-64ad-89ba6fdc2677");
        accountStatusUpdateRequest.setAccountStatus(AccountStatus.ACCOUNT_STATUS_CANCELLED);
        accountStatusUpdateRequest.setSubAccountIds(Arrays.asList("f76ca840-2553-d536-1ab8-9fa85c99db05"));
        return accountStatusUpdateRequest;
    }



    public MortgageApplicationInfo getMortgagePortingApplicationDetails(){
        MortgageApplicationInfo mortgagePortingApplicationDetails =  new MortgageApplicationInfo();
        mortgagePortingApplicationDetails.setApplicationNumber(randomUUID().toString());
        mortgagePortingApplicationDetails.setStatus(MortgagePortingApplicationStatus.WELCOME_PACK_RECEIVED);
        mortgagePortingApplicationDetails.setBorrowingAmount("800");
        mortgagePortingApplicationDetails.setAccountIdToBePorted("08551cec-e7b0-cc5b-7026-d2e4b7fabf3a");

        List<MortgagePortingApplicationSubAccountDetails> subAccountDetails = new ArrayList<>();
        MortgagePortingApplicationSubAccountDetails mortgagePortingApplicationSubAccountDetails = new MortgagePortingApplicationSubAccountDetails();
        mortgagePortingApplicationSubAccountDetails.setLoanAmount("800");
        subAccountDetails.add(mortgagePortingApplicationSubAccountDetails);

        mortgagePortingApplicationDetails.setSubAccountDetails(subAccountDetails);
        return mortgagePortingApplicationDetails;
    }

    public MortgageApplicationInfo getMortgagePortingApplicationDetailsIncorrectState(){
        MortgageApplicationInfo mortgagePortingApplicationDetails =  new MortgageApplicationInfo();
        mortgagePortingApplicationDetails.setApplicationNumber(randomUUID().toString());
        mortgagePortingApplicationDetails.setStatus(MortgagePortingApplicationStatus.APPROVED);
        return mortgagePortingApplicationDetails;
    }

    public MortgageApplicationInfo getMortgagePortingApplicationDetailsStateUnavailable(){
        MortgageApplicationInfo mortgagePortingApplicationDetails =  new MortgageApplicationInfo();
        mortgagePortingApplicationDetails.setApplicationNumber(randomUUID().toString());
        return mortgagePortingApplicationDetails;
    }

    public MortgageApplicationInfo getMortgagePortingApplicationDetailsIncorrectApplicationNumber(){
        MortgageApplicationInfo mortgagePortingApplicationDetails =  new MortgageApplicationInfo();
        mortgagePortingApplicationDetails.setApplicationNumber("APPLICATION_NUMBER");
        mortgagePortingApplicationDetails.setStatus(MortgagePortingApplicationStatus.APPROVED);
        return mortgagePortingApplicationDetails;
    }
}
