package com.lbg.epscw.mortgagesrvc.validator;
import com.lbg.epscw.mortgagesrvc.dto.MortgageAccountInfo;
import com.lbg.epscw.mortgagesrvc.exception.InvalidUpdateRequestException;
import com.lbg.epscw.mortgagesrvc.helper.MortgageOffsettingHelper;
import com.lbg.epscw.mortgagesrvc.restclient.MortgageAccountInfoRestClient;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.HashMap;
import java.util.Map;

import static org.junit.Assert.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.powermock.api.mockito.PowerMockito.mock;
import static org.powermock.api.mockito.PowerMockito.when;

@RunWith(SpringRunner.class)
public class MortgageOffsettingValidatorTest {

    @Mock
    private MortgageAccountInfoRestClient mortgageAccountInfoRestClient;

    @Before
    public void setup() {
        mortgageAccountInfoRestClient = mock(MortgageAccountInfoRestClient.class);
    }

    private MortgageOffsettingHelper mortgageOffsettingHelper= new MortgageOffsettingHelper();

    @Test(expected = InvalidUpdateRequestException.class)
    public void validateUpdateOffsettingOption_OffsettingOptionDoesNotExist(){
        MortgageAccountInfo mortgageAccountInfo=mortgageOffsettingHelper.mortgageAccountInfo_offsettingMock();
        Map<String,String> reqMap= new HashMap<>();
        String accountId="5a688301-6d00-485c-0242-1ee03844a5c4";
        MortgageOffsettingValidator offsettingValidator= new MortgageOffsettingValidator(mortgageAccountInfoRestClient);
        when(mortgageAccountInfoRestClient.getMortgageAccountInfo(any(String.class),any(Map.class))).thenReturn(mortgageAccountInfo);
        offsettingValidator.validateUpdateOffsettingOption(accountId,reqMap);
    }

    @Test
    public void validateUpdateOffsettingOption_ReturnsMortgageAccountInfo(){
        MortgageAccountInfo mortgageAccountInfo=mortgageOffsettingHelper.mortgageAccountInfo_withOffsetting();
        Map<String,String> reqMap= new HashMap<>();
        String accountId="6965d050-d8fd-7fc3-4b66-41e72168be27";
        MortgageOffsettingValidator offsettingValidator= new MortgageOffsettingValidator(mortgageAccountInfoRestClient);
        when(mortgageAccountInfoRestClient.getMortgageAccountInfo(any(String.class),any(Map.class))).thenReturn(mortgageAccountInfo);

        MortgageAccountInfo actualAccountInfo = offsettingValidator.validateUpdateOffsettingOption(accountId,reqMap);
        assertEquals(mortgageAccountInfo, actualAccountInfo);
    }

}
