package com.lbg.epscw.mortgagesrvc.service;

import com.lbg.epscw.mortgagesrvc.exception.CircuitBreakerOpenException;
import com.lbg.epscw.mortgagesrvc.helper.MortgagePortingHelper;
import com.lbg.epscw.mortgagesrvc.model.MortgageApplicationInfo;
import com.lbg.epscw.mortgagesrvc.model.PortingUpdateSolicitorInfoRequest;
import com.lbg.epscw.mortgagesrvc.model.SolicitorInfo;
import com.lbg.epscw.mortgagesrvc.restclient.MortgagePortingApplicationInfoRestClient;
import org.junit.Before;
import org.junit.Test;
import org.mockito.ArgumentCaptor;

import static com.lbg.epscw.mortgagesrvc.helper.MortgagePortingHelper.SOLICITOR_PANEL_NUMBER;
import static com.lbg.epscw.mortgagesrvc.model.MortgagePortingApplicationStatus.OPEN;
import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.mockito.ArgumentCaptor.forClass;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;

public class MortgagePortingApplicationSolicitorInfoServiceImplTest {
    private final MortgagePortingHelper helper = new MortgagePortingHelper();
    private MortgagePortingApplicationInfoRestClient restClient;
    private MortgagePortingApplicationSolicitorInfoServiceImpl underTest;

    @Before
    public void setup() {
        restClient = mock(MortgagePortingApplicationInfoRestClient.class);
        underTest = new MortgagePortingApplicationSolicitorInfoServiceImpl(restClient);
    }

    @Test
    public void verify_update_solicitor_details_is_successful() {
        underTest.updateSolicitorDetails(helper.mortgageApplicationInfoWithStatus(OPEN.name()), helper.updateSolicitorInfoPayloadBuilder().build());

        final ArgumentCaptor<MortgageApplicationInfo> captor = forClass(MortgageApplicationInfo.class);
        verify(restClient).updateApplication(anyString(), captor.capture());

        MortgageApplicationInfo actual = captor.getValue();
        assertThat(actual.getStatus(), is(OPEN));
        SolicitorInfo solicitorInfo = actual.getSolicitorInfo();
        assertThat(solicitorInfo.getSolicitorPanelNumber(), is(SOLICITOR_PANEL_NUMBER));
        assertThat(solicitorInfo.getSolicitorCompanyName(), is("Acme Sol Inc"));
        assertThat(solicitorInfo.getSolicitorAddressLine01(), is("123 Solicitor Road"));
        assertThat(solicitorInfo.getSolicitorAddressLine02(), is("Line 02"));
        assertThat(solicitorInfo.getSolicitorAddressLine03(), is("Line 03"));
        assertThat(solicitorInfo.getSolicitorAddressLine04(), is("Line 04"));
        assertThat(solicitorInfo.getSolicitorAddressLine05(), is("Line 05"));
        assertThat(solicitorInfo.getSolicitorCity(), is("London"));
        assertThat(solicitorInfo.getStateOrProvince(), is("London"));
        assertThat(solicitorInfo.getSolicitorCountryCode(), is("UK"));
        assertThat(solicitorInfo.getSolicitorAccount().getSchemeName(), is("SortCodeAccountNumber"));
        assertThat(solicitorInfo.getSolicitorAccount().getIdentification(), is("01020312345678"));
    }

    @Test(expected = CircuitBreakerOpenException.class)
    public void create_fallback_throws_exception_on_broken_circuit_for_create_application() {
        underTest.fallbackUpdateSolicitorDetails(PortingUpdateSolicitorInfoRequest.builder().build(), new IllegalArgumentException());
    }
}