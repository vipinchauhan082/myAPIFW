package com.lbg.epscw.mortgagesrvc.restclient;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.lbg.epscw.mortgagesrvc.dto.AccountCreationResponse;
import com.lbg.epscw.mortgagesrvc.helper.AccountCreationHelper;
import com.lbg.epscw.mortgagesrvc.service.RestClientService;
import com.lbg.epscw.mortgagesrvc.util.MortgageServiceUtil;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.junit4.SpringRunner;

import java.text.MessageFormat;

import static org.powermock.api.mockito.PowerMockito.when;
import static org.mockito.ArgumentMatchers.any;
import static org.junit.Assert.assertEquals;

@RunWith(PowerMockRunner.class)
@PrepareForTest({ MessageFormat.class })
public class MortgageSubAccountRestClientTest {

    @Mock
    private RestClientService restClientService;

    @Mock
    private MortgageServiceUtil mortgageServiceUtil;

    @InjectMocks
    private MortgageSubAccountRestClient mortgageSubAccountRestClient;

    @Autowired
    private ObjectMapper mapper;

    @Before
    public void setup() {
        this.mapper = new ObjectMapper();
    }

    @Test
    public void testCreateAccount() throws JsonProcessingException {
        //Given
        String stringyfyResponse = mapper.writeValueAsString(AccountCreationHelper.buildCreateAccountResponse());
        when(restClientService.post(Mockito.any(),Mockito.any(),Mockito.any())).thenReturn(stringyfyResponse);
        when(mortgageServiceUtil.readObject(any(String.class), any(Class.class))).thenReturn(AccountCreationHelper.buildCreateAccountResponse());

        //When
        AccountCreationResponse response = mortgageSubAccountRestClient.createSubAccount(AccountCreationHelper.generateAccountOpenRequestMortgage(),AccountCreationHelper.generateRequiredHeaders());

        //Then
        assertEquals("ACCOUNT_STATUS_OPEN",response.getStatus());
        assertEquals("lbg_mortgage",response.getProductId());
        assertEquals("mortgage", response.getProductName());

    }
}
