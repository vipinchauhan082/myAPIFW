package com.lbg.epscw.mortgagesrvc.service;


import com.lbg.epscw.mortgagesrvc.constants.CommonConstants;
import com.lbg.epscw.mortgagesrvc.dto.MortgageAccountData;
import com.lbg.epscw.mortgagesrvc.dto.MortgageAccountInfo;
import com.lbg.epscw.mortgagesrvc.dto.RedemptionStatementRequest;
import com.lbg.epscw.mortgagesrvc.dto.RedemptionStatementResponse;
import com.lbg.epscw.mortgagesrvc.dto.comms.*;
import com.lbg.epscw.mortgagesrvc.enums.Recipient;
import com.lbg.epscw.mortgagesrvc.helper.MortgageRedemptionHelper;
import com.lbg.epscw.mortgagesrvc.restclient.CustomerCommsRestClient;
import com.lbg.epscw.mortgagesrvc.restclient.MortgageAccountInfoRestClient;
import org.apache.commons.lang.StringUtils;
import org.junit.Test;
import org.junit.jupiter.api.Assertions;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.test.context.junit4.SpringRunner;

import static com.lbg.epscw.mortgagesrvc.constants.CommonConstants.COMMS_TEMPLATE_REFERENCE;
import static com.lbg.epscw.mortgagesrvc.constants.CommonConstants.REDEMPTION_VALIDITY_DAYS;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

import java.time.LocalDate;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

@RunWith(SpringRunner.class)
public class MortgageRedemptionServiceImplTest {

    private MortgageRedemptionHelper helper = new MortgageRedemptionHelper();


    @Mock
    private CustomerCommsRestClient customerCommsRestClient;

    @InjectMocks
    private MortgageRedemptionServiceImpl mortgageRedemptionService;


    @Test
    public void testSendComms() {

        List<MortgageAccountData> list = new ArrayList<>();
        list.add(
                MortgageAccountData.builder()
                        .accountId("Account_ID_123")
                        .accountSortCode("11-22-33")
                        .jarName("some Jarname")
                        .planNumber("some plan number")
                        .accountNumber("12345678")
                        .build()
        );

        //Given

        when(customerCommsRestClient.sendComms(any(), any())).thenReturn(
                CommsResponse.builder().body("Sent successfully!").build());

        //When
        RedemptionStatementResponse response =  mortgageRedemptionService.sendRedemptionStatement("Account_ID_123",
               helper.mock_mortgageAccountData("Account_ID_123"), helper.getRedemptionStatementRequest(),helper.getMapOfHeaders());


        //Then
        Assertions.assertNotNull(response);
        Assertions.assertEquals("Sent successfully!",response.getMessage());
    }

    @Test
    public void testSendCommsNotSuccess() {

        List<MortgageAccountData> list = new ArrayList<>();
        list.add(
                MortgageAccountData.builder()
                        .accountId("Account_ID_123")
                        .accountSortCode("11-22-33")
                        .jarName("some Jarname")
                        .planNumber("some plan number")
                        .accountNumber("12345678")
                        .build()
        );

        //Given

        when(customerCommsRestClient.sendComms(any(), any())).thenReturn(
                CommsResponse.builder().body("Communication Not sent!:").build());

        //When
        RedemptionStatementResponse response =  mortgageRedemptionService.sendRedemptionStatement("Account_ID_1234",
               helper.mock_mortgageAccountData("Account_ID_1234"), helper.getRedemptionStatementRequest(),helper.getMapOfHeaders());


        //Then
        Assertions.assertNotNull(response);
        Assertions.assertTrue(response.getMessage().contains("Communication Not sent!:"));
    }

    @Test
    public void testSendCommsSolicitor() {

        //Given
        when(customerCommsRestClient.sendComms(any(),any())).thenReturn(
                CommsResponse.builder().body("Sent successfully!").build());

        //When
        RedemptionStatementResponse response =  mortgageRedemptionService.sendRedemptionStatement("Account_ID_123",
                helper.mock_mortgageAccountData("Account_ID_123"), helper.getRedemptionStatementSolicitorRequestPayload(),helper.getMapOfHeaders());

        //Then
        Assertions.assertNotNull(response);
        Assertions.assertEquals("Sent successfully!",response.getMessage());
    }
}
