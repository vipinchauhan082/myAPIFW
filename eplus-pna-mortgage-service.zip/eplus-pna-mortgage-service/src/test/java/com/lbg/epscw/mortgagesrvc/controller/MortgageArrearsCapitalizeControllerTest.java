package com.lbg.epscw.mortgagesrvc.controller;


import com.lbg.epscw.mortgagesrvc.dto.CapitalizeArrearsResponse;
import com.lbg.epscw.mortgagesrvc.dto.MortgageAccountData;
import com.lbg.epscw.mortgagesrvc.exception.MortgageServiceException;
import com.lbg.epscw.mortgagesrvc.helper.AccountCreationHelper;
import com.lbg.epscw.mortgagesrvc.model.OverarchingAccountInfo;
import com.lbg.epscw.mortgagesrvc.service.MortgageArrearsCapitalizeService;
import com.lbg.epscw.mortgagesrvc.util.MortgageServiceUtil;
import com.lbg.epscw.mortgagesrvc.validator.MortgageArrearsCapitalizeValidator;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.List;
import java.util.Map;

import static org.junit.Assert.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyMap;
import static org.powermock.api.mockito.PowerMockito.when;

@RunWith(SpringRunner.class)
@WebMvcTest(controllers = { MortgageServiceUtil.class, MortgageArrearsCapitalizeController.class })
public class MortgageArrearsCapitalizeControllerTest {

    @MockBean
    private MortgageArrearsCapitalizeService mortgageArrearsCapitalizeService;


    @Autowired
    private MortgageArrearsCapitalizeController mortgageArrearsCapitalizeController;


    @MockBean
    private MortgageArrearsCapitalizeValidator mortgageArrearsCapitalizeValidator;


    @Test
    public void mortgage_Arrears_Capitalization(){


        List<MortgageAccountData> mortgageSubAccountData = AccountCreationHelper.getMortgageSubAccountData();
        mortgageSubAccountData.get(0).setProductFamily("Mortgage Payment");
        mortgageSubAccountData.get(0).setMortgageInArrears(true);


        when(mortgageArrearsCapitalizeValidator.validateCapitalizationOfArrears(any(OverarchingAccountInfo.class),any(Map.class))).thenReturn(mortgageSubAccountData);

        CapitalizeArrearsResponse capitalizeArrearsResponse = CapitalizeArrearsResponse.builder().internalAccountId("fa78d9f0-0fc2-59c1-4ff9-39c0d1f3ec14").
                productId("lbg_mortgage_repayment").productName("Mortgage").build();



        when(mortgageArrearsCapitalizeService.mortgageArrearsCapitalization(any(),any(OverarchingAccountInfo.class),anyMap()))
                .thenReturn(capitalizeArrearsResponse);

        ResponseEntity<CapitalizeArrearsResponse> responseEntity = mortgageArrearsCapitalizeController.mortgageArrearsCapitalization("IF","DIGITAL",
                "txnCorrelationId","jwttoken","internalSystemId",AccountCreationHelper.generateRequiredHeaders(),"fa78d9f0-0fc2-59c1-4ff9-39c0d1f3ec14");

        CapitalizeArrearsResponse response = responseEntity.getBody();

        assertEquals("fa78d9f0-0fc2-59c1-4ff9-39c0d1f3ec14", response.getInternalAccountId());

    }


    @Test(expected = MortgageServiceException.class)
    public void mortgage_Arrears_Capitalization_throw_exception_if_service_return_null(){


        List<MortgageAccountData> mortgageSubAccountData = AccountCreationHelper.getMortgageSubAccountData();
        mortgageSubAccountData.get(0).setProductFamily("Mortgage Payment");
        mortgageSubAccountData.get(0).setMortgageInArrears(true);


        when(mortgageArrearsCapitalizeValidator.validateCapitalizationOfArrears(any(OverarchingAccountInfo.class),any(Map.class))).thenReturn(mortgageSubAccountData);

        CapitalizeArrearsResponse capitalizeArrearsResponse = CapitalizeArrearsResponse.builder().internalAccountId("fa78d9f0-0fc2-59c1-4ff9-39c0d1f3ec14").
                productId("lbg_mortgage_repayment").productName("Mortgage").build();



        when(mortgageArrearsCapitalizeService.mortgageArrearsCapitalization(any(),any(OverarchingAccountInfo.class),anyMap()))
                .thenReturn(null);

        ResponseEntity<CapitalizeArrearsResponse> responseEntity = mortgageArrearsCapitalizeController.mortgageArrearsCapitalization("IF","DIGITAL",
                "txnCorrelationId","jwttoken","internalSystemId",AccountCreationHelper.generateRequiredHeaders(),"fa78d9f0-0fc2-59c1-4ff9-39c0d1f3ec14");


    }
}
