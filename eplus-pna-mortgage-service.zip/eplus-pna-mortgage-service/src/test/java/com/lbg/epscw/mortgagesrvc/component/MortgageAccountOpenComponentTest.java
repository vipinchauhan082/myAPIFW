package com.lbg.epscw.mortgagesrvc.component;

import com.lbg.epscw.entitlement.service.EntitlementValidationServiceImpl;
import com.lbg.epscw.handler.model.ErrorInfo;
import com.lbg.epscw.handler.model.ErrorResponse;
import com.lbg.epscw.mortgagesrvc.dto.AccountCreationResponse;
import com.lbg.epscw.mortgagesrvc.helper.AccountCreationHelper;
import com.lbg.epscw.mortgagesrvc.helper.ComponentHelper;
import com.lbg.epscw.mortgagesrvc.logger.HystrixContextCopyStrategy;
import com.lbg.epscw.mortgagesrvc.model.AccountOpenRequest;
import com.lbg.epscw.mortgagesrvc.service.MortgageAccountService;
import com.lbg.epscw.mortgagesrvc.service.RestClientService;
import org.apache.commons.lang.RandomStringUtils;
import org.junit.Assert;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mockito;
import org.mockito.internal.util.MockUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.context.ApplicationContext;
import org.springframework.http.HttpHeaders;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import static org.junit.Assert.assertEquals;
import static org.junit.jupiter.api.Assertions.assertAll;
import static org.mockito.ArgumentMatchers.any;
import static org.powermock.api.mockito.PowerMockito.when;

@Tag("component")
@ExtendWith(SpringExtension.class)
@SpringBootTest
@AutoConfigureMockMvc
public class MortgageAccountOpenComponentTest extends WebMVCTest {

    private static final String MORTGAGES_CREATE =
            "/mortgages/accounts/create";

    @MockBean
    private EntitlementValidationServiceImpl entitlementValidationService;

    @MockBean
    RestClientService restClientService;

    @MockBean
    private HystrixContextCopyStrategy hystrixContextCopyStrategy;

    @MockBean
    private MortgageAccountService mortgageAccountService;

    private ComponentHelper componentHelper;

    @Autowired
    private ApplicationContext context;

    @BeforeEach
    public void beforeEach() {
        this.componentHelper = new ComponentHelper();
        for (String name : context.getBeanDefinitionNames()) {
            Object bean = context.getBean(name);
            if (MockUtil.isMock(bean)) {
                Mockito.reset(bean);
            }
        }
    }

    @Test
    public void shouldCreatSubAccount() {
        //given
        when(mortgageAccountService.openAccount(any(),any())).thenReturn(AccountCreationHelper.buildCreateAccountResponse());
        AccountOpenRequest accountOpenRequest = AccountCreationHelper.generateAccountOpenRequestMortgage();
        String payload = componentHelper.writeValueAsString(accountOpenRequest);

        //when

        MockHttpServletResponse servletResponse = doPOST(MORTGAGES_CREATE, payload, AccountCreationHelper.generateHttpHeaders());

        String responseString = componentHelper.getServletResponseAsString(servletResponse);
        AccountCreationResponse response = (AccountCreationResponse) readObject(responseString, AccountCreationResponse.class);

        //then
        assertAll(
                () -> assertEquals("ACCOUNT_STATUS_OPEN", response.getStatus()),
                () -> assertEquals("mortgage", response.getProductName()),
                () -> assertEquals("lbg_mortgage", response.getProductId())
        );
    }


    @Test
    public void shouldCreateRepaymentAccount() {
        //given
        when(mortgageAccountService.openAccount(any(),any())).thenReturn(AccountCreationHelper.buildCreateRepaymentAccountResponse());
        AccountOpenRequest accountOpenRequest = AccountCreationHelper.generateRepaymentAccountOpenRequestMortgage();
        String payload = componentHelper.writeValueAsString(accountOpenRequest);

        //when

        MockHttpServletResponse servletResponse = doPOST(MORTGAGES_CREATE, payload, AccountCreationHelper.generateHttpHeaders());

        String responseString = componentHelper.getServletResponseAsString(servletResponse);
        AccountCreationResponse response = (AccountCreationResponse) readObject(responseString, AccountCreationResponse.class);

        //then
        assertAll(
                () -> assertEquals("ACCOUNT_STATUS_OPEN", response.getStatus()),
                () -> assertEquals("Mortgage Payment", response.getProductName()),
                () -> assertEquals("lbg_mortgage_repayment", response.getProductId())
        );
    }

    @Test
    public void shouldThrowBadRequestCreateRepaymentAccountWithoutPlan() {
        //given
        when(mortgageAccountService.openAccount(any(),any())).thenReturn(AccountCreationHelper.buildCreateAccountResponse());
        AccountOpenRequest accountOpenRequest = AccountCreationHelper.generateRepaymentAccountWithoutPlan();
        String payload = componentHelper.writeValueAsString(accountOpenRequest);

        //when

        MockHttpServletResponse servletResponse = doPOST(MORTGAGES_CREATE, payload, AccountCreationHelper.generateHttpHeaders());

        String responseString = componentHelper.getServletResponseAsString(servletResponse);
        ErrorResponse errorResponse = (ErrorResponse) readObject(responseString, ErrorResponse.class);
        ErrorInfo errorInfo = errorResponse.getErrors().get(0);

        //then
        assertAll(
                () -> assertEquals(400, servletResponse.getStatus()),
                () -> assertEquals("PNA.MORTGAGE_API.SYS.001", errorResponse.getCode()),
                () -> assertEquals("Bad Request", errorResponse.getMessage()),
                () -> assertEquals("PNA.MORTGAGE_API.POST_MORTGAGES_ACCOUNTS_CREATE.Value.NullOrEmpty", errorInfo.getReasonCode()),
                () -> assertEquals("'Empty attributes were:, plan_number' is null or empty", errorInfo.getMessage())
        );
    }

    @Test
    public void shouldThrowBadRequestCreateSubAccountWithoutDenomination() {
        //given
        when(mortgageAccountService.openAccount(any(),any())).thenReturn(AccountCreationHelper.buildCreateAccountResponse());
        AccountOpenRequest accountOpenRequest = AccountCreationHelper.generateAccountOpenRequestMortgage();
        accountOpenRequest.setDenomination(null);
        String payload = componentHelper.writeValueAsString(accountOpenRequest);

        //when

        MockHttpServletResponse servletResponse = doPOST(MORTGAGES_CREATE, payload, AccountCreationHelper.generateHttpHeaders());

        String responseString = componentHelper.getServletResponseAsString(servletResponse);
        ErrorResponse errorResponse = (ErrorResponse) readObject(responseString, ErrorResponse.class);
        ErrorInfo errorInfo = errorResponse.getErrors().get(0);

        //then
        assertAll(
                () -> assertEquals(400, servletResponse.getStatus()),
                () -> assertEquals("PNA.MORTGAGE_API.SYS.001", errorResponse.getCode()),
                () -> assertEquals("Bad Request", errorResponse.getMessage()),
                () -> assertEquals("PNA.MORTGAGE_API.POST_MORTGAGES_ACCOUNTS_CREATE.Argument.Invalid", errorInfo.getReasonCode()),
                () -> assertEquals("Denomination must not be empty", errorInfo.getMessage())
        );
    }

    @Test
    public void shouldThrowBadRequestCreateSubAccountWithoutMortgageNumber() {
        //given
        when(mortgageAccountService.openAccount(any(),any())).thenReturn(AccountCreationHelper.buildCreateAccountResponse());
        AccountOpenRequest accountOpenRequest = AccountCreationHelper.generateAccountOpenRequestMortgage();
        accountOpenRequest.setMortgageNumber(null);
        String payload = componentHelper.writeValueAsString(accountOpenRequest);

        //when

        MockHttpServletResponse servletResponse = doPOST(MORTGAGES_CREATE, payload, AccountCreationHelper.generateHttpHeaders());

        String responseString = componentHelper.getServletResponseAsString(servletResponse);
        ErrorResponse errorResponse = (ErrorResponse) readObject(responseString, ErrorResponse.class);
        ErrorInfo errorInfo = errorResponse.getErrors().get(0);

        //then
        assertAll(
                () -> assertEquals(400, servletResponse.getStatus()),
                () -> assertEquals("PNA.MORTGAGE_API.SYS.001", errorResponse.getCode()),
                () -> assertEquals("Bad Request", errorResponse.getMessage()),
                () -> assertEquals("PNA.MORTGAGE_API.POST_MORTGAGES_ACCOUNTS_CREATE.Argument.Invalid", errorInfo.getReasonCode()),
                () -> assertEquals("MortgageNumber must not be empty", errorInfo.getMessage())
        );
    }

    @Test
    public void shouldThrowBadRequestCreateSubAccountWithoutMandatoryField() {
        //given
        AccountOpenRequest accountOpenRequest = AccountCreationHelper.generateAccountOpenRequestMortgage();
        accountOpenRequest.setDepositAccount(null);
        String payload = componentHelper.writeValueAsString(accountOpenRequest);

        //when

        MockHttpServletResponse servletResponse = doPOST(MORTGAGES_CREATE, payload, AccountCreationHelper.generateHttpHeaders());

        String responseString = componentHelper.getServletResponseAsString(servletResponse);
        ErrorResponse errorResponse = (ErrorResponse) readObject(responseString, ErrorResponse.class);
        ErrorInfo errorInfo = errorResponse.getErrors().get(0);

        //then
        assertAll(
                () -> assertEquals(400, servletResponse.getStatus()),
                () -> assertEquals("PNA.MORTGAGE_API.SYS.001", errorResponse.getCode()),
                () -> assertEquals("Bad Request", errorResponse.getMessage()),
                () -> assertEquals("PNA.MORTGAGE_API.POST_MORTGAGES_ACCOUNTS_CREATE.Value.NullOrEmpty", errorInfo.getReasonCode())
        );
    }



    @Test
    public void shouldReturnErrorForEmptyJson() {
        //when
        MockHttpServletResponse servletResponse = doPOST(MORTGAGES_CREATE,
                "{}",
                AccountCreationHelper.generateHttpHeaders());

        String responseString = componentHelper.getServletResponseAsString(servletResponse);
        ErrorResponse errorResponse = (ErrorResponse) readObject(responseString, ErrorResponse.class);
        ErrorInfo errorInfo = errorResponse.getErrors().get(0);

        //then
        assertAll(
                () -> Assert.assertEquals(400, servletResponse.getStatus()),
                () -> Assert.assertEquals("PNA.MORTGAGE_API.SYS.001", errorResponse.getCode()),
                () -> Assert.assertEquals("Bad Request", errorResponse.getMessage())

        );
    }

    @Test
    public void shouldReturnErrorForEmptyRequestBody() {
        //given
        //when
        MockHttpServletResponse servletResponse = doPOST(MORTGAGES_CREATE,
                "",
                AccountCreationHelper.generateHttpHeaders());

        String responseString = componentHelper.getServletResponseAsString(servletResponse);
        ErrorResponse errorResponse = (ErrorResponse) readObject(responseString, ErrorResponse.class);
        ErrorInfo errorInfo = errorResponse.getErrors().get(0);

        //then
        assertAll(
                () -> Assert.assertEquals(400, servletResponse.getStatus()),
                () -> Assert.assertEquals("PNA.MORTGAGE_API.SYS.001", errorResponse.getCode()),
                () -> Assert.assertEquals("Bad Request", errorResponse.getMessage())

        );
    }


    @Test
    public void shouldReturnErrorForUpdateWhenCorrelationIdIsGreaterThanFortyCharacters() {
        //given

        AccountOpenRequest accountOpenRequest = AccountCreationHelper.generateRepaymentAccountOpenRequestMortgage();
        String payload = componentHelper.writeValueAsString(accountOpenRequest);
        HttpHeaders accountInfoHeaders = AccountCreationHelper.generateHttpHeaders();
        accountInfoHeaders.set("x-lbg-txn-correlation-id", RandomStringUtils.random(50));
        //when
        MockHttpServletResponse servletResponse = doPOST(MORTGAGES_CREATE,
                payload,
                accountInfoHeaders);
        String responseString = componentHelper.getServletResponseAsString(servletResponse);
        ErrorResponse errorResponse = (ErrorResponse) readObject(responseString, ErrorResponse.class);
        ErrorInfo errorInfo = errorResponse.getErrors().get(0);

        //then
        assertAll(
                () -> Assert.assertEquals(400, servletResponse.getStatus()),
                () -> Assert.assertEquals("PNA.MORTGAGE_API.SYS.001", errorResponse.getCode()),
                () -> Assert.assertEquals("Bad Request", errorResponse.getMessage()),
                () -> Assert.assertEquals("x-lbg-txn-correlation-id size should be between 10 and 40", errorInfo.getMessage())
        );
    }

    @Test
    public void shouldReturnErrorForUpdateWhenCorrelationIdIsLessThanTenCharacters() {
        //given
        AccountOpenRequest accountOpenRequest = AccountCreationHelper.generateRepaymentAccountOpenRequestMortgage();
        String payload = componentHelper.writeValueAsString(accountOpenRequest);
        HttpHeaders accountInfoHeaders = AccountCreationHelper.generateHttpHeaders();
        accountInfoHeaders.set("x-lbg-txn-correlation-id", RandomStringUtils.random(9));
        //when
        MockHttpServletResponse servletResponse = doPOST(MORTGAGES_CREATE,
                payload,
                accountInfoHeaders);
        String responseString = componentHelper.getServletResponseAsString(servletResponse);
        ErrorResponse errorResponse = (ErrorResponse) readObject(responseString, ErrorResponse.class);
        ErrorInfo errorInfo = errorResponse.getErrors().get(0);

        //then
        assertAll(
                () -> Assert.assertEquals(400, servletResponse.getStatus()),
                () -> Assert.assertEquals("PNA.MORTGAGE_API.SYS.001", errorResponse.getCode()),
                () -> Assert.assertEquals("Bad Request", errorResponse.getMessage()),
                () -> Assert.assertEquals("x-lbg-txn-correlation-id size should be between 10 and 40", errorInfo.getMessage())
        );
    }

    @Test
    public void shouldReturnErrorForUpdateWhenCorrelationIdIsMissing() {
        //given
        AccountOpenRequest accountOpenRequest = AccountCreationHelper.generateRepaymentAccountOpenRequestMortgage();
        String payload = componentHelper.writeValueAsString(accountOpenRequest);
        HttpHeaders accountInfoHeaders = AccountCreationHelper.generateHttpHeaders();
        accountInfoHeaders.remove("x-lbg-txn-correlation-id");
        //when
        MockHttpServletResponse servletResponse = doPOST(MORTGAGES_CREATE,
                payload,
                accountInfoHeaders);
        String responseString = componentHelper.getServletResponseAsString(servletResponse);
        ErrorResponse errorResponse = (ErrorResponse) readObject(responseString, ErrorResponse.class);
        ErrorInfo errorInfo = errorResponse.getErrors().get(0);

        //then
        assertAll(
                () -> Assert.assertEquals(400, servletResponse.getStatus()),
                () -> Assert.assertEquals("PNA.MORTGAGE_API.SYS.001", errorResponse.getCode()),
                () -> Assert.assertEquals("Bad Request", errorResponse.getMessage()),
                () -> Assert.assertEquals("Missing request header x-lbg-txn-correlation-id for method parameter of type String", errorInfo.getMessage())
        );
    }


    @Test
    public void shouldReturnErrorForUpdateWhenBrandIsMissing() {
        //given
        HttpHeaders accountInfoHeaders = AccountCreationHelper.generateHttpHeaders();
        accountInfoHeaders.remove("x-lbg-brand");
        //when
        MockHttpServletResponse servletResponse = doPOST(MORTGAGES_CREATE,
                "",
                accountInfoHeaders);
        String responseString = componentHelper.getServletResponseAsString(servletResponse);
        ErrorResponse errorResponse = (ErrorResponse) readObject(responseString, ErrorResponse.class);
        ErrorInfo errorInfo = errorResponse.getErrors().get(0);

        //then
        assertAll(
                () -> Assert.assertEquals(400, servletResponse.getStatus()),
                () -> Assert.assertEquals("PNA.MORTGAGE_API.SYS.001", errorResponse.getCode()),
                () -> Assert.assertEquals("Bad Request", errorResponse.getMessage()),
                () -> Assert.assertEquals("Missing request header 'x-lbg-brand' for method parameter of type String", errorInfo.getMessage())
        );
    }

}
