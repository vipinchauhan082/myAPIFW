package com.lbg.epscw.mortgagesrvc.helper;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.lbg.epscw.mortgagesrvc.dto.MortgageAccountInfo;
import com.lbg.epscw.mortgagesrvc.model.AccountOptionsUpdateResponse;
import com.lbg.epscw.mortgagesrvc.model.InstanceParamValsUpdate;
import com.lbg.epscw.mortgagesrvc.model.NominationRequest;
import com.lbg.epscw.mortgagesrvc.model.NominationResponse;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;

import java.util.HashMap;
import java.util.Map;

public class MortgageNominationHelper {

    public HttpHeaders getAccountInfoHeaders() {
        HttpHeaders httpHeaders = new HttpHeaders();
        httpHeaders.add("Authorization", "Bearer b2c9119f-09e5-4ac9-9738-9e28b334d3fa");
        httpHeaders.add("x-lbg-internal-system-id", "test");
        httpHeaders.add("x-lbg-brand", "IF");
        httpHeaders.add("x-lbg-txn-correlation-id", "123-456-789-123");
        httpHeaders.setContentType(MediaType.APPLICATION_JSON);
        return httpHeaders;
    }

    public NominationRequest getNominationRequest() {
        NominationRequest nominationRequest = new NominationRequest();
        nominationRequest.setNominatedAdhocOverpaymentAccount("1b69ad2f-63b3-c70f-6f52-ee85b97e314d");
        return nominationRequest;
    }

    public NominationRequest buildNominationRequestFor(String accountId) {
        NominationRequest nominationRequest = new NominationRequest();
        nominationRequest.setNominatedAdhocOverpaymentAccount(accountId);
        return nominationRequest;
    }

    public String getUpdateNominationVaultResponse() {
        return "{\n" +
                "    \"id\": \"6a29e8c6-2707-42d4-a374-71d0596ead0f\",\n" +
                "    \"account_id\": \"ee295584-cea8-d318-9c86-31be00d4063e\",\n" +
                "    \"status\": \"ACCOUNT_UPDATE_STATUS_PENDING_EXECUTION\",\n" +
                "    \"instance_param_vals_update\": {\n" +
                "        \"instance_param_vals\": {\n" +
                "            \"nominated_adhoc_overpayment_account\": \"90e804ab-5dad-7f7c-1d71-ab914545ebcc\"\n" +
                "        }\n" +
                "    },\n" +
                "    \"create_timestamp\": \"2020-09-14T17:45:04.687675Z\",\n" +
                "    \"last_status_update_timestamp\": \"2020-09-14T17:45:04.687675Z\",\n" +
                "    \"account_update_batch_id\": \"\",\n" +
                "    \"failure_reason\": \"\"\n" +
                "}";
    }

    public String getDeleteNominationVaultResponse() {
        return "{\n" +
                "    \"id\": \"6a29e8c6-2707-42d4-a374-71d0596ead0f\",\n" +
                "    \"account_id\": \"ee295584-cea8-d318-9c86-31be00d4063e\",\n" +
                "    \"status\": \"ACCOUNT_UPDATE_STATUS_PENDING_EXECUTION\",\n" +
                "    \"instance_param_vals_update\": {\n" +
                "        \"instance_param_vals\": {\n" +
                "            \"nominated_adhoc_overpayment_account\": \"\"\n" +
                "        }\n" +
                "    },\n" +
                "    \"create_timestamp\": \"2020-09-14T17:45:04.687675Z\",\n" +
                "    \"last_status_update_timestamp\": \"2020-09-14T17:45:04.687675Z\",\n" +
                "    \"account_update_batch_id\": \"\",\n" +
                "    \"failure_reason\": \"\"\n" +
                "}";
    }

    public String getMortgageQueryServiceResponse() {
        return "{\n" +
                "    \"Data\": [\n" +
                "        {\n" +
                "            \"mortgageNumber\": \"number_1112\",\n" +
                "            \"mortgagePrincipal\": \"4000\",\n" +
                "            \"keyDate\": \"7\",\n" +
                "            \"mortgageType\": \"INTEREST_ONLY\",\n" +
                "            \"totalTerm\": \"24\",\n" +
                "            \"productId\": \"lbg_mortgage\",\n" +
                "            \"accountId\": \"1601d0e5-e336-64d9-64ad-89ba6fdc2677\"\n" +
                "        },\n" +
                "        {\n" +
                "            \"mortgageNumber\": \"number_1112\",\n" +
                "            \"mortgagePrincipal\": \"3000\",\n" +
                "            \"keyDate\": \"7\",\n" +
                "            \"mortgageType\": \"INTEREST_ONLY\",\n" +
                "            \"totalTerm\": \"24\",\n" +
                "            \"productId\": \"lbg_mortgage\",\n" +
                "            \"accountId\": \"1b69ad2f-63b3-c70f-6f52-ee85b97e314d\"\n" +
                "        },\n" +
                "        {\n" +
                "            \"mortgageNumber\": \"number_1112\",\n" +
                "            \"productId\": \"lbg_mortgage_repayment\",\n" +
                "            \"accountId\": \"f76ca840-2553-d536-1ab8-9fa85c99db05\"\n" +
                "        }\n" +
                "    ]\n" +
                "}";
    }

    public String getMortgageQueryServiceResponseForSubAccount() {
        return "{\n" +
                "    \"Data\": [\n" +
                "        {\n" +
                "            \"mortgageNumber\": \"number_1112\",\n" +
                "            \"mortgagePrincipal\": \"4000\",\n" +
                "            \"keyDate\": \"7\",\n" +
                "            \"mortgageType\": \"INTEREST_ONLY\",\n" +
                "            \"totalTerm\": \"24\",\n" +
                "            \"productId\": \"lbg_mortgage\",\n" +
                "            \"accountId\": \"f76ca840-2553-d536-1ab8-9fa85c99db05\"\n" +
                "        }\n" +
                "    ]\n" +
                "}";
    }

    public MortgageAccountInfo getMortgageAccountInfo()  {
        try {
            return new ObjectMapper().readValue(getMortgageQueryServiceResponse(), MortgageAccountInfo.class);
        } catch (JsonProcessingException e) {
            return new MortgageAccountInfo();
        }
    }

    public AccountOptionsUpdateResponse getMockNominationUpdateResponse() {
        AccountOptionsUpdateResponse accountOptionsUpdateResponse =
                new AccountOptionsUpdateResponse();
        accountOptionsUpdateResponse.setAccountId("f76ca840-2553-d536-1ab8-9fa85c99db05");
        accountOptionsUpdateResponse.setStatus("ACCOUNT_UPDATE_STATUS_PENDING_EXECUTION");
        Map<String, String> accountOptions = new HashMap<>();
        accountOptions.put("nominated_adhoc_overpayment_account", "90e804ab-5dad-7f7c-1d71-ab914545ebcc");
        InstanceParamValsUpdate instanceParamValsUpdate = new InstanceParamValsUpdate();
        instanceParamValsUpdate.setInstanceParamVals(accountOptions);
        accountOptionsUpdateResponse.setInstanceParamValsUpdate(instanceParamValsUpdate);
        return accountOptionsUpdateResponse;
    }

    public AccountOptionsUpdateResponse getMockNominationDeleteResponse() {
        AccountOptionsUpdateResponse accountOptionsUpdateResponse =
                new AccountOptionsUpdateResponse();
        accountOptionsUpdateResponse.setAccountId("f76ca840-2553-d536-1ab8-9fa85c99db05");
        accountOptionsUpdateResponse.setStatus("ACCOUNT_UPDATE_STATUS_PENDING_EXECUTION");
        Map<String, String> accountOptions = new HashMap<>();
        accountOptions.put("nominated_adhoc_overpayment_account", "");
        InstanceParamValsUpdate instanceParamValsUpdate = new InstanceParamValsUpdate();
        instanceParamValsUpdate.setInstanceParamVals(accountOptions);
        accountOptionsUpdateResponse.setInstanceParamValsUpdate(instanceParamValsUpdate);
        return accountOptionsUpdateResponse;
    }

    public NominationResponse getMockUpdateNominationResponse() {
        NominationResponse nominationResponse = new NominationResponse();
        nominationResponse.setAccountId("f76ca840-2553-d536-1ab8-9fa85c99db05");
        nominationResponse.setStatus("ACCOUNT_UPDATE_STATUS_PENDING_EXECUTION");
        Map<String, String> accountOptions = new HashMap<>();
        accountOptions.put("NominatedAdhocOverpaymentAccount", "90e804ab-5dad-7f7c-1d71-ab914545ebcc");
        nominationResponse.setAdditionalDetails(accountOptions);
        return nominationResponse;
    }

    public NominationResponse getMockDeleteNominationResponse() {
        NominationResponse nominationResponse = new NominationResponse();
        nominationResponse.setAccountId("f76ca840-2553-d536-1ab8-9fa85c99db05");
        nominationResponse.setStatus("ACCOUNT_UPDATE_STATUS_PENDING_EXECUTION");
        Map<String, String> accountOptions = new HashMap<>();
        accountOptions.put("NominatedAdhocOverpaymentAccount", "");
        nominationResponse.setAdditionalDetails(accountOptions);
        return nominationResponse;
    }
}
