package com.lbg.epscw.mortgagesrvc.service;

import com.lbg.epscw.mortgagesrvc.dto.SettlementAmountInfo;
import com.lbg.epscw.mortgagesrvc.exception.CircuitBreakerOpenException;
import com.lbg.epscw.mortgagesrvc.exception.MortgageServiceException;
import com.lbg.epscw.mortgagesrvc.helper.MortgageRedemptionHelper;
import com.lbg.epscw.mortgagesrvc.model.MortgageSettlementAmountResponse;
import com.lbg.epscw.mortgagesrvc.restclient.MortgageAccountInfoRestClient;
import com.lbg.epscw.mortgagesrvc.restclient.MortgageSettlementAmountRestClient;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import static org.junit.Assert.assertEquals;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.HashMap;

import static org.mockito.ArgumentMatchers.anyMap;
import static org.mockito.ArgumentMatchers.anyString;
import static org.powermock.api.mockito.PowerMockito.mock;
import static org.powermock.api.mockito.PowerMockito.when;


@RunWith(SpringRunner.class)
public class MortgageSettlementAmountServiceImplTest {
    public static final String MOCK_ACCOUNT_ID = "144a38f3-a7b3-a3aa-d656-ff98fbaaa565";
    @Mock
    private MortgageSettlementAmountRestClient mortgageSettlementAmountRestClient;



    private MortgageRedemptionHelper mortgageRedemptionHelper = new MortgageRedemptionHelper();

    @Before
    public void setup() {
        mortgageSettlementAmountRestClient = mock(MortgageSettlementAmountRestClient.class);
    }

    @Test
    public void get_settlement_amount_success(){
        MortgageSettlementAmountService mortgageSettlementAmountService = new MortgageSettlementAmountServiceImpl(mortgageSettlementAmountRestClient);
        SettlementAmountInfo settlementAmountInfo = mortgageRedemptionHelper.settlementAmountInfoResponse();

        when(mortgageSettlementAmountRestClient.getSettlementAmountInfo(anyString(),anyString(),anyMap()))
                .thenReturn(settlementAmountInfo);

        MortgageSettlementAmountResponse mortgageSettlementAmountResponse =
                mortgageSettlementAmountService.getSettlementAmount(mortgageRedemptionHelper.settlementAmountRequest(),
                        MOCK_ACCOUNT_ID,new HashMap<>());

        assertEquals("1b69ad2f-63b3-c70f-6f52-ee85b97e314d", mortgageSettlementAmountResponse.getMortgageSettlementAmount().getMortgageAggregatedSettlementAmount().getAccountId());
        assertEquals("4.00", mortgageSettlementAmountResponse.getMortgageSettlementAmount().getMortgageAggregatedSettlementAmount().getTotalSettlementAmount());
        assertEquals("GBP", mortgageSettlementAmountResponse.getMortgageSettlementAmount().getCurrency());
//        assertEquals(2, mortgageSettlementAmountResponse.getMortgageSettlementAmount().getMortgageSubAccountsSettlementAmountList().size());
 }

    @Test(expected = MortgageServiceException.class)
    public void get_settlement_amount_success_returns_null() {
        MortgageSettlementAmountService mortgageSettlementAmountService =
                new MortgageSettlementAmountServiceImpl(mortgageSettlementAmountRestClient);
        SettlementAmountInfo settlementAmountInfo = mortgageRedemptionHelper.settlementAmountInfoResponse();

        when(mortgageSettlementAmountRestClient.getSettlementAmountInfo(anyString(), anyString(), anyMap()))
                .thenReturn(null);

        MortgageSettlementAmountResponse mortgageSettlementAmountResponse =
                mortgageSettlementAmountService.getSettlementAmount(mortgageRedemptionHelper.settlementAmountRequest(),
                MOCK_ACCOUNT_ID, new HashMap<>());

    }

    @Test(expected = MortgageServiceException.class)
    public void get_settlement_amount_success_restClient_exception() {
        MortgageSettlementAmountService mortgageSettlementAmountService =
                new MortgageSettlementAmountServiceImpl(mortgageSettlementAmountRestClient);
        SettlementAmountInfo settlementAmountInfo = mortgageRedemptionHelper.settlementAmountInfoResponse();

        when(mortgageSettlementAmountRestClient.getSettlementAmountInfo(anyString(), anyString(), anyMap()))
                .thenThrow(new MortgageServiceException("SettlementAmount","Error"));

        MortgageSettlementAmountResponse mortgageSettlementAmountResponse =
                mortgageSettlementAmountService.getSettlementAmount(mortgageRedemptionHelper.settlementAmountRequest(),
                        MOCK_ACCOUNT_ID, new HashMap<>());

    }

    @Test(expected = CircuitBreakerOpenException.class)
    public void get_settlement_amount_fallback() {
        MortgageSettlementAmountServiceImpl mortgageSettlementAmountService = new MortgageSettlementAmountServiceImpl(mortgageSettlementAmountRestClient);
        mortgageSettlementAmountService.fallbackGetSettlementAmount(mortgageRedemptionHelper.settlementAmountRequest(),
                MOCK_ACCOUNT_ID,new HashMap<>(),
                new Exception("Circuit open on update account options"));

    }

}
