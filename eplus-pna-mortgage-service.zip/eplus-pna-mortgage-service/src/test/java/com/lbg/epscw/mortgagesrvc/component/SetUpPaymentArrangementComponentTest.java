package com.lbg.epscw.mortgagesrvc.component;
import com.lbg.epscw.entitlement.service.EntitlementValidationServiceImpl;
import com.lbg.epscw.handler.model.ErrorInfo;
import com.lbg.epscw.handler.model.ErrorResponse;
import com.lbg.epscw.mortgagesrvc.helper.ComponentHelper;
import com.lbg.epscw.mortgagesrvc.helper.SetupMortgageHelper;
import com.lbg.epscw.mortgagesrvc.logger.HystrixContextCopyStrategy;
import com.lbg.epscw.mortgagesrvc.model.PaymentArrangementRequest;
import com.lbg.epscw.mortgagesrvc.model.PaymentArrangementResponse;
import com.lbg.epscw.mortgagesrvc.service.RestClientService;
import org.apache.commons.lang.RandomStringUtils;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.context.ApplicationContext;
import org.springframework.http.HttpHeaders;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import java.util.HashMap;

import static org.junit.Assert.assertEquals;
import static org.junit.jupiter.api.Assertions.assertAll;
import static org.mockito.ArgumentMatchers.any;
import static org.powermock.api.mockito.PowerMockito.when;

@Tag("component")
@ExtendWith(SpringExtension.class)
@SpringBootTest
@AutoConfigureMockMvc
public class SetUpPaymentArrangementComponentTest extends WebMVCTest {

    @MockBean
    RestClientService restClientService;

    @MockBean
    private EntitlementValidationServiceImpl entitlementValidationService;

    @Autowired
    private ApplicationContext context;

    @MockBean
    private HystrixContextCopyStrategy hystrixContextCopyStrategy;

    private static final String SET_UP_PAYMENTARRANGEMENT_OPTIONS ="/mortgages/1601d0e5-e336-64d9-64ad-89ba6fdc2677/paymentarrangement";

    private ComponentHelper componentHelper = new ComponentHelper();

    private SetupMortgageHelper setupMortgageHelper = new SetupMortgageHelper();

    @Test
    public void shouldSetUpPaymentArrangementOptions() {
        //given
        PaymentArrangementRequest paymentArrangementRequest = setupMortgageHelper.paymentArrangementRequest();
        String payload = componentHelper.writeValueAsString(paymentArrangementRequest);

        when(restClientService.get(any(String.class), any(HashMap.class)))
                .thenReturn(setupMortgageHelper.getMortgageQueryServiceResponse());
        when(restClientService.post(any(String.class), any(HashMap.class), any(String.class)))
                .thenReturn(setupMortgageHelper.getVaultResponse());

        //when
        MockHttpServletResponse servletResponse = doPOST(SET_UP_PAYMENTARRANGEMENT_OPTIONS,
                payload,
                setupMortgageHelper.getAccountInfoHeaders());
        String responseString = componentHelper.getServletResponseAsString(servletResponse);
        PaymentArrangementResponse response = (PaymentArrangementResponse) readObject(responseString, PaymentArrangementResponse.class);

        //then
        assertAll(
                () -> assertEquals("1601d0e5-e336-64d9-64ad-89ba6fdc2677", response.getAccountId()),
                () -> assertEquals("ACCOUNT_UPDATE_STATUS_PENDING_EXECUTION", response.getStatus())

        );
    }

    @Test
    public void shouldReturnErrorForUpdateWhenDateIsNull() {
        //given
        PaymentArrangementRequest paymentArrangementRequest = setupMortgageHelper.paymentArrangementRequest();
        paymentArrangementRequest.setPaymentArrangementStartMonth(null);
        String payload = componentHelper.writeValueAsString(paymentArrangementRequest);


        //when
        MockHttpServletResponse servletResponse = doPOST(SET_UP_PAYMENTARRANGEMENT_OPTIONS,
                payload,
                setupMortgageHelper.getAccountInfoHeaders());
        String responseString = componentHelper.getServletResponseAsString(servletResponse);
        ErrorResponse errorResponse = (ErrorResponse) readObject(responseString, ErrorResponse.class);
        ErrorInfo errorInfo = errorResponse.getErrors().get(0);

        //then
        assertAll(
                () -> assertEquals(400, servletResponse.getStatus()),
                () -> assertEquals("PNA.MORTGAGE_API.SYS.001", errorResponse.getCode()),
                () -> assertEquals("Bad Request", errorResponse.getMessage()),
                () -> assertEquals("PNA.MORTGAGE_API.POST_MORTGAGES_PAYMENTARRANGEMENT.Argument.Invalid", errorInfo.getReasonCode())

        );

    }

    @Test
    public void shouldReturnErrorForUpdateWhenAmountIsNullOREmpty() {
        //given
        PaymentArrangementRequest paymentArrangementRequest = setupMortgageHelper.paymentArrangementRequest();
        paymentArrangementRequest.setPaymentArrangementAmount("");
        String payload = componentHelper.writeValueAsString(paymentArrangementRequest);


        //when
        MockHttpServletResponse servletResponse = doPOST(SET_UP_PAYMENTARRANGEMENT_OPTIONS,
                payload,
                setupMortgageHelper.getAccountInfoHeaders());
        String responseString = componentHelper.getServletResponseAsString(servletResponse);
        ErrorResponse errorResponse = (ErrorResponse) readObject(responseString, ErrorResponse.class);
        ErrorInfo errorInfo = errorResponse.getErrors().get(0);

        //then
        assertAll(
                () -> assertEquals(400, servletResponse.getStatus()),
                () -> assertEquals("PNA.MORTGAGE_API.SYS.001", errorResponse.getCode()),
                () -> assertEquals("Bad Request", errorResponse.getMessage()),
                () -> assertEquals("PaymentArrangementAmount cannot be empty", errorInfo.getMessage())

        );

    }
    @Test
    public void shouldReturnErrorForUpdateWhenPaymentArrangementTypeIsInvalid() {
        //given
        PaymentArrangementRequest paymentArrangementRequest = setupMortgageHelper.paymentArrangementRequest();
        paymentArrangementRequest.setPaymentArrangementAmountType("abc");
        String payload = componentHelper.writeValueAsString(paymentArrangementRequest);


        //when
        MockHttpServletResponse servletResponse = doPOST(SET_UP_PAYMENTARRANGEMENT_OPTIONS,
                payload,
                setupMortgageHelper.getAccountInfoHeaders());
        String responseString = componentHelper.getServletResponseAsString(servletResponse);
        ErrorResponse errorResponse = (ErrorResponse) readObject(responseString, ErrorResponse.class);
        ErrorInfo errorInfo = errorResponse.getErrors().get(0);

        //then
        assertAll(
                () -> assertEquals(400, servletResponse.getStatus()),
                () -> assertEquals("PNA.MORTGAGE_API.SYS.001", errorResponse.getCode()),
                () -> assertEquals("Bad Request", errorResponse.getMessage()),
                () -> assertEquals("PNA.MORTGAGE_API.POST_MORTGAGES_PAYMENTARRANGEMENT.Argument.Invalid", errorInfo.getReasonCode()),
                () -> assertEquals("PaymentArrangementAmountType is not a valid paymentArrangementAmountType", errorInfo.getMessage())


        );

    }

    @Test
    public void shouldReturnErrorForUpdateWhenAccountIdIsMoreThan36Chars() {
        //given
        PaymentArrangementRequest paymentArrangementRequest = setupMortgageHelper.paymentArrangementRequest();
        String payload = componentHelper.writeValueAsString(paymentArrangementRequest);

        //when
        MockHttpServletResponse servletResponse = doPOST("/mortgages/"+RandomStringUtils.random(50)+"/paymentarrangement",
                payload,
                setupMortgageHelper.getAccountInfoHeaders());
        String responseString = componentHelper.getServletResponseAsString(servletResponse);
        ErrorResponse errorResponse = (ErrorResponse) readObject(responseString, ErrorResponse.class);
        ErrorInfo errorInfo = errorResponse.getErrors().get(0);

        //then
        assertAll(
                () -> assertEquals(400, servletResponse.getStatus()),
                () -> assertEquals("PNA.MORTGAGE_API.SYS.001", errorResponse.getCode()),
                () -> assertEquals("Bad Request", errorResponse.getMessage()),
                () -> assertEquals("AccountId should be max 36 characters", errorInfo.getMessage())
        );
    }

    @Test
    public void shouldReturnErrorForUpdateWhenAccountIdIsLessThan36Chars() {
        //given
        PaymentArrangementRequest paymentArrangementRequest = setupMortgageHelper.paymentArrangementRequest();
        String payload = componentHelper.writeValueAsString(paymentArrangementRequest);

        //when
        MockHttpServletResponse servletResponse = doPOST("/mortgages/"+RandomStringUtils.random(5)+"/paymentarrangement",
                payload,
                setupMortgageHelper.getAccountInfoHeaders());
        String responseString = componentHelper.getServletResponseAsString(servletResponse);
        ErrorResponse errorResponse = (ErrorResponse) readObject(responseString, ErrorResponse.class);
        ErrorInfo errorInfo = errorResponse.getErrors().get(0);

        //then
        assertAll(
                () -> assertEquals(400, servletResponse.getStatus()),
                () -> assertEquals("PNA.MORTGAGE_API.SYS.001", errorResponse.getCode()),
                () -> assertEquals("Bad Request", errorResponse.getMessage()),
                () -> assertEquals("AccountId should be min 36 characters", errorInfo.getMessage())
        );
    }

    @Test
    public void shouldReturnErrorForUpdateWhenCorrelationIdIsGreaterThanFortyCharacters() {
        //given
        PaymentArrangementRequest paymentArrangementRequest = setupMortgageHelper.paymentArrangementRequest();
        String payload = componentHelper.writeValueAsString(paymentArrangementRequest);
        HttpHeaders accountInfoHeaders = setupMortgageHelper.getAccountInfoHeaders();
        accountInfoHeaders.set("x-lbg-txn-correlation-id", RandomStringUtils.random(50));
        //when
        MockHttpServletResponse servletResponse = doPOST(SET_UP_PAYMENTARRANGEMENT_OPTIONS,
                payload,
                accountInfoHeaders);
        String responseString = componentHelper.getServletResponseAsString(servletResponse);
        ErrorResponse errorResponse = (ErrorResponse) readObject(responseString, ErrorResponse.class);
        ErrorInfo errorInfo = errorResponse.getErrors().get(0);

        //then
        assertAll(
                () -> assertEquals(400, servletResponse.getStatus()),
                () -> assertEquals("PNA.MORTGAGE_API.SYS.001", errorResponse.getCode()),
                () -> assertEquals("Bad Request", errorResponse.getMessage()),
                () -> assertEquals("x-lbg-txn-correlation-id size should be between 10 and 40", errorInfo.getMessage())
        );
    }

    @Test
    public void shouldReturnErrorForUpdateWhenCorrelationIdIsLessThanTenCharacters() {
        //given
        PaymentArrangementRequest paymentArrangementRequest = setupMortgageHelper.paymentArrangementRequest();
        String payload = componentHelper.writeValueAsString(paymentArrangementRequest);
        HttpHeaders accountInfoHeaders = setupMortgageHelper.getAccountInfoHeaders();
        accountInfoHeaders.set("x-lbg-txn-correlation-id", RandomStringUtils.random(9));
        //when
        MockHttpServletResponse servletResponse = doPOST(SET_UP_PAYMENTARRANGEMENT_OPTIONS,
                payload,
                accountInfoHeaders);
        String responseString = componentHelper.getServletResponseAsString(servletResponse);
        ErrorResponse errorResponse = (ErrorResponse) readObject(responseString, ErrorResponse.class);
        ErrorInfo errorInfo = errorResponse.getErrors().get(0);

        //then
        assertAll(
                () -> assertEquals(400, servletResponse.getStatus()),
                () -> assertEquals("PNA.MORTGAGE_API.SYS.001", errorResponse.getCode()),
                () -> assertEquals("Bad Request", errorResponse.getMessage()),
                () -> assertEquals("x-lbg-txn-correlation-id size should be between 10 and 40", errorInfo.getMessage())
        );
    }

    @Test
    public void shouldReturnErrorForUpdateWhenCorrelationIdIsMissing() {
        //given
        PaymentArrangementRequest paymentArrangementRequest = setupMortgageHelper.paymentArrangementRequest();
        String payload = componentHelper.writeValueAsString(paymentArrangementRequest);
        HttpHeaders accountInfoHeaders = setupMortgageHelper.getAccountInfoHeaders();
        accountInfoHeaders.remove("x-lbg-txn-correlation-id");
        //when
        MockHttpServletResponse servletResponse = doPOST(SET_UP_PAYMENTARRANGEMENT_OPTIONS,
                payload,
                accountInfoHeaders);
        String responseString = componentHelper.getServletResponseAsString(servletResponse);
        ErrorResponse errorResponse = (ErrorResponse) readObject(responseString, ErrorResponse.class);
        ErrorInfo errorInfo = errorResponse.getErrors().get(0);

        //then
        assertAll(
                () -> assertEquals(400, servletResponse.getStatus()),
                () -> assertEquals("PNA.MORTGAGE_API.SYS.001", errorResponse.getCode()),
                () -> assertEquals("Bad Request", errorResponse.getMessage()),
                () -> assertEquals("Missing request header x-lbg-txn-correlation-id for method parameter of type String", errorInfo.getMessage())
        );
    }

    @Test
    public void shouldReturnErrorForUpdateWhenBrandIsIncorrect() {
        //given
        PaymentArrangementRequest paymentArrangementRequest = setupMortgageHelper.paymentArrangementRequest();
        String payload = componentHelper.writeValueAsString(paymentArrangementRequest);
        HttpHeaders accountInfoHeaders = setupMortgageHelper.getAccountInfoHeaders();
        accountInfoHeaders.set("x-lbg-brand", "xxx");
        //when
        MockHttpServletResponse servletResponse = doPOST(SET_UP_PAYMENTARRANGEMENT_OPTIONS,
                payload,
                accountInfoHeaders);
        String responseString = componentHelper.getServletResponseAsString(servletResponse);
        ErrorResponse errorResponse = (ErrorResponse) readObject(responseString, ErrorResponse.class);
        ErrorInfo errorInfo = errorResponse.getErrors().get(0);

        //then
        assertAll(
                () -> assertEquals(400, servletResponse.getStatus()),
                () -> assertEquals("PNA.MORTGAGE_API.SYS.001", errorResponse.getCode()),
                () -> assertEquals("Bad Request", errorResponse.getMessage()),
                () -> assertEquals("Invalid enum value for type x-lbg-brand", errorInfo.getMessage())
        );
    }

    @Test
    public void shouldReturnErrorForUpdateWhenBrandIsMissing() {
        //given
        PaymentArrangementRequest paymentArrangementRequest = setupMortgageHelper.paymentArrangementRequest();
        String payload = componentHelper.writeValueAsString(paymentArrangementRequest);
        HttpHeaders accountInfoHeaders = setupMortgageHelper.getAccountInfoHeaders();
        accountInfoHeaders.remove("x-lbg-brand");
        //when
        MockHttpServletResponse servletResponse = doPOST(SET_UP_PAYMENTARRANGEMENT_OPTIONS,
                payload,
                accountInfoHeaders);
        String responseString = componentHelper.getServletResponseAsString(servletResponse);
        ErrorResponse errorResponse = (ErrorResponse) readObject(responseString, ErrorResponse.class);
        ErrorInfo errorInfo = errorResponse.getErrors().get(0);

        //then
        assertAll(
                () -> assertEquals(400, servletResponse.getStatus()),
                () -> assertEquals("PNA.MORTGAGE_API.SYS.001", errorResponse.getCode()),
                () -> assertEquals("Bad Request", errorResponse.getMessage()),
                () -> assertEquals("Missing request header 'x-lbg-brand' for method parameter of type String", errorInfo.getMessage())
        );
    }

    @Test
    public void shouldReturnErrorForEmptyJson() {
        //given
        //when
        MockHttpServletResponse servletResponse = doPOST(SET_UP_PAYMENTARRANGEMENT_OPTIONS,
                "{}",
                setupMortgageHelper.getAccountInfoHeaders());
        String responseString = componentHelper.getServletResponseAsString(servletResponse);
        ErrorResponse errorResponse = (ErrorResponse) readObject(responseString, ErrorResponse.class);
        ErrorInfo errorInfo = errorResponse.getErrors().get(0);

        //then
        assertAll(
                () -> assertEquals(400, servletResponse.getStatus()),
                () -> assertEquals("PNA.MORTGAGE_API.SYS.001", errorResponse.getCode()),
                () -> assertEquals("Bad Request", errorResponse.getMessage())

        );
    }

    @Test
    public void shouldReturnErrorForEmptyRequestBody() {
        //given
        //when
        MockHttpServletResponse servletResponse = doPOST(SET_UP_PAYMENTARRANGEMENT_OPTIONS,
                "",
                setupMortgageHelper.getAccountInfoHeaders());
        String responseString = componentHelper.getServletResponseAsString(servletResponse);
        ErrorResponse errorResponse = (ErrorResponse) readObject(responseString, ErrorResponse.class);
        ErrorInfo errorInfo = errorResponse.getErrors().get(0);

        //then
        assertAll(
                () -> assertEquals(400, servletResponse.getStatus()),
                () -> assertEquals("PNA.MORTGAGE_API.SYS.001", errorResponse.getCode()),
                () -> assertEquals("Bad Request", errorResponse.getMessage())

        );
    }





}
