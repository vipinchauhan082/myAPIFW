package com.lbg.epscw.mortgagesrvc.controller;

import com.lbg.epscw.mortgagesrvc.constants.CommonConstants;
import com.lbg.epscw.mortgagesrvc.exception.InvalidUpdateRequestException;
import com.lbg.epscw.mortgagesrvc.exception.MortgageServiceException;
import com.lbg.epscw.mortgagesrvc.exception.MortgageValidationException;
import com.lbg.epscw.mortgagesrvc.helper.MortgagePortingApplicationHelper;
import com.lbg.epscw.mortgagesrvc.helper.MortgagePortingHelper;
import com.lbg.epscw.mortgagesrvc.model.AccountPortingStatusResponse;
import com.lbg.epscw.mortgagesrvc.model.AccountStatus;
import com.lbg.epscw.mortgagesrvc.model.AccountStatusUpdateRequest;
import com.lbg.epscw.mortgagesrvc.model.Channel;
import com.lbg.epscw.mortgagesrvc.restclient.MortgagePortingApplicationInfoRestClient;
import com.lbg.epscw.mortgagesrvc.service.MortgagePortingService;
import com.lbg.epscw.mortgagesrvc.util.MortgageServiceUtil;
import com.lbg.epscw.mortgagesrvc.validator.MortgagePortingApplicationValidator;
import com.lbg.epscw.mortgagesrvc.validator.MortgagePortingValidator;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static com.lbg.epscw.mortgagesrvc.constants.CommonConstants.INVALID_BORROWING_AMOUNT;
import static com.lbg.epscw.mortgagesrvc.constants.CommonConstants.MORTGAGE_SUBMIT_APPLICATION;
import static org.junit.Assert.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.powermock.api.mockito.PowerMockito.*;

@RunWith(SpringRunner.class)
@WebMvcTest(controllers = { MortgageServiceUtil.class, MortgagePortingController.class })
public class MortgagePortingControllerTest {

    @MockBean
    private MortgagePortingValidator mortgagePortingValidator;

    @MockBean
    private MortgagePortingService mortgagePortingService;

    @Autowired
    private MortgagePortingController mortgagePortingController;

    @MockBean
    private MortgagePortingApplicationValidator mortgagePortingApplicationValidator;

    @MockBean
    MortgagePortingApplicationInfoRestClient mortgagePortingApplicationInfoRestClient;

    private MortgagePortingHelper mortgagePortingHelper = new MortgagePortingHelper();

    private MortgagePortingApplicationHelper mortgagePortingApplicationHelper = new MortgagePortingApplicationHelper();
    @Test
    public void change_account_status_of_newly_ported_mortgage_successfully() {
        //given
        when(mortgagePortingValidator.validateAccountStatus(any(AccountStatusUpdateRequest.class),any(Map.class))).thenReturn(new ArrayList());
        when(mortgagePortingService.updateMortgageAccountStatus(any(AccountStatusUpdateRequest.class), any()))
                .thenReturn(mortgagePortingHelper.buildAccountStatusUpdateListResponse());

        AccountStatusUpdateRequest accountStatusUpdateRequest = mortgagePortingHelper.buildAccountStatusUpdateRequestWithOnlyOverarchingAndCancelStatus();
        //when
        ResponseEntity<List<AccountPortingStatusResponse>> responseEntity = mortgagePortingController
                .mortgageAccountStatusUpdate("IF", Channel.DIGITAL.name(), "123-456-789-12", "Bearer 122", "ALL", new HashMap<String, String>(),
                        accountStatusUpdateRequest);
        List<AccountPortingStatusResponse> accountPortingStatusResponseList = responseEntity.getBody();

        //then
        assertEquals("b2c9119f-09e5-4ac9-9738-9e28b334d3fa", accountPortingStatusResponseList.get(0).getAccountId());
        assertEquals(AccountStatus.ACCOUNT_STATUS_OPEN.name(), accountPortingStatusResponseList.get(0).getStatus());
    }

    @Test(expected = InvalidUpdateRequestException.class)
    public void change_account_status_of_newly_ported_mortgage_throws_exception_when_validation_fails() {
        //given
        doThrow(new InvalidUpdateRequestException(CommonConstants.STATUS, CommonConstants.INVALID)).
                when(mortgagePortingValidator).validateAccountStatus(any(AccountStatusUpdateRequest.class),any(Map.class));
        AccountStatusUpdateRequest accountStatusUpdateRequest = mortgagePortingHelper.buildAccountStatusUpdateRequestWithOnlyOverarchingAndCancelStatus();

        //when
        mortgagePortingController
                .mortgageAccountStatusUpdate("IF",Channel.DIGITAL.name(), "123-456-789-12", "Bearer 122", "ALL", new HashMap<String, String>(),
                        accountStatusUpdateRequest);

    }

    @Test(expected = MortgageServiceException.class)
    public void change_account_status_of_newly_ported_mortgage_fails_when_service_returns_null_response() {
        //given
        when(mortgagePortingValidator.validateAccountStatus(any(AccountStatusUpdateRequest.class),any(Map.class))).thenReturn(new ArrayList());
        when(mortgagePortingService.updateMortgageAccountStatus(any(AccountStatusUpdateRequest.class), any()))
                .thenReturn(null);
        AccountStatusUpdateRequest accountStatusUpdateRequest = mortgagePortingHelper.buildAccountStatusUpdateRequestWithOnlyOverarchingAndCancelStatus();

        //when
        mortgagePortingController
                .mortgageAccountStatusUpdate("IF",Channel.DIGITAL.name(), "123-456-789-12", "Bearer 122", "ALL", new HashMap<String, String>(),
                        accountStatusUpdateRequest);

    }
}