package com.lbg.epscw.mortgagesrvc.service;

import com.lbg.epscw.mortgagesrvc.exception.CircuitBreakerOpenException;
import com.lbg.epscw.mortgagesrvc.exception.MortgageServiceException;
import com.lbg.epscw.mortgagesrvc.model.Asset;
import com.lbg.epscw.mortgagesrvc.model.MortgageApplicationInfo;
import com.lbg.epscw.mortgagesrvc.model.PortingApplicationStatusResponse;
import com.lbg.epscw.mortgagesrvc.model.SolicitorDocReceivedRequest;
import com.lbg.epscw.mortgagesrvc.restclient.MortgagePortingApplicationAssetRestClient;
import com.lbg.epscw.mortgagesrvc.restclient.MortgagePortingApplicationInfoRestClient;
import org.junit.Before;
import org.junit.Test;
import org.mockito.ArgumentCaptor;

import java.time.LocalDate;

import static com.lbg.epscw.mortgagesrvc.helper.MortgagePortingHelper.*;
import static com.lbg.epscw.mortgagesrvc.model.MortgagePortingApplicationStatus.SOLICITOR_DOC_RECEIVED;
import static java.time.LocalDate.now;
import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.*;

public class MortgagePortingSolicitorDocReceivedServiceImplTest {
    private MortgagePortingApplicationInfoRestClient applicationClient;
    private MortgagePortingApplicationAssetRestClient assetRestClient;
    private MortgagePortingSolicitorDocReceivedServiceImpl underTest;

    @Before
    public void setup() {
        applicationClient = mock(MortgagePortingApplicationInfoRestClient.class);
        assetRestClient = mock(MortgagePortingApplicationAssetRestClient.class);
        underTest = new MortgagePortingSolicitorDocReceivedServiceImpl(applicationClient, assetRestClient);
    }


    @Test
    public void update_application_status_success() {
        // Given
        LocalDate completionDate = now();
        MortgageApplicationInfo applicationInfo = MortgageApplicationInfo.builder().applicationNumber(APPLICATION_NUMBER).completionDate(completionDate).solicitorDocReceivedDate(now()).status(SOLICITOR_DOC_RECEIVED).build();
        when(applicationClient.updateApplication(anyString(), any())).thenReturn(applicationInfo);
        when(assetRestClient.getAssetByApplication(anyString())).thenReturn(Asset.builder().assetId(ASSET_NUMBER).applicationId(APPLICATION_NUMBER).titleDeed(TITLE_DEED_NUMBER).build());
        when(assetRestClient.updateAsset(anyString(), any())).thenReturn(Asset.builder().applicationId(APPLICATION_NUMBER).titleDeed(TITLE_DEED_NUMBER).build());
        SolicitorDocReceivedRequest request = SolicitorDocReceivedRequest.builder().titleDeedNumber(TITLE_DEED_NUMBER).completionDate(completionDate).build();
        // When
        PortingApplicationStatusResponse actual = underTest.solicitorDocReceived(MortgageApplicationInfo.builder().applicationNumber(APPLICATION_NUMBER).status(SOLICITOR_DOC_RECEIVED).build(), request);

        // Then
        ArgumentCaptor<MortgageApplicationInfo> applicationCaptor = ArgumentCaptor.forClass(MortgageApplicationInfo.class);
        verify(applicationClient).updateApplication(anyString(), applicationCaptor.capture());
        ArgumentCaptor<Asset> assetCaptor = ArgumentCaptor.forClass(Asset.class);
        verify(assetRestClient).updateAsset(anyString(), assetCaptor.capture());

        assertThat(actual, is(PortingApplicationStatusResponse.builder().applicationNumber(APPLICATION_NUMBER).status(SOLICITOR_DOC_RECEIVED).build()));
        MortgageApplicationInfo actualApplication = applicationCaptor.getValue();
        assertThat(actualApplication.getStatus(), is(SOLICITOR_DOC_RECEIVED));

        Asset actualAsset = assetCaptor.getValue();
        assertThat(actualAsset.getApplicationId(), is(APPLICATION_NUMBER));
        assertThat(actualAsset.getTitleDeed(), is(TITLE_DEED_NUMBER));
    }

    @Test(expected = MortgageServiceException.class)
    public void throw_service_exception_when_application_not_updated() {
        // Given
        MortgageApplicationInfo applicationInfo = MortgageApplicationInfo.builder().status(null).build();
        SolicitorDocReceivedRequest request = SolicitorDocReceivedRequest.builder().build();
        when(applicationClient.updateApplication(anyString(), any())).thenReturn(applicationInfo);

        // When
        underTest.solicitorDocReceived(MortgageApplicationInfo.builder().applicationNumber(APPLICATION_NUMBER).status(SOLICITOR_DOC_RECEIVED).build(), request);

        // Then expect exception
    }

    @Test(expected = MortgageServiceException.class)
    public void throw_service_exception_when_asset_not_updated() {
        // Given
        LocalDate completionDate = now();
        MortgageApplicationInfo applicationInfo = MortgageApplicationInfo.builder().applicationNumber(APPLICATION_NUMBER).completionDate(completionDate).solicitorDocReceivedDate(now()).status(SOLICITOR_DOC_RECEIVED).build();
        when(applicationClient.updateApplication(anyString(), any())).thenReturn(applicationInfo);
        when(assetRestClient.getAssetByApplication(anyString())).thenReturn(Asset.builder().assetId(ASSET_NUMBER).applicationId(APPLICATION_NUMBER).titleDeed(TITLE_DEED_NUMBER).build());
        when(assetRestClient.updateAsset(anyString(), any())).thenReturn(Asset.builder().titleDeed(null).build());

        SolicitorDocReceivedRequest request = SolicitorDocReceivedRequest.builder().titleDeedNumber(TITLE_DEED_NUMBER).build();

        // When
        underTest.solicitorDocReceived(MortgageApplicationInfo.builder().applicationNumber(APPLICATION_NUMBER).status(SOLICITOR_DOC_RECEIVED).build(), request);

        // Then expect exception
    }

    @Test(expected = MortgageServiceException.class)
    public void throw_service_exception_when_asset_not_found() {
        // Given
        LocalDate completionDate = now();
        MortgageApplicationInfo applicationInfo = MortgageApplicationInfo.builder().applicationNumber(APPLICATION_NUMBER).completionDate(completionDate).solicitorDocReceivedDate(now()).status(SOLICITOR_DOC_RECEIVED).build();
        when(applicationClient.updateApplication(anyString(), any())).thenReturn(applicationInfo);
        when(assetRestClient.getAssetByApplication(anyString())).thenReturn(Asset.builder().assetId(ASSET_NUMBER).applicationId(APPLICATION_NUMBER).titleDeed(TITLE_DEED_NUMBER).build());
        when(assetRestClient.updateAsset(anyString(), any())).thenReturn(null);

        SolicitorDocReceivedRequest request = SolicitorDocReceivedRequest.builder().titleDeedNumber(TITLE_DEED_NUMBER).build();

        // When
        underTest.solicitorDocReceived(MortgageApplicationInfo.builder().applicationNumber(APPLICATION_NUMBER).status(SOLICITOR_DOC_RECEIVED).build(), request);

        // Then expect exception
    }

    @Test(expected = CircuitBreakerOpenException.class)
    public void update_status_fallback_throws_exception_on_broken_circuit() {
        MortgageApplicationInfo application = MortgageApplicationInfo.builder().build();
        SolicitorDocReceivedRequest request = SolicitorDocReceivedRequest.builder().build();
        underTest.fallbackApplicationSolicitorDocReceived(application, request, new IllegalArgumentException());
    }
}
