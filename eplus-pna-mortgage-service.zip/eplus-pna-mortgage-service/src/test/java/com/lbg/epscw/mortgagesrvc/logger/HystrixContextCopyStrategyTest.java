package com.lbg.epscw.mortgagesrvc.logger;

import org.junit.Test;

import java.util.concurrent.Callable;

import static org.junit.Assert.assertEquals;

public class HystrixContextCopyStrategyTest {
    
	@Test
    public void wrap_callable() throws Exception {
		//given
        Callable<String> callable = () -> "success";
        //when
        Callable<String> response = new HystrixContextCopyStrategy().wrapCallable(callable);
        //then
        assertEquals("success", response.call());
    }
}
