package com.lbg.epscw.mortgagesrvc.restclient;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.lbg.epscw.handler.exception.system.SystemBadRequestException;
import com.lbg.epscw.mortgagesrvc.exception.MortgageServiceException;
import com.lbg.epscw.mortgagesrvc.helper.MortgageAccountDataHelper;
import com.lbg.epscw.mortgagesrvc.model.MortgageTermReductionResponse;
import com.lbg.epscw.mortgagesrvc.service.RestClientService;
import com.lbg.epscw.mortgagesrvc.util.MortgageServiceUtil;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.internal.util.reflection.FieldSetter;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;

import java.text.MessageFormat;
import java.util.HashMap;

import static org.junit.Assert.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.powermock.api.mockito.PowerMockito.when;

@RunWith(PowerMockRunner.class)
@PrepareForTest({ MessageFormat.class })
public class MortgageTermReductionCalcRestClientTest {

    @Value("${mortgage.term.reduction.get.endpoint}")
    private String mortgageTermReductionGetEndpoint;

    @Mock
    RestClientService restClientService;

    @Mock
    MortgageServiceUtil mortgageServiceUtil;

    @Autowired
    private ObjectMapper mapper;

    private MortgageAccountDataHelper mortgageAccountDataHelper = new MortgageAccountDataHelper();

    @InjectMocks
    private MortgageTermReductionCalcRestClient mortgageTermReductionCalcRestClient;

    @Before
    public void setup() {
        this.mapper = new ObjectMapper();
    }

    @Test
    public void get_mortgage_term_reduction_info_by_accountId() throws JsonProcessingException, NoSuchFieldException, SecurityException {

        MortgageTermReductionResponse termRedInfo = mortgageAccountDataHelper.buildViewMortgageTermReductionResponse("22","18","6");
        FieldSetter.setField(mortgageTermReductionCalcRestClient,
                mortgageTermReductionCalcRestClient.getClass().getDeclaredField("mortgageTermReductionGetEndpoint"),"mortgageTermReductionGetEndpoint");

        String stringResponse = mapper.writeValueAsString(termRedInfo);
        when(mortgageServiceUtil.fetchDefaultVaultHeaders()).thenReturn(new HashMap<String, String>());
        when(mortgageServiceUtil.readObject(any(String.class), any(Class.class))).thenReturn(termRedInfo);
        when(restClientService.get(any(String.class), any(HashMap.class))).thenReturn(stringResponse);
        MortgageTermReductionResponse response = mortgageTermReductionCalcRestClient.getMortgageTermReductionInfo("1b69ad2f-63b3-c70f-6f52-ee85b97e314d", new HashMap<>());
        assertNotNull(response);
        assertEquals("1b69ad2f-63b3-c70f-6f52-ee85b97e314d", response.getAccountId());
    }

    @Test(expected= SystemBadRequestException.class)
    public void get_mortgage_term_reduction_info_by_accountId_not_found() throws JsonProcessingException, NoSuchFieldException, SecurityException {

        MortgageTermReductionResponse termRedInfo = mortgageAccountDataHelper.buildViewMortgageTermReductionResponse("22","18","6");
        FieldSetter.setField(mortgageTermReductionCalcRestClient,
                mortgageTermReductionCalcRestClient.getClass().getDeclaredField("mortgageTermReductionGetEndpoint"),"mortgageTermReductionGetEndpoint");

        when(mortgageServiceUtil.fetchDefaultVaultHeaders()).thenReturn(new HashMap<String, String>());
        when(mortgageServiceUtil.readObject(any(String.class), any(Class.class))).thenReturn(termRedInfo);

        when(restClientService.get(any(String.class), any(HashMap.class))).thenReturn(null);
        mortgageTermReductionCalcRestClient.getMortgageTermReductionInfo("1b69ad2f-63b3-c70f-6f52-ee85b97e314d", new HashMap<>());
    }
}
