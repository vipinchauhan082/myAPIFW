package com.lbg.epscw.mortgagesrvc.helper;

import com.lbg.epscw.mortgagesrvc.dto.MortgageAccountData;
import com.lbg.epscw.mortgagesrvc.dto.MortgageAccountInfo;
import com.lbg.epscw.mortgagesrvc.model.*;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class MortgagePaymentOptionHelper {

    public MortgagePaymentOptionRequest getMortgagePaymentRequest(){

        MortgagePaymentOptionRequest mortgagePaymentOptionRequest= new MortgagePaymentOptionRequest();
        mortgagePaymentOptionRequest.setOption("LOWER_PAYMENTS");
        Map<String,String> mortgagePaymentOption= new HashMap<>();
        mortgagePaymentOption.put("MortgagePaymentOption","LOWER_PAYMENTS");
        mortgagePaymentOptionRequest.setMortgagePaymentOption(mortgagePaymentOption);
        return mortgagePaymentOptionRequest;
    }

    public String getMortgageQueryServiceResponse() {
        return "{\n" +
                "    \"Data\": [\n" +
                "        {\n" +
                "            \"mortgageNumber\": \"number_1112\",\n" +
                "            \"mortgagePrincipal\": \"4000\",\n" +
                "            \"keyDate\": \"7\",\n" +
                "            \"mortgageType\": \"INTEREST_ONLY\",\n" +
                "            \"totalTerm\": \"24\",\n" +
                "            \"productId\": \"lbg_mortgage_repayment\",\n" +
                "            \"productFamily\": \"Mortgage Payment\",\n" +
                "            \"offSettingOption\": \"OFFSET_CREDIT_BALANCES\",\n" +
                "            \"accountId\": \"5a688301-6d00-485c-0242-1ee03844a5c4\"\n" +
                "        }\n" +

                "    ]\n" +
                "}";
    }

    public String getVaultResponse(){
        return "{\n" +
                "    \"id\": \"5a688301-6d10-485c-0242-1ee03844a5c4\",\n" +
                "    \"account_id\": \"5a688301-6d00-485c-0242-1ee03844a5c4\",\n" +
                "    \"status\": \"ACCOUNT_UPDATE_STATUS_PENDING_EXECUTION\",\n" +
                "    \"instance_param_vals_update\": {\n" +
                "        \"instance_param_vals\": {\n" +
                "            \"mortgage_payment_option\": \"LOWER_PAYMENTS\"\n" +
                "        }\n" +
                "    },\n" +
                "    \"create_timestamp\": \"2020-09-14T17:45:04.687675Z\",\n" +
                "    \"last_status_update_timestamp\": \"2020-09-14T17:45:04.687675Z\",\n" +
                "    \"account_update_batch_id\": \"\",\n" +
                "    \"failure_reason\": \"\"\n" +
                "}";
    }

    public HttpHeaders getAccountInfoHeaders() {
        HttpHeaders httpHeaders = new HttpHeaders();
        httpHeaders.add("Authorization", "Bearer b2c9119f-09e5-4ac9-9738-9e28b334d3fa");
        httpHeaders.add("x-lbg-internal-system-id", "test");
        httpHeaders.add("x-lbg-brand", "IF");
        httpHeaders.add("x-lbg-txn-correlation-id", "123-456-789-123");
        httpHeaders.setContentType(MediaType.APPLICATION_JSON);
        return httpHeaders;
    }

    public String getMortgageQueryServiceInvalidResponse() {
        return "{\n" +
                "    \"Data\": [\n" +
                "        {\n" +
                "            \"mortgageNumber\": \"number_1112\",\n" +
                "            \"mortgagePrincipal\": \"4000\",\n" +
                "            \"keyDate\": \"7\",\n" +
                "            \"mortgageType\": \"INTEREST_ONLY\",\n" +
                "            \"totalTerm\": \"24\",\n" +
                "            \"productId\": \"lbg_mortgage\",\n" +
                "            \"offSettingOption\": \"OFFSET_DEBIT_BALANCES\",\n" +
                "            \"accountId\": \"5a688301-6d00-485c-0242-1ee03844a5c4\"\n" +
                "        }\n" +

                "    ]\n" +
                "}";
    }

    public String getMortgageQueryServiceInvalidResponse2() {
        return "{\n" +
                "    \"Data\": [\n" +
                "        {\n" +
                "            \"mortgageNumber\": \"number_1112\",\n" +
                "            \"mortgagePrincipal\": \"4000\",\n" +
                "            \"keyDate\": \"7\",\n" +
                "            \"mortgageType\": \"INTEREST_ONLY\",\n" +
                "            \"totalTerm\": \"24\",\n" +
                "            \"productId\": \"lbg_mortgage_repayment\",\n" +
                "            \"productFamily\": \"Mortgage Payment\",\n" +
                "            \"offSettingOption\": \"OFFSET_DEBIT_BALANCES\",\n" +
                "            \"accountId\": \"5a688301-6d00-485c-0242-1ee03844a5c4\"\n" +
                "        }\n" +

                "    ]\n" +
                "}";
    }

    public Map<String,String> readObjectResponse(){
        Map<String,String> readObjectMap= new HashMap<>();
        readObjectMap.put("MortgagePaymentOption","LOWER_PAYMENTS");
        return readObjectMap;
    }

    public AccountOptionsUpdateResponse mock_AccountOptionsUpdateResponse(){

        AccountOptionsUpdateResponse accountOptionsUpdateResponse= new AccountOptionsUpdateResponse();
        accountOptionsUpdateResponse.setAccountId("5a688301-6d00-485c-0242-1ee03844a5c4");
        accountOptionsUpdateResponse.setStatus("ACCOUNT_UPDATE_STATUS_PENDING_EXECUTION");
        Map<String,String> offsettingOptions= new HashMap<>();
        offsettingOptions.put("mortgage_payment_option", "LOWER_PAYMENTS");
        InstanceParamValsUpdate instanceParamValsUpdate = new InstanceParamValsUpdate();
        instanceParamValsUpdate.setInstanceParamVals(offsettingOptions);
        accountOptionsUpdateResponse.setInstanceParamValsUpdate(instanceParamValsUpdate);
        return accountOptionsUpdateResponse;
    }

    public MortgageAccountInfo mortgageAccountInfo_mortgagePaymentOptionMock(){

        MortgageAccountInfo mortgageAccountInfo= new MortgageAccountInfo();
        List<MortgageAccountData> mortgageAccountDataList= new ArrayList<>();
        MortgageAccountData mortgageAccountData= new MortgageAccountData();
        mortgageAccountData.setAccountId("5a688301-6d00-485c-0242-1ee03844a5c4");
        mortgageAccountData.setProductId("lbg_mortgage");
        mortgageAccountData.setOffSettingOption("OFFSET_DEBIT_BALANCES");
        mortgageAccountData.setPaymentArrangementStartMonth("2019-11-21");
        mortgageAccountData.setPaymentArrangementAmountType("FIXED_OVERPAYMENT");
        mortgageAccountDataList.add(mortgageAccountData);
        mortgageAccountInfo.setMortgageAccountData(mortgageAccountDataList);
        return mortgageAccountInfo;
    }

    public MortgageAccountInfo mortgageAccountInfo_mortgagePaymentOptionMock2(){

        MortgageAccountInfo mortgageAccountInfo= new MortgageAccountInfo();
        List<MortgageAccountData> mortgageAccountDataList= new ArrayList<>();
        MortgageAccountData mortgageAccountData= new MortgageAccountData();
        mortgageAccountData.setAccountId("5a688301-6d00-485c-0242-1ee03844a5c4");
        mortgageAccountData.setProductId("lbg_mortgage_repayment");
        mortgageAccountData.setOffSettingOption("OFFSET_DEBIT_BALANCES");
        mortgageAccountData.setPaymentArrangementStartMonth("2019-11-21");
        mortgageAccountData.setPaymentArrangementAmountType("FIXED_OVERPAYMENT");
        mortgageAccountDataList.add(mortgageAccountData);
        mortgageAccountInfo.setMortgageAccountData(mortgageAccountDataList);
        return mortgageAccountInfo;
    }

    public MortgagePaymentOptionUpdateResponse mock_mortgagePaymentOptionUpdateResponse(){
        MortgagePaymentOptionUpdateResponse mortgagePaymentOptionUpdateResponse= new MortgagePaymentOptionUpdateResponse();
        mortgagePaymentOptionUpdateResponse.setStatus("ACCOUNT_UPDATE_STATUS_PENDING_EXECUTION");
        mortgagePaymentOptionUpdateResponse.setAccountId("5a688301-6d00-485c-0242-1ee03844a5c4");
        Map<String,String> mortgagePaymentOptions= new HashMap<>();
        mortgagePaymentOptions.put("MortgagePaymentOption","LOWER_PAYMENTS");
        mortgagePaymentOptionUpdateResponse.setInstanceParamVals(mortgagePaymentOptions);
        return mortgagePaymentOptionUpdateResponse;
    }

    public MortgageAccountInfo mortgageAccountInfo_withOffsetting(){

        MortgageAccountInfo mortgageAccountInfo= new MortgageAccountInfo();
        List<MortgageAccountData> mortgageAccountDataList= new ArrayList<>();
        MortgageAccountData mortgageAccountDataOne= new MortgageAccountData();
        mortgageAccountDataOne.setAccountId("6965d050-d8fd-7fc3-4b66-41e72168be27");
        mortgageAccountDataOne.setPaymentArrangementStartMonth("2019-11-21");
        mortgageAccountDataOne.setPaymentArrangementAmountType("FIXED_OVERPAYMENT");
        mortgageAccountDataOne.setOffSettingOption("OFFSET_CREDIT_BALANCES");
        mortgageAccountDataOne.setProductId("lbg_mortgage_repayment");
        mortgageAccountDataOne.setProductFamily("Mortgage Payment");
        mortgageAccountDataList.add(mortgageAccountDataOne);

        MortgageAccountData mortgageAccountDataTwo= new MortgageAccountData();
        mortgageAccountDataTwo.setAccountId("5a688301-6d00-485c-0242-1ee03844a5c4");
        mortgageAccountDataTwo.setPaymentArrangementStartMonth("2019-11-21");
        mortgageAccountDataTwo.setPaymentArrangementAmountType("FIXED_OVERPAYMENT");
        mortgageAccountDataTwo.setProductId("lbg_mortgage");
        mortgageAccountDataTwo.setProductFamily("Mortgage");
        mortgageAccountDataTwo.setStatus("ACCOUNT_STATUS_OPEN");
        mortgageAccountDataList.add(mortgageAccountDataTwo);

        mortgageAccountInfo.setMortgageAccountData(mortgageAccountDataList);
        return mortgageAccountInfo;
    }
}
