package com.lbg.epscw.mortgagesrvc.helper;

import com.lbg.epscw.mortgagesrvc.model.*;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;

import java.util.HashMap;
import java.util.Map;

public class MortgageCTLHelper {

    public MortgageCTLResponse buildAccountCtlResponse() {
        MortgageCTLResponse response = new MortgageCTLResponse();
        response.setAccountId("b2c9119f-09e5-4ac9-9738-9e28b334d3fa");
        response.setStatus("ACCOUNT_STATUS_PENDING_CLOSURE");
        Map<String, String> itemsToAdd = new HashMap<>();
        itemsToAdd.put(CTLOptions.CTL_INDICATOR.getInternalName(), "true");
        itemsToAdd.put(CTLOptions.CTL_START_DATE.getInternalName(), "20/12/2020");
        response.setDetails(itemsToAdd);
        return response;
    }

    public VaultMetadataOptionsResponse buildAccountCtlVaultResponse() {
        VaultMetadataOptionsResponse response = new VaultMetadataOptionsResponse();
        response.setAccountId("b2c9119f-09e5-4ac9-9738-9e28b334d3fa");
        response.setStatus("ACCOUNT_STATUS_OPEN");
        Map<String, String> itemsToAdd = new HashMap<>();
        itemsToAdd.put(CTLOptions.CTL_INDICATOR.getInternalName(), "true");
        itemsToAdd.put(CTLOptions.CTL_START_DATE.getInternalName(), "20/12/2020");
        response.setDetails(itemsToAdd);
        return response;
    }


    public VaultMetadataOptionsResponse buildAccountCtlVaultResponseWithFalseCTLIndicator() {
        VaultMetadataOptionsResponse response = new VaultMetadataOptionsResponse();
        response.setAccountId("b2c9119f-09e5-4ac9-9738-9e28b334d3fa");
        response.setStatus("ACCOUNT_STATUS_OPEN");
        Map<String, String> itemsToAdd = new HashMap<>();
        itemsToAdd.put(CTLOptions.CTL_INDICATOR.getInternalName(), "false");
        itemsToAdd.put(CTLOptions.CTL_START_DATE.getInternalName(), "20/12/2020");
        response.setDetails(itemsToAdd);
        return response;
    }

    public VaultMetadataOptionsResponse buildAccountCtlVaultResponseNoIndicator() {
        VaultMetadataOptionsResponse response = new VaultMetadataOptionsResponse();
        response.setAccountId("b2c9119f-09e5-4ac9-9738-9e28b334d3fa");
        response.setStatus("ACCOUNT_STATUS_PENDING_CLOSURE");
        Map<String, String> itemsToAdd = new HashMap<>();
        response.setDetails(itemsToAdd);
        return response;
    }

    public VaultMetadataOptionsRequest buildAddCtlVaultRequest() {
        VaultMetadataOptionsRequest vaultRequest = new VaultMetadataOptionsRequest();
        vaultRequest.setRequestId("1234");
        Map<String, String> itemsToAdd = new HashMap<>();
        itemsToAdd.put(CTLOptions.CTL_INDICATOR.getInternalName(), "true");
        itemsToAdd.put(CTLOptions.CTL_START_DATE.getInternalName(), "20/12/2020");
        vaultRequest.setItemsToAdd(itemsToAdd);
        return vaultRequest;
    }

    public HashMap getAccountInfoHeaders() {
        HashMap httpHeaders = new HashMap();
        httpHeaders.put("Authorization", "Bearer b2c9119f-09e5-4ac9-9738-9e28b334d3fa");
        httpHeaders.put("x-lbg-internal-system-id", "test");
        httpHeaders.put("x-lbg-brand", "IF");
        httpHeaders.put("x-lbg-txn-correlation-id", "123-456-789-123");
        httpHeaders.put("content-type", MediaType.APPLICATION_JSON);
        return httpHeaders;
    }

    public HttpHeaders updateCTLFlagHeaders() {
        HttpHeaders httpHeaders = new HttpHeaders();
        httpHeaders.add("Authorization", "Bearer b2c9119f-09e5-4ac9-9738-9e28b334d3fa");
        httpHeaders.add("x-lbg-brand", "IF");
        httpHeaders.add("x-lbg-txn-correlation-id", "123-456-789-123");
        httpHeaders.setContentType(MediaType.APPLICATION_JSON);
        return httpHeaders;
    }

    public MortgageCTLRequest buildCtlRequest() {
        MortgageCTLRequest request = new MortgageCTLRequest();
        request.setStartDate("12/03/2014");
        return request;
    }

    public String getAddResponseString() {
        return "{\"id\":\"36fc5476-7688-832a-08be-f26ef3216d28\",\n" +
                "\t\"name\":\"Mortgage Repayment Account\",\n" +
                "\t\"product_id\":\"lbg_mortgage_repayment\",\n" +
                "\t\"product_version_id\":\"457\",\n" +
                "\t\"permitted_denominations\":[\"GBP\"],\n" +
                "\t\"status\":\"ACCOUNT_STATUS_OPEN\",\n" +
                "\t\"opening_timestamp\":\"2020-12-07T07:31:13.852169Z\",\n" +
                "\t\"closing_timestamp\":null,\n" +
                "\t\"stakeholder_ids\":[\"6138822169052936777\"],\n" +
                "\t\"instance_param_vals\":{\"available_payment_methods\":\"\",\"mortgage_number\":\"mort_9sddfsd900\",\"mortgage_payment_option\":\"\",\"nominated_adhoc_overpayment_account\":\"\",\"offsetting_option\":\"\"},\n" +
                "\t\"derived_instance_param_vals\":{},\n" +
                "\t\"details\":{\"brand\":\"IF\",\"mortgage_number\":\"20\"},\n" +
                "\t\"accounting\":{\"tside\":\"TSIDE_LIABILITY\"}}";

    }

}
