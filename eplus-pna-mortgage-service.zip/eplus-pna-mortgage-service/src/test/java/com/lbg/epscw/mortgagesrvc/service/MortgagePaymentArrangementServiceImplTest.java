package com.lbg.epscw.mortgagesrvc.service;

import com.lbg.epscw.mortgagesrvc.exception.CircuitBreakerOpenException;
import com.lbg.epscw.mortgagesrvc.helper.SetupMortgageHelper;
import com.lbg.epscw.mortgagesrvc.model.*;
import com.lbg.epscw.mortgagesrvc.restclient.MortgageAccountOptionRestClient;
import com.lbg.epscw.mortgagesrvc.util.MortgageServiceUtil;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.HashMap;
import java.util.Map;

import static org.junit.Assert.assertNotNull;
import static org.mockito.ArgumentMatchers.any;
import static org.powermock.api.mockito.PowerMockito.mock;
import static org.powermock.api.mockito.PowerMockito.when;

@RunWith(SpringRunner.class)
public class MortgagePaymentArrangementServiceImplTest {

    @Mock
    private MortgageServiceUtil mortgageServiceUtil;

    @Mock
    private MortgageAccountOptionRestClient mortgageAccountOptionRestClient;
    private SetupMortgageHelper setupMortgageHelper = new SetupMortgageHelper();

    @Before
    public void setup() {
        mortgageAccountOptionRestClient = mock(MortgageAccountOptionRestClient.class);
        mortgageServiceUtil = mock(MortgageServiceUtil.class);
    }

    @Test
    public void setup_payment_arrangement_success() {

        MortgagePaymentArrangementService mortgagePaymentArrangementService = new MortgagePaymentArrangementServiceImpl(mortgageAccountOptionRestClient, mortgageServiceUtil);

        when(mortgageServiceUtil.writeObjectAsString(any(PaymentArrangementRequest.class))).thenReturn("tempString");

        Map<String, String> readObjectMap = setupMortgageHelper.readObjectResponse();

        when(mortgageServiceUtil.readObject(any(String.class), any())).thenReturn(readObjectMap);

        when(mortgageAccountOptionRestClient.updateAccountOptions(any(VaultAccountOptionsUpdateRequest.class))).thenReturn(setupMortgageHelper.mock_GeneralAccountOptionsUpdateResponse());

        PaymentArrangementResponse paymentArrangementResponse = mortgagePaymentArrangementService.setUpPaymentArrangement(setupMortgageHelper.paymentArrangementRequest(), "ceabb62f-ee67-85da-fb0d-00415c349f89");

        Map<String,String> instanceParams = new HashMap<>();
        instanceParams = paymentArrangementResponse.getInstanceParamVals();
        Assert.assertEquals("ceabb62f-ee67-85da-fb0d-00415c349f89", paymentArrangementResponse.getAccountId());
        Assert.assertEquals("11/2039", instanceParams.get("PaymentArrangementStartMonth"));
        Assert.assertEquals("12/2040", instanceParams.get("PaymentArrangementEndMonth"));
        Assert.assertEquals("OVERPAYMENT", instanceParams.get("PaymentArrangementType"));
        Assert.assertEquals("123.45", instanceParams.get("PaymentArrangementAmount"));
        Assert.assertEquals("FIXED_PAYMENT_AMOUNT", instanceParams.get("PaymentArrangementAmountType"));
    }

    @Test
    public void setup_payment_arrangement_returns_null() {

        MortgagePaymentArrangementService mortgagePaymentArrangementService = new MortgagePaymentArrangementServiceImpl(mortgageAccountOptionRestClient, mortgageServiceUtil);

        when(mortgageServiceUtil.writeObjectAsString(any(PaymentArrangementRequest.class))).thenReturn("tempString");

        Map<String, String> readObjectMap = setupMortgageHelper.readObjectResponse();

        when(mortgageServiceUtil.readObject(any(String.class), any())).thenReturn(readObjectMap);

        when(mortgageAccountOptionRestClient.updateAccountOptions(any(VaultAccountOptionsUpdateRequest.class))).thenReturn(null);

        PaymentArrangementResponse paymentArrangementResponse = mortgagePaymentArrangementService.setUpPaymentArrangement(setupMortgageHelper.paymentArrangementRequest(), "ceabb62f-ee67-85da-fb0d-00415c349f89");

        Assert.assertEquals(null, paymentArrangementResponse);
    }

    @Test(expected = CircuitBreakerOpenException.class)
    public void hystrix_test_on_fallbackSetUpPaymentArrangement() {
        MortgagePaymentArrangementServiceImpl mortgageSrvc = new MortgagePaymentArrangementServiceImpl(mortgageAccountOptionRestClient, mortgageServiceUtil);
        mortgageSrvc.fallbackSetUpPaymentArrangement(setupMortgageHelper.paymentArrangementRequest(), "f76ca840-2553-d536-1ab8-9fa85c99db05",
                new Exception("Circuit open on update account options"));
    }

    @Test
    public void amend_payment_arrangement_test() {
        //given
        MortgagePaymentArrangementService mortgagePaymentArrangementService = new MortgagePaymentArrangementServiceImpl(mortgageAccountOptionRestClient, mortgageServiceUtil);
        PaymentArrangementUpdateRequest paymentArrangementUpdateRequest = setupMortgageHelper.buildPaymentArrangementUpdateRequest();
        AccountOptionsUpdateResponse accountOptionsUpdateResponse = setupMortgageHelper.buildAmendPaymentArrangementResponse();
        Map<String, String> readObjectMap = setupMortgageHelper.readPaymentArrangementAmendObjectresponse();

        when(mortgageServiceUtil.writeObjectAsString(any(PaymentArrangementUpdateRequest.class))).thenReturn("tempString");
        when(mortgageServiceUtil.readObject(any(String.class), any())).thenReturn(readObjectMap);
        when(mortgageAccountOptionRestClient.updateAccountOptions(any(VaultAccountOptionsUpdateRequest.class))).thenReturn(accountOptionsUpdateResponse);
        //when
        PaymentArrangementResponse response = mortgagePaymentArrangementService.updatePaymentArrangement(paymentArrangementUpdateRequest, "ceabb62f-ee67-85da-fb0d-00415c349f89");
        //then
        Assert.assertEquals("ceabb62f-ee67-85da-fb0d-00415c349f89", response.getAccountId());


    }

    @Test
    public void amend_payment_arrangement_returns_null() {
        //given
        MortgagePaymentArrangementService mortgagePaymentArrangementService = new MortgagePaymentArrangementServiceImpl(mortgageAccountOptionRestClient, mortgageServiceUtil);
        PaymentArrangementUpdateRequest paymentArrangementUpdateRequest = setupMortgageHelper.buildPaymentArrangementUpdateRequest();
        Map<String, String> readObjectMap = setupMortgageHelper.readPaymentArrangementAmendObjectresponse();

        when(mortgageServiceUtil.writeObjectAsString(any(PaymentArrangementUpdateRequest.class))).thenReturn("tempString");
        when(mortgageServiceUtil.readObject(any(String.class), any())).thenReturn(readObjectMap);
        when(mortgageAccountOptionRestClient.updateAccountOptions(any(VaultAccountOptionsUpdateRequest.class))).thenReturn(null);
        //when
        PaymentArrangementResponse response = mortgagePaymentArrangementService.updatePaymentArrangement(paymentArrangementUpdateRequest, "ceabb62f-ee67-85da-fb0d-00415c349f89");
        //then
        Assert.assertEquals(null, response);

    }

    @Test(expected = CircuitBreakerOpenException.class)
    public void hystrix_test_on_fallbackUpdatePaymentArrangementOptions() {
        MortgagePaymentArrangementServiceImpl mortgageSrvc = new MortgagePaymentArrangementServiceImpl(mortgageAccountOptionRestClient, mortgageServiceUtil);
        mortgageSrvc.fallbackUpdatePaymentArrangementOptions(setupMortgageHelper.buildPaymentArrangementUpdateRequest(), "ceabb62f-ee67-85da-fb0d-00415c349f89",
                new Exception("Circuit open on amend UnderPayment options"));
    }

    @Test
    public void cancel_payment_arrangement_test() {
        //given
        MortgagePaymentArrangementService mortgagePaymentArrangementService = new MortgagePaymentArrangementServiceImpl(mortgageAccountOptionRestClient, mortgageServiceUtil);
        AccountOptionsUpdateResponse accountOptionsUpdateResponse = setupMortgageHelper.buildCancelPaymentArrangementResponse();

        when(mortgageAccountOptionRestClient.updateAccountOptions(any(VaultAccountOptionsUpdateRequest.class))).thenReturn(accountOptionsUpdateResponse);
        //when
        PaymentArrangementResponse response = mortgagePaymentArrangementService.cancelPaymentArrangement( "ceabb62f-ee67-85da-fb0d-00415c349f89");
        //then
        assertNotNull(response);
        Assert.assertEquals("ceabb62f-ee67-85da-fb0d-00415c349f89", response.getAccountId());

    }

    @Test
    public void cancel_payment_arrangement_returns_null() {
        //given
        MortgagePaymentArrangementService mortgagePaymentArrangementService = new MortgagePaymentArrangementServiceImpl(mortgageAccountOptionRestClient, mortgageServiceUtil);

        when(mortgageAccountOptionRestClient.updateAccountOptions(any(VaultAccountOptionsUpdateRequest.class))).thenReturn(null);
        //when
        PaymentArrangementResponse response = mortgagePaymentArrangementService.cancelPaymentArrangement( "ceabb62f-ee67-85da-fb0d-00415c349f89");
        //then
        Assert.assertEquals(null, response);

    }

    @Test(expected = CircuitBreakerOpenException.class)
    public void hystrix_test_on_fallbackCancelPaymentArrangement() {
        MortgagePaymentArrangementServiceImpl mortgageSrvc = new MortgagePaymentArrangementServiceImpl(mortgageAccountOptionRestClient, mortgageServiceUtil);
        mortgageSrvc.fallbackCancelPaymentArrangement( "ceabb62f-ee67-85da-fb0d-00415c349f89",
                new Exception("Circuit open on amend UnderPayment options"));
    }
}
