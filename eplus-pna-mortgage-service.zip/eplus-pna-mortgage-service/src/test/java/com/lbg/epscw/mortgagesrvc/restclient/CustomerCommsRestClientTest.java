package com.lbg.epscw.mortgagesrvc.restclient;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.lbg.epscw.mortgagesrvc.dto.comms.CommsResponse;
import com.lbg.epscw.mortgagesrvc.helper.MortgageRedemptionHelper;
import com.lbg.epscw.mortgagesrvc.util.MortgageServiceUtil;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.web.client.RestTemplate;

import java.util.HashMap;

import static org.junit.Assert.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.powermock.api.mockito.PowerMockito.when;

@RunWith(SpringRunner.class)
public class CustomerCommsRestClientTest {

    MortgageRedemptionHelper helper = new MortgageRedemptionHelper();

    @Mock
    private RestTemplate restTemplate;

    @Mock
    private MortgageServiceUtil mortgageServiceUtil;

    @InjectMocks
    private CustomerCommsRestClient customerCommsRestClient;

    @Before
    public void setup(){

        ReflectionTestUtils.setField(customerCommsRestClient,"customerCommsEndpoint","http://somevalue");
        ReflectionTestUtils.setField(customerCommsRestClient,"internalSystemId","internal_system_Id");

    }

    @Test
    public void sendCommsRestClientTest() throws JsonProcessingException, NoSuchFieldException, SecurityException {

        when(restTemplate.postForEntity(anyString(), any(),any())).thenReturn(ResponseEntity.ok().build());
        when(mortgageServiceUtil.readObject(any(),any())).thenReturn(CommsResponse.builder().build());

        CommsResponse response = customerCommsRestClient.sendComms(helper.generateCommRequest(), new HashMap<>());
        assertNotNull(response);
    }

    @Test
    public void sendCommsRestClientFailureTest() throws JsonProcessingException, NoSuchFieldException, SecurityException {

        when(restTemplate.postForEntity(anyString(), any(),any())).thenReturn(ResponseEntity.notFound().build());
        when(mortgageServiceUtil.readObject(any(),any())).thenReturn(CommsResponse.builder().build());

        CommsResponse response = customerCommsRestClient.sendComms(helper.generateCommRequest(), new HashMap<>());
        assertTrue(response.getBody().contains("Communication Not sent!"));
    }
}
