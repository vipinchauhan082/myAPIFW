package com.lbg.epscw.mortgagesrvc.controller;

import com.lbg.epscw.mortgagesrvc.constants.CommonConstants;
import com.lbg.epscw.mortgagesrvc.dto.MortgageClosureEligibility;
import com.lbg.epscw.mortgagesrvc.exception.AccountClosureValidationException;
import com.lbg.epscw.mortgagesrvc.exception.MortgageServiceException;
import com.lbg.epscw.mortgagesrvc.helper.MortgageAccountClosureHelper;
import com.lbg.epscw.mortgagesrvc.model.AccountClosureResponse;
import com.lbg.epscw.mortgagesrvc.model.Channel;
import com.lbg.epscw.mortgagesrvc.service.MortgageAccountClosureService;
import com.lbg.epscw.mortgagesrvc.util.MortgageServiceUtil;
import com.lbg.epscw.mortgagesrvc.validator.MortgageAccountClosureValidator;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.test.context.junit4.SpringRunner;

import javax.validation.ConstraintViolationException;
import java.util.HashMap;
import java.util.Map;

import static org.junit.Assert.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.powermock.api.mockito.PowerMockito.*;

@RunWith(SpringRunner.class)
@WebMvcTest(controllers = { MortgageServiceUtil.class, AccountClosureController.class })
public class AccountClosureControllerTest {

    @Autowired
    private AccountClosureController accountClosureController;

    @MockBean
    private MortgageAccountClosureService mortgageAccountClosureService;

    @MockBean
    private MortgageAccountClosureValidator mortgageAccountClosureValidator;

    private MortgageAccountClosureHelper mortgageAccountClosureHelper=new MortgageAccountClosureHelper();

    @Test
    public void close_overarching_account_successful() {
        doNothing().when(mortgageAccountClosureValidator).validateAccountClosure(any(String.class),any(Map.class),
                any(MortgageClosureEligibility.class));
        when(mortgageAccountClosureService.closeMortgageAccount(any(String.class), any(MortgageClosureEligibility.class)))
                .thenReturn(mortgageAccountClosureHelper.buildAccountClosureResponse());
        //when
        ResponseEntity<AccountClosureResponse> responseEntity = accountClosureController
                .mortgageAccountClosure("IF", Channel.DIGITAL.name(), "123-456-789-12", "Bearer 122", "ALL", new HashMap<String, String>(),
                        "b2c9119f-09e5-4ac9-9738-9e28b334d3fa");
        AccountClosureResponse accountClosureResponse = responseEntity.getBody();

        //then
        assertEquals("b2c9119f-09e5-4ac9-9738-9e28b334d3fa", accountClosureResponse.getAccountId());
        assertEquals("ACCOUNT_STATUS_PENDING_CLOSURE", accountClosureResponse.getStatus());
    }

    @Test(expected = AccountClosureValidationException.class)
    public void should_not_allow_closing_overarching_account_() {
        doThrow(new AccountClosureValidationException("PENDING_OPEN_SUBACCOUNT",CommonConstants.ERROR)).when(mortgageAccountClosureValidator).
                validateAccountClosure(any(String.class),any(Map.class), any(MortgageClosureEligibility.class));

        //when
        ResponseEntity<AccountClosureResponse> responseEntity = accountClosureController
                .mortgageAccountClosure("IF",Channel.DIGITAL.name(), "123-456-789-12", "Bearer 122", "ALL", new HashMap<String, String>(),
                        "b2c9119f-09e5-4ac9-9738-9e28b334d3fa");

    }

    @Test(expected = MortgageServiceException.class)
    public void close_overarching_account_fails_when_service_layer_fails() {
        doNothing().when(mortgageAccountClosureValidator).validateAccountClosure(any(String.class),any(Map.class),
                any(MortgageClosureEligibility.class));
        when(mortgageAccountClosureService.closeMortgageAccount(any(String.class),any(MortgageClosureEligibility.class)))
                .thenReturn(null);
        //when
        ResponseEntity<AccountClosureResponse> responseEntity = accountClosureController
                .mortgageAccountClosure("IF",Channel.DIGITAL.name(), "123-456-789-12", "Bearer 122", "ALL", new HashMap<String, String>(),
                        "b2c9119f-09e5-4ac9-9738-9e28b334d3fa");
    }

    @Test(expected = AccessDeniedException.class)
    public void close_overarching_account_fails_when_validation_fails() {
        //given
        doThrow(new AccessDeniedException("Entitlement rejected request")).when(mortgageAccountClosureValidator)
                .validateAccountClosure(any(String.class),any(Map.class),any(MortgageClosureEligibility.class));


        //when
        ResponseEntity<AccountClosureResponse> responseEntity = accountClosureController
                .mortgageAccountClosure("IF", Channel.DIGITAL.name(), "123-456-789-12", null, "ALL", new HashMap<String, String>(), "b2c9119f-09e5-4ac9-9738-9e28b334d3fa");

    }

    @Test(expected = ConstraintViolationException.class)
    public void update_overpayment_options_rejects_request_if_account_id_length_is_small() {

        //when
        ResponseEntity<AccountClosureResponse> responseEntity = accountClosureController
                .mortgageAccountClosure("IF",Channel.DIGITAL.name(), "123-456-789-12", null, "ALL", new HashMap<String, String>(), "b2c9119f-09e5-4ac9-9738-9e28b334fa");

    }

    @Test(expected = ConstraintViolationException.class)
    public void update_overpayment_options_rejects_request_if_account_id_length_is_big() {

        //when
        ResponseEntity<AccountClosureResponse> responseEntity = accountClosureController
                .mortgageAccountClosure("IF",Channel.DIGITAL.name(), "123-456-789-12", null, "ALL", new HashMap<String, String>(),"b2c9119f-09e5-4ac9-9738-9e28b334d3fa23");

    }

    @Test(expected = ConstraintViolationException.class)
    public void update_overpayment_options_rejects_request_if_account_id_length_is_null() {

        //when
        ResponseEntity<AccountClosureResponse> responseEntity = accountClosureController
                .mortgageAccountClosure("IF",Channel.DIGITAL.name(), "123-456-789-12", null, "ALL", new HashMap<String, String>(),null);

    }

    @Test(expected = ConstraintViolationException.class)
    public void update_overpayment_options_rejects_request_if_account_id_length_is_empty() {

        //when
        ResponseEntity<AccountClosureResponse> responseEntity = accountClosureController
                .mortgageAccountClosure("IF",Channel.DIGITAL.name(), "123-456-789-12", null, "ALL", new HashMap<String, String>(), "");

    }

}