package com.lbg.epscw.mortgagesrvc.validator;

import com.lbg.epscw.mortgagesrvc.exception.MortgageValidationException;
import com.lbg.epscw.mortgagesrvc.helper.MortgagePortingApplicationHelper;
import com.lbg.epscw.mortgagesrvc.model.MortgageApplicationInfo;
import com.lbg.epscw.mortgagesrvc.service.MortgagePortingStateMachine;
import org.junit.Before;
import org.junit.Test;

import static com.lbg.epscw.mortgagesrvc.helper.MortgagePortingHelper.APPLICATION_NUMBER;

public class MortgagePortingSubmitApplicationValidatorTest {
    private MortgagePortingSubmitApplicationValidator underTest;

    @Before
    public void setup() {
        underTest = new MortgagePortingSubmitApplicationValidator(new MortgagePortingApplicationValidator(new MortgagePortingStateMachine()));
    }

    @Test(expected = MortgageValidationException.class)
    public void fetch_Mortgage_Porting_Application_Details() {
        MortgagePortingApplicationHelper mortgagePortingApplicationHelper = new MortgagePortingApplicationHelper();
        MortgageApplicationInfo mortgagePortingApplicationDetails = mortgagePortingApplicationHelper.getMortgagePortingApplicationDetails();
        mortgagePortingApplicationDetails.setApplicationNumber(APPLICATION_NUMBER);
        mortgagePortingApplicationDetails.setBorrowingAmount("5000");
        underTest.validate(mortgagePortingApplicationDetails);
    }

    @Test(expected = MortgageValidationException.class)
    public void fetch_Mortgage_Porting_Application_Details_with_invalid_status() {
        MortgagePortingApplicationHelper mortgagePortingApplicationHelper = new MortgagePortingApplicationHelper();

        MortgageApplicationInfo mortgagePortingApplicationDetails = mortgagePortingApplicationHelper.getMortgagePortingApplicationDetails();
        mortgagePortingApplicationDetails.setApplicationNumber(APPLICATION_NUMBER);
        mortgagePortingApplicationDetails.setBorrowingAmount("5000");

        underTest.validate(mortgagePortingApplicationDetails);
    }
}