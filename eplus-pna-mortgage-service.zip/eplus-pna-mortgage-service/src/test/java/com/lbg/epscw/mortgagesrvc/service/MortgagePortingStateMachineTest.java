package com.lbg.epscw.mortgagesrvc.service;

import org.junit.Before;
import org.junit.Test;

import static com.lbg.epscw.mortgagesrvc.model.MortgagePortingApplicationStatus.*;
import static java.util.Arrays.asList;
import static java.util.Collections.emptyList;
import static java.util.Collections.singletonList;
import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;

public class MortgagePortingStateMachineTest {

    private MortgagePortingStateMachine underTest;

    @Before
    public void setup() {
        underTest = new MortgagePortingStateMachine();
    }

    @Test
    public void create_mortgage_app_returns_correct_next_state() {
        assertThat(underTest.next(OPEN), is(singletonList(SUBMITTED)));
    }

    @Test
    public void ready_for_review_returns_correct_next_states() {
        assertThat(underTest.next(SUBMITTED), is(asList(APPROVED, REOPEN, DECLINED)));
    }

    @Test
    public void accept_returns_correct_next_state() {
        assertThat(underTest.next(APPROVED), is(singletonList(WELCOME_PACK_RECEIVED)));
    }

    @Test
    public void referred_returns_correct_next_state() {
        assertThat(underTest.next(REOPEN), is(singletonList(RESUBMITTED)));
    }

    @Test
    public void credit_decline_returns_no_next_state() {
        assertThat(underTest.next(DECLINED), is(emptyList()));
    }

    @Test
    public void application_complete_returns_correct_next_state() {
        assertThat(underTest.next(WELCOME_PACK_RECEIVED), is(singletonList(VALUATION_RECEIVED)));
    }

    @Test
    public void value_report_updated_returns_correct_next_states() {
        assertThat(underTest.next(VALUATION_RECEIVED), is(asList(REPROCESS, OFFERED, REOPEN)));
    }

    @Test
    public void formal_offer_returns_correct_next_state() {
        assertThat(underTest.next(OFFERED), is(singletonList(SOLICITOR_DOC_RECEIVED)));
    }

    @Test
    public void solicitor_doc_received_returns_correct_next_state() {
        assertThat(underTest.next(SOLICITOR_DOC_RECEIVED), is(singletonList(FUNDS_RELEASED)));
    }
}