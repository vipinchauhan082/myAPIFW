package com.lbg.epscw.mortgagesrvc.helper;

import com.lbg.epscw.mortgagesrvc.dto.MortgageAccountData;
import com.lbg.epscw.mortgagesrvc.dto.MortgageAccountInfo;
import com.lbg.epscw.mortgagesrvc.model.*;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static com.lbg.epscw.mortgagesrvc.constants.CommonConstants.UNDERPAYMENT;

public class SetupMortgageHelper {


    public PaymentArrangementRequest paymentArrangementRequest() {
        PaymentArrangementRequest paymentArrangementRequest = new PaymentArrangementRequest();
        paymentArrangementRequest.setPaymentArrangementEndMonth("11/2040");
        paymentArrangementRequest.setPaymentArrangementStartMonth("11/2039");
        paymentArrangementRequest.setPaymentArrangementAmount("123.45");
        paymentArrangementRequest.setPaymentArrangementAmountType("FIXED_PAYMENT_AMOUNT");
        paymentArrangementRequest.setPaymentArrangementType("OVERPAYMENT");
        Map<String, String> overPaymentOptions = new HashMap<>();
        overPaymentOptions.put("PaymentArrangementEndMonth", "11/2040");
        overPaymentOptions.put("PaymentArrangementAmount", "123.45");
        overPaymentOptions.put("PaymentArrangementStartMonth", "11/2039");
        overPaymentOptions.put("PaymentArrangementAmountType", "FIXED_PAYMENT_AMOUNT");
        paymentArrangementRequest.setPaymentArrangementOptions(overPaymentOptions);
        return paymentArrangementRequest;

    }


    public AccountOptionsUpdateResponse mock_AccountOptionsUpdateResponse() {
        AccountOptionsUpdateResponse accountOptionsUpdateResponse = new AccountOptionsUpdateResponse();
        accountOptionsUpdateResponse.setAccountId("ceabb62f-ee67-85da-fb0d-00415c349f89");
        accountOptionsUpdateResponse.setStatus("ACCOUNT_UPDATE_STATUS_PENDING_EXECUTION");

        Map<String, String> overPaymentOptions = new HashMap<>();
        overPaymentOptions.put("payment_arrangement_end_month", "11-2040");
        overPaymentOptions.put("payment_arrangement_amount", "123.45");
        overPaymentOptions.put("payment_arrangement_start_month", "11-2040");
        overPaymentOptions.put("payment_arrangement_amount_type", "FIXED_PAYMENT_AMOUNT");
        InstanceParamValsUpdate instanceParamValsUpdate = new InstanceParamValsUpdate();
        instanceParamValsUpdate.setInstanceParamVals(overPaymentOptions);
        accountOptionsUpdateResponse.setInstanceParamValsUpdate(instanceParamValsUpdate);

        return accountOptionsUpdateResponse;

    }

    public AccountOptionsUpdateResponse mock_GeneralAccountOptionsUpdateResponse() {
        AccountOptionsUpdateResponse accountOptionsUpdateResponse = new AccountOptionsUpdateResponse();
        accountOptionsUpdateResponse.setAccountId("ceabb62f-ee67-85da-fb0d-00415c349f89");
        accountOptionsUpdateResponse.setStatus("ACCOUNT_UPDATE_STATUS_PENDING_EXECUTION");

        Map<String, String> overPaymentOptions = new HashMap<>();
        overPaymentOptions.put("payment_arrangement_end_month", "12/2040");
        overPaymentOptions.put("payment_arrangement_amount", "123.45");
        overPaymentOptions.put("payment_arrangement_start_month", "11/2039");
        overPaymentOptions.put("payment_arrangement_amount_type", "FIXED_PAYMENT_AMOUNT");
        overPaymentOptions.put("payment_arrangement_type", "OVERPAYMENT");
        InstanceParamValsUpdate instanceParamValsUpdate = new InstanceParamValsUpdate();
        instanceParamValsUpdate.setInstanceParamVals(overPaymentOptions);
        accountOptionsUpdateResponse.setInstanceParamValsUpdate(instanceParamValsUpdate);

        return accountOptionsUpdateResponse;

    }

    public PaymentArrangementResponse mock_PaymentArrangementSetupResponse() {
        PaymentArrangementResponse paymentArrangementResponse = new PaymentArrangementResponse();
        paymentArrangementResponse.setStatus("ACCOUNT_UPDATE_STATUS_PENDING_EXECUTION");
        paymentArrangementResponse.setAccountId("ceabb62f-ee67-85da-fb0d-00415c349f89");
        Map<String, String> overPaymentOptions = new HashMap<>();
        overPaymentOptions.put("PaymentArrangementEndMonth", "11/2042");
        overPaymentOptions.put("PaymentArrangementAmount", "123.45");
        overPaymentOptions.put("PaymentArrangementStartMonth", "11/2041");
        overPaymentOptions.put("PaymentArrangementAmountType", "FIXED_PAYMENT_AMOUNT");
        overPaymentOptions.put("PaymentArrangementType", "OVERPAYMENT");
        paymentArrangementResponse.setInstanceParamVals(overPaymentOptions);
        return paymentArrangementResponse;
    }


    public Map<String, String> readObjectResponse() {
        Map<String, String> readObjectMap = new HashMap<>();
        readObjectMap.put("PaymentArrangementEndMonth", "11/2040");
        readObjectMap.put("PaymentArrangementAmount", "126.45");
        readObjectMap.put("PaymentArrangementStartMonth", "11/2039");
        readObjectMap.put("PaymentArrangementAmountType", "FIXED_PAYMENT_AMOUNT");
        return readObjectMap;
    }

    public Map<String, String> readPaymentArrangementAmendObjectresponse() {
        Map<String, String> readObjectMap = new HashMap<>();
        readObjectMap.put("PaymentArrangementEndMonth", "12-2040");
        readObjectMap.put("PaymentArrangementAmount", "126.45");
        readObjectMap.put("PaymentArrangementStartMonth", "11-2040");
        readObjectMap.put("PaymentArrangementAmountType", "FIXED_OVERPAYMENT");
        return readObjectMap;
    }

    public MortgageAccountInfo mortgageAccountInfo_ovePaymentMock() {
        MortgageAccountInfo mortgageAccountInfo = new MortgageAccountInfo();
        List<MortgageAccountData> mortgageAccountDataList = new ArrayList<>();
        MortgageAccountData mortgageAccountData = new MortgageAccountData();
        mortgageAccountData.setPaymentArrangementStartMonth("11-2040");
        mortgageAccountData.setStatus("ACCOUNT_STATUS_OPEN");
        mortgageAccountData.setPaymentArrangementAmountType("FIXED_PAYMENT_AMOUNT");
        mortgageAccountData.setPaymentArrangementType("OVERPAYMENT");
        mortgageAccountData.setKeyDate("7");
        mortgageAccountDataList.add(mortgageAccountData);
        mortgageAccountInfo.setMortgageAccountData(mortgageAccountDataList);
        return mortgageAccountInfo;
    }

    public MortgageAccountInfo mortgageAccountInfo_underPaymentMock() {
        MortgageAccountInfo mortgageAccountInfo = new MortgageAccountInfo();
        List<MortgageAccountData> mortgageAccountDataList = new ArrayList<>();
        MortgageAccountData mortgageAccountData = new MortgageAccountData();
        mortgageAccountData.setPaymentArrangementStartMonth("11-2040");
        mortgageAccountData.setPaymentArrangementAmountType("FIXED_PAYMENT_AMOUNT");
        mortgageAccountData.setPaymentArrangementType(UNDERPAYMENT);
        mortgageAccountData.setKeyDate("7");
        mortgageAccountDataList.add(mortgageAccountData);
        mortgageAccountInfo.setMortgageAccountData(mortgageAccountDataList);
        return mortgageAccountInfo;
    }

    public MortgageAccountInfo mortgageAccountInfo_repaymentMock() {
        MortgageAccountInfo mortgageAccountInfo = new MortgageAccountInfo();
        List<MortgageAccountData> mortgageAccountDataList = new ArrayList<>();
        MortgageAccountData mortgageAccountData = new MortgageAccountData();
        mortgageAccountData.setProductId("lbg_mortgage");
        mortgageAccountData.setPaymentArrangementAmountType("FIXED_PAYMENT_AMOUNT");
        mortgageAccountData.setPaymentArrangementType("OVERPAYMENT");
        mortgageAccountData.setKeyDate("20");
        mortgageAccountDataList.add(mortgageAccountData);
        mortgageAccountInfo.setMortgageAccountData(mortgageAccountDataList);
        return mortgageAccountInfo;
    }

    public HttpHeaders getAccountInfoHeaders() {
        HttpHeaders httpHeaders = new HttpHeaders();
        httpHeaders.add("Authorization", "Bearer b2c9119f-09e5-4ac9-9738-9e28b334d3fa");
        httpHeaders.add("x-lbg-internal-system-id", "test");
        httpHeaders.add("x-lbg-brand", "IF");
        httpHeaders.add("x-lbg-txn-correlation-id", "123-456-789-123");
        httpHeaders.setContentType(MediaType.APPLICATION_JSON);
        return httpHeaders;
    }

    public String getMortgageQueryServiceResponse() {
        return "{\n" +
                "    \"Data\": [\n" +
                "        {\n" +
                "            \"mortgageNumber\": \"number_1112\",\n" +
                "            \"mortgagePrincipal\": \"4000\",\n" +
                "            \"keyDate\": \"7\",\n" +
                "            \"mortgageType\": \"INTEREST_ONLY\",\n" +
                "            \"totalTerm\": \"24\",\n" +
                "            \"productId\": \"lbg_mortgage\",\n" +
                "            \"accountId\": \"1601d0e5-e336-64d9-64ad-89ba6fdc2677\",\n" +
                "            \"accountStatus\": \"ACCOUNT_STATUS_OPEN\",\n" +
                "            \"paymentArrangementStartMonth\": \"06/2040\",\n" +
                "            \"paymentArrangementEndMonth\": \"12/2040\",\n" +
                "            \"paymentArrangementAmount\": \"123.45\"\n" +
                "        }\n" +

                "    ]\n" +
                "}";
    }

    //write a response here
    public String getVaultResponse(){
        return "{\n" +
                "    \"id\": \"5a688301-6d10-485c-0242-1ee03844a5c4\",\n" +
                "    \"account_id\": \"1601d0e5-e336-64d9-64ad-89ba6fdc2677\",\n" +
                "    \"status\": \"ACCOUNT_UPDATE_STATUS_PENDING_EXECUTION\",\n" +
                "    \"instance_param_vals_update\": {\n" +
                "        \"instance_param_vals\": {\n" +
                "            \"payment_arrangement_start_month\": \"12-2040\",\n" +
                "            \"payment_arrangement_end_month\": \"06-2040\",\n" +
                "            \"payment_arrangement_amount\": \"126.45\"\n" +
                "        }\n" +
                "    },\n" +
                "    \"create_timestamp\": \"2020-09-14T17:45:04.687675Z\",\n" +
                "    \"last_status_update_timestamp\": \"2020-09-14T17:45:04.687675Z\",\n" +
                "    \"account_update_batch_id\": \"\",\n" +
                "    \"failure_reason\": \"\"\n" +
                "}";
    }

    public PaymentArrangementUpdateRequest buildPaymentArrangementUpdateRequest() {
        PaymentArrangementUpdateRequest paymentArrangementUpdateRequest = new PaymentArrangementUpdateRequest();
        paymentArrangementUpdateRequest.setPaymentArrangementEndMonth("10-2040");
        paymentArrangementUpdateRequest.setPaymentArrangementStartMonth("05-2040");
        paymentArrangementUpdateRequest.setPaymentArrangementAmount("123.45");
        Map<String, String> underPaymentOptions = new HashMap<>();
        underPaymentOptions.put("payment_arrangement_end_month", "10-2040");
        underPaymentOptions.put("payment_arrangement_start_month", "05-2040");
        underPaymentOptions.put("payment_arrangement_amount", "123.45");
        paymentArrangementUpdateRequest.setVaultInstanceParams(underPaymentOptions);
        return paymentArrangementUpdateRequest;
    }

    public AccountOptionsUpdateResponse buildAmendPaymentArrangementResponse() {
        AccountOptionsUpdateResponse accountOptionsUpdateResponse = new AccountOptionsUpdateResponse();
        accountOptionsUpdateResponse.setAccountId("ceabb62f-ee67-85da-fb0d-00415c349f89");
        accountOptionsUpdateResponse.setStatus("ACCOUNT_UPDATE_STATUS_PENDING_EXECUTION");
        Map<String, String> underPaymentOptions = new HashMap<>();
        underPaymentOptions.put("payment_arrangement_end_month", "09-2040");
        underPaymentOptions.put("payment_arrangement_amount", "123.45");
        underPaymentOptions.put("payment_arrangement_start_month", "04-2040");
        InstanceParamValsUpdate instanceParamValsUpdate = new InstanceParamValsUpdate();
        instanceParamValsUpdate.setInstanceParamVals(underPaymentOptions);
        accountOptionsUpdateResponse.setInstanceParamValsUpdate(instanceParamValsUpdate);
        return accountOptionsUpdateResponse;
    }

    public AccountOptionsUpdateResponse buildCancelPaymentArrangementResponse() {
        AccountOptionsUpdateResponse accountOptionsUpdateResponse = new AccountOptionsUpdateResponse();
        accountOptionsUpdateResponse.setAccountId("ceabb62f-ee67-85da-fb0d-00415c349f89");
        accountOptionsUpdateResponse.setStatus("ACCOUNT_UPDATE_STATUS_PENDING_EXECUTION");
        Map<String, String> underPaymentOptions = new HashMap<>();
        underPaymentOptions.put("payment_arrangement_end_month", "");
        underPaymentOptions.put("payment_arrangement_amount", "123.45");
        underPaymentOptions.put("payment_arrangement_start_month", "");
        InstanceParamValsUpdate instanceParamValsUpdate = new InstanceParamValsUpdate();
        instanceParamValsUpdate.setInstanceParamVals(underPaymentOptions);
        accountOptionsUpdateResponse.setInstanceParamValsUpdate(instanceParamValsUpdate);
        return accountOptionsUpdateResponse;
    }

    public MortgageAccountInfo mortgageAccountInfo_underPaymentMockWithNoData() {
        MortgageAccountInfo mortgageAccountInfo = new MortgageAccountInfo();
        List<MortgageAccountData> mortgageAccountDataList = new ArrayList<>();
        MortgageAccountData mortgageAccountData = new MortgageAccountData();
        mortgageAccountDataList.add(mortgageAccountData);
        mortgageAccountInfo.setMortgageAccountData(mortgageAccountDataList);
        return mortgageAccountInfo;
    }

    public String getMortgageQueryServiceResponseWithStartAndNoEndDate() {
        return "{\n" +
                "    \"Data\": [\n" +
                "        {\n" +
                "            \"mortgageNumber\": \"number_1112\",\n" +
                "            \"mortgagePrincipal\": \"4000\",\n" +
                "            \"keyDate\": \"7\",\n" +
                "            \"mortgageType\": \"INTEREST_ONLY\",\n" +
                "            \"totalTerm\": \"24\",\n" +
                "            \"productId\": \"lbg_mortgage\",\n" +
                "            \"accountId\": \"1601d0e5-e336-64d9-64ad-89ba6fdc2677\",\n" +
                "            \"underpaymentStartDate\": \"05-2040\",\n" +
                "            \"underpaymentType\": \"FIXED_PAYMENT_AMOUNT\",\n" +
                "            \"underpaymentAmount\": \"123.45\"\n" +
                "        }\n" +

                "    ]\n" +
                "}";
    }

    public String getMortgageQueryServiceResponseWithNoSubAccount() {
        return "{\n" +
                "    \"Data\": [\n" +
                "        {\n" +
                "            \"mortgageNumber\": \"number_1112\",\n" +
                "            \"mortgagePrincipal\": \"4000\",\n" +
                "            \"keyDate\": \"7\",\n" +
                "            \"mortgageType\": \"INTEREST_ONLY\",\n" +
                "            \"totalTerm\": \"24\",\n" +
                "            \"productId\": \"lbg_mortgage_repayment\",\n" +
                "            \"accountId\": \"1601d0e5-e336-64d9-64ad-89ba6fdc2677\"\n" +
                "        },\n" +
                "        {\n" +
                "            \"mortgageNumber\": \"number_1112\",\n" +
                "            \"mortgagePrincipal\": \"4000\",\n" +
                "            \"keyDate\": \"7\",\n" +
                "            \"mortgageType\": \"INTEREST_ONLY\",\n" +
                "            \"totalTerm\": \"24\",\n" +
                "            \"productId\": \"lbg_mortgage_repayment\",\n" +
                "            \"accountId\": \"1601d0e5-e336-64d9-64ad-89ba6fdc2634\"\n" +
                "        }\n" +

                "    ]\n" +
                "}";
    }
}
