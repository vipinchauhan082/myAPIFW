package com.lbg.epscw.mortgagesrvc.validator;

import com.lbg.epscw.mortgagesrvc.exception.MortgageValidationException;
import com.lbg.epscw.mortgagesrvc.model.MortgageApplicationInfo;
import com.lbg.epscw.mortgagesrvc.model.MortgagePortingApplicationStatus;
import com.lbg.epscw.mortgagesrvc.model.PortingUpdateSolicitorInfoRequest;
import org.junit.Before;
import org.junit.Test;

import java.util.List;

import static com.lbg.epscw.mortgagesrvc.enums.SolicitorAccountSchema.IBAN;
import static com.lbg.epscw.mortgagesrvc.model.MortgagePortingApplicationStatus.APPROVED;
import static java.util.Collections.singletonList;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;

public class MortgagePortingSolicitorInfoValidatorTest {
    private MortgagePortingApplicationValidator applicationValidator;
    private MortgagePortingSolicitorInfoValidator underTest;

    @Before
    public void setup() {
        applicationValidator = mock(MortgagePortingApplicationValidator.class);
        underTest = new MortgagePortingSolicitorInfoValidator(applicationValidator);
    }

    @Test
    public void verify_validate_is_successful() {
        PortingUpdateSolicitorInfoRequest request = PortingUpdateSolicitorInfoRequest.builder().identification("01234501234567").build();
        MortgageApplicationInfo applicationInfo = MortgageApplicationInfo.builder().build();
        List<MortgagePortingApplicationStatus> statuses = singletonList(APPROVED);

        underTest.validate(request, applicationInfo, statuses);

        verify(applicationValidator).validateCurrentState(applicationInfo, statuses);
    }

    @Test
    public void skip_identification_validation_when_schema_not_sort_code_account_number() {
        PortingUpdateSolicitorInfoRequest request = PortingUpdateSolicitorInfoRequest.builder()
                .schemaName(IBAN.name())
                .identification("1")
                .build();
        underTest.validate(request, new MortgageApplicationInfo(), singletonList(APPROVED));
    }

    @Test(expected = MortgageValidationException.class)
    public void validate_identification_length_when_schema_is_sort_code_account_number() {
        PortingUpdateSolicitorInfoRequest request = PortingUpdateSolicitorInfoRequest.builder().identification("1").build();
        underTest.validate(request, new MortgageApplicationInfo(), singletonList(APPROVED));
    }
}