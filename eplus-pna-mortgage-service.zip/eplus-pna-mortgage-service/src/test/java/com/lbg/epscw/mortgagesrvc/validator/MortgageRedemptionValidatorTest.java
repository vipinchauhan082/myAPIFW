package com.lbg.epscw.mortgagesrvc.validator;

import com.lbg.epscw.handler.exception.system.SystemNotFoundException;
import com.lbg.epscw.mortgagesrvc.dto.MortgageAccountInfo;
import com.lbg.epscw.mortgagesrvc.enums.Recipient;
import com.lbg.epscw.mortgagesrvc.exception.MortgageValidationException;
import com.lbg.epscw.mortgagesrvc.helper.MortgageRedemptionHelper;
import com.lbg.epscw.mortgagesrvc.model.RedemptionStatementPayloadRequest;
import com.lbg.epscw.mortgagesrvc.restclient.MortgageAccountInfoRestClient;
import org.junit.Before;
import org.junit.Test;
import org.junit.jupiter.api.Assertions;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static org.mockito.ArgumentMatchers.any;
import static org.powermock.api.mockito.PowerMockito.mock;
import static org.powermock.api.mockito.PowerMockito.when;
import com.lbg.epscw.mortgagesrvc.exception.InvalidUpdateRequestException;
import com.lbg.epscw.mortgagesrvc.model.SettlementAmountRequest;

import java.time.LocalDate;
import java.time.ZoneId;

@RunWith(SpringRunner.class)
public class MortgageRedemptionValidatorTest {

    private String accountId="ceabb62f-ee67-85da-fb0d-00415c349f89";
    private String invalidAccountId="ceabb62f-qq67-85da-fb0d-00415c349f89";

    @Mock
    private RedemptionStatementPayloadRequest payloadRequest;

    @Mock
    private MortgageAccountInfoRestClient mortgageAccountInfoRestClient;

    @Before
    public void setup() {
        mortgageAccountInfoRestClient = mock(MortgageAccountInfoRestClient.class);
    }

    private final MortgageRedemptionHelper mortgageRedemptionHelper = new MortgageRedemptionHelper();

    private final static String OVERARCHING_ACCOUNT_ID = "e1b23552-aba5-6c8b-1dfb-5532a18b44cb";

    private final static String SUB_ACCOUNT_ID = "c51f649c-96e2-13bd-8dca-d2cfa7dc9b4d";

    @Test(expected = SystemNotFoundException.class)
    public void shouldThrowErrorWhenAccountIdNotFound() {

        when(payloadRequest.getTotalAnticipatedInterest()).thenReturn("123.00");
        when(payloadRequest.getTotalBalance()).thenReturn("123456.00");
        when(payloadRequest.getTotalDailyInterest()).thenReturn("11.00");
        when(payloadRequest.getTotalSettlementAmount()).thenReturn("123456.00");
        when(payloadRequest.getRedemptionDate()).thenReturn("2021-05-01");

        //given
        MortgageRedemptionValidator mortgageRedemptionValidator = new MortgageRedemptionValidator(mortgageAccountInfoRestClient);
        mortgageRedemptionValidator.validateGenerateRedemptionStatement(OVERARCHING_ACCOUNT_ID, new HashMap<>());

    }

    @Test(expected = MortgageValidationException.class)
    public void shouldThrowErrorWhenAccountIsNotOverarching() {

        when(payloadRequest.getTotalAnticipatedInterest()).thenReturn("123.00");
        when(payloadRequest.getTotalBalance()).thenReturn("123456.00");
        when(payloadRequest.getTotalDailyInterest()).thenReturn("11.00");
        when(payloadRequest.getTotalSettlementAmount()).thenReturn("123456.00");
        when(payloadRequest.getRedemptionDate()).thenReturn("2021-05-01");
        MortgageAccountInfo mortgageAccountInfo = mortgageRedemptionHelper.mock_mortgageAccountInfoResponse(SUB_ACCOUNT_ID);

        //given
        MortgageRedemptionValidator mortgageRedemptionValidator = new MortgageRedemptionValidator(mortgageAccountInfoRestClient);
        when(mortgageAccountInfoRestClient.getMortgageAccountInfo(any(String.class), any(Map.class))).thenReturn(mortgageAccountInfo);
        mortgageRedemptionValidator.validateGenerateRedemptionStatement( SUB_ACCOUNT_ID, new HashMap<>());

    }

    @Test(expected = MortgageValidationException.class)
    public void shouldThrowErrorWhenEitherCustomerIdIsNotPassed() {

        when(payloadRequest.getTotalAnticipatedInterest()).thenReturn("123.00");
        when(payloadRequest.getTotalBalance()).thenReturn("123456.00");
        when(payloadRequest.getTotalDailyInterest()).thenReturn("11.00");
        when(payloadRequest.getTotalSettlementAmount()).thenReturn("123456.00");
        when(payloadRequest.getRedemptionDate()).thenReturn("2021-05-01");
        MortgageAccountInfo mortgageAccountInfo = mortgageRedemptionHelper.mock_mortgageAccountInfoResponse(SUB_ACCOUNT_ID);

        //given
        MortgageRedemptionValidator mortgageRedemptionValidator = new MortgageRedemptionValidator(mortgageAccountInfoRestClient);
        when(mortgageAccountInfoRestClient.getMortgageAccountInfo(any(String.class), any(Map.class))).thenReturn(mortgageAccountInfo);
        mortgageRedemptionValidator.validateGenerateRedemptionStatement( SUB_ACCOUNT_ID, new HashMap<>());

    }

    @Test(expected = MortgageValidationException.class)
    public void shouldThrowErrorWhenEitherCustomerIdOrRecipientAddressAreNotPassed() {

        when(payloadRequest.getTotalAnticipatedInterest()).thenReturn("123.00");
        when(payloadRequest.getTotalBalance()).thenReturn("123456.00");
        when(payloadRequest.getTotalDailyInterest()).thenReturn("11.00");
        when(payloadRequest.getTotalSettlementAmount()).thenReturn("123456.00");
        when(payloadRequest.getRedemptionDate()).thenReturn("2021-05-01");
        MortgageAccountInfo mortgageAccountInfo = mortgageRedemptionHelper.mock_mortgageAccountInfoResponse(SUB_ACCOUNT_ID);

        //given
        MortgageRedemptionValidator mortgageRedemptionValidator = new MortgageRedemptionValidator(mortgageAccountInfoRestClient);
        when(mortgageAccountInfoRestClient.getMortgageAccountInfo(any(String.class), any(Map.class))).thenReturn(mortgageAccountInfo);
        mortgageRedemptionValidator.validateGenerateRedemptionStatement(SUB_ACCOUNT_ID, new HashMap<>());
    }

    @Test(expected = InvalidUpdateRequestException.class)
    public void validateSettlementAmountRequest_no_redemption_date(){
        SettlementAmountRequest settlementAmountRequest = mortgageRedemptionHelper.settlementAmountRequest();
        settlementAmountRequest.setRedemptionDate(null);
        MortgageRedemptionValidator mortgageRedemptionValidator = new MortgageRedemptionValidator(mortgageAccountInfoRestClient);
        mortgageRedemptionValidator.validateSettlementAmountRequest(settlementAmountRequest,accountId);
    }

    @Test(expected = InvalidUpdateRequestException.class)
    public void validateSettlementAmountRequest_no_account_id(){
        SettlementAmountRequest settlementAmountRequest = mortgageRedemptionHelper.settlementAmountRequest();
        MortgageRedemptionValidator mortgageRedemptionValidator = new MortgageRedemptionValidator(mortgageAccountInfoRestClient);
        mortgageRedemptionValidator.validateSettlementAmountRequest(settlementAmountRequest,null);

    }


    @Test(expected = InvalidUpdateRequestException.class)
    public void validateSettlementAmountRequest_invalid_account_id(){
        SettlementAmountRequest settlementAmountRequest = mortgageRedemptionHelper.settlementAmountRequest();
        MortgageRedemptionValidator mortgageRedemptionValidator = new MortgageRedemptionValidator(mortgageAccountInfoRestClient);
        mortgageRedemptionValidator.validateSettlementAmountRequest(settlementAmountRequest,invalidAccountId);

    }

    @Test(expected = InvalidUpdateRequestException.class)
    public void validateSettlementAmountRequest_invalid_date(){
        SettlementAmountRequest settlementAmountRequest = mortgageRedemptionHelper.settlementAmountRequest();
        settlementAmountRequest.setRedemptionDate("22/11/2022");
        MortgageRedemptionValidator mortgageRedemptionValidator = new MortgageRedemptionValidator(mortgageAccountInfoRestClient);
        mortgageRedemptionValidator.validateSettlementAmountRequest(settlementAmountRequest,accountId);

    }

    @Test(expected = InvalidUpdateRequestException.class)
    public void validateSettlementAmountRequest_past_date(){
        SettlementAmountRequest settlementAmountRequest = mortgageRedemptionHelper.settlementAmountRequest();
        settlementAmountRequest.setRedemptionDate("2002-11-22");
        MortgageRedemptionValidator mortgageRedemptionValidator = new MortgageRedemptionValidator(mortgageAccountInfoRestClient);
        mortgageRedemptionValidator.validateSettlementAmountRequest(settlementAmountRequest,accountId);

    }

    @Test(expected = InvalidUpdateRequestException.class)
    public void validateSettlementAmountRequest_redemption_date_more_than_thirty_days() {
        SettlementAmountRequest settlementAmountRequest = mortgageRedemptionHelper.settlementAmountRequest();
        settlementAmountRequest.setRedemptionDate(LocalDate.now(ZoneId.systemDefault()).plusDays(40).toString());
        MortgageRedemptionValidator mortgageRedemptionValidator = new MortgageRedemptionValidator(mortgageAccountInfoRestClient);
        mortgageRedemptionValidator.validateSettlementAmountRequest(settlementAmountRequest, accountId);
    }

    @Test
    public void testSolicitorValidation(){
        RedemptionStatementPayloadRequest payloadRequest=mortgageRedemptionHelper.getRedemptionStatementSolicitorRequestPayload();
        MortgageRedemptionValidator mortgageRedemptionValidator = new MortgageRedemptionValidator(mortgageAccountInfoRestClient);
        List<String> errors = mortgageRedemptionValidator.validateRedemptionStatementPayload(payloadRequest);
        Assertions.assertTrue(errors.isEmpty());
    }

    @Test
    public void testSolicitorValidationBadRequest(){
        RedemptionStatementPayloadRequest payloadRequest=mortgageRedemptionHelper.getRedemptionStatementSolicitorRequestPayloadBad();
        MortgageRedemptionValidator mortgageRedemptionValidator = new MortgageRedemptionValidator(mortgageAccountInfoRestClient);
        List<String> errors = mortgageRedemptionValidator.validateRedemptionStatementPayload(payloadRequest);
        Assertions.assertEquals(5, errors.size());
    }



    @Test
    public void testSolicitorMissingAttributesValidation(){
        RedemptionStatementPayloadRequest payloadRequest=mortgageRedemptionHelper.getRedemptionStatementRequest();
        payloadRequest.setRecipient(Recipient.SOLICITOR);
        payloadRequest.setRecipientName(null);

        MortgageRedemptionValidator mortgageRedemptionValidator = new MortgageRedemptionValidator(mortgageAccountInfoRestClient);
        List<String> errors = mortgageRedemptionValidator.validateRedemptionStatementPayload(payloadRequest);
        Assertions.assertTrue(errors.size()==5);
    }

    @Test
    public void testSolicitorMissing4AttributesValidation(){
        RedemptionStatementPayloadRequest payloadRequest=mortgageRedemptionHelper.getRedemptionStatementRequest();
        payloadRequest.setRecipient(Recipient.SOLICITOR);
        payloadRequest.setRecipientName("Ed");

        MortgageRedemptionValidator mortgageRedemptionValidator = new MortgageRedemptionValidator(mortgageAccountInfoRestClient);
        List<String> errors = mortgageRedemptionValidator.validateRedemptionStatementPayload(payloadRequest);
        Assertions.assertTrue(errors.size()==4);
    }

}
