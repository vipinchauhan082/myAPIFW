package com.lbg.epscw.mortgagesrvc.restclient;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.lbg.epscw.mortgagesrvc.dto.MortgageAccountInfo;
import com.lbg.epscw.mortgagesrvc.exception.MortgageServiceException;
import com.lbg.epscw.mortgagesrvc.helper.MortgageAccountDataHelper;
import com.lbg.epscw.mortgagesrvc.service.RestClientService;
import com.lbg.epscw.mortgagesrvc.util.MortgageServiceUtil;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;

import java.text.MessageFormat;
import java.util.HashMap;

import static org.junit.Assert.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.internal.util.reflection.FieldSetter.setField;
import static org.powermock.api.mockito.PowerMockito.when;

@RunWith(PowerMockRunner.class)
@PrepareForTest({MessageFormat.class})
public class MortgageAccountInfoRestClientTest {
    private final MortgageAccountDataHelper helper = new MortgageAccountDataHelper();

    @Value("${mortgage.account.info.get.endpoint}")
    private String mortgageAccountInfoGetEndpoint;

    @Value("${mortgage.number.info.get.endpoint}")
    private String mortgageNumberInfoGetEndpoint;

    @Mock
    RestClientService restClientService;

    @Mock
    MortgageServiceUtil mortgageServiceUtil;

    @Autowired
    private ObjectMapper mapper;

    @InjectMocks
    private MortgageAccountInfoRestClient underTest;

    @Before
    public void setup() {
        this.mapper = new ObjectMapper();
    }

    @Test
    public void get_mortgage_info_by_accountId() throws JsonProcessingException, NoSuchFieldException, SecurityException {

        MortgageAccountInfo accountInfo = helper.buildViewAccountInfo();
        setField(underTest,
                underTest.getClass().getDeclaredField("mortgageAccountInfoGetEndpoint"), "mortgageAccountInfoGetEndpoint");

        when(mortgageServiceUtil.fetchDefaultVaultHeaders()).thenReturn(new HashMap<>());
        when(mortgageServiceUtil.readObject(any(String.class), any())).thenReturn(accountInfo);
        when(restClientService.get(anyString(), anyMap())).thenReturn(mapper.writeValueAsString(accountInfo));
        MortgageAccountInfo response = underTest.getMortgageAccountInfo("1b69ad2f-63b3-c70f-6f52-ee85b97e314d", new HashMap<>());
        assertNotNull(response);
        assertEquals("1b69ad2f-63b3-c70f-6f52-ee85b97e314d", response.getMortgageAccountData().get(0).getAccountId());
    }

    @Test
    public void get_mortgage_info_by_mortgage_number() throws JsonProcessingException, NoSuchFieldException, SecurityException {

        MortgageAccountInfo accountInfo = helper.buildViewAccountInfo();
        setField(underTest, underTest.getClass().getDeclaredField("mortgageNumberInfoGetEndpoint"), "mortgageNumberInfoGetEndpoint");

        when(mortgageServiceUtil.fetchDefaultVaultHeaders()).thenReturn(new HashMap<>());
        when(mortgageServiceUtil.readObject(anyString(), any())).thenReturn(accountInfo);
        when(restClientService.get(anyString(), anyMap())).thenReturn(mapper.writeValueAsString(accountInfo));
        MortgageAccountInfo response = underTest.getMortgageInfoByMortgageNumber("1b69ad2f-63b3-c70f-6f52-ee85b97e314d", new HashMap<>());
        assertNotNull(response);
        assertEquals("1b69ad2f-63b3-c70f-6f52-ee85b97e314d", response.getMortgageAccountData().get(0).getAccountId());
    }

    @Test(expected = MortgageServiceException.class)
    public void get_mortgage_info_by_accountId_not_found() throws NoSuchFieldException, SecurityException {

        MortgageAccountInfo accountInfo = helper.buildViewAccountInfo();
        setField(underTest, underTest.getClass().getDeclaredField("mortgageAccountInfoGetEndpoint"), "mortgageAccountInfoGetEndpoint");

        when(mortgageServiceUtil.fetchDefaultVaultHeaders()).thenReturn(new HashMap<>());
        when(mortgageServiceUtil.readObject(anyString(), any())).thenReturn(accountInfo);

        when(restClientService.get(anyString(), anyMap())).thenReturn(null);
        underTest.getMortgageAccountInfo("1b69ad2f-63b3-c70f-6f52-ee85b97e314d", new HashMap<>());
    }

    @Test(expected = MortgageServiceException.class)
    public void get_mortgage_info_by_mortgage_number_not_found() throws NoSuchFieldException, SecurityException {

        MortgageAccountInfo accountInfo = helper.buildViewAccountInfo();
        setField(underTest, underTest.getClass().getDeclaredField("mortgageNumberInfoGetEndpoint"), "mortgageNumberInfoGetEndpoint");

        when(mortgageServiceUtil.fetchDefaultVaultHeaders()).thenReturn(new HashMap<>());
        when(mortgageServiceUtil.readObject(anyString(), any())).thenReturn(accountInfo);

        when(restClientService.get(anyString(), anyMap())).thenReturn(null);
        underTest.getMortgageInfoByMortgageNumber("1b69ad2f-63b3-c70f-6f52-ee85b97e314d", new HashMap<>());
    }
}
