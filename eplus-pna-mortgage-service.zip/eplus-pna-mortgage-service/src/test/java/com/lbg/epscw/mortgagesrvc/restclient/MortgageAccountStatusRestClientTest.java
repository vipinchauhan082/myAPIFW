package com.lbg.epscw.mortgagesrvc.restclient;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.lbg.epscw.mortgagesrvc.dto.VaultAccountResponse;
import com.lbg.epscw.mortgagesrvc.dto.VaultAccountStatusUpdateRequest;
import com.lbg.epscw.mortgagesrvc.exception.MortgageServiceException;
import com.lbg.epscw.mortgagesrvc.helper.MortgageAccountClosureHelper;
import com.lbg.epscw.mortgagesrvc.model.AccountPortingStatusResponse;
import com.lbg.epscw.mortgagesrvc.model.AccountStatus;
import com.lbg.epscw.mortgagesrvc.model.AccountStatusUpdateRequest;
import com.lbg.epscw.mortgagesrvc.service.RestClientService;
import com.lbg.epscw.mortgagesrvc.util.MortgageServiceUtil;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.internal.util.reflection.FieldSetter;
import org.mockito.invocation.InvocationOnMock;
import org.mockito.stubbing.Answer;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;

import java.text.MessageFormat;
import java.util.HashMap;
import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.mockito.ArgumentMatchers.any;
import static org.powermock.api.mockito.PowerMockito.when;

@RunWith(PowerMockRunner.class)
@PrepareForTest({ MessageFormat.class })
public class MortgageAccountStatusRestClientTest {

    @Value("mortgageAccountStatusUpdateEndpoint")
    private String mortgageAccountStatusUpdateEndpoint;

    @Value("vaultAccountStatusUpdateEndpoint")
    private String vaultAccountStatusUpdateEndpoint;

    @Mock
    RestClientService restClientService;

    @Mock
    MortgageServiceUtil mortgageServiceUtil;

    @Autowired
    private ObjectMapper mapper;

    private MortgageAccountClosureHelper mortgageAccountClosureHelper = new MortgageAccountClosureHelper();

    @InjectMocks
    private MortgageAccountStatusRestClient mortgageAccountStatusRestClient;

    @Before
    public void setup() {
        this.mapper = new ObjectMapper();
    }


    @Test
    public void update_acc_status() throws JsonProcessingException, NoSuchFieldException, SecurityException {

        VaultAccountResponse accountStatusUpdateResponse = mortgageAccountClosureHelper
                .buildAccountClosureVaultResponse();
        String stringifyResponse = null;
        FieldSetter.setField(mortgageAccountStatusRestClient,
                mortgageAccountStatusRestClient.getClass().getDeclaredField("vaultAccountStatusUpdateEndpoint"),"");

        stringifyResponse = mapper.writeValueAsString(accountStatusUpdateResponse);

        when(mortgageServiceUtil.fetchDefaultVaultHeaders()).thenReturn(new HashMap<String, String>());
        when(mortgageServiceUtil.writeObjectAsString(any(VaultAccountStatusUpdateRequest.class)))
                .thenReturn(stringifyResponse);

        when(mortgageServiceUtil.readObject(any(String.class), any(Class.class)))
                .thenReturn(accountStatusUpdateResponse);

        when(restClientService.put(any(String.class), any(HashMap.class), any(String.class)))
                .thenReturn(stringifyResponse);

        VaultAccountStatusUpdateRequest vaultRequest = mortgageAccountClosureHelper.buildAccountClosureVaultRequest();

        VaultAccountResponse response = mortgageAccountStatusRestClient.updateAccountStatus("b2c9119f-09e5-4ac9-9738-9e28b334d3fa", vaultRequest);
        assertNotNull(response);
        assertEquals("b2c9119f-09e5-4ac9-9738-9e28b334d3fa",response.getAccountId());
        assertEquals("ACCOUNT_STATUS_PENDING_CLOSURE",response.getStatus());
    }

    @Test(expected = MortgageServiceException.class)
    public void update_acc_status_fails() throws JsonProcessingException, NoSuchFieldException, SecurityException {

        VaultAccountResponse accountStatusUpdateResponse = mortgageAccountClosureHelper
                .buildAccountClosureVaultResponse();
        String stringifyResponse = null;
        FieldSetter.setField(mortgageAccountStatusRestClient,
                mortgageAccountStatusRestClient.getClass().getDeclaredField("vaultAccountStatusUpdateEndpoint"),"");

        stringifyResponse = mapper.writeValueAsString(accountStatusUpdateResponse);

        when(mortgageServiceUtil.fetchDefaultVaultHeaders()).thenReturn(new HashMap<String, String>());
        when(mortgageServiceUtil.writeObjectAsString(any(VaultAccountStatusUpdateRequest.class)))
                .thenReturn(stringifyResponse);

        when(mortgageServiceUtil.readObject(any(String.class), any(Class.class)))
                .thenReturn(accountStatusUpdateResponse);

        when(restClientService.put(any(String.class), any(HashMap.class), any(String.class)))
                .thenThrow(new MortgageServiceException("VAULT","VAULT_ERROR"));

        VaultAccountStatusUpdateRequest vaultRequest = mortgageAccountClosureHelper.buildAccountClosureVaultRequest();

        mortgageAccountStatusRestClient.updateAccountStatus("b2c9119f-09e5-4ac9-9738-9e28b334d3fa", vaultRequest);

    }

    @Test
    public void update_mortgage_acc_status() throws JsonProcessingException, NoSuchFieldException, SecurityException {

        List<AccountPortingStatusResponse> accountStatusUpdateResponse = mortgageAccountClosureHelper
                .buildAccountStatusUpdateResponse();
        String stringifyResponse = null;
        FieldSetter.setField(mortgageAccountStatusRestClient,
                mortgageAccountStatusRestClient.getClass().getDeclaredField("mortgageAccountStatusUpdateEndpoint"),"");

        stringifyResponse = mapper.writeValueAsString(accountStatusUpdateResponse);

        when(mortgageServiceUtil.writeObjectAsString(any(AccountStatusUpdateRequest.class)))
                .thenReturn(stringifyResponse);

        when(mortgageServiceUtil.readList(any(String.class), any(Class.class)))
                .thenReturn(accountStatusUpdateResponse);

        when(restClientService.put(any(String.class), any(HashMap.class), any(String.class)))
                .thenReturn(stringifyResponse);

        VaultAccountStatusUpdateRequest vaultRequest = mortgageAccountClosureHelper.buildAccountClosureVaultRequest();

        List<AccountPortingStatusResponse> response = mortgageAccountStatusRestClient.mortgageAccountStatusUpdate(AccountStatusUpdateRequest.builder().overarchingAccount("1b69ad2f-63b3-c70f-6f52-ee85b97e314d").accountStatus(AccountStatus.ACCOUNT_STATUS_CANCELLED).build(), mortgageAccountClosureHelper.generateRequestHeaders());
        assertNotNull(response);
        assertEquals("b2c9119f-09e5-4ac9-9738-9e28b334d3fa",response.get(0).getAccountId());
        assertEquals("ACCOUNT_STATUS_CANCELLED",response.get(0).getStatus());
    }

    @Test(expected = MortgageServiceException.class)
    public void update_mortgage_acc_status_when_vault_fails() throws JsonProcessingException, NoSuchFieldException, SecurityException {

        List<AccountPortingStatusResponse> accountStatusUpdateResponse = mortgageAccountClosureHelper
                .buildAccountStatusUpdateResponse();
        String stringifyResponse = null;
        FieldSetter.setField(mortgageAccountStatusRestClient,
                mortgageAccountStatusRestClient.getClass().getDeclaredField("mortgageAccountStatusUpdateEndpoint"),"");

        stringifyResponse = mapper.writeValueAsString(accountStatusUpdateResponse);

        when(mortgageServiceUtil.writeObjectAsString(any(AccountStatusUpdateRequest.class)))
                .thenReturn(stringifyResponse);

        when(mortgageServiceUtil.readList(any(String.class), any(Class.class)))
                .thenReturn(accountStatusUpdateResponse);

        final String strResponse = stringifyResponse;
        when(restClientService.put(any(String.class), any(HashMap.class), any(String.class))).thenAnswer(new Answer() {
            private int count = 0;

            public Object answer(InvocationOnMock invocation) {
                if (count++ == 1)
                    return strResponse;

                throw new MortgageServiceException("VAULT","VAULT_ERROR");
            }
        });

        mortgageAccountStatusRestClient.mortgageAccountStatusUpdate(AccountStatusUpdateRequest.builder().overarchingAccount("1b69ad2f-63b3-c70f-6f52-ee85b97e314d").accountStatus(AccountStatus.ACCOUNT_STATUS_CANCELLED).build(), mortgageAccountClosureHelper.generateRequestHeaders());

    }


}