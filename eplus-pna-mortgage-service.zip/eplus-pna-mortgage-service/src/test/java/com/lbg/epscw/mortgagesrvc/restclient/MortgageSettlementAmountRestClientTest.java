package com.lbg.epscw.mortgagesrvc.restclient;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.lbg.epscw.mortgagesrvc.dto.SettlementAmountInfo;
import com.lbg.epscw.mortgagesrvc.exception.MortgageServiceException;
import com.lbg.epscw.mortgagesrvc.helper.MortgageRedemptionHelper;
import com.lbg.epscw.mortgagesrvc.service.RestClientService;
import com.lbg.epscw.mortgagesrvc.util.MortgageServiceUtil;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;

import java.text.MessageFormat;
import java.util.HashMap;

import static com.lbg.epscw.mortgagesrvc.helper.MortgageRedemptionHelper.REDEMPTION_DATE;
import static org.junit.Assert.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.internal.util.reflection.FieldSetter.setField;
import static org.powermock.api.mockito.PowerMockito.when;

@RunWith(PowerMockRunner.class)
@PrepareForTest({MessageFormat.class})

public class MortgageSettlementAmountRestClientTest {

    private final MortgageRedemptionHelper helper = new MortgageRedemptionHelper();

    @Value("${mortgage.settlement.amount.info.get.endpoint}")
    private String mortgageSettlementAmountInfoGetEndpoint;

    @Value("${self.system.id}")
    private String internalSystemId;

    @Mock
    RestClientService restClientService;

    @Mock
    MortgageServiceUtil mortgageServiceUtil;

    @Autowired
    private ObjectMapper mapper;

    @InjectMocks
    private MortgageSettlementAmountRestClient underTest;

    @Before
    public void setup() {
        this.mapper = new ObjectMapper();
    }

    @Test
    public void get_settlement_amount() throws NoSuchFieldException, JsonProcessingException {
        SettlementAmountInfo settlementAmountInfoResponse = helper.settlementAmountInfoResponse();
        setField(underTest, underTest.getClass().getDeclaredField("mortgageSettlementAmountInfoGetEndpoint"), "mortgageSettlementAmountInfoGetEndpoint");

        String stringResponse = mapper.writeValueAsString(settlementAmountInfoResponse);
        when(mortgageServiceUtil.readObject(any(String.class), any())).thenReturn(settlementAmountInfoResponse);
        when(restClientService.get(anyString(), anyMap())).thenReturn(stringResponse);

        SettlementAmountInfo response = underTest.getSettlementAmountInfo("1b69ad2f-63b3-c70f-6f52-ee85b97e314d", REDEMPTION_DATE ,new HashMap<>());

        assertNotNull(response);
        assertEquals("1b69ad2f-63b3-c70f-6f52-ee85b97e314d", response.getSettlementAmount().getAggregatedSettlementAmountInfo().getAccountId());
    }

    @Test
    public void get_settlement_amount_code_coverage_for_mock_enabled() throws NoSuchFieldException, JsonProcessingException {
        SettlementAmountInfo settlementAmountInfoResponse = helper.settlementAmountInfoResponse();
        setField(underTest, underTest.getClass().getDeclaredField("mortgageSettlementAmountInfoGetEndpoint"), "mortgageSettlementAmountInfoGetEndpoint");

        setField(underTest, underTest.getClass().getDeclaredField("isMockEnabled"), true);

        String stringResponse = mapper.writeValueAsString(settlementAmountInfoResponse);
        when(mortgageServiceUtil.readObject(any(String.class), any())).thenReturn(settlementAmountInfoResponse);
        when(restClientService.get(anyString(), anyMap())).thenReturn(stringResponse);

        SettlementAmountInfo response = underTest.getSettlementAmountInfo("1b69ad2f-63b3-c70f-6f52-ee85b97e314d", REDEMPTION_DATE ,new HashMap<>());

        assertNotNull(response);
        assertEquals("1b69ad2f-63b3-c70f-6f52-ee85b97e314d", response.getSettlementAmount().getAggregatedSettlementAmountInfo().getAccountId());
    }

    @Test(expected = MortgageServiceException.class)
    public void get_settlement_amount_not_found() throws NoSuchFieldException {
        SettlementAmountInfo settlementAmountInfoResponse = helper.settlementAmountInfoResponse();
        setField(underTest, underTest.getClass().getDeclaredField("mortgageSettlementAmountInfoGetEndpoint"), "mortgageSettlementAmountInfoGetEndpoint");

        when(mortgageServiceUtil.readObject(any(String.class), any())).thenReturn(settlementAmountInfoResponse);
        when(restClientService.get(anyString(), anyMap())).thenReturn(null);

        underTest.getSettlementAmountInfo("1b69ad2f-63b3-c70f-6f52-ee85b97e314d", REDEMPTION_DATE ,new HashMap<>());
    }


}
