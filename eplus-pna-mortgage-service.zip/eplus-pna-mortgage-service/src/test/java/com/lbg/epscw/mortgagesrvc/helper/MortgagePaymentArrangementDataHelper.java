package com.lbg.epscw.mortgagesrvc.helper;

import com.lbg.epscw.mortgagesrvc.constants.CommonConstants;
import com.lbg.epscw.mortgagesrvc.dto.MortgageAccountData;
import com.lbg.epscw.mortgagesrvc.dto.MortgageAccountInfo;
import com.lbg.epscw.mortgagesrvc.model.*;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Component
public class MortgagePaymentArrangementDataHelper {

    public HttpHeaders getAccountInfoHeaders() {
        HttpHeaders httpHeaders = new HttpHeaders();
        httpHeaders.add("Authorization", "Bearer b2c9119f-09e5-4ac9-9738-9e28b334d3fa");
        httpHeaders.add("x-lbg-internal-system-id", "test");
        httpHeaders.add("x-lbg-brand", "IF");
        httpHeaders.add("x-lbg-txn-correlation-id", "123-456-789-123");
        httpHeaders.setContentType(MediaType.APPLICATION_JSON);
        return httpHeaders;
    }

    public AccountOptionsUpdateResponse buildOverPaymentUpdateResponse(String paramName, String paramValue) {
        AccountOptionsUpdateResponse response = new AccountOptionsUpdateResponse();
        response.setAccountId("b2c9119f-09e5-4ac9-9738-9e28b334d3fa");
        InstanceParamValsUpdate instanceParamValsUpdate = new InstanceParamValsUpdate();
        HashMap<String, String> instanceParamMap = new HashMap<String, String>();
        instanceParamMap.put(paramName, paramValue);
        instanceParamValsUpdate.setInstanceParamVals(instanceParamMap);
        response.setInstanceParamValsUpdate(instanceParamValsUpdate);
        response.setStatus("ACCOUNT_UPDATE_STATUS_PENDING_EXECUTION");
        return response;
    }

    public PaymentArrangementUpdateRequest buildOPaymentArrangementUpdateRequestAmendAmountStartDateAndEndDate(String amount, String startDate,String endDate) {
        PaymentArrangementUpdateRequest request = new PaymentArrangementUpdateRequest();
        request.setPaymentArrangementAmount(amount);
        request.setPaymentArrangementEndMonth(endDate);
        request.setPaymentArrangementStartMonth(startDate);
        return request;
    }

    public PaymentArrangementResponse buildPaymentArrangementUpdateAmountAndEndDateUserResponse(String amount, String endDate) {
        PaymentArrangementResponse response = new PaymentArrangementResponse();
        response.setAccountId("b2c9119f-09e5-4ac9-9738-9e28b334d3fa");
        response.setStatus("ACCOUNT_UPDATE_STATUS_PENDING_EXECUTION");
        HashMap<String, String> instanceParamMap = new HashMap<String, String>();
        instanceParamMap.put(CommonConstants.PAYMENT_ARRANGEMENT_AMOUNT, amount);
        instanceParamMap.put(CommonConstants.PAYMENT_ARRANGEMENT_END_MONTH, endDate);
        response.setInstanceParamVals(instanceParamMap);
        return response;
    }

    public PaymentArrangementResponse buildPaymentArrangementCancelResponse(String amount) {
        PaymentArrangementResponse response = new PaymentArrangementResponse();
        response.setAccountId("b2c9119f-09e5-4ac9-9738-9e28b334d3fa");
        response.setStatus("ACCOUNT_UPDATE_STATUS_PENDING_EXECUTION");
        HashMap<String, String> instanceParamMap = new HashMap<String, String>();
        instanceParamMap.put(CommonConstants.PAYMENT_ARRANGEMENT_AMOUNT, amount);
        instanceParamMap.put(CommonConstants.PAYMENT_ARRANGEMENT_END_MONTH, "");
        response.setInstanceParamVals(instanceParamMap);
        return response;
    }


    public MortgageAccountInfo mortgageAccountInfoWithPaymentArrangement(boolean paymentArrangement) {

        MortgageAccountInfo mortgageAccountInfo = new MortgageAccountInfo();
        List<MortgageAccountData> mortgageAccountDataList = new ArrayList<>();
        MortgageAccountData mortgageAccountData = new MortgageAccountData();
        mortgageAccountData.setProductId("lbg_mortgage");
        if (paymentArrangement) {
            mortgageAccountData.setPaymentArrangementAmountType("FIXED_PAYMENT_AMOUNT");
            mortgageAccountData.setPaymentArrangementType("OVERPAYMENT");
            mortgageAccountData.setPaymentArrangementStartMonth("11/2040");
            mortgageAccountData.setPaymentArrangementEndMonth("11-2042");
            mortgageAccountData.setKeyDate("7");
        }
        mortgageAccountData.setStatus("ACCOUNT_STATUS_OPEN");
        mortgageAccountDataList.add(mortgageAccountData);
        mortgageAccountInfo.setMortgageAccountData(mortgageAccountDataList);
        return mortgageAccountInfo;


    }
     public MortgageAccountInfo mortgageAccountInfoWithInvalidPaymentArrangementType(){
         MortgageAccountInfo mortgageAccountInfo = new MortgageAccountInfo();
         List<MortgageAccountData> mortgageAccountDataList = new ArrayList<>();
         MortgageAccountData mortgageAccountData = new MortgageAccountData();
         mortgageAccountData.setProductId("lbg_mortgage");
         mortgageAccountData.setStatus("ACCOUNT_STATUS_OPEN");
         mortgageAccountData.setPaymentArrangementType("OVERPAYMENTS");
         mortgageAccountData.setPaymentArrangementAmountType("FIXED_PAYMENT_AMOUNT");
         mortgageAccountData.setPaymentArrangementEndMonth("08/2020");
         mortgageAccountDataList.add(mortgageAccountData);
         mortgageAccountInfo.setMortgageAccountData(mortgageAccountDataList);
         return mortgageAccountInfo;
     }

    public MortgageAccountInfo mortgageAccountInfoWithPaymentArrangementWithExpiredEndDate() {

        MortgageAccountInfo mortgageAccountInfo = new MortgageAccountInfo();
        List<MortgageAccountData> mortgageAccountDataList = new ArrayList<>();
        MortgageAccountData mortgageAccountData = new MortgageAccountData();
        mortgageAccountData.setProductId("lbg_mortgage");
        mortgageAccountData.setKeyDate("7");
        mortgageAccountData.setStatus("ACCOUNT_STATUS_OPEN");
        mortgageAccountData.setPaymentArrangementType("OVERPAYMENT");
        mortgageAccountData.setPaymentArrangementAmountType("FIXED_PAYMENT_AMOUNT");
        mortgageAccountData.setPaymentArrangementStartMonth("08/2020");
        mortgageAccountData.setPaymentArrangementEndMonth("09/2020");
        mortgageAccountDataList.add(mortgageAccountData);
        mortgageAccountInfo.setMortgageAccountData(mortgageAccountDataList);
        return mortgageAccountInfo;
    }

    public MortgageAccountInfo mortgageAccountInfoWithPaymentArrangement() {

        MortgageAccountInfo mortgageAccountInfo = new MortgageAccountInfo();
        List<MortgageAccountData> mortgageAccountDataList = new ArrayList<>();
        MortgageAccountData mortgageAccountData = new MortgageAccountData();
        mortgageAccountData.setProductId("lbg_mortgage");
        mortgageAccountData.setStatus("ACCOUNT_STATUS_OPEN");
        mortgageAccountData.setPaymentArrangementType("OVERPAYMENT");
        mortgageAccountData.setPaymentArrangementAmountType("FIXED_PAYMENT_AMOUNT");
        mortgageAccountData.setPaymentArrangementStartMonth("08/2030");
        mortgageAccountData.setPaymentArrangementEndMonth("09/2032");
        mortgageAccountDataList.add(mortgageAccountData);
        mortgageAccountInfo.setMortgageAccountData(mortgageAccountDataList);
        return mortgageAccountInfo;
    }

    public MortgageAccountInfo mortgageAccountInfoWithPaymentArrangementAmountType() {

        MortgageAccountInfo mortgageAccountInfo = new MortgageAccountInfo();
        List<MortgageAccountData> mortgageAccountDataList = new ArrayList<>();
        MortgageAccountData mortgageAccountData = new MortgageAccountData();
        mortgageAccountData.setProductId("lbg_mortgage");
        mortgageAccountData.setPaymentArrangementAmountType("GENERIC_OVERPAYMENT");
        mortgageAccountData.setPaymentArrangementType("OVERPAYMENT");
        mortgageAccountData.setPaymentArrangementStartMonth("10/2031");
        mortgageAccountData.setStatus("ACCOUNT_STATUS_OPEN");
        mortgageAccountDataList.add(mortgageAccountData);
        mortgageAccountInfo.setMortgageAccountData(mortgageAccountDataList);
        return mortgageAccountInfo;
    }

    public MortgageAccountInfo mortgageAccountInfoWithStartDateGreaterThanEndDate() {

        MortgageAccountInfo mortgageAccountInfo = new MortgageAccountInfo();
        List<MortgageAccountData> mortgageAccountDataList = new ArrayList<>();
        MortgageAccountData mortgageAccountData = new MortgageAccountData();
        mortgageAccountData.setProductId("lbg_mortgage");
        mortgageAccountData.setPaymentArrangementAmountType("GENERIC_OVERPAYMENT");
        mortgageAccountData.setPaymentArrangementType("OVERPAYMENT");
        mortgageAccountData.setPaymentArrangementStartMonth("10/2031");
        mortgageAccountData.setPaymentArrangementEndMonth("10/2030");
        mortgageAccountData.setPaymentArrangementAmount("100");
        mortgageAccountData.setPaymentArrangementAmountType("FIXED_PAYMENT_AMOUNT");
        mortgageAccountData.setStatus("ACCOUNT_STATUS_OPEN");
        mortgageAccountDataList.add(mortgageAccountData);
        mortgageAccountInfo.setMortgageAccountData(mortgageAccountDataList);
        return mortgageAccountInfo;


    }



    public MortgageAccountInfo mortgageQueryServiceAccountInfoWithAndWithoutSubaccount(boolean mortgageAccount) {

        if (mortgageAccount) {
            MortgageAccountInfo mortgageAccountInfo = new MortgageAccountInfo();
            List<MortgageAccountData> mortgageAccountDataList = new ArrayList<>();
            MortgageAccountData mortgageAccountData = new MortgageAccountData();
            mortgageAccountData.setProductId("lbg_mortgage");
            mortgageAccountData.setKeyDate("25");
            mortgageAccountData.setPaymentArrangementAmount("400");
            mortgageAccountData.setPaymentArrangementStartMonth("03/2039");
            mortgageAccountData.setPaymentArrangementEndMonth("03/2040");
            mortgageAccountData.setPaymentArrangementAmountType("FIXED_PAYMENT_AMOUNT");
            mortgageAccountData.setPaymentArrangementType("OVERPAYMENT");
            mortgageAccountData.setStatus("ACCOUNT_STATUS_OPEN");
            mortgageAccountDataList.add(mortgageAccountData);
            mortgageAccountInfo.setMortgageAccountData(mortgageAccountDataList);
            return mortgageAccountInfo;
        } else {
            MortgageAccountInfo mortgageAccountInfo = new MortgageAccountInfo();
            List<MortgageAccountData> mortgageAccountDataList = new ArrayList<>();
            MortgageAccountData mortgageAccountData = new MortgageAccountData();
            mortgageAccountData.setProductId("lbg_mortgage_repayment");
            mortgageAccountData.setMortgageNumber("00113");
            mortgageAccountData.setStatus("ACCOUNT_STATUS_OPEN");
            mortgageAccountDataList.add(mortgageAccountData);
            MortgageAccountData mortgageAccountData1 = new MortgageAccountData();
            mortgageAccountData1.setProductId("lbg_mortgage_repayment");
            mortgageAccountData1.setMortgageNumber("00113");
            mortgageAccountDataList.add(mortgageAccountData);
            mortgageAccountInfo.setMortgageAccountData(mortgageAccountDataList);
            return mortgageAccountInfo;
        }

    }


    public PaymentArrangementUpdateRequest buildPaymentArrangementUpdateRequestAmendAmount(String amount) {
        PaymentArrangementUpdateRequest request = new PaymentArrangementUpdateRequest();
        request.setPaymentArrangementAmount(amount);
        request.setPaymentArrangementStartMonth("03/2038");
        return request;
    }

    public PaymentArrangementUpdateRequest buildPaymentArrangementUpdateRequestWithPastStartDate() {
        PaymentArrangementUpdateRequest request = new PaymentArrangementUpdateRequest();
        request.setPaymentArrangementAmount("100");
        request.setPaymentArrangementStartMonth("03/2019");
        request.setPaymentArrangementEndMonth("03/2021");
        return request;
    }

    public PaymentArrangementUpdateRequest buildPaymentArrangementUpdateRequestWithGreaterStartDate() {
        PaymentArrangementUpdateRequest request = new PaymentArrangementUpdateRequest();
        request.setPaymentArrangementAmount("100");
        request.setPaymentArrangementStartMonth("03/2030");
        request.setPaymentArrangementEndMonth("03/2021");
        return request;
    }

    public PaymentArrangementUpdateRequest buildPaymentArrangementUpdateRequestWithEndDateAfter() {
        PaymentArrangementUpdateRequest request = new PaymentArrangementUpdateRequest();
        request.setPaymentArrangementAmount("100");
        request.setPaymentArrangementStartMonth("08/2029");
        request.setPaymentArrangementEndMonth("03/2033");
        return request;
    }

    public PaymentArrangementUpdateRequest buildPaymentArrangementUpdateRequestWithPastEndDate() {
        PaymentArrangementUpdateRequest request = new PaymentArrangementUpdateRequest();
        request.setPaymentArrangementAmount("100");
        request.setPaymentArrangementStartMonth("03/2022");
        request.setPaymentArrangementEndMonth("03/2019");
        return request;
    }

    public PaymentArrangementUpdateRequest buildPaymentArrangementUpdateRequestAmount(String amount) {
        PaymentArrangementUpdateRequest request = new PaymentArrangementUpdateRequest();
        request.setPaymentArrangementAmount(amount);
        return request;
    }

    public PaymentArrangementUpdateRequest buildPaymentArrangementUpdateRequestAmendAmountAndEndDate(String amount, String endDate) {
        PaymentArrangementUpdateRequest request = new PaymentArrangementUpdateRequest();
        request.setPaymentArrangementAmount(amount);
        request.setPaymentArrangementEndMonth(endDate);
        request.setPaymentArrangementStartMonth("07/2029");
        return request;
    }

    public Map<String,String> readObjectrespone(){
        Map<String,String> readObjectMap= new HashMap<>();
        readObjectMap.put("PaymentArrangementEndMonth", "11-2020");
        readObjectMap.put("PaymentArrangementAmount","123.45");
        return readObjectMap;

    }

    public String getMortgageQueryServiceResponse() {
        return "{\n" +
                "    \"Data\": [\n" +
                "        {\n" +
                "            \"mortgageNumber\": \"number_1112\",\n" +
                "            \"mortgagePrincipal\": \"4000\",\n" +
                "            \"keyDate\": \"7\",\n" +
                "            \"mortgageType\": \"INTEREST_ONLY\",\n" +
                "            \"totalTerm\": \"24\",\n" +
                "            \"productId\": \"lbg_mortgage\",\n" +
                "            \"accountStatus\": \"ACCOUNT_STATUS_OPEN\",\n" +
                "            \"paymentArrangementType\": \"OVERPAYMENT\",\n" +
                "            \"paymentArrangementAmountType\": \"FIXED_PAYMENT_AMOUNT\",\n" +
                "            \"paymentArrangementEndMonth\": \"02/2050\",\n" +
                "            \"paymentArrangementStartMonth\": \"02/2048\",\n" +
                "            \"accountId\": \"1601d0e5-e336-64d9-64ad-89ba6fdc2677\"\n" +
                "        }\n" +

                "    ]\n" +
                "}";
    }

    public String getMortgageQueryServiceResponseWithPastEndDate() {
        return "{\n" +
                "    \"Data\": [\n" +
                "        {\n" +
                "            \"mortgageNumber\": \"number_1112\",\n" +
                "            \"mortgagePrincipal\": \"4000\",\n" +
                "            \"keyDate\": \"7\",\n" +
                "            \"mortgageType\": \"INTEREST_ONLY\",\n" +
                "            \"totalTerm\": \"24\",\n" +
                "            \"productId\": \"lbg_mortgage\",\n" +
                "            \"paymentArrangementType\": \"OVERPAYMENT\",\n" +
                "            \"paymentArrangementAmountType\": \"FIXED_PAYMENT_AMOUNT\",\n" +
                "            \"paymentArrangementStartMonth\": \"02/2018\",\n" +
                "            \"accountStatus\": \"ACCOUNT_STATUS_OPEN\",\n" +
                "            \"accountId\": \"1601d0e5-e336-64d9-64ad-89ba6fdc2677\"\n" +
                "        }\n" +

                "    ]\n" +
                "}";
    }

    public String getMortgageQueryServiceResponseWithInvalidDateFormat() {
        return "{\n" +
                "    \"Data\": [\n" +
                "        {\n" +
                "            \"mortgageNumber\": \"number_1112\",\n" +
                "            \"mortgagePrincipal\": \"4000\",\n" +
                "            \"keyDate\": \"7\",\n" +
                "            \"mortgageType\": \"INTEREST_ONLY\",\n" +
                "            \"totalTerm\": \"24\",\n" +
                "            \"productId\": \"lbg_mortgage\",\n" +
                "            \"paymentArrangementType\": \"OVERPAYMENT\",\n" +
                "            \"paymentArrangementAmountType\": \"FIXED_PAYMENT_AMOUNT\",\n" +
                "            \"paymentArrangementStartMonth\": \"02-2018\",\n" +
                "            \"accountStatus\": \"ACCOUNT_STATUS_OPEN\",\n" +
                "            \"accountId\": \"1601d0e5-e336-64d9-64ad-89ba6fdc2677\"\n" +
                "        }\n" +

                "    ]\n" +
                "}";
    }



    public String getMortgageQueryServiceResponseWithStartAndNoEndDate() {
        return "{\n" +
                "    \"Data\": [\n" +
                "        {\n" +
                "            \"mortgageNumber\": \"number_1112\",\n" +
                "            \"mortgagePrincipal\": \"4000\",\n" +
                "            \"keyDate\": \"7\",\n" +
                "            \"mortgageType\": \"INTEREST_ONLY\",\n" +
                "            \"accountStatus\": \"ACCOUNT_STATUS_OPEN\",\n" +
                "            \"totalTerm\": \"24\",\n" +
                "            \"productId\": \"lbg_mortgage\",\n" +
                "            \"paymentArrangementAmountType\": \"FIXED_PAYMENT_AMOUNT\",\n" +
                "            \"paymentArrangementType\": \"OVERPAYMENT\",\n" +
                "            \"paymentArrangementStartMonth\": \"02/2050\",\n" +
                "            \"accountId\": \"1601d0e5-e336-64d9-64ad-89ba6fdc2677\"\n" +
                "        }\n" +

                "    ]\n" +
                "}";
    }

    public String getMortgageQueryServiceResponseWithNoStartAndEndDate() {
        return "{\n" +
                "    \"Data\": [\n" +
                "        {\n" +
                "            \"mortgageNumber\": \"number_1112\",\n" +
                "            \"mortgagePrincipal\": \"4000\",\n" +
                "            \"keyDate\": \"7\",\n" +
                "            \"mortgageType\": \"INTEREST_ONLY\",\n" +
                "            \"accountStatus\": \"ACCOUNT_STATUS_OPEN\",\n" +
                "            \"totalTerm\": \"24\",\n" +
                "            \"productId\": \"lbg_mortgage\",\n" +
                "            \"paymentArrangementType\": \"OVERPAYMENT\",\n" +
                "            \"paymentArrangementAmountType\": \"FIXED_PAYMENT_AMOUNT\",\n" +
                "            \"accountId\": \"1601d0e5-e336-64d9-64ad-89ba6fdc2677\"\n" +
                "        }\n" +

                "    ]\n" +
                "}";
    }

    public String getMortgageQueryServiceResponseWithInvalidOverpaymentType() {
        return "{\n" +
                "    \"Data\": [\n" +
                "        {\n" +
                "            \"mortgageNumber\": \"number_1112\",\n" +
                "            \"mortgagePrincipal\": \"4000\",\n" +
                "            \"keyDate\": \"7\",\n" +
                "            \"mortgageType\": \"INTEREST_ONLY\",\n" +
                "            \"accountStatus\": \"ACCOUNT_STATUS_OPEN\",\n" +
                "            \"totalTerm\": \"24\",\n" +
                "            \"productId\": \"lbg_mortgage\",\n" +
                "            \"paymentArrangementType\": \"OVERPAYMENT_FIXED\",\n" +
                "            \"paymentArrangementAmountType\": \"NOTFIXED\",\n" +
                "            \"paymentArrangementStartMonth\": \"02/2050\",\n" +
                "            \"accountId\": \"1601d0e5-e336-64d9-64ad-89ba6fdc2677\"\n" +
                "        }\n" +

                "    ]\n" +
                "}";
    }


    public String getMortgageQueryServiceResponseWithNoOverPayment() {
        return "{\n" +
                "    \"Data\": [\n" +
                "        {\n" +
                "            \"mortgageNumber\": \"number_1112\",\n" +
                "            \"mortgagePrincipal\": \"4000\",\n" +
                "            \"keyDate\": \"7\",\n" +
                "            \"mortgageType\": \"INTEREST_ONLY\",\n" +
                "            \"accountStatus\": \"ACCOUNT_STATUS_OPEN\",\n" +
                "            \"totalTerm\": \"24\",\n" +
                "            \"productId\": \"lbg_mortgage\",\n" +
                "            \"accountId\": \"1601d0e5-e336-64d9-64ad-89ba6fdc2677\"\n" +
                "        }\n" +

                "    ]\n" +
                "}";
    }

    public String getMortgageQueryServiceResponseWithNoSubAccount() {
        return "{\n" +
                "    \"Data\": [\n" +
                "        {\n" +
                "            \"mortgageNumber\": \"number_1112\",\n" +
                "            \"mortgagePrincipal\": \"4000\",\n" +
                "            \"keyDate\": \"7\",\n" +
                "            \"mortgageType\": \"INTEREST_ONLY\",\n" +
                "            \"totalTerm\": \"24\",\n" +
                "            \"productId\": \"lbg_mortgage_repayment\",\n" +
                "            \"accountId\": \"1601d0e5-e336-64d9-64ad-89ba6fdc2677\"\n" +
                "        },\n" +
                "        {\n" +
                "            \"mortgageNumber\": \"number_1112\",\n" +
                "            \"mortgagePrincipal\": \"4000\",\n" +
                "            \"keyDate\": \"7\",\n" +
                "            \"mortgageType\": \"INTEREST_ONLY\",\n" +
                "            \"totalTerm\": \"24\",\n" +
                "            \"productId\": \"lbg_mortgage_repayment\",\n" +
                "            \"accountId\": \"1601d0e5-e336-64d9-64ad-89ba6fdc2634\"\n" +
                "        }\n" +

                "    ]\n" +
                "}";
    }



    public String getOverpaymentVaultResponse() {
        return "{\n" +
                "    \"id\": \"6a29e8c6-2707-42d4-a374-71d0596ead0f\",\n" +
                "    \"account_id\": \"1601d0e5-e336-64d9-64ad-89ba6fdc2677\",\n" +
                "    \"status\": \"ACCOUNT_UPDATE_STATUS_PENDING_EXECUTION\",\n" +
                "    \"instance_param_vals_update\": {\n" +
                "        \"instance_param_vals\": {\n" +
                "            \"payment_arrangement_amount\": \"100\",\n" +
                "            \"payment_arrangement_end_month\": \"10-2050\"\n" +
                "        }\n" +
                "    },\n" +
                "    \"create_timestamp\": \"2020-09-14T17:45:04.687675Z\",\n" +
                "    \"last_status_update_timestamp\": \"2020-09-14T17:45:04.687675Z\",\n" +
                "    \"account_update_batch_id\": \"\",\n" +
                "    \"failure_reason\": \"\"\n" +
                "}";

    }

}
