package com.lbg.epscw.mortgagesrvc.component;

import com.lbg.epscw.entitlement.service.EntitlementValidationServiceImpl;
import com.lbg.epscw.handler.model.ErrorInfo;
import com.lbg.epscw.mortgagesrvc.exception.MortgageServiceException;
import com.lbg.epscw.mortgagesrvc.helper.ComponentHelper;
import com.lbg.epscw.mortgagesrvc.helper.MortgagePortingHelper;
import com.lbg.epscw.mortgagesrvc.logger.HystrixContextCopyStrategy;
import com.lbg.epscw.mortgagesrvc.model.MortgageApplicationInfo;
import com.lbg.epscw.mortgagesrvc.model.MortgagePortingApplicationStatus;
import com.lbg.epscw.mortgagesrvc.model.PortingApplicationStatusResponse;
import com.lbg.epscw.mortgagesrvc.restclient.MortgagePortingApplicationInfoRestClient;
import com.lbg.epscw.mortgagesrvc.service.MortgagePortingWelcomePackService;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpHeaders;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import static com.google.api.client.http.HttpStatusCodes.STATUS_CODE_BAD_REQUEST;
import static com.lbg.epscw.mortgagesrvc.constants.CommonConstants.MORTGAGE_ACCOUNT_STATUS;
import static com.lbg.epscw.mortgagesrvc.constants.CommonConstants.NOT_UPDATED;
import static com.lbg.epscw.mortgagesrvc.helper.MortgagePortingHelper.*;
import static com.lbg.epscw.mortgagesrvc.model.MortgagePortingApplicationStatus.*;
import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.when;
import static org.springframework.mock.web.MockHttpServletResponse.*;

@Tag("component")
@ExtendWith(SpringExtension.class)
@SpringBootTest
@AutoConfigureMockMvc
public class MortgagePortingWelcomePackReceivedComponentTest extends WebMVCTest {

    private final MortgagePortingHelper helper = new MortgagePortingHelper();
    private final ComponentHelper componentHelper = new ComponentHelper();

    @MockBean
    private MortgagePortingApplicationInfoRestClient restClient;

    @MockBean
    private EntitlementValidationServiceImpl entitlement;
    @MockBean
    private HystrixContextCopyStrategy hystrixContextCopyStrategy;

    @MockBean
    private MortgagePortingWelcomePackService service;

    @Test
    public void success_when_mortgage_porting_application_has_valid_state(){
        // Given
        when(restClient.getApplicationInfo(anyString())).thenReturn(MortgageApplicationInfo.builder().status(APPROVED).build());
        when(service.applicationWelcomePackReceived(anyString(),any())).thenReturn(PortingApplicationStatusResponse.builder().applicationNumber("1234").status(WELCOME_PACK_RECEIVED).build());

        // When
        HttpHeaders headers = helper.getAccountInfoHeaders();
        MockHttpServletResponse response = doPOST(WELCOME_PACK_ACTION_ENDPOINT, "", headers);

        String responseString = componentHelper.getServletResponseAsString(response);
        PortingApplicationStatusResponse actual = readObject(responseString, PortingApplicationStatusResponse.class);

        // Then
        assertThat(response.getStatus(), is(SC_OK));
        assertThat(actual.getStatus(), is(WELCOME_PACK_RECEIVED));
    }

    @Test
    public void reject_verification_when_application_invalid_status() {
        assertThatInvalidStatusThrowsError(OPEN);
        assertThatInvalidStatusThrowsError(SUBMITTED);
        assertThatInvalidStatusThrowsError(DECLINED);
        assertThatInvalidStatusThrowsError(WELCOME_PACK_RECEIVED);
        assertThatInvalidStatusThrowsError(APPROVED_WITH_CONDITIONS);
        assertThatInvalidStatusThrowsError(REPROCESS);
        assertThatInvalidStatusThrowsError(OFFERED);
        assertThatInvalidStatusThrowsError(FUNDS_RELEASED);
    }

    private void assertThatInvalidStatusThrowsError(MortgagePortingApplicationStatus fromStatus) {
        //given
        when(restClient.getApplicationInfo(anyString())).thenReturn(MortgageApplicationInfo.builder().status(fromStatus).build());
        //when
        HttpHeaders headers = helper.getAccountInfoHeaders();
        MockHttpServletResponse response = doPOST(WELCOME_PACK_ACTION_ENDPOINT, "", headers);
        ErrorInfo error = readErrorInfo(componentHelper.getServletResponseAsString(response));
        //then
        assertThat(response.getStatus(), is(SC_BAD_REQUEST));
        assertEquals("PNA.MORTGAGE_API.POST_MORTGAGES_APPLICATION_WELCOME_PACK_RECEIVED.MortgagePortingApplication.InvalidStatus", error.getReasonCode());
        assertEquals("Invalid Data", error.getMessage());
    }

    @Test
    public void failure_when_mortgage_porting_application_status_not_available(){
        // Given
        doThrow(new MortgageServiceException(MORTGAGE_ACCOUNT_STATUS, NOT_UPDATED)).when(service).applicationWelcomePackReceived(anyString(),any());

        // When
        String payload = helper.actionPayload(WELCOME_PACK_RECEIVED.name());
        HttpHeaders headers= helper.getAccountInfoHeaders();
        MockHttpServletResponse response = doPOST(WELCOME_PACK_ACTION_ENDPOINT, payload, headers);
        ErrorInfo error = readErrorInfo(componentHelper.getServletResponseAsString(response));

        // Then
        assertEquals(SC_INTERNAL_SERVER_ERROR, response.getStatus());
        assertEquals("PNA.MORTGAGE_API.POST_MORTGAGES_APPLICATION_WELCOME_PACK_RECEIVED.MortgagePortingApplication.NotFound", error.getReasonCode());
        assertEquals("Invalid Data", error.getMessage());

    }

    @Test
    public void return_error_when_application_id_is_invalid() {
        //given
        String payload = componentHelper.writeValueAsString(helper.updateSolicitorInfoPayloadBuilder().build());

        //when
        MockHttpServletResponse response = doPOST("/mortgages/application/invalid/welcome-pack-received", payload, helper.getAccountInfoHeaders());
        ErrorInfo error = readErrorInfo(componentHelper.getServletResponseAsString(response));

        //then
        assertThat(response.getStatus(), is(STATUS_CODE_BAD_REQUEST));
        assertEquals("PNA.MORTGAGE_API.POST_MORTGAGES_APPLICATION_WELCOME_PACK_RECEIVED.Param.Invalid", error.getReasonCode());
        assertEquals("Invalid application number", error.getMessage());
    }

    @Test
    public void throws_exception_when_correlationId_is_missing() {
        //given
        HttpHeaders headers = helper.getAccountInfoHeaders();
        headers.remove("x-lbg-txn-correlation-id");

        // when
        String payload = helper.actionPayload(APPROVED.name());
        MockHttpServletResponse response = doPOST(WELCOME_PACK_ACTION_ENDPOINT, payload, headers);
        ErrorInfo error = readErrorInfo(componentHelper.getServletResponseAsString(response));

        // then
        assertEquals(400, response.getStatus());
        assertEquals("PNA.MORTGAGE_API.POST_MORTGAGES_APPLICATION_WELCOME_PACK_RECEIVED.Header.Missing.x-lbg-txn-correlation-id", error.getReasonCode());
        assertEquals("Missing request header x-lbg-txn-correlation-id for method parameter of type String", error.getMessage());
    }

    @Test
    public void throws_exception_when_brand_is_missing() {
        //given
        HttpHeaders headers = helper.getAccountInfoHeaders();
        headers.remove("x-lbg-brand");

        // when
        String payload = helper.actionPayload(APPROVED.name());
        MockHttpServletResponse response = doPOST(WELCOME_PACK_ACTION_ENDPOINT, payload, headers);
        ErrorInfo error = readErrorInfo(componentHelper.getServletResponseAsString(response));

        // then
        assertEquals(400, response.getStatus());
        assertEquals("PNA.MORTGAGE_API.POST_MORTGAGES_APPLICATION_WELCOME_PACK_RECEIVED.Header.Missing.x-lbg-brand", error.getReasonCode());
        assertEquals("Missing request header 'x-lbg-brand' for method parameter of type String", error.getMessage());
    }

    @Test
    public void throws_exception_when_channel_is_missing() {
        //given
        HttpHeaders headers = helper.getAccountInfoHeaders();
        headers.remove("x-lbg-channel");

        // when
        String payload = helper.actionPayload(APPROVED.name());
        MockHttpServletResponse response = doPOST(WELCOME_PACK_ACTION_ENDPOINT, payload, headers);
        ErrorInfo error = readErrorInfo(componentHelper.getServletResponseAsString(response));

        // then
        assertEquals(400, response.getStatus());
        assertEquals("PNA.MORTGAGE_API.POST_MORTGAGES_APPLICATION_WELCOME_PACK_RECEIVED.Header.Missing.x-lbg-channel", error.getReasonCode());
        assertEquals("Missing request header 'x-lbg-channel' for method parameter of type String", error.getMessage());
    }

    @Test
    public void throws_exception_when_brand_name_is_invalid() {
        //given
        HttpHeaders headers = helper.getAccountInfoHeaders();
        headers.set("x-lbg-brand", "invalid");

        // when
        String payload = helper.actionPayload(OFFERED.name());
        MockHttpServletResponse response = doPOST(WELCOME_PACK_ACTION_ENDPOINT, payload, headers);
        ErrorInfo error = readErrorInfo(componentHelper.getServletResponseAsString(response));

        // then
        assertEquals(400, response.getStatus());
        assertEquals("PNA.MORTGAGE_API.POST_MORTGAGES_APPLICATION_WELCOME_PACK_RECEIVED.Header.Invalid", error.getReasonCode());
        assertEquals("Invalid enum value for type x-lbg-brand", error.getMessage());
    }
}
