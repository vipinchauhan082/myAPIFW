package com.lbg.epscw.mortgagesrvc.component;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.lbg.epscw.handler.model.ErrorInfo;
import com.lbg.epscw.handler.model.ErrorResponse;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.request.MockHttpServletRequestBuilder;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;


public abstract class WebMVCTest {

    protected static final String CONTENT_TYPE = "Content-Type";

    @Autowired
    private MockMvc mvc;

    @Autowired
    private ObjectMapper mapper;

    public MockHttpServletResponse doGET(String uri, HttpHeaders headers) {
        MvcResult mvcResult = null;

        try {
            mvcResult = mvc.perform(get(uri).headers(headers)).andReturn();
            return mvcResult.getResponse();
        } catch (Exception exception) {
            throw new RuntimeException(exception.getMessage());
        }
    }

    public MockHttpServletResponse doPUT(String uri, String payload, HttpHeaders headers) {
        MvcResult mvcResult = null;

        try {
            MockHttpServletRequestBuilder requestBuilder = put(uri).headers(headers);

            if (StringUtils.isNotEmpty(payload)) {
                requestBuilder.content(payload);
            }

            mvcResult = mvc.perform(requestBuilder).andReturn();
            return mvcResult.getResponse();
        } catch (Exception exception) {
            throw new RuntimeException(exception.getMessage());
        }
    }

    public MockHttpServletResponse doPOST(String uri, String payload, HttpHeaders headers) {
        MvcResult mvcResult = null;

        try {
            MockHttpServletRequestBuilder requestBuilder = post(uri).headers(headers);

            if (StringUtils.isNotEmpty(payload)) {
                requestBuilder.content(payload);
            }

            mvcResult = mvc.perform(requestBuilder).andReturn();
            return mvcResult.getResponse();
        } catch (Exception exception) {
            throw new RuntimeException(exception.getMessage());
        }
    }

    public MockHttpServletResponse doDELETE(String uri, String payload, HttpHeaders headers) {
        MvcResult mvcResult = null;

        try {
            MockHttpServletRequestBuilder requestBuilder = delete(uri).headers(headers);

            if (StringUtils.isNotEmpty(payload)) {
                requestBuilder.content(payload);
            }

            mvcResult = mvc.perform(requestBuilder).andReturn();
            return mvcResult.getResponse();
        } catch (Exception exception) {
            throw new RuntimeException(exception.getMessage());
        }
    }

    public <T> T readObject(String value, Class<T> clz) {
        try {
            return mapper.readValue(value, clz);
        } catch (JsonProcessingException e) {
            throw new RuntimeException(e.getMessage());
        }
    }

    public String writeObject(Object obj) {
        try {
            return mapper.writeValueAsString(obj);
        } catch (JsonProcessingException e) {
            throw new RuntimeException(e.getMessage());
        }
    }

    public ErrorInfo readErrorInfo(String responseString) {
        ErrorResponse errorResponse = readObject(responseString, ErrorResponse.class);
        return errorResponse.getErrors().get(0);
    }

    public <T> List<T> readList(String str, Class<T> type) {
        return readList(str, ArrayList.class, type);
    }

    public <T> List<T> readList(String str, Class<? extends Collection> type, Class<T> elementType) {
        try {
            return mapper.readValue(str, mapper.getTypeFactory().constructCollectionType(type, elementType));
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

}