package com.lbg.epscw.mortgagesrvc.service;

import com.lbg.epscw.mortgagesrvc.dto.AccountCreationResponse;
import com.lbg.epscw.mortgagesrvc.exception.CircuitBreakerOpenException;
import com.lbg.epscw.mortgagesrvc.helper.AccountCreationHelper;
import com.lbg.epscw.mortgagesrvc.helper.MortgageAccountDataHelper;
import com.lbg.epscw.mortgagesrvc.model.AccountOpenRequest;
import com.lbg.epscw.mortgagesrvc.model.BenefitsResponse;
import com.lbg.epscw.mortgagesrvc.model.VaultMetadataOptionsRequest;
import com.lbg.epscw.mortgagesrvc.restclient.MortgageMetadataRestClient;
import com.lbg.epscw.mortgagesrvc.restclient.MortgageSubAccountRestClient;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;

import org.mockito.Mock;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.Map;

import static org.junit.Assert.assertNull;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.powermock.api.mockito.PowerMockito.when;
import static org.mockito.ArgumentMatchers.any;
import static org.junit.Assert.assertEquals;



@RunWith(SpringRunner.class)
public class MortgageAccountServiceTest {

    @Mock
    MortgageSubAccountRestClient mortgageDAO;

    @InjectMocks
    MortgageAccountService mortgageAccountService;

    @Mock
    MortgageMetadataRestClient mortgageMetadataRestClient;

    private MortgageAccountDataHelper helper = new MortgageAccountDataHelper();

    @Test
    public void testAccountCreate(){

        //Given
        when(mortgageDAO.createSubAccount(any(AccountOpenRequest.class),any(Map.class))).thenReturn(AccountCreationHelper.buildCreateAccountResponse());
        //When
        AccountCreationResponse response = mortgageAccountService.openAccount(AccountCreationHelper.generateAccountOpenRequestMortgage(),AccountCreationHelper.generateRequiredHeaders());
        //Then
        assertEquals("mortgage",response.getProductName());
        assertEquals("ACCOUNT_STATUS_OPEN",response.getStatus());
    }

    @Test(expected = RuntimeException.class)
    public void testAccountCreateFailure(){

        //Given
        when(mortgageDAO.createSubAccount(any(AccountOpenRequest.class),any(Map.class))).thenThrow(RuntimeException.class);
        //When
        AccountCreationResponse response = mortgageAccountService.openAccount(AccountCreationHelper.generateAccountOpenRequestMortgage(),AccountCreationHelper.generateRequiredHeaders());
    }

    @Test(expected = CircuitBreakerOpenException.class)
    public void shouldThrowHystrixExceptionForFallbackUpdateNomination() {
        //then
        mortgageAccountService.fallbackOpenAccount(AccountCreationHelper.generateAccountOpenRequestMortgage()
                ,AccountCreationHelper.generateRequiredHeaders(), new Exception("Circuit open on create"));
    }

    @Test
    public void updateAccountBenefitsDetails_successTrue(){
        when(mortgageMetadataRestClient.updateMetadataOptions(any(String.class),any(VaultMetadataOptionsRequest.class))).
                thenReturn(helper.buildAccountBenefitsTrueUpdateResponse());

        BenefitsResponse response = mortgageAccountService.updateAccountBenefitsDetails(
                helper.accountList_mock(),helper.mockRequest_TrueBenefits());

        assertNotNull(response);
        assertEquals(2,response.getBenefitsDetails().size());

    }

    @Test
    public void updateAccountBenefitsDetails_successFalse(){
        when(mortgageMetadataRestClient.updateMetadataOptions(any(String.class),any(VaultMetadataOptionsRequest.class))).
                thenReturn(helper.buildAccountBenefitsFalseUpdateResponse());

        BenefitsResponse response = mortgageAccountService.updateAccountBenefitsDetails(
                helper.accountList_mock(),helper.mockRequest_FalseBenefits());

        assertNotNull(response);
        assertEquals(1,response.getBenefitsDetails().size());

    }

    @Test
    public void updateAccountBenefitsDetails_successNull(){
        when(mortgageMetadataRestClient.updateMetadataOptions(any(String.class),any(VaultMetadataOptionsRequest.class))).
                thenReturn(null);

        BenefitsResponse response = mortgageAccountService.updateAccountBenefitsDetails(
                helper.accountList_mock(),helper.mockRequest_FalseBenefits());

        assertNull(response);
    }

    @Test(expected = CircuitBreakerOpenException.class)
    public void hystrix_test_on_fallbackUpdateAccountBenefitsDetails() {

        mortgageAccountService.fallbackUpdateAccountBenefitsDetails(helper.accountList_mock(),
                helper.mockRequest_TrueBenefits(),
                new Exception("Circuit open on update-benefit-details"));
    }

}
