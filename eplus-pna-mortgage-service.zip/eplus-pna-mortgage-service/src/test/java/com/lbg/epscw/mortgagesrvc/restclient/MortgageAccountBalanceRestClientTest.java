package com.lbg.epscw.mortgagesrvc.restclient;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.lbg.epscw.mortgagesrvc.dto.*;
import com.lbg.epscw.mortgagesrvc.exception.MortgageServiceException;
import com.lbg.epscw.mortgagesrvc.helper.MortgageArrearsCapitalizeHelper;
import com.lbg.epscw.mortgagesrvc.service.RestClientService;
import com.lbg.epscw.mortgagesrvc.util.MortgageServiceUtil;
import org.junit.Before;
import org.junit.Test;
import org.junit.jupiter.api.Assertions;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.internal.util.reflection.FieldSetter;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;

import java.text.MessageFormat;
import java.util.HashMap;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.mockito.ArgumentMatchers.any;
import static org.powermock.api.mockito.PowerMockito.when;

@RunWith(PowerMockRunner.class)
@PrepareForTest({ MessageFormat.class })
public class MortgageAccountBalanceRestClientTest {

    @Mock
    private RestClientService restClientService;

    @Mock
    private MortgageServiceUtil mortgageServiceUtil;

    @Value("mortgageAccountBalanceEndpoint")
    private String mortgageAccountBalanceEndpoint;

    @Autowired
    private ObjectMapper mapper;

    private MortgageArrearsCapitalizeHelper mortgageArrearsCapitalizeHelper = new MortgageArrearsCapitalizeHelper();

    @InjectMocks
    private MortgageAccountBalanceRestClient mortgageAccountBalanceRestClient;

    @Before
    public void setup() {
        this.mapper = new ObjectMapper();
    }

    @Test
    public void mortgageAccountBalanceInfo() throws JsonProcessingException, NoSuchFieldException {
        //given
        VaultPostingsInstructionsBatchRequest vaultPostingsInstructionsBatchRequest = VaultPostingsInstructionsBatchRequest.builder()
                .postingsInstructionsBatch(PostingsInstructionsBatch.builder().clientBatchId("123").build()).build();

        MortgageResponse mortgageBalanceResponse = MortgageArrearsCapitalizeHelper.getMortgageOverarchingBalanceWithArrears();

        String stringyfyResponse = null;

        FieldSetter.setField(mortgageAccountBalanceRestClient,
                mortgageAccountBalanceRestClient.getClass().getDeclaredField("mortgageAccountBalanceEndpoint"),
                "mortgageAccountBalanceEndpoint");

        stringyfyResponse = mapper.writeValueAsString(mortgageBalanceResponse);
        when(mortgageServiceUtil.readObject(any(String.class), any(Class.class))).thenReturn(mortgageBalanceResponse);
        when(restClientService.get(any(String.class), any(HashMap.class))).thenReturn(stringyfyResponse);
        MortgageResponse response = mortgageAccountBalanceRestClient.getMortgageAccountBalanceInfo("1b69ad2f-63b3-c70f-6f52-ee85b97e314d", new HashMap<>());
        assertNotNull(response);
        Assertions.assertEquals("50.0", response.getMortgageBalance().getAggregatedMap().get("ArrearAmount"));

    }

    @Test(expected = MortgageServiceException.class)
    public void mortgageAccountBalanceInfoNotFound() throws JsonProcessingException, NoSuchFieldException {
        //given
        VaultPostingsInstructionsBatchRequest vaultPostingsInstructionsBatchRequest = VaultPostingsInstructionsBatchRequest.builder()
                .postingsInstructionsBatch(PostingsInstructionsBatch.builder().clientBatchId("123").build()).build();

        MortgageResponse mortgageBalanceResponse = MortgageArrearsCapitalizeHelper.getMortgageOverarchingBalanceWithArrears();

        String stringyfyResponse = null;

        FieldSetter.setField(mortgageAccountBalanceRestClient,
                mortgageAccountBalanceRestClient.getClass().getDeclaredField("mortgageAccountBalanceEndpoint"),
                "mortgageAccountBalanceEndpoint");

        stringyfyResponse = mapper.writeValueAsString(mortgageBalanceResponse);
        when(mortgageServiceUtil.readObject(any(String.class), any(Class.class))).thenReturn(null);
        when(restClientService.get(any(String.class), any(HashMap.class))).thenReturn(stringyfyResponse);
        mortgageAccountBalanceRestClient.getMortgageAccountBalanceInfo("1b69ad2f-63b3-c70f-6f52-ee85b97e314d", new HashMap<>());

    }
}