package com.lbg.epscw.mortgagesrvc.service;


import com.lbg.epscw.mortgagesrvc.helper.MortgageAssetDataHelper;
import com.lbg.epscw.mortgagesrvc.model.Asset;
import com.lbg.epscw.mortgagesrvc.model.MortgageApplicationInfo;
import com.lbg.epscw.mortgagesrvc.restclient.MortgagePortingApplicationAssetRestClientStub;
import org.junit.Before;
import org.junit.Test;

import static com.lbg.epscw.mortgagesrvc.helper.MortgageAssetDataHelper.ASSET_ID;
import static com.lbg.epscw.mortgagesrvc.helper.MortgagePortingHelper.APPLICATION_NUMBER;
import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

public class MortgageAssetServiceImplTest {

    private MortgagePortingApplicationAssetRestClientStub restClient;
    private MortgageAssetServiceImpl underTest;
    private MortgageApplicationInfo mortgageApplicationInfo;

    @Before
    public void setup(){
        restClient = mock(MortgagePortingApplicationAssetRestClientStub.class);
        mortgageApplicationInfo = mock(MortgageApplicationInfo.class);
        underTest = new MortgageAssetServiceImpl(restClient);
    }
    @Test
    public void update_asset_info(){
        MortgageApplicationInfo expected = MortgageApplicationInfo.builder().assetId(ASSET_ID).build();
        Asset update = MortgageAssetDataHelper.generateMortgageAssetUpdateRequest();
        Asset create = MortgageAssetDataHelper.generateMortgageAssetCreateRequest();
        when(restClient.createAsset(anyString(), any(Asset.class))).thenReturn(create);
        when(restClient.updateAsset(anyString(), any(Asset.class))).thenReturn(update);
        Asset createResponse = underTest.updateAssetInfo(MortgageApplicationInfo.builder().applicationNumber(APPLICATION_NUMBER).build(), create);
        Asset updateResponse = underTest.updateAssetInfo(MortgageApplicationInfo.builder().applicationNumber(APPLICATION_NUMBER).assetId(ASSET_ID).build(), update);
        assertThat(createResponse, is(create));
        assertThat(updateResponse, is(update));
    }

    @Test
    public void update_mortgage_asset() {
      Asset expected = MortgageAssetDataHelper.generateMortgageAssetUpdateRequest();
      when(restClient.updateAsset(anyString(), any(Asset.class))).thenReturn(expected);
      Asset response = restClient.updateAsset("121232", expected);
      assertThat(response, is(expected));
    }

    @Test
    public void create_mortgage_asset() {
       Asset expected = MortgageAssetDataHelper.generateMortgageAssetCreateRequest();
       when(restClient.createAsset(anyString(), any(Asset.class))).thenReturn(expected);
       Asset response = restClient.createAsset("123243", expected);
       assertThat(response, is(expected));
    }
}