package com.lbg.epscw.mortgagesrvc.restclient;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.lbg.epscw.mortgagesrvc.dto.PaymentHolidayEligibility;
import com.lbg.epscw.mortgagesrvc.exception.MortgageServiceException;
import com.lbg.epscw.mortgagesrvc.helper.MortgagePaymentHolidayHelper;
import com.lbg.epscw.mortgagesrvc.service.RestClientService;
import com.lbg.epscw.mortgagesrvc.util.MortgageServiceUtil;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.internal.util.reflection.FieldSetter;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;

import java.text.MessageFormat;
import java.util.HashMap;

import static org.junit.Assert.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.powermock.api.mockito.PowerMockito.when;

@RunWith(PowerMockRunner.class)
@PrepareForTest({ MessageFormat.class })
public class MortgagePaymentHolidayEligibilityRestClientTest {

    @Value("${mortgage.payment.holiday.eligibility.get.endpoint}")
    private String mortgagePaymentHolidayEligibilityGetEndpoint;

    @Mock
    RestClientService restClientService;

    @Mock
    MortgageServiceUtil mortgageServiceUtil;

    @Autowired
    private ObjectMapper mapper;

    private MortgagePaymentHolidayHelper mortgagePaymentHolidayHelper = new MortgagePaymentHolidayHelper();

    @InjectMocks
    private MortgagePaymentHolidayEligibilityRestClient mortgagePaymentHolidayEligibilityRestClient;

    @Before
    public void setup() {
        this.mapper = new ObjectMapper();
    }

    @Test
    public void get_mortgage_payment_holiday_eligibility() throws NoSuchFieldException, JsonProcessingException {
        PaymentHolidayEligibility paymentHolidayEligibilityInfo = mortgagePaymentHolidayHelper.buildPaymentHolidayEligibilityInfo(true);
        FieldSetter.setField(mortgagePaymentHolidayEligibilityRestClient,
                mortgagePaymentHolidayEligibilityRestClient.getClass().getDeclaredField("mortgagePaymentHolidayEligibilityGetEndpoint"),
                "mortgagePaymentHolidayEligibilityGetEndpoint");

        String stringyfyResponse = mapper.writeValueAsString(paymentHolidayEligibilityInfo);
        when(mortgageServiceUtil.fetchDefaultVaultHeaders()).thenReturn(new HashMap<String, String>());
        when(mortgageServiceUtil.readObject(any(String.class), any(Class.class))).thenReturn(paymentHolidayEligibilityInfo);
        when(restClientService.get(any(String.class), any(HashMap.class))).thenReturn(stringyfyResponse);
        PaymentHolidayEligibility response = mortgagePaymentHolidayEligibilityRestClient.getMortgagePaymentHolidayEligibility("ee115ba6-2f2a-ece4-eba6-edf9a3a7cf40","10/2021","11/2021", new HashMap<>());
        assertNotNull(response);
        assertEquals(true, response.isEligibleForPaymentHoliday());
    }

    @Test(expected = MortgageServiceException.class)
    public void mortgage_payment_holiday_response_is_null() throws NoSuchFieldException, JsonProcessingException {
        PaymentHolidayEligibility paymentHolidayEligibilityInfo = mortgagePaymentHolidayHelper.buildPaymentHolidayEligibilityInfo(true);
        FieldSetter.setField(mortgagePaymentHolidayEligibilityRestClient,
                mortgagePaymentHolidayEligibilityRestClient.getClass().getDeclaredField("mortgagePaymentHolidayEligibilityGetEndpoint"),
                "mortgagePaymentHolidayEligibilityGetEndpoint");

        String stringyfyResponse = mapper.writeValueAsString(paymentHolidayEligibilityInfo);
        when(mortgageServiceUtil.fetchDefaultVaultHeaders()).thenReturn(new HashMap<String, String>());
        when(mortgageServiceUtil.readObject(any(String.class), any(Class.class))).thenReturn(null);
        when(restClientService.get(any(String.class), any(HashMap.class))).thenReturn(stringyfyResponse);
        PaymentHolidayEligibility response = mortgagePaymentHolidayEligibilityRestClient.getMortgagePaymentHolidayEligibility("ee115ba6-2f2a-ece4-eba6-edf9a3a7cf40","10/2021","11/2021", new HashMap<>());
    }
}