package com.lbg.epscw.mortgagesrvc.controller;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.lbg.epscw.mortgagesrvc.exception.MortgageServiceException;
import com.lbg.epscw.mortgagesrvc.helper.MortgageCTLHelper;
import com.lbg.epscw.mortgagesrvc.model.*;
import com.lbg.epscw.mortgagesrvc.service.MortgageCTLService;
import com.lbg.epscw.mortgagesrvc.util.MortgageServiceUtil;
import lombok.extern.flogger.Flogger;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit4.SpringRunner;

import javax.validation.ConstraintViolationException;
import java.util.HashMap;

import static org.junit.Assert.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.powermock.api.mockito.PowerMockito.when;

@Flogger
@RunWith(SpringRunner.class)
@WebMvcTest(controllers = { MortgageServiceUtil.class, MortgageCTLController.class })
public class MortgageCTLControllerTest {

    @MockBean
    private MortgageCTLService ctlService;

    @Autowired
    private MortgageCTLController ctlController;

    private final MortgageCTLHelper ctlHelper = new MortgageCTLHelper();

    public static final String ACCOUNT_ID = "f76ca840-2553-d536-1ab8-9fa85c99db05";

    @Test
    public void addMortgageCTL() throws JsonProcessingException {
        //given
        when(ctlService.addConsentToLease(any(MortgageCTLRequest.class), any(String.class)))
                .thenReturn(ctlHelper.buildAccountCtlResponse());

        //when
        ResponseEntity<MortgageCTLResponse> responseEntity = ctlController.addConsentToLease(
                "IF", Channel.DIGITAL.name(), "123-456-789-12", null, "ALL", new HashMap<String, String>(),
                new MortgageCTLRequest(),
                ACCOUNT_ID
        );
        MortgageCTLResponse response = responseEntity.getBody();
        //then
        System.out.println(response.toString());
        assertEquals("b2c9119f-09e5-4ac9-9738-9e28b334d3fa", response.getAccountId());
        assertEquals("ACCOUNT_STATUS_PENDING_CLOSURE", response.getStatus());
        assertEquals(2, response.getDetails().size());
    }

    @Test
    public void cancelMortgageCTL() throws JsonProcessingException {
        //given
        when(ctlService.cancelConsentToLease(anyString(), any(HashMap.class)))
                .thenReturn(ctlHelper.buildAccountCtlResponse());

        //when
        ResponseEntity<MortgageCTLResponse> responseEntity = ctlController.cancelConsentToLease(
                "IF", Channel.DIGITAL.name(), "123-456-789-12", null, "ALL", new HashMap<String, String>(),
                ACCOUNT_ID
        );
        MortgageCTLResponse response = responseEntity.getBody();
        //then
        assertEquals("b2c9119f-09e5-4ac9-9738-9e28b334d3fa", response.getAccountId());
        assertEquals("ACCOUNT_STATUS_PENDING_CLOSURE", response.getStatus());
        assertEquals(2, response.getDetails().size());
    }

    @Test(expected = MortgageServiceException.class)
    public void shouldThrowExceptionWhenCancelServiceMethodReturnsNull() {
        //given
        when(ctlService.cancelConsentToLease(anyString(), any(HashMap.class))).thenReturn(null);

        //when
        ctlController.cancelConsentToLease(
                "IF",Channel.DIGITAL.name(), "123-456-789-12", null, "ALL", new HashMap<String, String>(),
                ACCOUNT_ID
        );
    }

    @Test(expected = MortgageServiceException.class)
    public void shouldThrowExceptionWhenAddServiceMethodReturnsNull() {
        //given
        when(ctlService.addConsentToLease(any(MortgageCTLRequest.class), anyString())).thenReturn(null);

        //when
        ctlController.addConsentToLease(
                "IF",Channel.DIGITAL.name(), "123-456-789-12", null, "ALL", new HashMap<String, String>(),
                new MortgageCTLRequest(),
                ACCOUNT_ID
        );
    }

    @Test(expected = ConstraintViolationException.class)
    public void shouldThrowExceptionWhenAccountIdLengthIsSmall() {
        //when
        ctlController.cancelConsentToLease(
                "IF",Channel.DIGITAL.name(), "123-456-789-12", null, "ALL", new HashMap<String, String>(),
                ACCOUNT_ID.substring(5)
        );
    }

    @Test(expected = ConstraintViolationException.class)
    public void shouldThrowExceptionWhenAccountIdLengthIsLong() {
        //when
        ctlController.cancelConsentToLease(
                "IF",Channel.DIGITAL.name(), "123-456-789-12", null, "ALL", new HashMap<String, String>(),
                ACCOUNT_ID.concat("123")
        );
    }

    @Test(expected = ConstraintViolationException.class)
    public void shouldThrowExceptionWhenAccountIdLengthIsEmpty() {
        //when
        ctlController.cancelConsentToLease(
                "IF",Channel.DIGITAL.name(), "123-456-789-12", null, "ALL", new HashMap<String, String>(),
                ""
        );
    }
}