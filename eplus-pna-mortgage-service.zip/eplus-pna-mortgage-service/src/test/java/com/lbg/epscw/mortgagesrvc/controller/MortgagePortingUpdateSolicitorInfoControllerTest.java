package com.lbg.epscw.mortgagesrvc.controller;

import com.lbg.epscw.mortgagesrvc.exception.MortgageServiceException;
import com.lbg.epscw.mortgagesrvc.model.PortingApplicationStatusResponse;
import com.lbg.epscw.mortgagesrvc.model.PortingUpdateSolicitorInfoRequest;
import com.lbg.epscw.mortgagesrvc.service.MortgagePortingApplicationInfoService;
import com.lbg.epscw.mortgagesrvc.service.MortgagePortingApplicationSolicitorInfoService;
import com.lbg.epscw.mortgagesrvc.util.MortgageServiceUtil;
import com.lbg.epscw.mortgagesrvc.validator.MortgagePortingSolicitorInfoValidator;
import org.junit.Before;
import org.junit.Test;
import org.springframework.http.ResponseEntity;

import static com.lbg.epscw.mortgagesrvc.helper.MortgagePortingHelper.*;
import static com.lbg.epscw.mortgagesrvc.model.MortgagePortingApplicationStatus.REOPEN;
import static io.opencensus.trace.Tracing.getTracer;
import static io.opencensus.trace.samplers.Samplers.alwaysSample;
import static java.util.Collections.emptyMap;
import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.mock;
import static org.powermock.api.mockito.PowerMockito.when;

public class MortgagePortingUpdateSolicitorInfoControllerTest {
    private MortgagePortingSolicitorInfoValidator validator;
    private MortgagePortingApplicationSolicitorInfoService service;
    private MortgagePortingUpdateSolicitorInfoController underTest;

    @Before
    public void setup() {
        MortgageServiceUtil utility = mock(MortgageServiceUtil.class);
        when(utility.buildSpan(anyString())).thenReturn(getTracer().spanBuilder("any").setSampler(alwaysSample()));
        validator = mock(MortgagePortingSolicitorInfoValidator.class);
        MortgagePortingApplicationInfoService applicationInfoService = mock(MortgagePortingApplicationInfoService.class);
        service = mock(MortgagePortingApplicationSolicitorInfoService.class);
        underTest = new MortgagePortingUpdateSolicitorInfoController(utility, validator, applicationInfoService, service);
    }

    @Test
    public void verify_application_status_permitted_reopen() {
        //given
        PortingApplicationStatusResponse expected = PortingApplicationStatusResponse.builder().
                applicationNumber(APPLICATION_NUMBER).status(REOPEN).build();
        when(service.updateSolicitorDetails(any(), any())).thenReturn(expected);
        //when
        PortingUpdateSolicitorInfoRequest request = PortingUpdateSolicitorInfoRequest.builder().build();
        ResponseEntity<PortingApplicationStatusResponse> actual = underTest.solicitorInfo(BRAND, CHANNEL, CORRELATION_ID, JWT, INTERNAL_SYS_ID, emptyMap(), APPLICATION_NUMBER, request);
        //then
        assertThat(actual.getBody(), is(expected));
    }

    @Test
    public void verify_solicitor_info_is_successful() {
        PortingApplicationStatusResponse expected = PortingApplicationStatusResponse.builder().build();
        when(service.updateSolicitorDetails(any(), any())).thenReturn(expected);

        PortingUpdateSolicitorInfoRequest request = PortingUpdateSolicitorInfoRequest.builder().build();
        ResponseEntity<PortingApplicationStatusResponse> actual = underTest.solicitorInfo(BRAND, CHANNEL, CORRELATION_ID, JWT, INTERNAL_SYS_ID, emptyMap(), APPLICATION_NUMBER, request);

        assertThat(actual.getBody(), is(expected));
    }

    @Test(expected = MortgageServiceException.class)
    public void check_update_solicitor_info_throws_error() {
        doThrow(MortgageServiceException.class).when(validator).validate(any(), any(), any());

        PortingUpdateSolicitorInfoRequest request = PortingUpdateSolicitorInfoRequest.builder().build();
        underTest.solicitorInfo(BRAND, CHANNEL, CORRELATION_ID, JWT, INTERNAL_SYS_ID, emptyMap(), APPLICATION_NUMBER, request);
    }

    @Test(expected = MortgageServiceException.class)
    public void check_update_solicitor_info_service_throws_error() {
        doThrow(MortgageServiceException.class).when(service).updateSolicitorDetails(any(), any());

        PortingUpdateSolicitorInfoRequest request = PortingUpdateSolicitorInfoRequest.builder().build();
        underTest.solicitorInfo(BRAND, CHANNEL, CORRELATION_ID, JWT, INTERNAL_SYS_ID, emptyMap(), APPLICATION_NUMBER, request);
    }
}