package com.lbg.epscw.mortgagesrvc.component;

import com.lbg.epscw.entitlement.service.EntitlementValidationService;
import com.lbg.epscw.handler.model.ErrorInfo;
import com.lbg.epscw.handler.model.ErrorResponse;
import com.lbg.epscw.mortgagesrvc.helper.ComponentHelper;
import com.lbg.epscw.mortgagesrvc.helper.MortgagePaymentHolidayHelper;
import com.lbg.epscw.mortgagesrvc.logger.HystrixContextCopyStrategy;
import com.lbg.epscw.mortgagesrvc.model.PaymentHolidayRequest;
import com.lbg.epscw.mortgagesrvc.model.PaymentHolidayResponse;
import com.lbg.epscw.mortgagesrvc.restclient.MortgageAccountInfoRestClient;
import com.lbg.epscw.mortgagesrvc.restclient.MortgagePaymentHolidayEligibilityRestClient;
import com.lbg.epscw.mortgagesrvc.service.RestClientService;
import org.apache.commons.lang.RandomStringUtils;
import org.junit.Before;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.internal.util.MockUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.context.ApplicationContext;
import org.springframework.http.HttpHeaders;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import java.util.HashMap;

import static org.junit.Assert.assertEquals;
import static org.junit.jupiter.api.Assertions.assertAll;
import static org.mockito.ArgumentMatchers.any;
import static org.powermock.api.mockito.PowerMockito.mock;
import static org.powermock.api.mockito.PowerMockito.when;

@Tag("component")
@ExtendWith(SpringExtension.class)
@SpringBootTest
@AutoConfigureMockMvc
public class MortgagePaymentHolidayComponentTest extends WebMVCTest {

    @MockBean
    RestClientService restClientService;

    @MockBean
    private EntitlementValidationService entitlementValidationService;

    @Mock
    private MortgageAccountInfoRestClient mortgageAccountInfoRestClient;

    @Mock
    private MortgagePaymentHolidayEligibilityRestClient mortgagePaymentHolidayEligibilityRestClient;

    @Autowired
    private ApplicationContext context;

    @MockBean
    private HystrixContextCopyStrategy hystrixContextCopyStrategy;

    private ComponentHelper componentHelper;

    private static final String ADD_PAYMENT_HOLIDAY = "/payment/d7442689-9f34-302e-64f3-83ce97c2317c/payment-holiday";

    private static final String CANCEL_PAYMENT_HOLIDAY = "/payment/d7442689-9f34-302e-64f3-83ce97c2317c/payment-holiday";

    private MortgagePaymentHolidayHelper mortgagePaymentHolidayHelper;

    @Before
    public void setup() {
        mortgageAccountInfoRestClient = mock(MortgageAccountInfoRestClient.class);
        mortgagePaymentHolidayEligibilityRestClient = mock(MortgagePaymentHolidayEligibilityRestClient.class);
    }

    @BeforeEach
    public void beforeEach() {
        this.componentHelper = new ComponentHelper();
        this.mortgagePaymentHolidayHelper = new MortgagePaymentHolidayHelper();
        for (String name : context.getBeanDefinitionNames()) {
            Object bean = context.getBean(name);
            if (MockUtil.isMock(bean)) {
                Mockito.reset(bean);
            }
        }
    }

//    @Test
//    public void shouldAddPaymentHoliday() {
//        //given
//        PaymentHolidayRequest paymentHolidayRequest = mortgagePaymentHolidayHelper.buildPaymentHolidayRequest("10/2021", "11/2021");
//        String payload = componentHelper.writeValueAsString(paymentHolidayRequest);
//
//        PaymentHolidayEligibility paymentHolidayEligibility = mortgagePaymentHolidayHelper.buildPaymentHolidayEligibilityInfo(true);
//        when(mortgagePaymentHolidayEligibilityRestClient.getMortgagePaymentHolidayEligibility(any(String.class),any(String.class),any(String.class), any(Map.class))).thenReturn(paymentHolidayEligibility);
//
//        MortgageAccountInfo mortgageAccountInfo = mortgagePaymentHolidayHelper.mortgageAccountInfo_mortgagePaymentHolidayMock();
//        when(mortgageAccountInfoRestClient.getMortgageAccountInfo(any(String.class), any(Map.class))).thenReturn(mortgageAccountInfo);
//
//        when(restClientService.post(any(String.class), any(HashMap.class), any(String.class)))
//                .thenReturn(mortgagePaymentHolidayHelper.getVaultResponse());
//
//        //when
//        MockHttpServletResponse servletResponse = doPOST(ADD_PAYMENT_HOLIDAY, payload, mortgagePaymentHolidayHelper.getAccountInfoHeaders());
//        String responseString = componentHelper.getServletResponseAsString(servletResponse);
//        PaymentHolidayResponse response = (PaymentHolidayResponse) readObject(responseString, PaymentHolidayResponse.class);
//
//        //then
//        assertAll(
//                () -> assertEquals("d7442689-9f34-302e-64f3-83ce97c2317c", response.getAccountId())
////                () -> assertEquals(PAYMENT_HOLIDAY_ADD_SUCCESS, response.getStatus())
//        );
//    }

    @Test
    public void shouldCancelPaymentHoliday() {
        //given
        PaymentHolidayRequest paymentHolidayRequest = mortgagePaymentHolidayHelper.buildPaymentHolidayRequest("10/2021", "11/2021");
        String payload = componentHelper.writeValueAsString(paymentHolidayRequest);

        when(restClientService.get(any(String.class), any(HashMap.class)))
                .thenReturn(mortgagePaymentHolidayHelper.getMortgageQueryServiceResponse());
        when(restClientService.post(any(String.class), any(HashMap.class), any(String.class)))
                .thenReturn(mortgagePaymentHolidayHelper.getVaultResponse());
        //when
        MockHttpServletResponse servletResponse = doPUT(CANCEL_PAYMENT_HOLIDAY, payload, mortgagePaymentHolidayHelper.getAccountInfoHeaders());
        String responseString = componentHelper.getServletResponseAsString(servletResponse);
        PaymentHolidayResponse response = (PaymentHolidayResponse) readObject(responseString, PaymentHolidayResponse.class);

        //then
        assertAll(
                () -> assertEquals("d7442689-9f34-302e-64f3-83ce97c2317c", response.getAccountId())
//                () -> assertEquals(PAYMENT_HOLIDAY_CANCEL_SUCCESS, response.getStatus())

        );
    }

    @Test
    public void shouldReturnErrorForEmptyRequestBody() {

        when(restClientService.get(any(String.class), any(HashMap.class)))
                .thenReturn(mortgagePaymentHolidayHelper.getMortgageQueryServiceResponse());
        when(restClientService.post(any(String.class), any(HashMap.class), any(String.class)))
                .thenReturn(mortgagePaymentHolidayHelper.getVaultResponse());
        //when
        MockHttpServletResponse servletResponse = doPOST(ADD_PAYMENT_HOLIDAY, "", mortgagePaymentHolidayHelper.getAccountInfoHeaders());
        String responseString = componentHelper.getServletResponseAsString(servletResponse);
        ErrorResponse errorResponse = (ErrorResponse) readObject(responseString, ErrorResponse.class);
        ErrorInfo errorInfo = errorResponse.getErrors().get(0);

        //then
        assertAll(
                () -> assertEquals(400, servletResponse.getStatus()),
                () -> assertEquals("PNA.MORTGAGE_API.SYS.001", errorResponse.getCode()),
                () -> assertEquals("Bad Request", errorResponse.getMessage()),
                () -> assertEquals("PNA.MORTGAGE_API.POST_PAYMENT_PAYMENT_HOLIDAY.Message.NotReadable", errorInfo.getReasonCode()),
                () -> assertEquals("Required request body is missing", errorInfo.getMessage())
        );
    }

    @Test
    public void shouldReturnErrorForEmptyJson() {
        //when
        MockHttpServletResponse servletResponse = doPOST(ADD_PAYMENT_HOLIDAY, "{}", mortgagePaymentHolidayHelper.getAccountInfoHeaders());
        String responseString = componentHelper.getServletResponseAsString(servletResponse);
        ErrorResponse errorResponse = (ErrorResponse) readObject(responseString, ErrorResponse.class);
        ErrorInfo errorInfo = errorResponse.getErrors().get(0);

        //then
        assertAll(
                () -> assertEquals(400, servletResponse.getStatus()),
                () -> assertEquals("PNA.MORTGAGE_API.SYS.001", errorResponse.getCode()),
                () -> assertEquals("Bad Request", errorResponse.getMessage()),
                () -> assertEquals("PNA.MORTGAGE_API.POST_PAYMENT_PAYMENT_HOLIDAY.Argument.Invalid", errorInfo.getReasonCode()),
                () -> assertEquals(1, errorResponse.getErrors().size())
        );
    }

    @Test
    public void shouldReturnErrorWhenStartDateIsGreaterThanEndDate() {
        //given
        PaymentHolidayRequest paymentHolidayRequest = mortgagePaymentHolidayHelper.buildPaymentHolidayRequest("12/2021", "11/2021");
        String payload = componentHelper.writeValueAsString(paymentHolidayRequest);

        //when
        MockHttpServletResponse servletResponse = doPOST(ADD_PAYMENT_HOLIDAY, payload, mortgagePaymentHolidayHelper.getAccountInfoHeaders());
        String responseString = componentHelper.getServletResponseAsString(servletResponse);
        ErrorResponse errorResponse = (ErrorResponse) readObject(responseString, ErrorResponse.class);
        ErrorInfo errorInfo = errorResponse.getErrors().get(0);

        //then
        assertAll(
                () -> assertEquals(400, servletResponse.getStatus()),
                () -> assertEquals("PNA.MORTGAGE_API.SYS.001", errorResponse.getCode()),
                () -> assertEquals("Bad Request", errorResponse.getMessage()),
                () -> assertEquals("PNA.MORTGAGE_API.POST_PAYMENT_PAYMENT_HOLIDAY.Date.Invalid start/end date", errorInfo.getReasonCode()),
                () -> assertEquals("Invalid Data", errorInfo.getMessage())
        );
    }

    @Test
    public void shouldReturnErrorWhenStartOrEndDateIsLessThanCurrentDate() {
        //given
        PaymentHolidayRequest paymentHolidayRequest = mortgagePaymentHolidayHelper.buildPaymentHolidayRequest("11/2020", "11/2021");
        String payload = componentHelper.writeValueAsString(paymentHolidayRequest);

        //when
        MockHttpServletResponse servletResponse = doPOST(ADD_PAYMENT_HOLIDAY, payload, mortgagePaymentHolidayHelper.getAccountInfoHeaders());
        String responseString = componentHelper.getServletResponseAsString(servletResponse);
        ErrorResponse errorResponse = (ErrorResponse) readObject(responseString, ErrorResponse.class);
        ErrorInfo errorInfo = errorResponse.getErrors().get(0);

        //then
        assertAll(
                () -> assertEquals(400, servletResponse.getStatus()),
                () -> assertEquals("PNA.MORTGAGE_API.SYS.001", errorResponse.getCode()),
                () -> assertEquals("Bad Request", errorResponse.getMessage()),
                () -> assertEquals("PNA.MORTGAGE_API.POST_PAYMENT_PAYMENT_HOLIDAY.Date.Invalid start/end date", errorInfo.getReasonCode()),
                () -> assertEquals("Invalid Data", errorInfo.getMessage())
        );
    }

    @Test
    public void shouldReturnErrorWhenBrandIsMissing() {
        //given
        PaymentHolidayRequest paymentHolidayRequest = mortgagePaymentHolidayHelper.buildPaymentHolidayRequest("2021-10", "2021-11");
        String payload = componentHelper.writeValueAsString(paymentHolidayRequest);
        HttpHeaders accountInfoHeaders = mortgagePaymentHolidayHelper.getAccountInfoHeaders();
        accountInfoHeaders.remove("x-lbg-brand");

        //when
        MockHttpServletResponse servletResponse = doPOST(ADD_PAYMENT_HOLIDAY, payload, accountInfoHeaders);
        String responseString = componentHelper.getServletResponseAsString(servletResponse);
        ErrorResponse errorResponse = (ErrorResponse) readObject(responseString, ErrorResponse.class);
        ErrorInfo errorInfo = errorResponse.getErrors().get(0);

        //then
        assertAll(
                () -> assertEquals(400, servletResponse.getStatus()),
                () -> assertEquals("PNA.MORTGAGE_API.SYS.001", errorResponse.getCode()),
                () -> assertEquals("Bad Request", errorResponse.getMessage()),
                () -> assertEquals("PNA.MORTGAGE_API.POST_PAYMENT_PAYMENT_HOLIDAY.Header.Missing.x-lbg-brand", errorInfo.getReasonCode()),
                () -> assertEquals("Missing request header 'x-lbg-brand' for method parameter of type String", errorInfo.getMessage())
        );
    }

    @Test
    public void shouldReturnErrorWhenBrandIsIncorrect() {
        //given
        PaymentHolidayRequest paymentHolidayRequest = mortgagePaymentHolidayHelper.buildPaymentHolidayRequest("2021-10", "2021-11");
        String payload = componentHelper.writeValueAsString(paymentHolidayRequest);
        HttpHeaders accountInfoHeaders = mortgagePaymentHolidayHelper.getAccountInfoHeaders();
        accountInfoHeaders.set("x-lbg-brand", "xxx");

        //when
        MockHttpServletResponse servletResponse = doPOST(ADD_PAYMENT_HOLIDAY, payload, accountInfoHeaders);
        String responseString = componentHelper.getServletResponseAsString(servletResponse);
        ErrorResponse errorResponse = (ErrorResponse) readObject(responseString, ErrorResponse.class);
        ErrorInfo errorInfo = errorResponse.getErrors().get(0);

        //then
        assertAll(
                () -> assertEquals(400, servletResponse.getStatus()),
                () -> assertEquals("PNA.MORTGAGE_API.SYS.001", errorResponse.getCode()),
                () -> assertEquals("Bad Request", errorResponse.getMessage()),
                () -> assertEquals("PNA.MORTGAGE_API.POST_PAYMENT_PAYMENT_HOLIDAY.Header.Invalid", errorInfo.getReasonCode()),
                () -> assertEquals("Invalid enum value for type x-lbg-brand", errorInfo.getMessage())
        );
    }

    @Test
    public void shouldReturnErrorWhenCorrelationIdIsMissing() {
        //given
        PaymentHolidayRequest paymentHolidayRequest = mortgagePaymentHolidayHelper.buildPaymentHolidayRequest("2021-10", "2021-11");
        String payload = componentHelper.writeValueAsString(paymentHolidayRequest);
        HttpHeaders accountInfoHeaders = mortgagePaymentHolidayHelper.getAccountInfoHeaders();
        accountInfoHeaders.remove("x-lbg-txn-correlation-id");

        //when
        MockHttpServletResponse servletResponse = doPOST(ADD_PAYMENT_HOLIDAY, payload, accountInfoHeaders);
        String responseString = componentHelper.getServletResponseAsString(servletResponse);
        ErrorResponse errorResponse = (ErrorResponse) readObject(responseString, ErrorResponse.class);
        ErrorInfo errorInfo = errorResponse.getErrors().get(0);

        //then
        assertAll(
                () -> assertEquals(400, servletResponse.getStatus()),
                () -> assertEquals("PNA.MORTGAGE_API.SYS.001", errorResponse.getCode()),
                () -> assertEquals("Bad Request", errorResponse.getMessage()),
                () -> assertEquals("PNA.MORTGAGE_API.POST_PAYMENT_PAYMENT_HOLIDAY.Header.Missing.x-lbg-txn-correlation-id", errorInfo.getReasonCode()),
                () -> assertEquals("Missing request header x-lbg-txn-correlation-id for method parameter of type String", errorInfo.getMessage())
        );
    }

    @Test
    public void shouldReturnErrorWhenCorrelationIdIsLessThanTenCharacters() {
        //given
        PaymentHolidayRequest paymentHolidayRequest = mortgagePaymentHolidayHelper.buildPaymentHolidayRequest("2021-10", "2021-11");
        String payload = componentHelper.writeValueAsString(paymentHolidayRequest);
        HttpHeaders accountInfoHeaders = mortgagePaymentHolidayHelper.getAccountInfoHeaders();
        accountInfoHeaders.set("x-lbg-txn-correlation-id", RandomStringUtils.random(9));

        //when
        MockHttpServletResponse servletResponse = doPOST(ADD_PAYMENT_HOLIDAY, payload, accountInfoHeaders);
        String responseString = componentHelper.getServletResponseAsString(servletResponse);
        ErrorResponse errorResponse = (ErrorResponse) readObject(responseString, ErrorResponse.class);
        ErrorInfo errorInfo = errorResponse.getErrors().get(0);

        //then
        assertAll(
                () -> assertEquals(400, servletResponse.getStatus()),
                () -> assertEquals("PNA.MORTGAGE_API.SYS.001", errorResponse.getCode()),
                () -> assertEquals("Bad Request", errorResponse.getMessage()),
                () -> assertEquals("PNA.MORTGAGE_API.POST_PAYMENT_PAYMENT_HOLIDAY.Header.Invalid", errorInfo.getReasonCode()),
                () -> assertEquals("x-lbg-txn-correlation-id size should be between 10 and 40", errorInfo.getMessage())
        );
    }

    @Test
    public void shouldReturnErrorWhenCorrelationIdIsGreaterThanFortyCharacters() {
        //given
        PaymentHolidayRequest paymentHolidayRequest = mortgagePaymentHolidayHelper.buildPaymentHolidayRequest("2021-10", "2021-11");
        String payload = componentHelper.writeValueAsString(paymentHolidayRequest);
        HttpHeaders accountInfoHeaders = mortgagePaymentHolidayHelper.getAccountInfoHeaders();
        accountInfoHeaders.set("x-lbg-txn-correlation-id", RandomStringUtils.random(50));


        //when
        MockHttpServletResponse servletResponse = doPOST(ADD_PAYMENT_HOLIDAY, payload, accountInfoHeaders);
        String responseString = componentHelper.getServletResponseAsString(servletResponse);
        ErrorResponse errorResponse = (ErrorResponse) readObject(responseString, ErrorResponse.class);
        ErrorInfo errorInfo = errorResponse.getErrors().get(0);

        //then
        assertAll(
                () -> assertEquals(400, servletResponse.getStatus()),
                () -> assertEquals("PNA.MORTGAGE_API.SYS.001", errorResponse.getCode()),
                () -> assertEquals("Bad Request", errorResponse.getMessage()),
                () -> assertEquals("PNA.MORTGAGE_API.POST_PAYMENT_PAYMENT_HOLIDAY.Header.Invalid", errorInfo.getReasonCode()),
                () -> assertEquals("x-lbg-txn-correlation-id size should be between 10 and 40", errorInfo.getMessage())
        );
    }

    @Test
    public void shouldReturnErrorWhenAuthorisationIsMissing() {
        //given
        PaymentHolidayRequest paymentHolidayRequest = mortgagePaymentHolidayHelper.buildPaymentHolidayRequest("10/2021", "11/2021");
        String payload = componentHelper.writeValueAsString(paymentHolidayRequest);
        HttpHeaders accountInfoHeaders = mortgagePaymentHolidayHelper.getAccountInfoHeaders();
        accountInfoHeaders.remove("x-lbg-internal-system-id");
        accountInfoHeaders.remove("Authorization");

        //when
        MockHttpServletResponse servletResponse = doPOST(ADD_PAYMENT_HOLIDAY, payload, accountInfoHeaders);
        String responseString = componentHelper.getServletResponseAsString(servletResponse);
        ErrorResponse errorResponse = (ErrorResponse) readObject(responseString, ErrorResponse.class);
        ErrorInfo errorInfo = errorResponse.getErrors().get(0);

        //then
        assertAll(
                () -> assertEquals(401, servletResponse.getStatus()),
                () -> assertEquals("PNA.MORTGAGE_API.SYS.002", errorResponse.getCode()),
                () -> assertEquals("Resource Unauthorised", errorResponse.getMessage()),
                () -> assertEquals("PNA.MORTGAGE_API.POST_PAYMENT_PAYMENT_HOLIDAY.Access.Unauthorised", errorInfo.getReasonCode()),
                () -> assertEquals("Please Supply headers : 'Authorization' or 'x-lbg-internal-system-id'", errorInfo.getMessage())
        );
    }

    @Test
    public void shouldReturnErrorWhenAccountIdIsMoreThan36Chars() {
        //given
        PaymentHolidayRequest paymentHolidayRequest = mortgagePaymentHolidayHelper.getPaymentHolidayRequest();
        String payload = componentHelper.writeValueAsString(paymentHolidayRequest);
        String accountId = RandomStringUtils.random(50);
        //when
        MockHttpServletResponse servletResponse = doPOST("/payment/" + accountId + "/payment-holiday",
                payload,
                mortgagePaymentHolidayHelper.getAccountInfoHeaders());
        String responseString = componentHelper.getServletResponseAsString(servletResponse);
        ErrorResponse errorResponse = (ErrorResponse) readObject(responseString, ErrorResponse.class);
        ErrorInfo errorInfo = errorResponse.getErrors().get(0);

        //then
        assertAll(
                () -> assertEquals(400, servletResponse.getStatus()),
                () -> assertEquals("PNA.MORTGAGE_API.SYS.001", errorResponse.getCode()),
                () -> assertEquals("Bad Request", errorResponse.getMessage()),
                () -> assertEquals("PNA.MORTGAGE_API.POST_PAYMENT_PAYMENT_HOLIDAY.Param.Invalid", errorInfo.getReasonCode()),
                () -> assertEquals("AccountId should be max 36 characters", errorInfo.getMessage())
        );
    }

    @Test
    public void shouldReturnErrorWhenAccountIdIsLessThan36Chars() {
        //given
        PaymentHolidayRequest paymentHolidayRequest = mortgagePaymentHolidayHelper.getPaymentHolidayRequest();
        String payload = componentHelper.writeValueAsString(paymentHolidayRequest);

        //when
        MockHttpServletResponse servletResponse = doPOST("/payment/" + RandomStringUtils.random(5) + "/payment-holiday",
                payload,
                mortgagePaymentHolidayHelper.getAccountInfoHeaders());
        String responseString = componentHelper.getServletResponseAsString(servletResponse);
        ErrorResponse errorResponse = (ErrorResponse) readObject(responseString, ErrorResponse.class);
        ErrorInfo errorInfo = errorResponse.getErrors().get(0);

        //then
        assertAll(
                () -> assertEquals(400, servletResponse.getStatus()),
                () -> assertEquals("PNA.MORTGAGE_API.SYS.001", errorResponse.getCode()),
                () -> assertEquals("Bad Request", errorResponse.getMessage()),
                () -> assertEquals("PNA.MORTGAGE_API.POST_PAYMENT_PAYMENT_HOLIDAY.Param.Invalid", errorInfo.getReasonCode()),
                () -> assertEquals("AccountId should be min 36 characters", errorInfo.getMessage())
        );
    }

    @Test
    public void shouldReturnErrorForAddWhenIncorrectEndpointIsCalled() {
        //given
        PaymentHolidayRequest paymentHolidayRequest = mortgagePaymentHolidayHelper.buildPaymentHolidayRequest("2021-10", "2021-11");
        String payload = componentHelper.writeValueAsString(paymentHolidayRequest);
        HttpHeaders accountInfoHeaders = mortgagePaymentHolidayHelper.getAccountInfoHeaders();

        //when
        MockHttpServletResponse servletResponse = doPOST(ADD_PAYMENT_HOLIDAY.concat("s"), payload, accountInfoHeaders);

        //then
        assertAll(
                () -> assertEquals(404, servletResponse.getStatus())
        );
    }

    @Test
    public void shouldReturnErrorForCancelWhenIncorrectEndpointIsCalled() {
        //given
        PaymentHolidayRequest paymentHolidayRequest = mortgagePaymentHolidayHelper.buildPaymentHolidayRequest("2021-10", "2021-11");
        String payload = componentHelper.writeValueAsString(paymentHolidayRequest);
        HttpHeaders accountInfoHeaders = mortgagePaymentHolidayHelper.getAccountInfoHeaders();

        //when
        MockHttpServletResponse servletResponse = doPOST(CANCEL_PAYMENT_HOLIDAY.concat("s"), payload, accountInfoHeaders);

        //then
        assertAll(
                () -> assertEquals(404, servletResponse.getStatus())
        );
    }

}