package com.lbg.epscw.mortgagesrvc.component;

import com.lbg.epscw.entitlement.service.EntitlementValidationServiceImpl;
import com.lbg.epscw.handler.model.ErrorInfo;
import com.lbg.epscw.mortgagesrvc.helper.ComponentHelper;
import com.lbg.epscw.mortgagesrvc.helper.MortgageAssetDataHelper;
import com.lbg.epscw.mortgagesrvc.helper.MortgagePortingHelper;
import com.lbg.epscw.mortgagesrvc.logger.HystrixContextCopyStrategy;
import com.lbg.epscw.mortgagesrvc.model.Asset;
import com.lbg.epscw.mortgagesrvc.model.MortgageApplicationInfo;
import com.lbg.epscw.mortgagesrvc.restclient.MortgagePortingApplicationAssetRestClient;
import com.lbg.epscw.mortgagesrvc.service.MortgageAssetService;
import com.lbg.epscw.mortgagesrvc.service.MortgagePortingApplicationInfoService;
import com.lbg.epscw.mortgagesrvc.validator.MortgageAssetValidator;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpHeaders;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import static com.google.api.client.http.HttpStatusCodes.STATUS_CODE_BAD_REQUEST;
import static com.google.api.client.http.HttpStatusCodes.STATUS_CODE_SERVER_ERROR;
import static com.lbg.epscw.mortgagesrvc.helper.MortgageAssetDataHelper.*;
import static com.lbg.epscw.mortgagesrvc.model.MortgagePortingApplicationStatus.DECLINED;
import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;

@Tag("component")
@ExtendWith(SpringExtension.class)
@SpringBootTest
@AutoConfigureMockMvc
public class MortgageAssetComponentTest extends WebMVCTest {
    private final MortgageAssetDataHelper mortgageAssetDataHelper = new MortgageAssetDataHelper();
    private final MortgagePortingHelper portingHelper = new MortgagePortingHelper();
    private final ComponentHelper componentHelper = new ComponentHelper();

    @MockBean
    private EntitlementValidationServiceImpl entitlement;

    @MockBean
    private HystrixContextCopyStrategy hystrixContextCopyStrategy;

    @MockBean
    private MortgageAssetService mortgageAssetService;

    @MockBean
    private MortgagePortingApplicationAssetRestClient restClient;

    @MockBean
    private MortgagePortingApplicationInfoService infoService;

    @MockBean
    private MortgageAssetValidator validator;

    @Test
    public void update_asset_info_successful(){
        //given
        String payload = componentHelper.writeValueAsString(mortgageAssetDataHelper.mortgageAssetPayload());
        HttpHeaders headers = mortgageAssetDataHelper.getMortgageAssetHeaders();
        Asset expected = MortgageAssetDataHelper.assetResponse();
        MortgageApplicationInfo info = portingHelper.getMortgagePortingApplicationDetails();

        when(infoService.getApplicationInfo(anyString())).thenReturn(info);
        when(mortgageAssetService.updateAssetInfo(any(), any())).thenReturn(expected);
        when(restClient.createAsset(anyString(), any())).thenReturn(expected);
        when(restClient.updateAsset(anyString(), any())).thenReturn(expected);

        //when
        MockHttpServletResponse response = doPUT(MortgageAssetDataHelper.MORTGAGE_ASSET_INFO_ENDPOINT, payload, headers);
        String responseString = componentHelper.getServletResponseAsString(response);
        Asset actual = readObject(responseString, Asset.class);

        //then
        assertThat(response.getStatus(), is(200));
        assertThat(actual.getAssetId(), is(ASSET_ID));
        assertThat(actual.getMortgageNumber(), is(MORTGAGE_NUMBER));
    }

    @Test
    public void assertThatInvalidStatusThrowsError() {
        //given
        when(infoService.getApplicationInfo(anyString())).thenReturn(MortgageApplicationInfo.builder().status(DECLINED).build());
        //when
        String payload = componentHelper.writeValueAsString(mortgageAssetDataHelper.mortgageAssetPayload());
        HttpHeaders headers = mortgageAssetDataHelper.getMortgageAssetHeaders();
        MockHttpServletResponse response = doPUT(MortgageAssetDataHelper.MORTGAGE_ASSET_INFO_ENDPOINT, payload, headers);
        ErrorInfo error = readErrorInfo(componentHelper.getServletResponseAsString(response));
        //then
        assertThat(response.getStatus(), is(STATUS_CODE_SERVER_ERROR));
        assertEquals("PNA.MORTGAGE_API.PUT_MORTGAGES_APPLICATION_ASSET_INFO.AssetInfo.Failed", error.getReasonCode());
        assertEquals("Invalid Data", error.getMessage());

    }

    @Test
    public void throws_exception_when_brand_is_missing() {
        //given
        HttpHeaders headers = mortgageAssetDataHelper.getMortgageAssetHeaders();
        headers.remove("x-lbg-brand");

        // when
        String payload = componentHelper.writeValueAsString(mortgageAssetDataHelper.mortgageAssetPayload());
        MockHttpServletResponse response = doPUT(MortgageAssetDataHelper.MORTGAGE_ASSET_INFO_ENDPOINT, payload, headers);
        ErrorInfo error = readErrorInfo(componentHelper.getServletResponseAsString(response));

        // then
        assertEquals(400, response.getStatus());
        assertEquals("PNA.MORTGAGE_API.PUT_MORTGAGES_APPLICATION_ASSET_INFO.Header.Missing.x-lbg-brand", error.getReasonCode());
        assertEquals("Missing request header 'x-lbg-brand' for method parameter of type String", error.getMessage());
    }

    @Test
    public void throws_exception_when_channel_is_missing() {
        //given
        HttpHeaders headers = mortgageAssetDataHelper.getMortgageAssetHeaders();
        headers.remove("x-lbg-channel");

        // when
        String payload = componentHelper.writeValueAsString(mortgageAssetDataHelper.mortgageAssetPayload());
        MockHttpServletResponse response = doPUT(MortgageAssetDataHelper.MORTGAGE_ASSET_INFO_ENDPOINT, payload, headers);
        ErrorInfo error = readErrorInfo(componentHelper.getServletResponseAsString(response));

        // then
        assertEquals(400, response.getStatus());
        assertEquals("PNA.MORTGAGE_API.PUT_MORTGAGES_APPLICATION_ASSET_INFO.Header.Missing.x-lbg-channel", error.getReasonCode());
        assertEquals("Missing request header 'x-lbg-channel' for method parameter of type String", error.getMessage());
    }

    @Test
    public void throws_exception_when_brand_name_is_invalid() {
        //given
        HttpHeaders headers = mortgageAssetDataHelper.getMortgageAssetHeaders();
        headers.set("x-lbg-brand", "invalid");

        // when
        String payload = componentHelper.writeValueAsString(mortgageAssetDataHelper.mortgageAssetPayload());
        MockHttpServletResponse response = doPUT(MortgageAssetDataHelper.MORTGAGE_ASSET_INFO_ENDPOINT, payload, headers);
        ErrorInfo error = readErrorInfo(componentHelper.getServletResponseAsString(response));

        // then
        assertEquals(400, response.getStatus());
        assertEquals("PNA.MORTGAGE_API.PUT_MORTGAGES_APPLICATION_ASSET_INFO.Header.Invalid", error.getReasonCode());
        assertEquals("Invalid enum value for type x-lbg-brand", error.getMessage());
    }

}
