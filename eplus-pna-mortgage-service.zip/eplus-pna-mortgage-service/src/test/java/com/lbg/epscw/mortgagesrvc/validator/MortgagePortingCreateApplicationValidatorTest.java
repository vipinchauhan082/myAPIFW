package com.lbg.epscw.mortgagesrvc.validator;

import com.lbg.epscw.mortgagesrvc.exception.MortgageValidationException;
import com.lbg.epscw.mortgagesrvc.helper.MortgagePortingHelper;
import com.lbg.epscw.mortgagesrvc.util.MortgageServiceUtil;
import org.junit.Before;
import org.junit.Test;

import static com.lbg.epscw.mortgagesrvc.helper.MortgagePortingHelper.CUSTOMER_ID;
import static com.lbg.epscw.mortgagesrvc.model.AccountStatus.ACCOUNT_STATUS_CLOSED;
import static com.lbg.epscw.mortgagesrvc.model.AccountStatus.ACCOUNT_STATUS_OPEN;
import static org.mockito.Mockito.mock;

public class MortgagePortingCreateApplicationValidatorTest {
    private final MortgagePortingHelper helper = new MortgagePortingHelper();

    private MortgagePortingCreateApplicationValidator underTest;

    @Before
    public void setup() {
        underTest = new MortgagePortingCreateApplicationValidator(mock(MortgageServiceUtil.class));
    }

    @Test
    public void validate_is_successful_when_open_and_customer_id_matches() {
        underTest.validate(CUSTOMER_ID, helper.mortgageAccountInfoWithStatus(ACCOUNT_STATUS_OPEN.name(), CUSTOMER_ID));
    }

    @Test(expected = MortgageValidationException.class)
    public void validation_fails_when_account_not_open() {
        underTest.validate(CUSTOMER_ID, helper.mortgageAccountInfoWithStatus(ACCOUNT_STATUS_CLOSED.name(), CUSTOMER_ID));
    }

    @Test(expected = MortgageValidationException.class)
    public void validation_fails_when_customer_number_does_not_match() {
        underTest.validate(CUSTOMER_ID, helper.mortgageAccountInfoWithStatus(ACCOUNT_STATUS_OPEN.name(), "invalid"));
    }
}