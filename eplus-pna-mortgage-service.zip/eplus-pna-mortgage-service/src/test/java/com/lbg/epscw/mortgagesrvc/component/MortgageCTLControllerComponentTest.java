package com.lbg.epscw.mortgagesrvc.component;

import com.lbg.epscw.entitlement.service.EntitlementValidationService;
import com.lbg.epscw.handler.model.ErrorInfo;
import com.lbg.epscw.handler.model.ErrorResponse;
import com.lbg.epscw.mortgagesrvc.constants.CommonConstants;
import com.lbg.epscw.mortgagesrvc.exception.MortgageCTLValidationException;
import com.lbg.epscw.mortgagesrvc.helper.ComponentHelper;
import com.lbg.epscw.mortgagesrvc.helper.MortgageCTLHelper;

import com.lbg.epscw.mortgagesrvc.logger.HystrixContextCopyStrategy;
import com.lbg.epscw.mortgagesrvc.model.MortgageCTLResponse;
import com.lbg.epscw.mortgagesrvc.model.VaultMetadataOptionsRequest;
import com.lbg.epscw.mortgagesrvc.restclient.MortgageMetadataRestClient;
import com.lbg.epscw.mortgagesrvc.service.RestClientService;
import org.apache.commons.lang.RandomStringUtils;
import org.junit.Assert;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mockito;
import org.mockito.internal.util.MockUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.context.ApplicationContext;
import org.springframework.http.HttpHeaders;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import static com.lbg.epscw.mortgagesrvc.constants.CommonConstants.NO_CTL_INDICATOR_FOUND;
import static org.junit.jupiter.api.Assertions.assertAll;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.when;

@Tag("component")
@ExtendWith(SpringExtension.class)
@SpringBootTest
@AutoConfigureMockMvc
public class MortgageCTLControllerComponentTest extends WebMVCTest {

    private static final String MORTGAGES_ADD_CTL =
            "/mortgages/f76ca840-2553-d536-1ab8-9fa85c99db05/consent-to-lease";

    private static final String MORTGAGES_CANCEL_CTL =
            "/mortgages/f76ca840-2553-d536-1ab8-9fa85c99db05/consent-to-lease-cancel";

    @MockBean
    private EntitlementValidationService entitlementService;

    @MockBean
    RestClientService restClientService;




    @MockBean
    private HystrixContextCopyStrategy hystrixContextCopyStrategy;

    private ComponentHelper componentHelper;

    private MortgageCTLHelper mortgageCTLHelper;

    @MockBean
    private MortgageMetadataRestClient mortgageCTLRestClient;

    @Autowired
    private ApplicationContext context;

    @BeforeEach
    public void beforeEach() {
        this.componentHelper = new ComponentHelper();
        this.mortgageCTLHelper = new MortgageCTLHelper();
        for (String name : context.getBeanDefinitionNames()) {
            Object bean = context.getBean(name);
            if (MockUtil.isMock(bean)) {
                Mockito.reset(bean);
            }
        }
    }


    @Test
    public void ctl_flag_should_be_updated_to_true_for_repayment_account() {

        when(mortgageCTLRestClient.updateMetadataOptions(anyString(), any(VaultMetadataOptionsRequest.class)))
                .thenReturn(mortgageCTLHelper.buildAccountCtlVaultResponse());

        String payload = componentHelper.writeValueAsString(mortgageCTLHelper.buildCtlRequest());

        // when
        MockHttpServletResponse servletResponse =
                doPOST(MORTGAGES_ADD_CTL, payload, mortgageCTLHelper.updateCTLFlagHeaders());
        String responseString = componentHelper.getServletResponseAsString(servletResponse);
        MortgageCTLResponse mortgageCTLResponse =
                (MortgageCTLResponse) readObject(responseString, MortgageCTLResponse.class);

        //then
        assertEquals("b2c9119f-09e5-4ac9-9738-9e28b334d3fa", mortgageCTLResponse.getAccountId());
        assertEquals("20/12/2020", mortgageCTLResponse.getDetails().get("ctl_start_date"));
        assertEquals("true", mortgageCTLResponse.getDetails().get("ctl_indicator"));
    }


    @Test
    public void shouldReturnErrorForUpdateWhenAccountIdIsMoreThan36Chars() {
        //given
        String payload = componentHelper.writeValueAsString(mortgageCTLHelper.buildCtlRequest());

        //when
        MockHttpServletResponse servletResponse = doPOST("/mortgages/"+ RandomStringUtils.random(50)+"/consent-to-lease",
                payload,
                mortgageCTLHelper.updateCTLFlagHeaders());
        String responseString = componentHelper.getServletResponseAsString(servletResponse);
        ErrorResponse errorResponse = (ErrorResponse) readObject(responseString, ErrorResponse.class);
        ErrorInfo errorInfo = errorResponse.getErrors().get(0);

        //then
        assertAll(
                () -> Assert.assertEquals(400, servletResponse.getStatus()),
                () -> Assert.assertEquals("PNA.MORTGAGE_API.SYS.001", errorResponse.getCode()),
                () -> Assert.assertEquals("Bad Request", errorResponse.getMessage()),
                () -> Assert.assertEquals("AccountId should be max 36 characters", errorInfo.getMessage())
        );
    }

    @Test
    public void shouldReturnErrorForUpdateWhenAccountIdIsLessThan36Chars() {
        //given
        String payload = componentHelper.writeValueAsString(mortgageCTLHelper.buildCtlRequest());
        //when
        MockHttpServletResponse servletResponse = doPOST("/mortgages/"+RandomStringUtils.random(5)+"/consent-to-lease",
                payload,
                mortgageCTLHelper.updateCTLFlagHeaders());
        String responseString = componentHelper.getServletResponseAsString(servletResponse);
        ErrorResponse errorResponse = (ErrorResponse) readObject(responseString, ErrorResponse.class);
        ErrorInfo errorInfo = errorResponse.getErrors().get(0);

        //then
        assertAll(
                () -> Assert.assertEquals(400, servletResponse.getStatus()),
                () -> Assert.assertEquals("PNA.MORTGAGE_API.SYS.001", errorResponse.getCode()),
                () -> Assert.assertEquals("Bad Request", errorResponse.getMessage()),
                () -> Assert.assertEquals("AccountId should be min 36 characters", errorInfo.getMessage())
        );
    }

    @Test
    public void shouldReturnErrorForUpdateWhenCorrelationIdIsGreaterThanFortyCharacters() {
        //given
        String payload = componentHelper.writeValueAsString(mortgageCTLHelper.buildCtlRequest());
        HttpHeaders accountInfoHeaders = mortgageCTLHelper.updateCTLFlagHeaders();
        accountInfoHeaders.set("x-lbg-txn-correlation-id", RandomStringUtils.random(50));
        //when
        MockHttpServletResponse servletResponse = doPOST(MORTGAGES_ADD_CTL,
                payload,
                accountInfoHeaders);
        String responseString = componentHelper.getServletResponseAsString(servletResponse);
        ErrorResponse errorResponse = (ErrorResponse) readObject(responseString, ErrorResponse.class);
        ErrorInfo errorInfo = errorResponse.getErrors().get(0);

        //then
        assertAll(
                () -> Assert.assertEquals(400, servletResponse.getStatus()),
                () -> Assert.assertEquals("PNA.MORTGAGE_API.SYS.001", errorResponse.getCode()),
                () -> Assert.assertEquals("Bad Request", errorResponse.getMessage()),
                () -> Assert.assertEquals("x-lbg-txn-correlation-id size should be between 10 and 40", errorInfo.getMessage())
        );
    }

    @Test
    public void shouldReturnErrorForUpdateWhenCorrelationIdIsLessThanTenCharacters() {
        //given
        String payload = componentHelper.writeValueAsString(mortgageCTLHelper.buildCtlRequest());
        HttpHeaders accountInfoHeaders = mortgageCTLHelper.updateCTLFlagHeaders();
        accountInfoHeaders.set("x-lbg-txn-correlation-id", RandomStringUtils.random(9));
        //when
        MockHttpServletResponse servletResponse = doPOST(MORTGAGES_ADD_CTL,
                payload,
                accountInfoHeaders);
        String responseString = componentHelper.getServletResponseAsString(servletResponse);
        ErrorResponse errorResponse = (ErrorResponse) readObject(responseString, ErrorResponse.class);
        ErrorInfo errorInfo = errorResponse.getErrors().get(0);

        //then
        assertAll(
                () -> Assert.assertEquals(400, servletResponse.getStatus()),
                () -> Assert.assertEquals("PNA.MORTGAGE_API.SYS.001", errorResponse.getCode()),
                () -> Assert.assertEquals("Bad Request", errorResponse.getMessage()),
                () -> Assert.assertEquals("x-lbg-txn-correlation-id size should be between 10 and 40", errorInfo.getMessage())
        );
    }

    @Test
    public void shouldReturnErrorForUpdateWhenCorrelationIdIsMissing() {
        //given
        String payload = componentHelper.writeValueAsString(mortgageCTLHelper.buildCtlRequest());
        HttpHeaders accountInfoHeaders = mortgageCTLHelper.updateCTLFlagHeaders();
        accountInfoHeaders.remove("x-lbg-txn-correlation-id");
        //when
        MockHttpServletResponse servletResponse = doPOST(MORTGAGES_ADD_CTL,
                payload,
                accountInfoHeaders);
        String responseString = componentHelper.getServletResponseAsString(servletResponse);
        ErrorResponse errorResponse = (ErrorResponse) readObject(responseString, ErrorResponse.class);
        ErrorInfo errorInfo = errorResponse.getErrors().get(0);

        //then
        assertAll(
                () -> Assert.assertEquals(400, servletResponse.getStatus()),
                () -> Assert.assertEquals("PNA.MORTGAGE_API.SYS.001", errorResponse.getCode()),
                () -> Assert.assertEquals("Bad Request", errorResponse.getMessage()),
                () -> Assert.assertEquals("Missing request header x-lbg-txn-correlation-id for method parameter of type String", errorInfo.getMessage())
        );
    }

    @Test
    public void shouldReturnErrorForUpdateWhenBrandIsIncorrect() {
        //given
        String payload = componentHelper.writeValueAsString(mortgageCTLHelper.buildCtlRequest());
        HttpHeaders accountInfoHeaders = mortgageCTLHelper.updateCTLFlagHeaders();
        accountInfoHeaders.set("x-lbg-brand", "xxx");
        //when
        MockHttpServletResponse servletResponse = doPOST(MORTGAGES_ADD_CTL,
                payload,
                accountInfoHeaders);
        String responseString = componentHelper.getServletResponseAsString(servletResponse);
        ErrorResponse errorResponse = (ErrorResponse) readObject(responseString, ErrorResponse.class);
        ErrorInfo errorInfo = errorResponse.getErrors().get(0);

        //then
        assertAll(
                () -> Assert.assertEquals(400, servletResponse.getStatus()),
                () -> Assert.assertEquals("PNA.MORTGAGE_API.SYS.001", errorResponse.getCode()),
                () -> Assert.assertEquals("Bad Request", errorResponse.getMessage()),
                () -> Assert.assertEquals("Invalid enum value for type x-lbg-brand", errorInfo.getMessage())
        );
    }

    @Test
    public void shouldReturnErrorForUpdateWhenBrandIsMissing() {
        //given
        String payload = componentHelper.writeValueAsString(mortgageCTLHelper.buildCtlRequest());
        HttpHeaders accountInfoHeaders = mortgageCTLHelper.updateCTLFlagHeaders();
        accountInfoHeaders.remove("x-lbg-brand");
        //when
        MockHttpServletResponse servletResponse = doPOST(MORTGAGES_ADD_CTL,
                payload,
                accountInfoHeaders);
        String responseString = componentHelper.getServletResponseAsString(servletResponse);
        ErrorResponse errorResponse = (ErrorResponse) readObject(responseString, ErrorResponse.class);
        ErrorInfo errorInfo = errorResponse.getErrors().get(0);

        //then
        assertAll(
                () -> Assert.assertEquals(400, servletResponse.getStatus()),
                () -> Assert.assertEquals("PNA.MORTGAGE_API.SYS.001", errorResponse.getCode()),
                () -> Assert.assertEquals("Bad Request", errorResponse.getMessage()),
                () -> Assert.assertEquals("Missing request header 'x-lbg-brand' for method parameter of type String", errorInfo.getMessage())
        );
    }


    @Test
    public void ctl_flag_should_be_updated_to_false_for_cancel_ctl_repayment_account() {

        when(mortgageCTLRestClient.updateMetadataOptions(anyString(), any(VaultMetadataOptionsRequest.class)))
                .thenReturn(mortgageCTLHelper.buildAccountCtlVaultResponseWithFalseCTLIndicator());

        String payload = componentHelper.writeValueAsString(mortgageCTLHelper.buildCtlRequest());

        // when
        MockHttpServletResponse servletResponse =
                doPUT(MORTGAGES_CANCEL_CTL, payload, mortgageCTLHelper.updateCTLFlagHeaders());
        String responseString = componentHelper.getServletResponseAsString(servletResponse);
        MortgageCTLResponse mortgageCTLResponse =
                (MortgageCTLResponse) readObject(responseString, MortgageCTLResponse.class);

        //then
        assertEquals("b2c9119f-09e5-4ac9-9738-9e28b334d3fa", mortgageCTLResponse.getAccountId());
        assertEquals("20/12/2020", mortgageCTLResponse.getDetails().get("ctl_start_date"));
        assertEquals("false", mortgageCTLResponse.getDetails().get("ctl_indicator"));
    }


    @Test
    public void cancel_ctl_should_throw_exception_for_inactive_flag() {
        //given
        String payload = componentHelper.writeValueAsString(mortgageCTLHelper.buildCtlRequest());
        HttpHeaders accountInfoHeaders = mortgageCTLHelper.updateCTLFlagHeaders();

        doThrow(new MortgageCTLValidationException(NO_CTL_INDICATOR_FOUND, CommonConstants.ERROR)).when(mortgageCTLRestClient).validateAccountCTL(anyString());


        //when
        MockHttpServletResponse servletResponse =
                doPUT(MORTGAGES_CANCEL_CTL, payload, mortgageCTLHelper.updateCTLFlagHeaders());
        String responseString = componentHelper.getServletResponseAsString(servletResponse);
        ErrorResponse errorResponse = (ErrorResponse) readObject(responseString, ErrorResponse.class);
        ErrorInfo errorInfo = errorResponse.getErrors().get(0);

        //then
        assertAll(
                () -> Assert.assertEquals(400, servletResponse.getStatus()),
                () -> Assert.assertEquals("PNA.MORTGAGE_API.SYS.001", errorResponse.getCode()),
                () -> Assert.assertEquals("Bad Request", errorResponse.getMessage()),
                () -> Assert.assertEquals("No Active Indicator Found", errorInfo.getMessage())
        );
    }


    @Test
    public void cancel_ctl_shouldReturnErrorForUpdateWhenAccountIdIsMoreThan36Chars() {
        //given
        String payload = componentHelper.writeValueAsString(mortgageCTLHelper.buildCtlRequest());

        //when
        MockHttpServletResponse servletResponse = doPUT("/mortgages/"+RandomStringUtils.random(40)+"/consent-to-lease-cancel",
                payload,
                mortgageCTLHelper.updateCTLFlagHeaders());
        String responseString = componentHelper.getServletResponseAsString(servletResponse);
        ErrorResponse errorResponse = (ErrorResponse) readObject(responseString, ErrorResponse.class);
        ErrorInfo errorInfo = errorResponse.getErrors().get(0);

        //then
        assertAll(
                () -> Assert.assertEquals(400, servletResponse.getStatus()),
                () -> Assert.assertEquals("PNA.MORTGAGE_API.SYS.001", errorResponse.getCode()),
                () -> Assert.assertEquals("Bad Request", errorResponse.getMessage()),
                () -> Assert.assertEquals("AccountId should be max 36 characters", errorInfo.getMessage())
        );
    }

    @Test
    public void cancel_ctl_shouldReturnErrorForUpdateWhenAccountIdIsLessThan36Chars() {
        //given
        String payload = componentHelper.writeValueAsString(mortgageCTLHelper.buildCtlRequest());
        //when
        String accountId = RandomStringUtils.random(5);
        MockHttpServletResponse servletResponse = doPUT("/mortgages/"+ accountId +"/consent-to-lease-cancel",
                payload,
                mortgageCTLHelper.updateCTLFlagHeaders());

        String responseString = componentHelper.getServletResponseAsString(servletResponse);
        ErrorResponse errorResponse = (ErrorResponse) readObject(responseString, ErrorResponse.class);
        ErrorInfo errorInfo = errorResponse.getErrors().get(0);

        //then
        assertAll(
                () -> Assert.assertEquals(400, servletResponse.getStatus()),
                () -> Assert.assertEquals("PNA.MORTGAGE_API.SYS.001", errorResponse.getCode()),
                () -> Assert.assertEquals("Bad Request", errorResponse.getMessage()),
                () -> Assert.assertEquals("AccountId should be min 36 characters", errorInfo.getMessage())
        );
    }

    @Test
    public void cancel_ctl_shouldReturnErrorForUpdateWhenCorrelationIdIsGreaterThanFortyCharacters() {
        //given
        String payload = componentHelper.writeValueAsString(mortgageCTLHelper.buildCtlRequest());
        HttpHeaders accountInfoHeaders = mortgageCTLHelper.updateCTLFlagHeaders();
        accountInfoHeaders.set("x-lbg-txn-correlation-id", RandomStringUtils.random(50));
        //when
        MockHttpServletResponse servletResponse =
                doPUT(MORTGAGES_CANCEL_CTL, payload, accountInfoHeaders);
        String responseString = componentHelper.getServletResponseAsString(servletResponse);
        ErrorResponse errorResponse = (ErrorResponse) readObject(responseString, ErrorResponse.class);
        ErrorInfo errorInfo = errorResponse.getErrors().get(0);

        //then
        assertAll(
                () -> Assert.assertEquals(400, servletResponse.getStatus()),
                () -> Assert.assertEquals("PNA.MORTGAGE_API.SYS.001", errorResponse.getCode()),
                () -> Assert.assertEquals("Bad Request", errorResponse.getMessage()),
                () -> Assert.assertEquals("x-lbg-txn-correlation-id size should be between 10 and 40", errorInfo.getMessage())
        );
    }

    @Test
    public void cancel_ctl_shouldReturnErrorForUpdateWhenCorrelationIdIsLessThanTenCharacters() {
        //given
        String payload = componentHelper.writeValueAsString(mortgageCTLHelper.buildCtlRequest());
        HttpHeaders accountInfoHeaders = mortgageCTLHelper.updateCTLFlagHeaders();
        accountInfoHeaders.set("x-lbg-txn-correlation-id", RandomStringUtils.random(9));
        //when
        MockHttpServletResponse servletResponse =
                doPUT(MORTGAGES_CANCEL_CTL, payload, accountInfoHeaders);
        String responseString = componentHelper.getServletResponseAsString(servletResponse);
        ErrorResponse errorResponse = (ErrorResponse) readObject(responseString, ErrorResponse.class);
        ErrorInfo errorInfo = errorResponse.getErrors().get(0);

        //then
        assertAll(
                () -> Assert.assertEquals(400, servletResponse.getStatus()),
                () -> Assert.assertEquals("PNA.MORTGAGE_API.SYS.001", errorResponse.getCode()),
                () -> Assert.assertEquals("Bad Request", errorResponse.getMessage()),
                () -> Assert.assertEquals("x-lbg-txn-correlation-id size should be between 10 and 40", errorInfo.getMessage())
        );
    }

    @Test
    public void cancel_ctl_shouldReturnErrorForUpdateWhenCorrelationIdIsMissing() {
        //given
        String payload = componentHelper.writeValueAsString(mortgageCTLHelper.buildCtlRequest());
        HttpHeaders accountInfoHeaders = mortgageCTLHelper.updateCTLFlagHeaders();
        accountInfoHeaders.remove("x-lbg-txn-correlation-id");
        //when
        MockHttpServletResponse servletResponse =
                doPUT(MORTGAGES_CANCEL_CTL, payload, accountInfoHeaders);
        String responseString = componentHelper.getServletResponseAsString(servletResponse);
        ErrorResponse errorResponse = (ErrorResponse) readObject(responseString, ErrorResponse.class);
        ErrorInfo errorInfo = errorResponse.getErrors().get(0);

        //then
        assertAll(
                () -> Assert.assertEquals(400, servletResponse.getStatus()),
                () -> Assert.assertEquals("PNA.MORTGAGE_API.SYS.001", errorResponse.getCode()),
                () -> Assert.assertEquals("Bad Request", errorResponse.getMessage()),
                () -> Assert.assertEquals("Missing request header x-lbg-txn-correlation-id for method parameter of type String", errorInfo.getMessage())
        );
    }

    @Test
    public void cancel_ctl_shouldReturnErrorForUpdateWhenBrandIsIncorrect() {
        //given
        String payload = componentHelper.writeValueAsString(mortgageCTLHelper.buildCtlRequest());
        HttpHeaders accountInfoHeaders = mortgageCTLHelper.updateCTLFlagHeaders();
        accountInfoHeaders.set("x-lbg-brand", "xxx");
        //when
        MockHttpServletResponse servletResponse =
                doPUT(MORTGAGES_CANCEL_CTL, payload, accountInfoHeaders);
        String responseString = componentHelper.getServletResponseAsString(servletResponse);
        ErrorResponse errorResponse = (ErrorResponse) readObject(responseString, ErrorResponse.class);
        ErrorInfo errorInfo = errorResponse.getErrors().get(0);

        //then
        assertAll(
                () -> Assert.assertEquals(400, servletResponse.getStatus()),
                () -> Assert.assertEquals("PNA.MORTGAGE_API.SYS.001", errorResponse.getCode()),
                () -> Assert.assertEquals("Bad Request", errorResponse.getMessage()),
                () -> Assert.assertEquals("Invalid enum value for type x-lbg-brand", errorInfo.getMessage())
        );
    }

    @Test
    public void cancel_ctl_shouldReturnErrorForUpdateWhenBrandIsMissing() {
        //given
        String payload = componentHelper.writeValueAsString(mortgageCTLHelper.buildCtlRequest());
        HttpHeaders accountInfoHeaders = mortgageCTLHelper.updateCTLFlagHeaders();
        accountInfoHeaders.remove("x-lbg-brand");
        //when
        MockHttpServletResponse servletResponse =
                doPUT(MORTGAGES_CANCEL_CTL, payload, accountInfoHeaders);
        String responseString = componentHelper.getServletResponseAsString(servletResponse);
        ErrorResponse errorResponse = (ErrorResponse) readObject(responseString, ErrorResponse.class);
        ErrorInfo errorInfo = errorResponse.getErrors().get(0);

        //then
        assertAll(
                () -> Assert.assertEquals(400, servletResponse.getStatus()),
                () -> Assert.assertEquals("PNA.MORTGAGE_API.SYS.001", errorResponse.getCode()),
                () -> Assert.assertEquals("Bad Request", errorResponse.getMessage()),
                () -> Assert.assertEquals("Missing request header 'x-lbg-brand' for method parameter of type String", errorInfo.getMessage())
        );
    }
}
