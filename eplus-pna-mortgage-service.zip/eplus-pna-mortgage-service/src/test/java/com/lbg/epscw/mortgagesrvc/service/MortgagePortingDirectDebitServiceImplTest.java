package com.lbg.epscw.mortgagesrvc.service;

import com.lbg.epscw.mortgagesrvc.exception.CircuitBreakerOpenException;
import com.lbg.epscw.mortgagesrvc.model.DirectDebitDetailsRequest;
import com.lbg.epscw.mortgagesrvc.model.DirectDebitInfo;
import com.lbg.epscw.mortgagesrvc.model.MortgageApplicationInfo;
import com.lbg.epscw.mortgagesrvc.model.PortingApplicationStatusResponse;
import com.lbg.epscw.mortgagesrvc.restclient.MortgagePortingApplicationInfoRestClient;
import org.junit.Before;
import org.junit.Test;

import static com.lbg.epscw.mortgagesrvc.helper.MortgagePortingHelper.APPLICATION_NUMBER;
import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.*;


public class MortgagePortingDirectDebitServiceImplTest {
    private MortgagePortingApplicationInfoRestClient applicationClient;
    private MortgagePortingDirectDebitServiceImpl underTest;
    private final DirectDebitInfo directDebitInfo=new DirectDebitInfo();

    @Before
    public void setUp() throws Exception {
        applicationClient = mock(MortgagePortingApplicationInfoRestClient.class);
        underTest = new MortgagePortingDirectDebitServiceImpl(applicationClient);
    }

    @Test
    public void updateDirectDebitDetails() {
        MortgageApplicationInfo expected = MortgageApplicationInfo.builder().applicationNumber(APPLICATION_NUMBER).directDebitInfo(directDebitInfo).build();

        when(applicationClient.updateApplication(anyString(), any())).thenReturn(expected);
        PortingApplicationStatusResponse actual = underTest.updateDirectDebitDetails(expected,
                DirectDebitDetailsRequest.builder().mainAccountHolder("Jame").secondAccountHolder("Mil")
                        .schemeName("SortCodeAccountNumber").identification("80200110203348").build());
        assertThat(actual, is(PortingApplicationStatusResponse.builder().applicationNumber(APPLICATION_NUMBER).build()));
    }

    @Test(expected = CircuitBreakerOpenException.class)
    public void update_status_fallback_throws_exception_on_broken_circuit() {
        underTest.fallbackUpdateDirectDebitDetails(MortgageApplicationInfo.builder().build(), DirectDebitDetailsRequest.builder().build(), new IllegalArgumentException());

    }
}