package com.lbg.epscw.mortgagesrvc.helper;

import com.lbg.epscw.mortgagesrvc.constants.CommonConstants;
import com.lbg.epscw.mortgagesrvc.dto.*;
import com.lbg.epscw.mortgagesrvc.dto.comms.*;
import com.lbg.epscw.mortgagesrvc.enums.MortgageFamily;
import com.lbg.epscw.mortgagesrvc.enums.Recipient;
import com.lbg.epscw.mortgagesrvc.model.RedemptionStatementPayloadRequest;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.lbg.epscw.mortgagesrvc.model.*;

import java.time.LocalDate;
import java.time.ZoneId;

public class MortgageRedemptionHelper {
    public static final String REDEMPTION_DATE =  LocalDate.now(ZoneId.systemDefault()).plusDays(10).toString();




    public RedemptionStatementPayloadRequest getRedemptionStatementRequest() {
        RedemptionStatementPayloadRequest payloadRequest = new RedemptionStatementPayloadRequest();

        payloadRequest.setTotalAnticipatedInterest("123.00");
        payloadRequest.setTotalBalance("45600.00");
        payloadRequest.setTotalDailyInterest("11.00");
        payloadRequest.setTotalSettlementAmount("12345.00");
        payloadRequest.setRedemptionDate("2021-05-01");
        payloadRequest.setRecipientId("abc-def-ghi");
        payloadRequest.setRecipient(Recipient.CUSTOMER);
        payloadRequest.setReference("1c5f410b-20a8-4275-86b1-e89ed91add9d");


        return payloadRequest;
    }

    public RedemptionStatementPayloadRequest getRedemptionStatementSolicitorRequestPayload() {
        RedemptionStatementPayloadRequest payloadRequest = new RedemptionStatementPayloadRequest();

        payloadRequest.setTotalAnticipatedInterest("123.00");
        payloadRequest.setTotalBalance("45600.00");
        payloadRequest.setTotalDailyInterest("11.00");
        payloadRequest.setTotalSettlementAmount("12345.00");
        payloadRequest.setRedemptionDate("2021-05-01");
        payloadRequest.setRecipientId("abc-def-ghi");
        payloadRequest.setRecipient(Recipient.SOLICITOR);
        payloadRequest.setAddressFirstLine("20 Wellesly Rd");
        payloadRequest.setCity("Croydon");
        payloadRequest.setCountry("UK");
        payloadRequest.setPostcode("CR0 9BN");
        payloadRequest.setRecipientName("LA LAW FIRM");

        return payloadRequest;
    }

    public RedemptionStatementPayloadRequest getRedemptionStatementSolicitorRequestPayloadBad() {
        RedemptionStatementPayloadRequest payloadRequest = new RedemptionStatementPayloadRequest();

        payloadRequest.setTotalAnticipatedInterest("123.00");
        payloadRequest.setTotalBalance("45600.00");
        payloadRequest.setTotalDailyInterest("11.00");
        payloadRequest.setTotalSettlementAmount("12345.00");
        payloadRequest.setRedemptionDate("2021-05-01");
        payloadRequest.setRecipientId("abc-def-ghi");
        payloadRequest.setRecipient(Recipient.SOLICITOR);
        payloadRequest.setAddressFirstLine("20 Wellesly @ Rd");
        payloadRequest.setCity("Croydon)");
        payloadRequest.setCountry("");
        payloadRequest.setPostcode("CR0 %9BN");
        payloadRequest.setRecipientName("L");

        return payloadRequest;
    }

    public RedemptionStatementRequest getRedemptionStatementSolicitorRequest() {
        RedemptionStatementRequest payloadRequest = new RedemptionStatementRequest();

        payloadRequest.setTotalAnticipatedInterest("123.00");
        payloadRequest.setAggregatedBalance("45600.00");
        payloadRequest.setTotalDailyInterest("11.00");
        payloadRequest.setTotalSettlementAmount("12345.00");
        payloadRequest.setRedemptionDate("2021-05-01");
        payloadRequest.setRecipientId("abc-def-ghi");
        payloadRequest.setRecipient(Recipient.SOLICITOR);
        payloadRequest.setAddressFirstLine("20 Wellesly Rd");
        payloadRequest.setCity("Croydon");
        payloadRequest.setCountry("UK");
        payloadRequest.setPostcode("CR0 9BN");
        payloadRequest.setRecipientName("LA LAW FIRM");

        return payloadRequest;
    }


    public MortgageAccountInfo mock_mortgageOverArchingAccountInfoResponse(String acctId) {

        MortgageAccountInfo mortgageAccountInfo = new MortgageAccountInfo();
        List<MortgageAccountData> mortgageAccountDataList = new ArrayList<>();
        MortgageAccountData mortgageAccountData = new MortgageAccountData();

        mortgageAccountData.setAccountId(acctId);
        mortgageAccountData.setProductId("lbg_mortgage");
        mortgageAccountData.setProductFamily(MortgageFamily.MORTGAGE_PAYMENT.toString());
        mortgageAccountDataList.add(mortgageAccountData);
        mortgageAccountInfo.setMortgageAccountData(mortgageAccountDataList);

        return mortgageAccountInfo;
    }


    public MortgageAccountInfo mock_mortgageAccountInfoResponse(String acctId) {

        MortgageAccountInfo mortgageAccountInfo = new MortgageAccountInfo();
        List<MortgageAccountData> mortgageAccountDataList = new ArrayList<>();
        MortgageAccountData mortgageAccountData = new MortgageAccountData();

        mortgageAccountData.setAccountId(acctId);
        mortgageAccountData.setProductId("lbg_mortgage");
        mortgageAccountData.setProductFamily(MortgageFamily.MORTGAGE.toString());
        mortgageAccountDataList.add(mortgageAccountData);
        mortgageAccountInfo.setMortgageAccountData(mortgageAccountDataList);

        return mortgageAccountInfo;
    }

    public MortgageAccountData mock_mortgageAccountData(String acctId) {

        MortgageAccountData mortgageAccountData = new MortgageAccountData();

        mortgageAccountData.setAccountId(acctId);
        mortgageAccountData.setProductId("lbg_mortgage");
        mortgageAccountData.setProductFamily(MortgageFamily.MORTGAGE.toString());
        mortgageAccountData.setAccountNumber("12345678");
        mortgageAccountData.setAccountSortCode("11-22-33");
        mortgageAccountData.setJarName("some Jar");
        mortgageAccountData.setPlanNumber("some plan number");

        return mortgageAccountData;
    }

    public HttpHeaders getAccountInfoHeaders() {

        HttpHeaders httpHeaders = new HttpHeaders();

        httpHeaders.add("Authorization", "Bearer b2c9119f-09e5-4ac9-9738-9e28b334d3fa");
        httpHeaders.add("x-lbg-internal-system-id", "test");
        httpHeaders.add("x-lbg-brand", "IF");
        httpHeaders.add("x-lbg-txn-correlation-id", "123-456-789-123");
        httpHeaders.setContentType(MediaType.APPLICATION_JSON);

        return httpHeaders;
    }

    public Map<String, String> getMapOfHeaders() {

        Map<String,String> httpHeaders = new HashMap<>();

        httpHeaders.put("Authorization", "Bearer b2c9119f-09e5-4ac9-9738-9e28b334d3fa");
        httpHeaders.put("x-lbg-internal-system-id", "test");
        httpHeaders.put("x-lbg-brand", "IF");
        httpHeaders.put("x-lbg-txn-correlation-id", "123-456-789-123");
        httpHeaders.put("Content-Type",MediaType.APPLICATION_JSON_VALUE);

        return httpHeaders;
    }

    public CommsRequest generateCommRequest(){

        List<Document> documentList = new ArrayList<>();
        documentList.add(Document.builder().overrideDocumentFileName(CommonConstants.REDEMPTION_STATEMENT)
                .templateKey(CommonConstants.TEMPLATE_ID_1).build());

        CommsRequest cr = CommsRequest.builder()
                .payload(Payload.builder().data(Data.builder()
                        .anticipatedInterestAmount("1.0")
                        .mortgageBalanceOnDate("120")
                        .redemptionDate("01/01/2021")
                        .statementValidDate("02/02/2021")
                        .settlementAmount("1200")
                        .reference("123456789")
                        .dailyInterestAmount("7")
                        .jarName("some jar")
                        .planNumber("Plan 123545")
                        .accountSortCode("11-22-33")
                        .accountNumber("12345678")
                        .dateOfLetter("02/01/2021")
                        .templateReference(CommonConstants.COMMS_TEMPLATE_REFERENCE)
                        .build()).build())
                .headerData(HeaderData.builder()
                        .customerId("CustomerID1234")
                        .documents(documentList)
                        .category(Category.REGULAR)
                        .overrideNotificationChannel(OverrideNotificationChannel.PAPER)
                        .version(CommonConstants.VERSION_1_REDEMPTION_STATEMENT)
                        .priority(Priority.HIGHEST)
                        .accountId("some account ID")
                        .communicationEvent(CommonConstants.REDEMPTION_STATEMENT)
                        .externalSystemId("our external system ID")
                        .initiator("initiator")
                        .referenceId("some UUID")
                        .build()).build();

        return cr;

    }


    public MortgageSettlementAmountResponse settlementAmountResponse(){
        MortgageSettlementAmountResponse mortgageSettlementAmountResponse = new MortgageSettlementAmountResponse();
        MortgageSettlementAmount mortgageSettlementAmount = new MortgageSettlementAmount();
        List<MortgageSubAccountsSettlementAmount> mortgageSubAccountsSettlementAmountList = new ArrayList<>();
        MortgageAggregatedSettlementAmount mortgageAggregatedSettlementAmount = new MortgageAggregatedSettlementAmount();
        MortgageSubAccountsSettlementAmount mortgageSubAccountsSettlementAmount = new MortgageSubAccountsSettlementAmount();
        MortgageSubAccountsSettlementAmount mortgageSubAccountsSettlementAmount1 = new MortgageSubAccountsSettlementAmount();

        mortgageAggregatedSettlementAmount.setTotalSettlementAmount("4.00");
        mortgageAggregatedSettlementAmount.setAccountId("1b69ad2f-63b3-c70f-6f52-ee85b97e314d");
        mortgageAggregatedSettlementAmount.setDayInterestAfterRedemptionDate("");
        mortgageAggregatedSettlementAmount.setRedemptionDateRequested(REDEMPTION_DATE);
        mortgageAggregatedSettlementAmount.setTotalSettlementDailyInterest("0.00");
        mortgageAggregatedSettlementAmount.setTotalAnticipatedInterest("0.00");

        mortgageSubAccountsSettlementAmount.setSettlementAmount("2.00");
        mortgageSubAccountsSettlementAmount.setAccountId("649270b9-e728-71bf-e6d9-1a3577b6a567");
        mortgageSubAccountsSettlementAmount.setSettlementDailyInterest("0.00");
        mortgageSubAccountsSettlementAmount.setAnticipatedInterest("0.00");

        mortgageSubAccountsSettlementAmount1.setSettlementAmount("2.00");
        mortgageSubAccountsSettlementAmount1.setAccountId("2134567-e728-71bf-e6d9-1a3577123456");
        mortgageSubAccountsSettlementAmount1.setSettlementDailyInterest("0.00");
        mortgageSubAccountsSettlementAmount1.setAnticipatedInterest("0.00");

        mortgageSubAccountsSettlementAmountList.add(mortgageSubAccountsSettlementAmount);
        mortgageSubAccountsSettlementAmountList.add(mortgageSubAccountsSettlementAmount1);

        mortgageSettlementAmount.setMortgageAggregatedSettlementAmount(mortgageAggregatedSettlementAmount);
        mortgageSettlementAmount.setMortgageSubAccountsSettlementAmountList(mortgageSubAccountsSettlementAmountList);
        mortgageSettlementAmount.setCurrency("GBP");

        mortgageSettlementAmountResponse.setMortgageSettlementAmount(mortgageSettlementAmount);

        return mortgageSettlementAmountResponse;

    }

    public SettlementAmountInfo settlementAmountInfoResponse(){
        SettlementAmountInfo settlementAmountResponse = new SettlementAmountInfo();
        SettlementAmount mortgageSettlementAmount = new SettlementAmount();
        List<SubAccountsSettlementAmount> mortgageSubAccountsSettlementAmountList = new ArrayList<>();
        AggregatedSettlementAmountInfo mortgageAggregatedSettlementAmount = new AggregatedSettlementAmountInfo();
        SubAccountsSettlementAmount mortgageSubAccountsSettlementAmount = new SubAccountsSettlementAmount();
        SubAccountsSettlementAmount mortgageSubAccountsSettlementAmount1 = new SubAccountsSettlementAmount();

        mortgageAggregatedSettlementAmount.setTotalSettlementAmount("4.00");
        mortgageAggregatedSettlementAmount.setAccountId("1b69ad2f-63b3-c70f-6f52-ee85b97e314d");
        mortgageAggregatedSettlementAmount.setDayInterestAfterRedemptionDate("1");
        mortgageAggregatedSettlementAmount.setRedemptionDateRequested(REDEMPTION_DATE);
        mortgageAggregatedSettlementAmount.setTotalSettlementDailyInterest("0.00");
        mortgageAggregatedSettlementAmount.setTotalAnticipatedInterest("0.00");

        mortgageSubAccountsSettlementAmount.setSettlementAmount("2.00");
        mortgageSubAccountsSettlementAmount.setAccountId("649270b9-e728-71bf-e6d9-1a3577b6a567");
        mortgageSubAccountsSettlementAmount.setSettlementDailyInterest("0.00");
        mortgageSubAccountsSettlementAmount.setAnticipatedInterest("0.00");

        mortgageSubAccountsSettlementAmount1.setSettlementAmount("2.00");
        mortgageSubAccountsSettlementAmount1.setAccountId("2134567-e728-71bf-e6d9-1a3577123456");
        mortgageSubAccountsSettlementAmount1.setSettlementDailyInterest("0.00");
        mortgageSubAccountsSettlementAmount1.setAnticipatedInterest("0.00");

        mortgageSubAccountsSettlementAmountList.add(mortgageSubAccountsSettlementAmount);
        mortgageSubAccountsSettlementAmountList.add(mortgageSubAccountsSettlementAmount1);

        mortgageSettlementAmount.setAggregatedSettlementAmountInfo(mortgageAggregatedSettlementAmount);
        mortgageSettlementAmount.setSubAccountsSettlementAmountList(mortgageSubAccountsSettlementAmountList);
        mortgageSettlementAmount.setCurrency("GBP");

        settlementAmountResponse.setSettlementAmount(mortgageSettlementAmount);

        return settlementAmountResponse;

    }

    public SettlementAmountRequest settlementAmountRequest(){
        SettlementAmountRequest settlementAmountRequest = new SettlementAmountRequest();
        settlementAmountRequest.setRedemptionDate(REDEMPTION_DATE);

        return settlementAmountRequest;
    }

    public HttpHeaders getSettlementAmountHeaders() {
        HttpHeaders httpHeaders = new HttpHeaders();
        httpHeaders.add("Authorization", "Bearer b2c9119f-09e5-4ac9-9738-9e28b334d3fa");
        httpHeaders.add("x-lbg-brand", "IF");
        httpHeaders.add("x-lbg-channel", "DIGITAL");
        httpHeaders.add("x-lbg-txn-correlation-id", "123-456-789-123");
        httpHeaders.setContentType(MediaType.APPLICATION_JSON);
        return httpHeaders;
    }

}
