package com.lbg.epscw.mortgagesrvc.helper;

import com.lbg.epscw.mortgagesrvc.constants.CommonConstants;
import com.lbg.epscw.mortgagesrvc.dto.*;
import com.lbg.epscw.mortgagesrvc.model.AccountClosureResponse;
import com.lbg.epscw.mortgagesrvc.model.AccountPortingStatusResponse;
import com.lbg.epscw.mortgagesrvc.model.AccountStatus;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;

import java.util.*;

import static com.lbg.epscw.mortgagesrvc.constants.CommonConstants.*;
import static org.springframework.http.MediaType.APPLICATION_JSON_VALUE;

public class MortgageAccountClosureHelper {

    public HttpHeaders getAccountInfoHeaders() {
        HttpHeaders httpHeaders = new HttpHeaders();
        httpHeaders.add("Authorization", "Bearer b2c9119f-09e5-4ac9-9738-9e28b334d3fa");
        httpHeaders.add("x-lbg-internal-system-id", "test");
        httpHeaders.add("x-lbg-brand", "IF");
        httpHeaders.add("x-lbg-txn-correlation-id", "123-456-789-123");
        httpHeaders.setContentType(MediaType.APPLICATION_JSON);
        return httpHeaders;
    }

    public AccountClosureResponse buildAccountClosureResponse() {
        AccountClosureResponse response = new AccountClosureResponse();
        response.setAccountId("b2c9119f-09e5-4ac9-9738-9e28b334d3fa");
        response.setStatus("ACCOUNT_STATUS_PENDING_CLOSURE");
        return response;
    }

    public VaultAccountResponse buildAccountClosureVaultResponse() {
        VaultAccountResponse response = new VaultAccountResponse();
        response.setAccountId("b2c9119f-09e5-4ac9-9738-9e28b334d3fa");
        response.setStatus("ACCOUNT_STATUS_PENDING_CLOSURE");
        return response;
    }

    public List<AccountPortingStatusResponse> buildAccountStatusUpdateResponse() {
        List<AccountPortingStatusResponse> responseList = new ArrayList<>();
        AccountPortingStatusResponse response = new AccountPortingStatusResponse();
        response.setAccountId("b2c9119f-09e5-4ac9-9738-9e28b334d3fa");
        response.setStatus("ACCOUNT_STATUS_CANCELLED");
        responseList.add(response);
        return responseList;
    }

    public VaultAccountStatusUpdateRequest buildAccountClosureVaultRequest() {
        VaultAccountStatusUpdateRequest vaultRequest = new VaultAccountStatusUpdateRequest();
        vaultRequest.setRequestId("1234");
        Account account = new Account();
        account.setStatus(AccountStatus.ACCOUNT_STATUS_PENDING_CLOSURE.name());
        vaultRequest.setAccount(account);
        UpdatedMask updateMask=new UpdatedMask();
        updateMask.setPaths(Arrays.asList("status"));
        vaultRequest.setUpdatedMask(updateMask);
        return vaultRequest;
    }

    public MortgageClosureEligibility buildMortgageClosureEligibilityInfo(boolean eligible){
        MortgageClosureEligibility mortgageClosureEligibility=new MortgageClosureEligibility();
        if(eligible) {
            mortgageClosureEligibility.setEligibleForClosure(true);
            mortgageClosureEligibility.setEligibilityFailureReasonList(new ArrayList<>());
        }
        else {
            mortgageClosureEligibility.setEligibleForClosure(false);
            EligibilityFailureReason eligibilityFailureReason=new EligibilityFailureReason("101","All sub accounts are not closed");
            mortgageClosureEligibility.setEligibilityFailureReasonList(Arrays.asList(eligibilityFailureReason));
        }
        return mortgageClosureEligibility;
    }

    public String getMortgageQueryServiceResponse() {
        return "{\n" +
                "            \"eligibleForClosure\": \"true\",\n" +
                "            \"accountStatus\": \"ACCOUNT_STATUS_OPEN\",\n" +
                "            \"eligibilityFailureReason\": [\n" +

                "    ]\n" +
                "}";
    }

    public String getMortgageQueryServiceResponseWithStatusPendingClosure() {
        return "{\n" +
                "            \"eligibleForClosure\": \"true\",\n" +
                "            \"accountStatus\": \"ACCOUNT_STATUS_PENDING_CLOSURE\",\n" +
                "            \"eligibilityFailureReason\": [\n" +

                "    ]\n" +
                "}";
    }


    public String getMortgageQueryServiceResponseWithPendingOpenSubAccount() {
        return "{\n" +
                "            \"eligibleForClosure\": \"false\",\n" +
                "            \"eligibilityFailureReason\": [\n" +
                "                   {\n" +
                "                       \"code\": \"PENDING_OPEN_SUBACCOUNT\",\n" +
                "                       \"message\": \"All Sub-Accounts are not Closed\"\n" +
                "                   }\n" +
                "    ]\n" +
                "}";
    }

    public String getMortgageQueryServiceResponseWithPendingBalance() {
        return "{\n" +
                "            \"eligibleForClosure\": \"false\",\n" +
                "            \"eligibilityFailureReason\": [\n" +
                "                   {\n" +
                "                       \"code\": \"PENDING_BAL_OVERARCHING_ACC\",\n" +
                "                       \"message\": \"Accounts still holding pending balance\"\n" +
                "                   }\n" +
                "    ]\n" +
                "}";
    }


    public String getAccountStatusUpdateVaultResponse() {
        return "{\n" +
                "    \"id\": \"b2c9119f-09e5-4ac9-9738-9e28b334d3fa\",\n" +
                "    \"status\": \"ACCOUNT_STATUS_PENDING_CLOSURE\"\n" +
                "}";

    }

    public String getAccountStatusUpdateVaultResponseWithCloseStatus() {
        return "{\n" +
                "    \"id\": \"b2c9119f-09e5-4ac9-9738-9e28b334d3fa\",\n" +
                "    \"status\": \"ACCOUNT_STATUS_CLOSED\"\n" +
                "}";

    }

    public Map<String, String> generateRequestHeaders() {
        Map<String, String> headers = new HashMap<>();
        headers.put(AUTHORIZATION, AUTHORIZATION);
        headers.put(X_LBG_BRAND, X_LBG_BRAND);
        headers.put(CommonConstants.CORRELATION_ID, CommonConstants.CORRELATION_ID);
        headers.put(CONTENT_TYPE, APPLICATION_JSON_VALUE);
        headers.put(X_LBG_INTERNAL_SYSTEM_ID, CommonConstants.CORRELATION_ID);
        headers.put(X_LBG_CHANNEL, X_LBG_CHANNEL);
        return headers;
    }

}
