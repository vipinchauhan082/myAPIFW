package com.lbg.epscw.mortgagesrvc.component;

import com.lbg.epscw.entitlement.service.EntitlementValidationServiceImpl;
import com.lbg.epscw.handler.model.ErrorInfo;
import com.lbg.epscw.handler.model.ErrorResponse;
import com.lbg.epscw.mortgagesrvc.helper.ComponentHelper;
import com.lbg.epscw.mortgagesrvc.helper.MortgagePaymentOptionHelper;
import com.lbg.epscw.mortgagesrvc.logger.HystrixContextCopyStrategy;
import com.lbg.epscw.mortgagesrvc.model.MortgagePaymentOptionRequest;
import com.lbg.epscw.mortgagesrvc.model.MortgagePaymentOptionUpdateResponse;
import com.lbg.epscw.mortgagesrvc.service.RestClientService;
import org.apache.commons.lang.RandomStringUtils;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.context.ApplicationContext;
import org.springframework.http.HttpHeaders;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import java.util.HashMap;
import java.util.Map;

import static org.junit.Assert.assertEquals;
import static org.junit.jupiter.api.Assertions.assertAll;
import static org.mockito.ArgumentMatchers.any;
import static org.powermock.api.mockito.PowerMockito.when;

@Tag("component")
@ExtendWith(SpringExtension.class)
@SpringBootTest
@AutoConfigureMockMvc
public class UpdateMortgagePaymentOptionComponentTest extends WebMVCTest{

    @MockBean
    RestClientService restClientService;

    @MockBean
    private EntitlementValidationServiceImpl entitlementValidationService;

    @Autowired
    private ApplicationContext context;

    @MockBean
    private HystrixContextCopyStrategy hystrixContextCopyStrategy;

    private static final String UPDATE_MORTGAGE_PAYMENT_OPTION ="/mortgages/5a688301-6d00-485c-0242-1ee03844a5c4/mortgage-payment-option";

    private ComponentHelper componentHelper = new ComponentHelper();

    private MortgagePaymentOptionHelper mortgagePaymentOptionHelper = new MortgagePaymentOptionHelper();

    @Test
    public void shouldUpdateMortgagePaymentOption() {
        //given
        MortgagePaymentOptionRequest mortgagePaymentOptionRequest = mortgagePaymentOptionHelper.getMortgagePaymentRequest();
        String payload = componentHelper.writeValueAsString(mortgagePaymentOptionRequest);

        when(restClientService.get(any(String.class), any(HashMap.class)))
                .thenReturn(mortgagePaymentOptionHelper.getMortgageQueryServiceResponse());
        when(restClientService.post(any(String.class), any(HashMap.class), any(String.class)))
                .thenReturn(mortgagePaymentOptionHelper.getVaultResponse());

        //when
        MockHttpServletResponse servletResponse = doPUT(UPDATE_MORTGAGE_PAYMENT_OPTION,
                payload,
                mortgagePaymentOptionHelper.getAccountInfoHeaders());
        String responseString = componentHelper.getServletResponseAsString(servletResponse);
        MortgagePaymentOptionUpdateResponse response = (MortgagePaymentOptionUpdateResponse) readObject(responseString, MortgagePaymentOptionUpdateResponse.class);
        Map.Entry<String,String> entry = response.getInstanceParamVals().entrySet().iterator().next();
        String mpo = entry.getValue();

        //then
        assertAll(
                () -> assertEquals("5a688301-6d00-485c-0242-1ee03844a5c4", response.getAccountId()),
                () -> assertEquals("ACCOUNT_UPDATE_STATUS_PENDING_EXECUTION", response.getStatus()),
                () -> assertEquals("LOWER_PAYMENTS", mpo)

        );
    }

    @Test
    public void shouldReturnErrorForUpdateWhenMortgagePaymentOptionIsInvalid() {
        //given
        MortgagePaymentOptionRequest mortgagePaymentOptionRequest = mortgagePaymentOptionHelper.getMortgagePaymentRequest();
        mortgagePaymentOptionRequest.setOption("abc");
        String payload = componentHelper.writeValueAsString(mortgagePaymentOptionRequest);

        //when
        MockHttpServletResponse servletResponse = doPUT(UPDATE_MORTGAGE_PAYMENT_OPTION,
                payload,
                mortgagePaymentOptionHelper.getAccountInfoHeaders());
        String responseString = componentHelper.getServletResponseAsString(servletResponse);
        ErrorResponse errorResponse = (ErrorResponse) readObject(responseString, ErrorResponse.class);
        ErrorInfo errorInfo = errorResponse.getErrors().get(0);

        //then
        assertAll(
                () -> assertEquals(400, servletResponse.getStatus()),
                () -> assertEquals("PNA.MORTGAGE_API.SYS.001", errorResponse.getCode()),
                () -> assertEquals("Bad Request", errorResponse.getMessage()),
                () -> assertEquals("PNA.MORTGAGE_API.PUT_MORTGAGES_MORTGAGE_PAYMENT_OPTION.Argument.Invalid", errorInfo.getReasonCode()),
                () -> assertEquals("Option is not a valid Mortgage Payment Option", errorInfo.getMessage())
        );
    }

    @Test
    public void shouldReturnErrorForUpdateMortgagePaymentOptionWhenAccountIdIsSubAccount() {

        //given
        MortgagePaymentOptionRequest mortgagePaymentOptionRequest = mortgagePaymentOptionHelper.getMortgagePaymentRequest();
        String payload = componentHelper.writeValueAsString(mortgagePaymentOptionRequest);

        when(restClientService.get(any(String.class), any(HashMap.class)))
                .thenReturn(mortgagePaymentOptionHelper.getMortgageQueryServiceInvalidResponse());
        when(restClientService.post(any(String.class), any(HashMap.class), any(String.class)))
                .thenReturn(mortgagePaymentOptionHelper.getVaultResponse());

        //when
        MockHttpServletResponse servletResponse = doPUT(UPDATE_MORTGAGE_PAYMENT_OPTION,
                payload,
                mortgagePaymentOptionHelper.getAccountInfoHeaders());

        String responseString = componentHelper.getServletResponseAsString(servletResponse);
        ErrorResponse errorResponse = (ErrorResponse) readObject(responseString, ErrorResponse.class);
        ErrorInfo errorInfo = errorResponse.getErrors().get(0);

        //then
        assertAll(
                () -> assertEquals(400, servletResponse.getStatus()),
                () -> assertEquals("PNA.MORTGAGE_API.BUS.601", errorResponse.getCode()),
                () -> assertEquals("PNA.MORTGAGE_API.PUT_MORTGAGES_MORTGAGE_PAYMENT_OPTION.MPO.RequestInvalid", errorInfo.getReasonCode()),
                () -> assertEquals("Mortgage Payment Option can not be set at sub-account level", errorInfo.getMessage())

        );
    }

    @Test
    public void shouldReturnErrorForUpdateMortgagePaymentOptionWhenOffsettingOptionIs2() {

        //given
        MortgagePaymentOptionRequest mortgagePaymentOptionRequest = mortgagePaymentOptionHelper.getMortgagePaymentRequest();
        String payload = componentHelper.writeValueAsString(mortgagePaymentOptionRequest);

        when(restClientService.get(any(String.class), any(HashMap.class)))
                .thenReturn(mortgagePaymentOptionHelper.getMortgageQueryServiceInvalidResponse2());
        when(restClientService.post(any(String.class), any(HashMap.class), any(String.class)))
                .thenReturn(mortgagePaymentOptionHelper.getVaultResponse());

        //when
        MockHttpServletResponse servletResponse = doPUT(UPDATE_MORTGAGE_PAYMENT_OPTION,
                payload,
                mortgagePaymentOptionHelper.getAccountInfoHeaders());

        String responseString = componentHelper.getServletResponseAsString(servletResponse);
        ErrorResponse errorResponse = (ErrorResponse) readObject(responseString, ErrorResponse.class);
        ErrorInfo errorInfo = errorResponse.getErrors().get(0);

        //then
        assertAll(
                () -> assertEquals(400, servletResponse.getStatus()),
                () -> assertEquals("PNA.MORTGAGE_API.BUS.601", errorResponse.getCode()),
                () -> assertEquals("PNA.MORTGAGE_API.PUT_MORTGAGES_MORTGAGE_PAYMENT_OPTION.MPO.OffsettingInvalid", errorInfo.getReasonCode()),
                () -> assertEquals("Mortgage Payment Option can not be set for Offsetting Option 'OFFSET_DEBIT_BALANCES'", errorInfo.getMessage())

        );
    }

    @Test
    public void shouldReturnErrorForEmptyJson() {
        //when
        MockHttpServletResponse servletResponse = doPUT(UPDATE_MORTGAGE_PAYMENT_OPTION,
                "{}",
                mortgagePaymentOptionHelper.getAccountInfoHeaders());

        String responseString = componentHelper.getServletResponseAsString(servletResponse);
        ErrorResponse errorResponse = (ErrorResponse) readObject(responseString, ErrorResponse.class);
        ErrorInfo errorInfo = errorResponse.getErrors().get(0);

        //then
        assertAll(
                () -> assertEquals(400, servletResponse.getStatus()),
                () -> assertEquals("PNA.MORTGAGE_API.SYS.001", errorResponse.getCode()),
                () -> assertEquals("Bad Request", errorResponse.getMessage())

        );
    }

    @Test
    public void shouldReturnErrorForEmptyRequestBody() {
        //given
        //when
        MockHttpServletResponse servletResponse = doPUT(UPDATE_MORTGAGE_PAYMENT_OPTION,
                "",
                mortgagePaymentOptionHelper.getAccountInfoHeaders());

        String responseString = componentHelper.getServletResponseAsString(servletResponse);
        ErrorResponse errorResponse = (ErrorResponse) readObject(responseString, ErrorResponse.class);
        ErrorInfo errorInfo = errorResponse.getErrors().get(0);

        //then
        assertAll(
                () -> assertEquals(400, servletResponse.getStatus()),
                () -> assertEquals("PNA.MORTGAGE_API.SYS.001", errorResponse.getCode()),
                () -> assertEquals("Bad Request", errorResponse.getMessage())

        );
    }

    @Test
    public void shouldReturnErrorForUpdateWhenAccountIdIsLessThan36Chars() {
        //given
        MortgagePaymentOptionRequest mortgagePaymentOptionRequest = mortgagePaymentOptionHelper.getMortgagePaymentRequest();
        String payload = componentHelper.writeValueAsString(mortgagePaymentOptionRequest);

        //when
        MockHttpServletResponse servletResponse = doPUT("/mortgages/"+ RandomStringUtils.random(5)+"/mortgage-payment-option",
                payload,
                mortgagePaymentOptionHelper.getAccountInfoHeaders());
        String responseString = componentHelper.getServletResponseAsString(servletResponse);
        ErrorResponse errorResponse = (ErrorResponse) readObject(responseString, ErrorResponse.class);
        ErrorInfo errorInfo = errorResponse.getErrors().get(0);

        //then
        assertAll(
                () -> assertEquals(400, servletResponse.getStatus()),
                () -> assertEquals("PNA.MORTGAGE_API.SYS.001", errorResponse.getCode()),
                () -> assertEquals("Bad Request", errorResponse.getMessage()),
                () -> assertEquals("AccountId should be min 36 characters", errorInfo.getMessage())
        );
    }

    @Test
    public void shouldReturnErrorForUpdateWhenAccountIdIsMoreThan36Chars() {
        //given
        MortgagePaymentOptionRequest mortgagePaymentOptionRequest = mortgagePaymentOptionHelper.getMortgagePaymentRequest();
        String payload = componentHelper.writeValueAsString(mortgagePaymentOptionRequest);

        //when
        MockHttpServletResponse servletResponse = doPUT("/mortgages/"+ RandomStringUtils.random(40)+"/mortgage-payment-option",
                payload,
                mortgagePaymentOptionHelper.getAccountInfoHeaders());
        String responseString = componentHelper.getServletResponseAsString(servletResponse);
        ErrorResponse errorResponse = (ErrorResponse) readObject(responseString, ErrorResponse.class);
        ErrorInfo errorInfo = errorResponse.getErrors().get(0);

        //then
        assertAll(
                () -> assertEquals(400, servletResponse.getStatus()),
                () -> assertEquals("PNA.MORTGAGE_API.SYS.001", errorResponse.getCode()),
                () -> assertEquals("Bad Request", errorResponse.getMessage()),
                () -> assertEquals("AccountId should be max 36 characters", errorInfo.getMessage())
        );
    }

    @Test
    public void shouldReturnErrorForUpdateWhenCorrelationIdIsGreaterThanFortyCharacters() {
        //given
        MortgagePaymentOptionRequest mortgagePaymentOptionRequest = mortgagePaymentOptionHelper.getMortgagePaymentRequest();
        String payload = componentHelper.writeValueAsString(mortgagePaymentOptionRequest);

        HttpHeaders accountInfoHeaders = mortgagePaymentOptionHelper.getAccountInfoHeaders();
        accountInfoHeaders.set("x-lbg-txn-correlation-id", RandomStringUtils.random(50));
        //when
        MockHttpServletResponse servletResponse = doPUT(UPDATE_MORTGAGE_PAYMENT_OPTION,
                payload,
                accountInfoHeaders);
        String responseString = componentHelper.getServletResponseAsString(servletResponse);
        ErrorResponse errorResponse = (ErrorResponse) readObject(responseString, ErrorResponse.class);
        ErrorInfo errorInfo = errorResponse.getErrors().get(0);

        //then
        assertAll(
                () -> assertEquals(400, servletResponse.getStatus()),
                () -> assertEquals("PNA.MORTGAGE_API.SYS.001", errorResponse.getCode()),
                () -> assertEquals("Bad Request", errorResponse.getMessage()),
                () -> assertEquals("x-lbg-txn-correlation-id size should be between 10 and 40", errorInfo.getMessage())
        );
    }

    @Test
    public void shouldReturnErrorForUpdateWhenCorrelationIdIsLessThanTenCharacters() {
        //given
        MortgagePaymentOptionRequest mortgagePaymentOptionRequest = mortgagePaymentOptionHelper.getMortgagePaymentRequest();
        String payload = componentHelper.writeValueAsString(mortgagePaymentOptionRequest);

        HttpHeaders accountInfoHeaders = mortgagePaymentOptionHelper.getAccountInfoHeaders();
        accountInfoHeaders.set("x-lbg-txn-correlation-id", RandomStringUtils.random(50));
        //when
        MockHttpServletResponse servletResponse = doPUT(UPDATE_MORTGAGE_PAYMENT_OPTION,
                payload,
                accountInfoHeaders);
        String responseString = componentHelper.getServletResponseAsString(servletResponse);
        ErrorResponse errorResponse = (ErrorResponse) readObject(responseString, ErrorResponse.class);
        ErrorInfo errorInfo = errorResponse.getErrors().get(0);

        //then
        assertAll(
                () -> assertEquals(400, servletResponse.getStatus()),
                () -> assertEquals("PNA.MORTGAGE_API.SYS.001", errorResponse.getCode()),
                () -> assertEquals("Bad Request", errorResponse.getMessage()),
                () -> assertEquals("x-lbg-txn-correlation-id size should be between 10 and 40", errorInfo.getMessage())
        );
    }

    @Test
    public void shouldReturnErrorForUpdateWhenCorrelationIdIsMissing() {
        //given
        MortgagePaymentOptionRequest mortgagePaymentOptionRequest = mortgagePaymentOptionHelper.getMortgagePaymentRequest();
        String payload = componentHelper.writeValueAsString(mortgagePaymentOptionRequest);

        HttpHeaders accountInfoHeaders = mortgagePaymentOptionHelper.getAccountInfoHeaders();
        accountInfoHeaders.remove("x-lbg-txn-correlation-id");
        //when
        MockHttpServletResponse servletResponse = doPUT(UPDATE_MORTGAGE_PAYMENT_OPTION,
                payload,
                accountInfoHeaders);
        String responseString = componentHelper.getServletResponseAsString(servletResponse);
        ErrorResponse errorResponse = (ErrorResponse) readObject(responseString, ErrorResponse.class);
        ErrorInfo errorInfo = errorResponse.getErrors().get(0);

        //then
        assertAll(
                () -> assertEquals(400, servletResponse.getStatus()),
                () -> assertEquals("PNA.MORTGAGE_API.SYS.001", errorResponse.getCode()),
                () -> assertEquals("Bad Request", errorResponse.getMessage()),
                () -> assertEquals("Missing request header x-lbg-txn-correlation-id for method parameter of type String", errorInfo.getMessage())
        );
    }


    @Test
    public void shouldReturnErrorForUpdateWhenBrandIsMissing() {
        //given
        MortgagePaymentOptionRequest mortgagePaymentOptionRequest = mortgagePaymentOptionHelper.getMortgagePaymentRequest();
        String payload = componentHelper.writeValueAsString(mortgagePaymentOptionRequest);

        HttpHeaders accountInfoHeaders = mortgagePaymentOptionHelper.getAccountInfoHeaders();
        accountInfoHeaders.remove("x-lbg-brand");
        //when
        MockHttpServletResponse servletResponse = doPUT(UPDATE_MORTGAGE_PAYMENT_OPTION,
                payload,
                accountInfoHeaders);
        String responseString = componentHelper.getServletResponseAsString(servletResponse);
        ErrorResponse errorResponse = (ErrorResponse) readObject(responseString, ErrorResponse.class);
        ErrorInfo errorInfo = errorResponse.getErrors().get(0);

        //then
        assertAll(
                () -> assertEquals(400, servletResponse.getStatus()),
                () -> assertEquals("PNA.MORTGAGE_API.SYS.001", errorResponse.getCode()),
                () -> assertEquals("Bad Request", errorResponse.getMessage()),
                () -> assertEquals("Missing request header 'x-lbg-brand' for method parameter of type String", errorInfo.getMessage())
        );
    }
}
