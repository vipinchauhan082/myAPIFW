package com.lbg.epscw.mortgagesrvc.service;

import com.lbg.epscw.mortgagesrvc.exception.CircuitBreakerOpenException;
import com.lbg.epscw.mortgagesrvc.helper.MortgageOffsettingHelper;
import com.lbg.epscw.mortgagesrvc.model.OffsettingOptionUpdateResponse;
import com.lbg.epscw.mortgagesrvc.model.OffsettingRequest;
import com.lbg.epscw.mortgagesrvc.model.VaultAccountOptionsUpdateRequest;
import com.lbg.epscw.mortgagesrvc.restclient.MortgageAccountOptionRestClient;
import com.lbg.epscw.mortgagesrvc.util.MortgageServiceUtil;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.Map;

import static org.junit.Assert.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.powermock.api.mockito.PowerMockito.mock;
import static org.powermock.api.mockito.PowerMockito.when;


@RunWith(SpringRunner.class)
public class MortgageOffsettingServiceImplTest {

    @Mock
    private MortgageServiceUtil mortgageServiceUtil;

    @Mock
    private MortgageAccountOptionRestClient mortgageAccountOptionRestClient;

    @Before
    public void setup() {
        mortgageAccountOptionRestClient = mock(MortgageAccountOptionRestClient.class);
        mortgageServiceUtil=mock(MortgageServiceUtil.class);

    }

    private MortgageOffsettingHelper mortgageOffsettingHelper= new MortgageOffsettingHelper();

    @Test
    public void update_offsetting_option_success_with_OFFSET_DEBIT_BALANCES(){

        MortgageOffsettingService mortgageOffsettingService= new MortgageOffsettingServiceImpl(mortgageAccountOptionRestClient, mortgageServiceUtil);

        when(mortgageServiceUtil.writeObjectAsString(any(OffsettingRequest.class))).thenReturn("tempString");

        Map<String,String> readObjectMap= mortgageOffsettingHelper.readObjectrespone();

        when(mortgageServiceUtil.readObject(any(String.class),any())).thenReturn(readObjectMap);

        when(mortgageAccountOptionRestClient.updateAccountOptions(any(VaultAccountOptionsUpdateRequest.class))).thenReturn(mortgageOffsettingHelper.mock_AccountOptionsUpdateResponse("OFFSET_DEBIT_BALANCES"));

        OffsettingOptionUpdateResponse offsettingOptionUpdateResponse=mortgageOffsettingService.updateOffsettingOption(mortgageOffsettingHelper.getOffsettingRequest("OFFSET_DEBIT_BALANCES"),mortgageOffsettingHelper.mortgageAccountInfo_withOffsetting(),
                "6965d050-d8fd-7fc3-4b66-41e72168be27");

        assertEquals("6965d050-d8fd-7fc3-4b66-41e72168be27", offsettingOptionUpdateResponse.getAccountId());
        assertEquals("OFFSET_DEBIT_BALANCES",offsettingOptionUpdateResponse.getInstanceParamVals().get("OffsettingOption"));
    }

    @Test
    public void update_offsetting_option_success_with_OFFSET_CREDIT_BALANCES(){

        MortgageOffsettingService mortgageOffsettingService= new MortgageOffsettingServiceImpl(mortgageAccountOptionRestClient, mortgageServiceUtil);

        when(mortgageServiceUtil.writeObjectAsString(any(OffsettingRequest.class))).thenReturn("tempString");

        Map<String,String> readObjectMap= mortgageOffsettingHelper.readObjectrespone();

        when(mortgageServiceUtil.readObject(any(String.class),any())).thenReturn(readObjectMap);

        when(mortgageAccountOptionRestClient.updateAccountOptions(any(VaultAccountOptionsUpdateRequest.class))).thenReturn(mortgageOffsettingHelper.mock_AccountOptionsUpdateResponse("OFFSET_CREDIT_BALANCES"));

        OffsettingOptionUpdateResponse offsettingOptionUpdateResponse=mortgageOffsettingService.updateOffsettingOption(mortgageOffsettingHelper.getOffsettingRequest("OFFSET_CREDIT_BALANCES"),mortgageOffsettingHelper.mortgageAccountInfo_withOffsetting(),
                "6965d050-d8fd-7fc3-4b66-41e72168be27");

        assertEquals("6965d050-d8fd-7fc3-4b66-41e72168be27", offsettingOptionUpdateResponse.getAccountId());
        assertEquals("OFFSET_CREDIT_BALANCES",offsettingOptionUpdateResponse.getInstanceParamVals().get("OffsettingOption"));
    }

    @Test
    public void update_offsetting_option_returns_null(){

        MortgageOffsettingService mortgageOffsettingService= new MortgageOffsettingServiceImpl(mortgageAccountOptionRestClient, mortgageServiceUtil);

        when(mortgageServiceUtil.writeObjectAsString(any(OffsettingRequest.class))).thenReturn("tempString");

        Map<String,String> readObjectMap= mortgageOffsettingHelper.readObjectrespone();

        when(mortgageServiceUtil.readObject(any(String.class),any())).thenReturn(readObjectMap);

        when(mortgageAccountOptionRestClient.updateAccountOptions(any(VaultAccountOptionsUpdateRequest.class))).thenReturn(null);

        OffsettingOptionUpdateResponse offsettingOptionUpdateResponse=mortgageOffsettingService.updateOffsettingOption(mortgageOffsettingHelper.getOffsettingRequest("OFFSET_DEBIT_BALANCES"),mortgageOffsettingHelper.mortgageAccountInfo_withOffsetting(),
                "ceabb62f-ee67-85da-fb0d-00415c349f89");

        assertEquals(null,offsettingOptionUpdateResponse);

    }



    @Test(expected = CircuitBreakerOpenException.class)
    public void hystrix_test_on_fallbackSetUpOverPaymentOptions() {

        MortgageOffsettingServiceImpl mortgageOffsettingService= new MortgageOffsettingServiceImpl(mortgageAccountOptionRestClient,mortgageServiceUtil);
        mortgageOffsettingService.fallbackUpdateOffsettingOption(mortgageOffsettingHelper.getOffsettingRequest("OFFSET_DEBIT_BALANCES"),mortgageOffsettingHelper.mortgageAccountInfo_withOffsetting(),"f76ca840-2553-d536-1ab8-9fa85c99db05",
                new Exception("Circuit open on update account options"));
    }



}
