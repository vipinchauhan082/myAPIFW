package com.lbg.epscw.mortgagesrvc.component;

import com.lbg.epscw.entitlement.service.EntitlementValidationServiceImpl;
import com.lbg.epscw.handler.constants.SystemErrors;
import com.lbg.epscw.handler.exception.RestServiceException;
import com.lbg.epscw.handler.model.ErrorInfo;
import com.lbg.epscw.handler.model.ErrorResponse;
import com.lbg.epscw.mortgagesrvc.helper.ComponentHelper;
import com.lbg.epscw.mortgagesrvc.helper.MortgageNominationHelper;
import com.lbg.epscw.mortgagesrvc.logger.HystrixContextCopyStrategy;
import com.lbg.epscw.mortgagesrvc.model.NominationRequest;
import com.lbg.epscw.mortgagesrvc.model.NominationResponse;
import com.lbg.epscw.mortgagesrvc.service.RestClientService;
import org.apache.commons.lang.RandomStringUtils;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mockito;
import org.mockito.internal.util.MockUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.context.ApplicationContext;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.util.StringUtils;

import java.util.HashMap;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import static org.junit.jupiter.api.Assertions.assertAll;
import static org.mockito.ArgumentMatchers.any;
import static org.powermock.api.mockito.PowerMockito.when;

@Tag("component")
@ExtendWith(SpringExtension.class)
@SpringBootTest
@AutoConfigureMockMvc
public class MortgageNominationComponentTest extends WebMVCTest {

    private static final String MORTGAGES_NOMINATION =
            "/mortgages/f76ca840-2553-d536-1ab8-9fa85c99db05/nomination";

    @MockBean
    private EntitlementValidationServiceImpl entitlementValidationService;

    @MockBean
    RestClientService restClientService;

    @MockBean
    private HystrixContextCopyStrategy hystrixContextCopyStrategy;

    private ComponentHelper componentHelper;

    private MortgageNominationHelper mortgageNominationHelper;

    @Autowired
    private ApplicationContext context;

    @BeforeEach
    public void beforeEach() {
        this.componentHelper = new ComponentHelper();
        this.mortgageNominationHelper = new MortgageNominationHelper();
        for (String name : context.getBeanDefinitionNames()) {
            Object bean = context.getBean(name);
            if (MockUtil.isMock(bean)) {
                Mockito.reset(bean);
            }
        }
    }

    @Test
    public void shouldUpdateNomination() {
        //given
        when(restClientService.get(any(String.class), any(HashMap.class)))
                .thenReturn(mortgageNominationHelper.getMortgageQueryServiceResponse());
        when(restClientService.post(any(String.class), any(HashMap.class), any(String.class)))
                .thenReturn(mortgageNominationHelper.getUpdateNominationVaultResponse());

        NominationRequest nominationRequest = mortgageNominationHelper.getNominationRequest();
        String payload = componentHelper.writeValueAsString(nominationRequest);

        //when
        MockHttpServletResponse servletResponse = doPUT(MORTGAGES_NOMINATION, payload, mortgageNominationHelper.getAccountInfoHeaders());
        String responseString = componentHelper.getServletResponseAsString(servletResponse);
        NominationResponse response = (NominationResponse) readObject(responseString, NominationResponse.class);

        //then
        assertAll(
                () -> assertEquals("ee295584-cea8-d318-9c86-31be00d4063e", response.getAccountId()),
                () -> assertEquals("ACCOUNT_UPDATE_STATUS_PENDING_EXECUTION", response.getStatus()),
                () -> assertEquals("90e804ab-5dad-7f7c-1d71-ab914545ebcc", response.getAdditionalDetails().get("NominatedAdhocOverpaymentAccount"))
        );
    }

    @Test
    public void shouldAddNomination() {
        //given
        when(restClientService.get(any(String.class), any(HashMap.class)))
                .thenReturn(mortgageNominationHelper.getMortgageQueryServiceResponse());
        when(restClientService.post(any(String.class), any(HashMap.class), any(String.class)))
                .thenReturn(mortgageNominationHelper.getUpdateNominationVaultResponse());

        NominationRequest nominationRequest = mortgageNominationHelper.getNominationRequest();
        String payload = componentHelper.writeValueAsString(nominationRequest);

        //when
        MockHttpServletResponse servletResponse = doPOST(MORTGAGES_NOMINATION, payload, mortgageNominationHelper.getAccountInfoHeaders());
        String responseString = componentHelper.getServletResponseAsString(servletResponse);
        NominationResponse response = (NominationResponse) readObject(responseString, NominationResponse.class);

        //then
        assertAll(
                () -> assertEquals("ee295584-cea8-d318-9c86-31be00d4063e", response.getAccountId()),
                () -> assertEquals("ACCOUNT_UPDATE_STATUS_PENDING_EXECUTION", response.getStatus()),
                () -> assertEquals("90e804ab-5dad-7f7c-1d71-ab914545ebcc", response.getAdditionalDetails().get("NominatedAdhocOverpaymentAccount"))
        );
    }

    @Test
    public void shouldDeleteNomination() {
        //given
        when(restClientService.get(any(String.class), any(HashMap.class)))
                .thenReturn(mortgageNominationHelper.getMortgageQueryServiceResponse());
        when(restClientService.post(any(String.class), any(HashMap.class), any(String.class)))
                .thenReturn(mortgageNominationHelper.getDeleteNominationVaultResponse());

        //when
        MockHttpServletResponse servletResponse = doDELETE(MORTGAGES_NOMINATION, null, mortgageNominationHelper.getAccountInfoHeaders());
        String responseString = componentHelper.getServletResponseAsString(servletResponse);
        NominationResponse response = (NominationResponse) readObject(responseString, NominationResponse.class);

        //then
        assertAll(
                () -> assertEquals("ee295584-cea8-d318-9c86-31be00d4063e", response.getAccountId()),
                () -> assertEquals("ACCOUNT_UPDATE_STATUS_PENDING_EXECUTION", response.getStatus()),
                () -> assertTrue(StringUtils.isEmpty(response.getAdditionalDetails().get("NominatedAdhocOverpaymentAccount")))
        );
    }

    @Test
    public void shouldReturnErrorForUpdateWhenValidationFailsForSubAccountNotInRepaymentAccount() {
        //given
        when(restClientService.get(any(String.class), any(HashMap.class)))
                .thenReturn(mortgageNominationHelper.getMortgageQueryServiceResponse());
        when(restClientService.post(any(String.class), any(HashMap.class), any(String.class)))
                .thenReturn(mortgageNominationHelper.getUpdateNominationVaultResponse());

        NominationRequest nominationRequest = mortgageNominationHelper.buildNominationRequestFor("90e804ab-5dad-7f7c-1d71-ab914545ebcc");
        String payload = componentHelper.writeValueAsString(nominationRequest);

        //when
        MockHttpServletResponse servletResponse = doPUT(MORTGAGES_NOMINATION, payload, mortgageNominationHelper.getAccountInfoHeaders());
        String responseString = componentHelper.getServletResponseAsString(servletResponse);
        ErrorResponse errorResponse = (ErrorResponse) readObject(responseString, ErrorResponse.class);
        ErrorInfo errorInfo = errorResponse.getErrors().get(0);

        //then
        assertAll(
                () -> assertEquals(400, servletResponse.getStatus()),
                () -> assertEquals("PNA.MORTGAGE_API.BUS.601", errorResponse.getCode()),
                () -> assertEquals("Invalid Update Request", errorResponse.getMessage()),
                () -> assertEquals("PNA.MORTGAGE_API.PUT_MORTGAGES_NOMINATION.Value.Invalid", errorInfo.getReasonCode()),
                () -> assertEquals("Nominated Account has invalid value", errorInfo.getMessage())
        );
    }

    @Test
    public void shouldReturnErrorForUpdateWhenValidationFailsForSubAccountSameAsRepaymentAccount() {
        //given
        when(restClientService.get(any(String.class), any(HashMap.class)))
                .thenReturn(mortgageNominationHelper.getMortgageQueryServiceResponse());
        when(restClientService.post(any(String.class), any(HashMap.class), any(String.class)))
                .thenReturn(mortgageNominationHelper.getUpdateNominationVaultResponse());

        NominationRequest nominationRequest = mortgageNominationHelper.buildNominationRequestFor("f76ca840-2553-d536-1ab8-9fa85c99db05");
        String payload = componentHelper.writeValueAsString(nominationRequest);

        //when
        MockHttpServletResponse servletResponse = doPUT(MORTGAGES_NOMINATION, payload, mortgageNominationHelper.getAccountInfoHeaders());
        String responseString = componentHelper.getServletResponseAsString(servletResponse);
        ErrorResponse errorResponse = (ErrorResponse) readObject(responseString, ErrorResponse.class);
        ErrorInfo errorInfo = errorResponse.getErrors().get(0);

        //then
        assertAll(
                () -> assertEquals(400, servletResponse.getStatus()),
                () -> assertEquals("PNA.MORTGAGE_API.BUS.601", errorResponse.getCode()),
                () -> assertEquals("Invalid Update Request", errorResponse.getMessage()),
                () -> assertEquals("PNA.MORTGAGE_API.PUT_MORTGAGES_NOMINATION.Value.Invalid", errorInfo.getReasonCode()),
                () -> assertEquals("Nominated Account has invalid value", errorInfo.getMessage())
        );
    }

    @Test
    public void shouldReturnErrorForUpdateWhenValidationFailsForSubAccountIsProvidedInPath() {
        //given
        when(restClientService.get(any(String.class), any(HashMap.class)))
                .thenReturn(mortgageNominationHelper.getMortgageQueryServiceResponseForSubAccount());
        when(restClientService.post(any(String.class), any(HashMap.class), any(String.class)))
                .thenReturn(mortgageNominationHelper.getUpdateNominationVaultResponse());

        NominationRequest nominationRequest = mortgageNominationHelper.buildNominationRequestFor("f76ca840-2553-d536-1ab8-9fa85c99db05");
        String payload = componentHelper.writeValueAsString(nominationRequest);

        //when
        MockHttpServletResponse servletResponse = doPUT(MORTGAGES_NOMINATION, payload, mortgageNominationHelper.getAccountInfoHeaders());
        String responseString = componentHelper.getServletResponseAsString(servletResponse);
        ErrorResponse errorResponse = (ErrorResponse) readObject(responseString, ErrorResponse.class);
        ErrorInfo errorInfo = errorResponse.getErrors().get(0);

        //then
        assertAll(
                () -> assertEquals(400, servletResponse.getStatus()),
                () -> assertEquals("PNA.MORTGAGE_API.BUS.601", errorResponse.getCode()),
                () -> assertEquals("Invalid Update Request", errorResponse.getMessage()),
                () -> assertEquals("PNA.MORTGAGE_API.PUT_MORTGAGES_NOMINATION.Value.Invalid", errorInfo.getReasonCode()),
                () -> assertEquals("Nominated Account has invalid value", errorInfo.getMessage())
        );
    }

    @Test
    public void shouldReturnErrorForUpdateWhenMortgageQueryServiceThrowsException() {
        //given
        when(restClientService.get(any(String.class), any(HashMap.class)))
                .thenThrow(new RestServiceException(SystemErrors.INTERNAL_SERVER_ERROR.getErrorCode(),
                        HttpStatus.INTERNAL_SERVER_ERROR,
                        ".Generic.Error",
                        "Internal Server Error"));
        when(restClientService.post(any(String.class), any(HashMap.class), any(String.class)))
                .thenReturn(mortgageNominationHelper.getUpdateNominationVaultResponse());

        NominationRequest nominationRequest = mortgageNominationHelper.getNominationRequest();
        String payload = componentHelper.writeValueAsString(nominationRequest);

        //when
        MockHttpServletResponse servletResponse = doPUT(MORTGAGES_NOMINATION, payload, mortgageNominationHelper.getAccountInfoHeaders());
        String responseString = componentHelper.getServletResponseAsString(servletResponse);
        ErrorResponse errorResponse = (ErrorResponse) readObject(responseString, ErrorResponse.class);
        ErrorInfo errorInfo = errorResponse.getErrors().get(0);

        //then
        assertAll(
                () -> assertEquals(500, servletResponse.getStatus()),
                () -> assertEquals("PNA.MORTGAGE_API.SYS.006", errorResponse.getCode()),
                () -> assertEquals("Internal server error", errorResponse.getMessage()),
                () -> assertEquals("PNA.MORTGAGE_API.PUT_MORTGAGES_NOMINATION.Generic.Error", errorInfo.getReasonCode()),
                () -> assertEquals("Internal Server Error", errorInfo.getMessage())
        );
    }

    @Test
    public void shouldReturnErrorForUpdateWhenVaultThrowsException() {
        //given
        when(restClientService.get(any(String.class), any(HashMap.class)))
                .thenReturn(mortgageNominationHelper.getMortgageQueryServiceResponse());
        when(restClientService.post(any(String.class), any(HashMap.class), any(String.class)))
                .thenThrow(new RestServiceException(SystemErrors.INTERNAL_SERVER_ERROR.getErrorCode(),
                        HttpStatus.INTERNAL_SERVER_ERROR,
                        ".Generic.Error",
                        "Internal Server Error"));

        NominationRequest nominationRequest = mortgageNominationHelper.getNominationRequest();
        String payload = componentHelper.writeValueAsString(nominationRequest);

        //when
        MockHttpServletResponse servletResponse = doPUT(MORTGAGES_NOMINATION, payload, mortgageNominationHelper.getAccountInfoHeaders());
        String responseString = componentHelper.getServletResponseAsString(servletResponse);
        ErrorResponse errorResponse = (ErrorResponse) readObject(responseString, ErrorResponse.class);
        ErrorInfo errorInfo = errorResponse.getErrors().get(0);

        //then
        assertAll(
                () -> assertEquals(500, servletResponse.getStatus()),
                () -> assertEquals("PNA.MORTGAGE_API.SYS.006", errorResponse.getCode()),
                () -> assertEquals("Internal server error", errorResponse.getMessage()),
                () -> assertEquals("PNA.MORTGAGE_API.PUT_MORTGAGES_NOMINATION.AccountOptions.NotUpdated", errorInfo.getReasonCode()),
                () -> assertEquals("Failed to update account options", errorInfo.getMessage())
        );
    }

    @Test
    public void shouldReturnErrorForEmptyRequestBody() {
        //when
        MockHttpServletResponse servletResponse = doPUT(MORTGAGES_NOMINATION, "", mortgageNominationHelper.getAccountInfoHeaders());
        String responseString = componentHelper.getServletResponseAsString(servletResponse);
        ErrorResponse errorResponse = (ErrorResponse) readObject(responseString, ErrorResponse.class);
        ErrorInfo errorInfo = errorResponse.getErrors().get(0);

        //then
        assertAll(
                () -> assertEquals(400, servletResponse.getStatus()),
                () -> assertEquals("PNA.MORTGAGE_API.SYS.001", errorResponse.getCode()),
                () -> assertEquals("Bad Request", errorResponse.getMessage()),
                () -> assertEquals("PNA.MORTGAGE_API.PUT_MORTGAGES_NOMINATION.Message.NotReadable", errorInfo.getReasonCode()),
                () -> assertEquals("Required request body is missing", errorInfo.getMessage())
        );
    }

    @Test
    public void shouldReturnErrorForEmptyJson() {
        //when
        MockHttpServletResponse servletResponse = doPUT(MORTGAGES_NOMINATION, "{}", mortgageNominationHelper.getAccountInfoHeaders());
        String responseString = componentHelper.getServletResponseAsString(servletResponse);
        ErrorResponse errorResponse = (ErrorResponse) readObject(responseString, ErrorResponse.class);
        ErrorInfo errorInfo = errorResponse.getErrors().get(0);
        System.out.println(errorInfo.getMessage());

        //then
        assertAll(
                () -> assertEquals(400, servletResponse.getStatus()),
                () -> assertEquals("PNA.MORTGAGE_API.SYS.001", errorResponse.getCode()),
                () -> assertEquals("Bad Request", errorResponse.getMessage()),
                () -> assertEquals("PNA.MORTGAGE_API.PUT_MORTGAGES_NOMINATION.Argument.Invalid", errorInfo.getReasonCode()),
                () -> assertEquals("NominatedAdhocOverpaymentAccount AccountId should be min 36 characters", errorInfo.getMessage())
        );
    }

    @Test
    public void shouldReturnErrorForIncorrectLengthAccountIdInRequestBody() {
        //given
        NominationRequest nominationRequest = mortgageNominationHelper.buildNominationRequestFor("f76ca840-2553-d536-1ab8-9fa85c99db05".concat("123"));
        String payload = componentHelper.writeValueAsString(nominationRequest);

        //when
        MockHttpServletResponse servletResponse = doPUT(MORTGAGES_NOMINATION, payload, mortgageNominationHelper.getAccountInfoHeaders());
        String responseString = componentHelper.getServletResponseAsString(servletResponse);
        ErrorResponse errorResponse = (ErrorResponse) readObject(responseString, ErrorResponse.class);
        ErrorInfo errorInfo = errorResponse.getErrors().get(0);

        //then
        assertAll(
                () -> assertEquals(400, servletResponse.getStatus()),
                () -> assertEquals("PNA.MORTGAGE_API.SYS.001", errorResponse.getCode()),
                () -> assertEquals("Bad Request", errorResponse.getMessage()),
                () -> assertEquals("PNA.MORTGAGE_API.PUT_MORTGAGES_NOMINATION.Argument.Invalid", errorInfo.getReasonCode()),
                () -> assertEquals("NominatedAdhocOverpaymentAccount AccountId should be max 36 characters", errorInfo.getMessage())
        );
    }

    @Test
    public void shouldReturnErrorForUpdateWhenBrandIsMissing() {
        //given
        NominationRequest nominationRequest = mortgageNominationHelper.buildNominationRequestFor("f76ca840-2553-d536-1ab8-9fa85c99db05");
        String payload = componentHelper.writeValueAsString(nominationRequest);
        HttpHeaders accountInfoHeaders = mortgageNominationHelper.getAccountInfoHeaders();
        accountInfoHeaders.remove("x-lbg-brand");

        //when
        MockHttpServletResponse servletResponse = doPUT(MORTGAGES_NOMINATION, payload, accountInfoHeaders);
        String responseString = componentHelper.getServletResponseAsString(servletResponse);
        ErrorResponse errorResponse = (ErrorResponse) readObject(responseString, ErrorResponse.class);
        ErrorInfo errorInfo = errorResponse.getErrors().get(0);

        //then
        assertAll(
                () -> assertEquals(400, servletResponse.getStatus()),
                () -> assertEquals("PNA.MORTGAGE_API.SYS.001", errorResponse.getCode()),
                () -> assertEquals("Bad Request", errorResponse.getMessage()),
                () -> assertEquals("PNA.MORTGAGE_API.PUT_MORTGAGES_NOMINATION.Header.Missing.x-lbg-brand", errorInfo.getReasonCode()),
                () -> assertEquals("Missing request header 'x-lbg-brand' for method parameter of type String", errorInfo.getMessage())
        );
    }

    @Test
    public void shouldReturnErrorForUpdateWhenBrandIsIncorrect() {
        //given
        NominationRequest nominationRequest = mortgageNominationHelper.buildNominationRequestFor("f76ca840-2553-d536-1ab8-9fa85c99db05");
        String payload = componentHelper.writeValueAsString(nominationRequest);
        HttpHeaders accountInfoHeaders = mortgageNominationHelper.getAccountInfoHeaders();
        accountInfoHeaders.set("x-lbg-brand", "xxx");

        //when
        MockHttpServletResponse servletResponse = doPUT(MORTGAGES_NOMINATION, payload, accountInfoHeaders);
        String responseString = componentHelper.getServletResponseAsString(servletResponse);
        ErrorResponse errorResponse = (ErrorResponse) readObject(responseString, ErrorResponse.class);
        ErrorInfo errorInfo = errorResponse.getErrors().get(0);

        //then
        assertAll(
                () -> assertEquals(400, servletResponse.getStatus()),
                () -> assertEquals("PNA.MORTGAGE_API.SYS.001", errorResponse.getCode()),
                () -> assertEquals("Bad Request", errorResponse.getMessage()),
                () -> assertEquals("PNA.MORTGAGE_API.PUT_MORTGAGES_NOMINATION.Header.Invalid", errorInfo.getReasonCode()),
                () -> assertEquals("Invalid enum value for type x-lbg-brand", errorInfo.getMessage())
        );
    }

    @Test
    public void shouldReturnErrorForUpdateWhenCorrelationIdIsMissing() {
        //given
        NominationRequest nominationRequest = mortgageNominationHelper.buildNominationRequestFor("f76ca840-2553-d536-1ab8-9fa85c99db05");
        String payload = componentHelper.writeValueAsString(nominationRequest);
        HttpHeaders accountInfoHeaders = mortgageNominationHelper.getAccountInfoHeaders();
        accountInfoHeaders.remove("x-lbg-txn-correlation-id");

        //when
        MockHttpServletResponse servletResponse = doPUT(MORTGAGES_NOMINATION, payload, accountInfoHeaders);
        String responseString = componentHelper.getServletResponseAsString(servletResponse);
        ErrorResponse errorResponse = (ErrorResponse) readObject(responseString, ErrorResponse.class);
        ErrorInfo errorInfo = errorResponse.getErrors().get(0);

        //then
        assertAll(
                () -> assertEquals(400, servletResponse.getStatus()),
                () -> assertEquals("PNA.MORTGAGE_API.SYS.001", errorResponse.getCode()),
                () -> assertEquals("Bad Request", errorResponse.getMessage()),
                () -> assertEquals("PNA.MORTGAGE_API.PUT_MORTGAGES_NOMINATION.Header.Missing.x-lbg-txn-correlation-id", errorInfo.getReasonCode()),
                () -> assertEquals("Missing request header x-lbg-txn-correlation-id for method parameter of type String", errorInfo.getMessage())
        );
    }

    @Test
    public void shouldReturnErrorForUpdateWhenCorrelationIdIsLessThanTenCharacters() {
        //given
        NominationRequest nominationRequest = mortgageNominationHelper.buildNominationRequestFor("f76ca840-2553-d536-1ab8-9fa85c99db05");
        String payload = componentHelper.writeValueAsString(nominationRequest);
        HttpHeaders accountInfoHeaders = mortgageNominationHelper.getAccountInfoHeaders();
        accountInfoHeaders.set("x-lbg-txn-correlation-id", RandomStringUtils.random(9));

        //when
        MockHttpServletResponse servletResponse = doPUT(MORTGAGES_NOMINATION, payload, accountInfoHeaders);
        String responseString = componentHelper.getServletResponseAsString(servletResponse);
        ErrorResponse errorResponse = (ErrorResponse) readObject(responseString, ErrorResponse.class);
        ErrorInfo errorInfo = errorResponse.getErrors().get(0);

        //then
        assertAll(
                () -> assertEquals(400, servletResponse.getStatus()),
                () -> assertEquals("PNA.MORTGAGE_API.SYS.001", errorResponse.getCode()),
                () -> assertEquals("Bad Request", errorResponse.getMessage()),
                () -> assertEquals("PNA.MORTGAGE_API.PUT_MORTGAGES_NOMINATION.Header.Invalid", errorInfo.getReasonCode()),
                () -> assertEquals("x-lbg-txn-correlation-id size should be between 10 and 40", errorInfo.getMessage())
        );
    }

    @Test
    public void shouldReturnErrorForUpdateWhenCorrelationIdIsGreaterThanFortyCharacters() {
        //given
        NominationRequest nominationRequest = mortgageNominationHelper.buildNominationRequestFor("f76ca840-2553-d536-1ab8-9fa85c99db05");
        String payload = componentHelper.writeValueAsString(nominationRequest);
        HttpHeaders accountInfoHeaders = mortgageNominationHelper.getAccountInfoHeaders();
        accountInfoHeaders.set("x-lbg-txn-correlation-id", RandomStringUtils.random(50));


        //when
        MockHttpServletResponse servletResponse = doPUT(MORTGAGES_NOMINATION, payload, accountInfoHeaders);
        String responseString = componentHelper.getServletResponseAsString(servletResponse);
        ErrorResponse errorResponse = (ErrorResponse) readObject(responseString, ErrorResponse.class);
        ErrorInfo errorInfo = errorResponse.getErrors().get(0);

        //then
        assertAll(
                () -> assertEquals(400, servletResponse.getStatus()),
                () -> assertEquals("PNA.MORTGAGE_API.SYS.001", errorResponse.getCode()),
                () -> assertEquals("Bad Request", errorResponse.getMessage()),
                () -> assertEquals("PNA.MORTGAGE_API.PUT_MORTGAGES_NOMINATION.Header.Invalid", errorInfo.getReasonCode()),
                () -> assertEquals("x-lbg-txn-correlation-id size should be between 10 and 40", errorInfo.getMessage())
        );
    }

    @Test
    public void shouldReturnErrorForUpdateWhenAuthorisationIsMissing() {
        //given
        NominationRequest nominationRequest = mortgageNominationHelper.buildNominationRequestFor("f76ca840-2553-d536-1ab8-9fa85c99db05");
        String payload = componentHelper.writeValueAsString(nominationRequest);
        HttpHeaders accountInfoHeaders = mortgageNominationHelper.getAccountInfoHeaders();
        accountInfoHeaders.remove("x-lbg-internal-system-id");
        accountInfoHeaders.remove("Authorization");

        //when
        MockHttpServletResponse servletResponse = doPUT(MORTGAGES_NOMINATION, payload, accountInfoHeaders);
        String responseString = componentHelper.getServletResponseAsString(servletResponse);
        ErrorResponse errorResponse = (ErrorResponse) readObject(responseString, ErrorResponse.class);
        ErrorInfo errorInfo = errorResponse.getErrors().get(0);

        //then
        assertAll(
                () -> assertEquals(401, servletResponse.getStatus()),
                () -> assertEquals("PNA.MORTGAGE_API.SYS.002", errorResponse.getCode()),
                () -> assertEquals("Resource Unauthorised", errorResponse.getMessage()),
                () -> assertEquals("PNA.MORTGAGE_API.PUT_MORTGAGES_NOMINATION.Access.Unauthorised", errorInfo.getReasonCode()),
                () -> assertEquals("Please Supply headers : 'Authorization' or 'x-lbg-internal-system-id'", errorInfo.getMessage())
        );
    }

    @Test
    public void shouldReturnErrorForUpdateWhenAccountIdIsMoreThan36Chars() {
        //given
        NominationRequest nominationRequest = mortgageNominationHelper.getNominationRequest();
        String payload = componentHelper.writeValueAsString(nominationRequest);

        //when
        MockHttpServletResponse servletResponse = doPUT("/mortgages/"+RandomStringUtils.random(50)+"/nomination",
                payload,
                mortgageNominationHelper.getAccountInfoHeaders());
        String responseString = componentHelper.getServletResponseAsString(servletResponse);
        ErrorResponse errorResponse = (ErrorResponse) readObject(responseString, ErrorResponse.class);
        ErrorInfo errorInfo = errorResponse.getErrors().get(0);

        //then
        assertAll(
                () -> assertEquals(400, servletResponse.getStatus()),
                () -> assertEquals("PNA.MORTGAGE_API.SYS.001", errorResponse.getCode()),
                () -> assertEquals("Bad Request", errorResponse.getMessage()),
                () -> assertEquals("PNA.MORTGAGE_API.PUT_MORTGAGES_NOMINATION.Param.Invalid", errorInfo.getReasonCode()),
                () -> assertEquals("AccountId should be max 36 characters", errorInfo.getMessage())
        );
    }

    @Test
    public void shouldReturnErrorForUpdateWhenAccountIdIsLessThan36Chars() {
        //given
        NominationRequest nominationRequest = mortgageNominationHelper.getNominationRequest();
        String payload = componentHelper.writeValueAsString(nominationRequest);

        //when
        MockHttpServletResponse servletResponse = doPUT("/mortgages/"+RandomStringUtils.random(5)+"/nomination",
                payload,
                mortgageNominationHelper.getAccountInfoHeaders());
        String responseString = componentHelper.getServletResponseAsString(servletResponse);
        ErrorResponse errorResponse = (ErrorResponse) readObject(responseString, ErrorResponse.class);
        ErrorInfo errorInfo = errorResponse.getErrors().get(0);

        //then
        assertAll(
                () -> assertEquals(400, servletResponse.getStatus()),
                () -> assertEquals("PNA.MORTGAGE_API.SYS.001", errorResponse.getCode()),
                () -> assertEquals("Bad Request", errorResponse.getMessage()),
                () -> assertEquals("PNA.MORTGAGE_API.PUT_MORTGAGES_NOMINATION.Param.Invalid", errorInfo.getReasonCode()),
                () -> assertEquals("AccountId should be min 36 characters", errorInfo.getMessage())
        );
    }

    @Test
    public void shouldReturnErrorForUpdateWhenIncorrectEndpointIsCalled() {
        //given
        NominationRequest nominationRequest = mortgageNominationHelper.buildNominationRequestFor("f76ca840-2553-d536-1ab8-9fa85c99db05");
        String payload = componentHelper.writeValueAsString(nominationRequest);
        HttpHeaders accountInfoHeaders = mortgageNominationHelper.getAccountInfoHeaders();

        //when
        MockHttpServletResponse servletResponse = doPUT(MORTGAGES_NOMINATION.concat("s"), payload, accountInfoHeaders);

        //then
        assertAll(
                () -> assertEquals(404, servletResponse.getStatus())
        );
    }

}
