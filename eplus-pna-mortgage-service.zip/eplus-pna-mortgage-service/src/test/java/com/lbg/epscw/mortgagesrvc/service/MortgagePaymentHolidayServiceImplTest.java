package com.lbg.epscw.mortgagesrvc.service;

import com.lbg.epscw.mortgagesrvc.dto.MortgageAccountInfo;
import com.lbg.epscw.mortgagesrvc.exception.CircuitBreakerOpenException;
import com.lbg.epscw.mortgagesrvc.helper.MortgagePaymentHolidayHelper;
import com.lbg.epscw.mortgagesrvc.model.AccountOptionsUpdateResponse;
import com.lbg.epscw.mortgagesrvc.model.PaymentHolidayResponse;
import com.lbg.epscw.mortgagesrvc.model.VaultAccountOptionsUpdateRequest;
import com.lbg.epscw.mortgagesrvc.restclient.MortgageAccountInfoRestClient;
import com.lbg.epscw.mortgagesrvc.restclient.MortgageAccountOptionRestClient;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.HashMap;
import java.util.Map;

import static com.lbg.epscw.mortgagesrvc.constants.CommonConstants.*;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;
import static org.mockito.ArgumentMatchers.any;
import static org.powermock.api.mockito.PowerMockito.when;
import static org.powermock.api.mockito.PowerMockito.mock;

@RunWith(SpringRunner.class)
public class MortgagePaymentHolidayServiceImplTest {

    public static final String MOCK_ACCOUNT_ID = "144a38f3-a7b3-a3aa-d656-ff98fbaaa565";

    @Mock
    private MortgageAccountOptionRestClient mortgageAccountOptionRestClient;

    @Mock
    private MortgageAccountInfoRestClient mortgageAccountInfoRestClient;

    private MortgagePaymentHolidayHelper mortgagePaymentHolidayHelper = new MortgagePaymentHolidayHelper();

    @Before
    public void setup() {
        mortgageAccountOptionRestClient = mock(MortgageAccountOptionRestClient.class);
        mortgageAccountInfoRestClient = mock(MortgageAccountInfoRestClient.class);
    }

    @Test
    public void add_payment_holiday_success() {
        //given
        MortgagePaymentHolidayService mortgagePaymentHolidayService = new MortgagePaymentHolidayServiceImpl(mortgageAccountOptionRestClient, mortgageAccountInfoRestClient);
        AccountOptionsUpdateResponse accountOptionsUpdateResponse = mortgagePaymentHolidayHelper.buildAccountOptionsUpdateResponse(MOCK_ACCOUNT_ID,PAYMENT_HOLIDAY_ADD_SUCCESS);
        when(mortgageAccountOptionRestClient.updateAccountOptions(any(VaultAccountOptionsUpdateRequest.class))).thenReturn(accountOptionsUpdateResponse);
        MortgageAccountInfo mortgageAccountInfo = mortgagePaymentHolidayHelper.mortgageAccountInfo_mortgagePaymentHolidayMock();
        when(mortgageAccountInfoRestClient.getMortgageAccountInfo(any(String.class), any(Map.class))).thenReturn(mortgageAccountInfo);
        //when
        PaymentHolidayResponse paymentHolidayResponse = mortgagePaymentHolidayService.addPaymentHoliday(MOCK_ACCOUNT_ID, mortgagePaymentHolidayHelper.getPaymentHolidayRequest(), new HashMap<>());

        //then
        assertEquals(MOCK_ACCOUNT_ID, paymentHolidayResponse.getAccountId());
        assertEquals(PAYMENT_HOLIDAY_ADD_SUCCESS, paymentHolidayResponse.getStatus());
        assertEquals("03/2017,04/2019,07/2019,10/2021,11/2021", paymentHolidayResponse.getInstanceParamVals().get("ListOfPaymentHolidays"));

    }

    @Test
    public void add_payment_holiday_when_payment_holidays_is_empty() {
        //given
        MortgagePaymentHolidayService mortgagePaymentHolidayService = new MortgagePaymentHolidayServiceImpl(mortgageAccountOptionRestClient, mortgageAccountInfoRestClient);

        AccountOptionsUpdateResponse accountOptionsUpdateResponse = mortgagePaymentHolidayHelper.buildAccountOptionsUpdateResponse(MOCK_ACCOUNT_ID,PAYMENT_HOLIDAY_ADD_SUCCESS);
        when(mortgageAccountOptionRestClient.updateAccountOptions(any(VaultAccountOptionsUpdateRequest.class))).thenReturn(accountOptionsUpdateResponse);

        MortgageAccountInfo mortgageAccountInfo = mortgagePaymentHolidayHelper.mortgageAccountInfo_mortgagePaymentHolidayEmpty();
        when(mortgageAccountInfoRestClient.getMortgageAccountInfo(any(String.class), any(Map.class))).thenReturn(mortgageAccountInfo);
        //when
        PaymentHolidayResponse paymentHolidayResponse = mortgagePaymentHolidayService.addPaymentHoliday(MOCK_ACCOUNT_ID, mortgagePaymentHolidayHelper.getPaymentHolidayRequest(), new HashMap<>());

        //then
        assertEquals(MOCK_ACCOUNT_ID, paymentHolidayResponse.getAccountId());
        assertEquals(PAYMENT_HOLIDAY_ADD_SUCCESS, paymentHolidayResponse.getStatus());
        assertEquals("03/2017,04/2019,07/2019,10/2021,11/2021", paymentHolidayResponse.getInstanceParamVals().get("ListOfPaymentHolidays"));

    }

    @Test
    public void add_payment_holiday_returns_null() {
        //given
        MortgagePaymentHolidayService mortgagePaymentHolidayService = new MortgagePaymentHolidayServiceImpl(mortgageAccountOptionRestClient, mortgageAccountInfoRestClient);
        AccountOptionsUpdateResponse accountOptionsUpdateResponse = null;
        when(mortgageAccountOptionRestClient.updateAccountOptions(any(VaultAccountOptionsUpdateRequest.class))).thenReturn(accountOptionsUpdateResponse);
        MortgageAccountInfo mortgageAccountInfo = mortgagePaymentHolidayHelper.mortgageAccountInfo_mortgagePaymentHolidayMock();
        when(mortgageAccountInfoRestClient.getMortgageAccountInfo(any(String.class), any(Map.class))).thenReturn(mortgageAccountInfo);
        //when
        PaymentHolidayResponse paymentHolidayResponse = mortgagePaymentHolidayService.addPaymentHoliday(MOCK_ACCOUNT_ID, mortgagePaymentHolidayHelper.getPaymentHolidayRequest(), new HashMap<>());

        //then
        assertNull(paymentHolidayResponse);
    }

    @Test(expected = CircuitBreakerOpenException.class)
    public void hystrix_test_on_fallbackAddPaymentHoliday() {

        MortgagePaymentHolidayServiceImpl mortgageService= new MortgagePaymentHolidayServiceImpl(mortgageAccountOptionRestClient, mortgageAccountInfoRestClient);
        mortgageService.fallbackAddPaymentHoliday("81d9ab5c-076b-5141-3d01-f619ddf7d9f7", mortgagePaymentHolidayHelper.getPaymentHolidayRequest(),
                new Exception("Circuit open on add payment holiday"));
    }

    @Test
    public void cancel_payment_holiday_returns_success() {
        //given
        MortgagePaymentHolidayService mortgagePaymentHolidayService = new MortgagePaymentHolidayServiceImpl(mortgageAccountOptionRestClient, mortgageAccountInfoRestClient);
        AccountOptionsUpdateResponse accountOptionsUpdateResponse = mortgagePaymentHolidayHelper.buildAccountOptionsUpdateResponse(MOCK_ACCOUNT_ID,PAYMENT_HOLIDAY_CANCEL_SUCCESS);
        when(mortgageAccountOptionRestClient.updateAccountOptions(any(VaultAccountOptionsUpdateRequest.class))).thenReturn(accountOptionsUpdateResponse);
        MortgageAccountInfo mortgageAccountInfo = mortgagePaymentHolidayHelper.mortgageAccountInfo_mortgagePaymentHolidayMock();
        when(mortgageAccountInfoRestClient.getMortgageAccountInfo(any(String.class), any(Map.class))).thenReturn(mortgageAccountInfo);
        //when
        PaymentHolidayResponse paymentHolidayResponse = mortgagePaymentHolidayService.cancelPaymentHoliday(MOCK_ACCOUNT_ID, mortgagePaymentHolidayHelper.getPaymentHolidayRequest(), new HashMap<>());

        //then
        assertEquals(MOCK_ACCOUNT_ID, paymentHolidayResponse.getAccountId());
        assertEquals(PAYMENT_HOLIDAY_CANCEL_SUCCESS, paymentHolidayResponse.getStatus());
        assertEquals("03/2017,04/2019,07/2019,10/2021,11/2021", paymentHolidayResponse.getInstanceParamVals().get("ListOfPaymentHolidays"));
    }

    @Test(expected = CircuitBreakerOpenException.class)
    public void hystrix_test_on_fallbackCancelPaymentHoliday() {

        MortgagePaymentHolidayServiceImpl mortgageService= new MortgagePaymentHolidayServiceImpl(mortgageAccountOptionRestClient, mortgageAccountInfoRestClient);
        mortgageService.fallbackCancelPaymentHoliday("81d9ab5c-076b-5141-3d01-f619ddf7d9f7", mortgagePaymentHolidayHelper.getPaymentHolidayRequest(),
                new Exception("Circuit open on cancel payment holiday"));
    }

}
