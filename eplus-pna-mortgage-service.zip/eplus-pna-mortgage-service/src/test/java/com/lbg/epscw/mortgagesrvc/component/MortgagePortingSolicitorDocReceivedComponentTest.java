package com.lbg.epscw.mortgagesrvc.component;

import com.lbg.epscw.entitlement.service.EntitlementValidationServiceImpl;
import com.lbg.epscw.handler.model.ErrorInfo;
import com.lbg.epscw.mortgagesrvc.helper.ComponentHelper;
import com.lbg.epscw.mortgagesrvc.helper.MortgagePortingHelper;
import com.lbg.epscw.mortgagesrvc.logger.HystrixContextCopyStrategy;
import com.lbg.epscw.mortgagesrvc.model.MortgageApplicationInfo;
import com.lbg.epscw.mortgagesrvc.model.MortgagePortingApplicationStatus;
import com.lbg.epscw.mortgagesrvc.model.PortingApplicationStatusResponse;
import com.lbg.epscw.mortgagesrvc.restclient.MortgagePortingApplicationInfoRestClient;
import com.lbg.epscw.mortgagesrvc.service.MortgagePortingSolicitorDocReceivedService;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpHeaders;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import java.time.LocalDate;

import static com.google.api.client.http.HttpStatusCodes.*;
import static com.lbg.epscw.mortgagesrvc.helper.MortgagePortingHelper.*;
import static com.lbg.epscw.mortgagesrvc.model.MortgagePortingApplicationStatus.*;
import static javax.servlet.http.HttpServletResponse.SC_BAD_REQUEST;
import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;


@Tag("component")
@ExtendWith(SpringExtension.class)
@SpringBootTest
@AutoConfigureMockMvc
public class MortgagePortingSolicitorDocReceivedComponentTest extends WebMVCTest {
    private final MortgagePortingHelper portingHelper = new MortgagePortingHelper();
    private final ComponentHelper componentHelper = new ComponentHelper();
    @MockBean
    private EntitlementValidationServiceImpl entitlement;
    @MockBean
    private HystrixContextCopyStrategy hystrix;

    @MockBean
    private MortgagePortingApplicationInfoRestClient infoService;
    @MockBean
    private MortgagePortingSolicitorDocReceivedService service;

    @Test
    public void verify_application_is_ready_for_review_when_accepting() {
        //given
        when(infoService.getApplicationInfo(anyString())).thenReturn(MortgageApplicationInfo.builder().status(OFFERED).build());
        when(service.solicitorDocReceived(any(), any())).thenReturn(PortingApplicationStatusResponse.builder()
                .applicationNumber(APPLICATION_NUMBER)
                .status(SOLICITOR_DOC_RECEIVED)
                .build());
        String payload = componentHelper.writeValueAsString(portingHelper.solicitorDocPayload().build());
        //when
        MockHttpServletResponse response = doPOST(SOLICITOR_DOC_RECEIVED_ENDPOINT, payload, portingHelper.getAccountInfoHeaders());
        String responseString = componentHelper.getServletResponseAsString(response);
        PortingApplicationStatusResponse actual = readObject(responseString, PortingApplicationStatusResponse.class);

        //then
        assertThat(response.getStatus(), is(STATUS_CODE_OK));
        assertThat(actual.getApplicationNumber(), is(APPLICATION_NUMBER));
        assertThat(actual.getStatus(), is(SOLICITOR_DOC_RECEIVED));
    }

    @Test
    public void reject_verification_when_application_invalid_status() {
        assertThatInvalidStatusThrowsError(OPEN);
        assertThatInvalidStatusThrowsError(SUBMITTED);
        assertThatInvalidStatusThrowsError(DECLINED);
        assertThatInvalidStatusThrowsError(VALUATION_RECEIVED);
        assertThatInvalidStatusThrowsError(WELCOME_PACK_RECEIVED);
        assertThatInvalidStatusThrowsError(APPROVED_WITH_CONDITIONS);
        assertThatInvalidStatusThrowsError(REPROCESS);
        assertThatInvalidStatusThrowsError(FUNDS_RELEASED);
    }

    private void assertThatInvalidStatusThrowsError(MortgagePortingApplicationStatus fromStatus) {
        //given
        String payload = componentHelper.writeValueAsString(portingHelper.solicitorDocPayload().build());
        when(infoService.getApplicationInfo(anyString())).thenReturn(MortgageApplicationInfo.builder().status(fromStatus).build());
        //when
        MockHttpServletResponse response = doPOST(SOLICITOR_DOC_RECEIVED_ENDPOINT, payload, portingHelper.getAccountInfoHeaders());
        ErrorInfo error = readErrorInfo(componentHelper.getServletResponseAsString(response));
        //then
        assertThat(response.getStatus(), is(SC_BAD_REQUEST));
        assertEquals("PNA.MORTGAGE_API.POST_MORTGAGES_APPLICATION_SOLICITOR_DOC_RECEIVED.MortgagePortingApplication.InvalidStatus", error.getReasonCode());
        assertEquals("Invalid Data", error.getMessage());
    }

    @Test
    public void title_deed_is_mandatory() {
        //given
        String payload = componentHelper.writeValueAsString(portingHelper.solicitorDocPayload().titleDeedNumber(null).build());

        // when
        MockHttpServletResponse response = doPOST(SOLICITOR_DOC_RECEIVED_ENDPOINT, payload, portingHelper.getAccountInfoHeaders());
        ErrorInfo error = readErrorInfo(componentHelper.getServletResponseAsString(response));

        // then
        assertEquals(STATUS_CODE_BAD_REQUEST, response.getStatus());
        assertEquals("PNA.MORTGAGE_API.POST_MORTGAGES_APPLICATION_SOLICITOR_DOC_RECEIVED.Argument.Invalid", error.getReasonCode());
        assertEquals("TitleDeedNumber is required", error.getMessage());
    }

    @Test
    public void return_error_when_application_id_is_invalid() {
        //given
        String payload = componentHelper.writeValueAsString(portingHelper.solicitorDocPayload().build());

        //when
        MockHttpServletResponse response = doPOST("/mortgages/application/invalid/solicitor-doc-received", payload, portingHelper.getAccountInfoHeaders());
        ErrorInfo error = readErrorInfo(componentHelper.getServletResponseAsString(response));

        //then
        assertThat(response.getStatus(), is(STATUS_CODE_BAD_REQUEST));
        assertEquals("PNA.MORTGAGE_API.POST_MORTGAGES_APPLICATION_SOLICITOR_DOC_RECEIVED.Param.Invalid", error.getReasonCode());
        assertEquals("Invalid application ID", error.getMessage());
    }

    @Test
    public void validate_complete_date_in_future() {
        //given
        String payload = componentHelper.writeValueAsString(portingHelper.solicitorDocPayload().completionDate(LocalDate.parse("2020-01-01")).build());

        // when
        MockHttpServletResponse response = doPOST(SOLICITOR_DOC_RECEIVED_ENDPOINT, payload, portingHelper.getAccountInfoHeaders());
        ErrorInfo error = readErrorInfo(componentHelper.getServletResponseAsString(response));

        // then
        assertEquals(STATUS_CODE_BAD_REQUEST, response.getStatus());
        assertEquals("PNA.MORTGAGE_API.POST_MORTGAGES_APPLICATION_SOLICITOR_DOC_RECEIVED.Argument.Invalid", error.getReasonCode());
        assertEquals("CompletionDate must not be in the past", error.getMessage());
    }

    @Test
    public void return_error_when_application_status_not_available() {
        //given
        when(infoService.getApplicationInfo(anyString())).thenReturn(null);

        //when
        String payload = componentHelper.writeValueAsString(portingHelper.solicitorDocPayload().build());
        MockHttpServletResponse response = doPOST(SOLICITOR_DOC_RECEIVED_ENDPOINT, payload, portingHelper.getAccountInfoHeaders());
        ErrorInfo error = readErrorInfo(componentHelper.getServletResponseAsString(response));

        //then
        assertThat(response.getStatus(), is(STATUS_CODE_SERVER_ERROR));
        assertEquals("PNA.MORTGAGE_API.POST_MORTGAGES_APPLICATION_SOLICITOR_DOC_RECEIVED.MortgagePortingApplication.NotFound", error.getReasonCode());
        assertEquals("Invalid Data", error.getMessage());
    }

    @Test
    public void throws_exception_when_correlationId_is_missing() {
        //given
        HttpHeaders headers = portingHelper.getAccountInfoHeaders();
        headers.remove("x-lbg-txn-correlation-id");

        // when
        String payload = componentHelper.writeValueAsString(portingHelper.solicitorDocPayload().build());
        MockHttpServletResponse response = doPOST(SOLICITOR_DOC_RECEIVED_ENDPOINT, payload, headers);
        ErrorInfo error = readErrorInfo(componentHelper.getServletResponseAsString(response));

        // then
        assertEquals(STATUS_CODE_BAD_REQUEST, response.getStatus());
        assertEquals("PNA.MORTGAGE_API.POST_MORTGAGES_APPLICATION_SOLICITOR_DOC_RECEIVED.Header.Missing.x-lbg-txn-correlation-id", error.getReasonCode());
        assertEquals("Missing request header x-lbg-txn-correlation-id for method parameter of type String", error.getMessage());
    }

    @Test
    public void throws_exception_when_brand_is_missing() {
        //given
        HttpHeaders headers = portingHelper.getAccountInfoHeaders();
        headers.remove("x-lbg-brand");

        // when
        String payload = componentHelper.writeValueAsString(portingHelper.solicitorDocPayload().build());
        MockHttpServletResponse response = doPOST(SOLICITOR_DOC_RECEIVED_ENDPOINT, payload, headers);
        ErrorInfo error = readErrorInfo(componentHelper.getServletResponseAsString(response));

        // then
        assertEquals(STATUS_CODE_BAD_REQUEST, response.getStatus());
        assertEquals("PNA.MORTGAGE_API.POST_MORTGAGES_APPLICATION_SOLICITOR_DOC_RECEIVED.Header.Missing.x-lbg-brand", error.getReasonCode());
        assertEquals("Missing request header 'x-lbg-brand' for method parameter of type String", error.getMessage());
    }

    @Test
    public void throws_exception_when_channel_is_missing() {
        //given
        HttpHeaders headers = portingHelper.getAccountInfoHeaders();
        headers.remove("x-lbg-channel");

        // when
        String payload = componentHelper.writeValueAsString(portingHelper.solicitorDocPayload().build());
        MockHttpServletResponse response = doPOST(SOLICITOR_DOC_RECEIVED_ENDPOINT, payload, headers);
        ErrorInfo error = readErrorInfo(componentHelper.getServletResponseAsString(response));

        // then
        assertEquals(STATUS_CODE_BAD_REQUEST, response.getStatus());
        assertEquals("PNA.MORTGAGE_API.POST_MORTGAGES_APPLICATION_SOLICITOR_DOC_RECEIVED.Header.Missing.x-lbg-channel", error.getReasonCode());
        assertEquals("Missing request header 'x-lbg-channel' for method parameter of type String", error.getMessage());
    }

    @Test
    public void throws_exception_when_brand_name_is_invalid() {
        //given
        HttpHeaders headers = portingHelper.getAccountInfoHeaders();
        headers.set("x-lbg-brand", "invalid");

        // when
        String payload = componentHelper.writeValueAsString(portingHelper.solicitorDocPayload().build());
        MockHttpServletResponse response = doPOST(SOLICITOR_DOC_RECEIVED_ENDPOINT, payload, headers);
        ErrorInfo error = readErrorInfo(componentHelper.getServletResponseAsString(response));

        // then
        assertEquals(STATUS_CODE_BAD_REQUEST, response.getStatus());
        assertEquals("PNA.MORTGAGE_API.POST_MORTGAGES_APPLICATION_SOLICITOR_DOC_RECEIVED.Header.Invalid", error.getReasonCode());
        assertEquals("Invalid enum value for type x-lbg-brand", error.getMessage());
    }
}