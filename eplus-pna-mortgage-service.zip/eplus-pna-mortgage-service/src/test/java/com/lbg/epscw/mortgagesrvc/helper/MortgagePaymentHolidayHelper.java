package com.lbg.epscw.mortgagesrvc.helper;

import com.lbg.epscw.mortgagesrvc.dto.*;
import com.lbg.epscw.mortgagesrvc.model.AccountOptionsUpdateResponse;
import com.lbg.epscw.mortgagesrvc.model.InstanceParamValsUpdate;
import com.lbg.epscw.mortgagesrvc.model.PaymentHolidayRequest;
import com.lbg.epscw.mortgagesrvc.model.PaymentHolidayResponse;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;

import java.time.LocalDate;
import java.time.ZoneId;
import java.util.*;

import static com.lbg.epscw.mortgagesrvc.constants.CommonConstants.*;

public class MortgagePaymentHolidayHelper {

    public HttpHeaders getAccountInfoHeaders() {
        HttpHeaders httpHeaders = new HttpHeaders();
        httpHeaders.add("Authorization", "Bearer b2c9119f-09e5-4ac9-9738-9e28b334d3fa");
        httpHeaders.add("x-lbg-internal-system-id", "test");
        httpHeaders.add("x-lbg-brand", "IF");
        httpHeaders.add("x-lbg-txn-correlation-id", "123-456-789-123");
        httpHeaders.setContentType(MediaType.APPLICATION_JSON);
        return httpHeaders;
    }

    public PaymentHolidayRequest getPaymentHolidayRequest() {
        PaymentHolidayRequest paymentHolidayRequest = new PaymentHolidayRequest();
        paymentHolidayRequest.setStartMonthYear("10/2021");
        paymentHolidayRequest.setEndMonthYear("11/2021");
        return paymentHolidayRequest;
    }

    public PaymentHolidayRequest buildPaymentHolidayRequest(String startDate, String endDate) {
        PaymentHolidayRequest paymentHolidayRequest = new PaymentHolidayRequest();
        paymentHolidayRequest.setStartMonthYear(startDate);
        paymentHolidayRequest.setEndMonthYear(endDate);
        return paymentHolidayRequest;
    }

    public PaymentHolidayResponse getMockAddPaymentHolidayResponse() {
        PaymentHolidayResponse response = new PaymentHolidayResponse();
        response.setAccountId("144a38f3-a7b3-a3aa-d656-ff98fbaaa565");
        response.setStatus(PAYMENT_HOLIDAY_ADD_SUCCESS);
        Map<String, String> instanceParamVals = new HashMap<>();
        instanceParamVals.put(START_DATE, "10/2021");
        instanceParamVals.put(END_DATE, "11/2021");
        response.setInstanceParamVals(instanceParamVals);

        return response;
    }

    public PaymentHolidayResponse getMockCancelPaymentHolidayResponse() {
        PaymentHolidayResponse response = new PaymentHolidayResponse();
        response.setAccountId("144a38f3-a7b3-a3aa-d656-ff98fbaaa565");
        response.setStatus(PAYMENT_HOLIDAY_CANCEL_SUCCESS);
        Map<String, String> instanceParamVals = new HashMap<>();
        instanceParamVals.put(START_DATE, "10/2021");
        instanceParamVals.put(END_DATE, "11/2021");
        response.setInstanceParamVals(instanceParamVals);

        return response;
    }

    public MortgageAccountInfo mortgageAccountInfo_mortgagePaymentHolidayMock() {

        MortgageAccountInfo mortgageAccountInfo = new MortgageAccountInfo();
        List<MortgageAccountData> mortgageAccountDataList = new ArrayList<>();
        MortgageAccountData mortgageAccountData = new MortgageAccountData();
        mortgageAccountData.setAccountId("132a38f3-a7b3-a3aa-d656-ff98fbaba565");
        mortgageAccountData.setProductId("lbg_mortgage");
        mortgageAccountData.setKeyDate(String.valueOf(LocalDate.now(ZoneId.systemDefault()).getDayOfMonth()+4));
        mortgageAccountData.setPaymentHolidayMonths(new String[]{"03/2021","04/2021","11/2021"});
        mortgageAccountDataList.add(mortgageAccountData);
        mortgageAccountInfo.setMortgageAccountData(mortgageAccountDataList);
        return mortgageAccountInfo;
    }

    public MortgageAccountInfo mortgageAccountInfo_mortgagePaymentHolidayEmpty() {

        MortgageAccountInfo mortgageAccountInfo = new MortgageAccountInfo();
        List<MortgageAccountData> mortgageAccountDataList = new ArrayList<>();
        MortgageAccountData mortgageAccountData = new MortgageAccountData();
        mortgageAccountData.setAccountId("132a38f3-a7b3-a3aa-d656-ff98fbaaa565");
        mortgageAccountData.setProductId("lbg_mortgage");
        mortgageAccountData.setKeyDate(String.valueOf(LocalDate.now(ZoneId.systemDefault()).getDayOfMonth()+4));
        mortgageAccountData.setPaymentHolidayMonths(new String[]{""});
        mortgageAccountDataList.add(mortgageAccountData);
        mortgageAccountInfo.setMortgageAccountData(mortgageAccountDataList);
        return mortgageAccountInfo;
    }

    public MortgageAccountInfo mortgageAccountInfo_mortgagePaymentHolidayMockforEligibile() {

        MortgageAccountInfo mortgageAccountInfo = new MortgageAccountInfo();
        List<MortgageAccountData> mortgageAccountDataList = new ArrayList<>();
        MortgageAccountData mortgageAccountData = new MortgageAccountData();
        mortgageAccountData.setAccountId("132a38f3-a7b3-a3aa-d656-ff98fbaaa565");
        mortgageAccountData.setProductId("lbg_mortgage");
        mortgageAccountData.setKeyDate(String.valueOf(LocalDate.now(ZoneId.systemDefault()).getDayOfMonth()+2));
        mortgageAccountData.setPaymentHolidayMonths(new String[]{"03/2021","04/2021","11/2021"});
        mortgageAccountDataList.add(mortgageAccountData);
        mortgageAccountInfo.setMortgageAccountData(mortgageAccountDataList);
        return mortgageAccountInfo;
    }

    public String getMortgageQueryServiceResponse() {
        return "{\n" +
                "    \"Data\": [\n" +
                "        {\n" +
                "            \"mortgageNumber\": \"BBJourney004Dakshi\",\n" +
                "            \"mortgagePrincipal\": \"3500\",\n" +
                "            \"keyDate\": \""+(LocalDate.now(ZoneId.systemDefault()).getDayOfMonth()+4)+"\",\n" +
                "            \"mortgageType\": \"CAPITAL_REPAYMENT\",\n" +
                "            \"totalTerm\": \"12\",\n" +
                "            \"accountStatus\": \"ACCOUNT_STATUS_OPEN\",\n" +
                "            \"accountOpeningDate\": \"2020-12-21\",\n" +
                "            \"accountId\": \"d7453689-9f34-302e-64f3-83ce97c2317c\",\n" +
                "            \"productFamily\": \"Mortgage\",\n" +
                "            \"productId\": \"lbg_mortgage\",\n" +
                "            \"paymentHolidayMonths\": [\n" +
                "                \"10/2021\",\n" +
                "                \"11/2021\",\n" +
                "                \"11/2022\"\n" +
                "            ]\n" +
                "        }\n" +
                "    ]\n" +
                "}";

    }

    public PaymentHolidayEligibility buildPaymentHolidayEligibilityInfo(boolean eligible) {
        PaymentHolidayEligibility paymentHolidayEligibility = new PaymentHolidayEligibility();
        if(eligible) {
            paymentHolidayEligibility.setEligibleForPaymentHoliday(true);
            paymentHolidayEligibility.setEligibilityFailureReasonList(new ArrayList<>());
        }
        else {
            paymentHolidayEligibility.setEligibleForPaymentHoliday(false);
            EligibilityFailureReason eligibilityFailureReason=new EligibilityFailureReason("101","Payment Holiday not eligible");
            paymentHolidayEligibility.setEligibilityFailureReasonList(Arrays.asList(eligibilityFailureReason));
        }
        return paymentHolidayEligibility;
    }

    public Map<String,String> readObjectResponse(){
        Map<String,String> readObjectMap= new HashMap<>();
        readObjectMap.put("StartMonthYear", "10/2021");
        readObjectMap.put("EndMonthYear","11/2021");
        return readObjectMap;

    }

    public AccountOptionsUpdateResponse buildAccountOptionsUpdateResponse(String accountId,String status) {
        AccountOptionsUpdateResponse accountOptionsUpdateResponse= new AccountOptionsUpdateResponse();
        accountOptionsUpdateResponse.setAccountId(accountId);
        accountOptionsUpdateResponse.setStatus(status);

        Map<String,String> paymentHolidayOptions= new HashMap<>();
        paymentHolidayOptions.put("payment_holiday_months","03/2017,04/2019,07/2019,10/2021,11/2021");
        InstanceParamValsUpdate instanceParamValsUpdate = new InstanceParamValsUpdate();
        instanceParamValsUpdate.setInstanceParamVals(paymentHolidayOptions);
        accountOptionsUpdateResponse.setInstanceParamValsUpdate(instanceParamValsUpdate);

        return accountOptionsUpdateResponse;
    }

    public String getVaultResponse() {
        return "{\n" +
                "    \"id\": \"3x807adc-1476-4842-94d7-93d95f01c36d\",\n" +
                "    \"account_id\": \"d7442689-9f34-302e-64f3-83ce97c2317c\",\n" +
                "    \"status\": \"ACCOUNT_UPDATE_STATUS_PENDING_EXECUTION\",\n" +
                "    \"instance_param_vals_update\": {\n" +
                "        \"instance_param_vals\": {\n" +
                "            \"payment_holiday_months\": \"10/2022,11/2022,11/2021\"\n" +
                "        }\n" +
                "    },\n" +
                "    \"create_timestamp\": \"2020-12-22T07:42:28.223833Z\",\n" +
                "    \"last_status_update_timestamp\": \"2020-12-22T07:42:28.223833Z\",\n" +
                "    \"account_update_batch_id\": \"\",\n" +
                "    \"failure_reason\": \"\"\n" +
                "}";
    }

    public String getPaymentHolidayEligibilityResponse() {
        return "{\n" +
                "    \"eligibleForPaymentHoliday\": false,\n" +
                "    \"eligibilityFailureReason\": [\n" +
                "        {\n" +
                "            \"code\": \"MORTGAGE_PAYMENT_HOLIDAY_INELIGIBLE\",\n" +
                "            \"message\": \"Mortgage term is less than 3 years\"\n" +
                "        }\n" +
                "    ]\n" +
                "}";
    }
}
