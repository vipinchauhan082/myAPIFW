package com.lbg.epscw.mortgagesrvc.controller;

import com.lbg.epscw.mortgagesrvc.constants.CommonConstants;
import com.lbg.epscw.mortgagesrvc.exception.MortgageServiceException;
import com.lbg.epscw.mortgagesrvc.helper.MortgageAccountOptionDataHelper;
import com.lbg.epscw.mortgagesrvc.model.Channel;
import com.lbg.epscw.mortgagesrvc.model.MortgageOptionsUpdateResponse;
import com.lbg.epscw.mortgagesrvc.service.MortgageAccountOptionService;
import com.lbg.epscw.mortgagesrvc.util.MortgageServiceUtil;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit4.SpringRunner;

import javax.validation.ConstraintViolationException;
import java.util.HashMap;
import java.util.Map;

import static org.junit.Assert.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.powermock.api.mockito.PowerMockito.when;

@RunWith(SpringRunner.class)
@WebMvcTest(controllers = { MortgageServiceUtil.class, MortgageTermReductionController.class })

public class MortgageTermReductionControllerTest {

    @MockBean
    private MortgageAccountOptionService mortgageAccountOptionService;

    private MortgageAccountOptionDataHelper mortgageAccountOptionDataHelper = new MortgageAccountOptionDataHelper();

    @Autowired
    private MortgageTermReductionController mortgageTermReductionController;

    @Test
    public void reduce_mortgage_term_successful() {
        when(mortgageAccountOptionService.reduceMortgageTerm(any(String.class), any(Map.class)))
                .thenReturn(mortgageAccountOptionDataHelper.buildMortgageOptionsUpdateResponse(CommonConstants.KEY_MORTGAGE_TERM, "15"));
        //when
        ResponseEntity<MortgageOptionsUpdateResponse> responseEntity = mortgageTermReductionController
                .reduceMortgageTerm("IF", Channel.DIGITAL.name(), "123-456-789-12", "Bearer 122", "ALL", new HashMap<String, String>(),"1601d0e5-e336-64d9-64ad-89ba6fdc2677");
        MortgageOptionsUpdateResponse accountOptionsUpdateResponse = responseEntity.getBody();

        //then
        assertEquals("1601d0e5-e336-64d9-64ad-89ba6fdc2677", accountOptionsUpdateResponse.getAccountId());
    }

    @Test(expected = MortgageServiceException.class)
    public void reduce_mortgage_term_when_service_layer_fails() {

        when(mortgageAccountOptionService.reduceMortgageTerm(any(String.class), any(Map.class)))
                .thenReturn(null);
        //when
        mortgageTermReductionController
                .reduceMortgageTerm("IF", Channel.DIGITAL.name(), "123-456-789-12", "Bearer 122", "ALL", new HashMap<String, String>(),
                        "1601d0e5-e336-64d9-64ad-89ba6fdc2677");
    }

    @Test(expected = ConstraintViolationException.class)
    public void reduce_mortgage_term_rejects_request_if_accountId_length_is_small() {
        //when
        mortgageTermReductionController
                .reduceMortgageTerm("IF", Channel.DIGITAL.name(), "123-456-789-12", "Bearer 122", "ALL", new HashMap<String, String>(),
                        "1601-e336-64d9-64ad-89ba6fdc2677");
    }

    @Test(expected = ConstraintViolationException.class)
    public void reduce_mortgage_term_rejects_request_if_accountId_length_is_big() {
        mortgageTermReductionController
                .reduceMortgageTerm("IF", Channel.DIGITAL.name(), "123-456-789-12", "Bearer 122", "ALL", new HashMap<String, String>(),
                        "1601d0e5-e336-64d9-64ad-89ba6fdc2677-pplu");
    }

    @Test(expected = ConstraintViolationException.class)
    public void reduce_mortgage_term_rejects_request_if_accountId_length_is_empty() {
        //when
        mortgageTermReductionController
                .reduceMortgageTerm("IF", Channel.DIGITAL.name(), "123-456-789-12", "Bearer 122", "ALL", new HashMap<String, String>(),
                        "");
    }

    @Test(expected = ConstraintViolationException.class)
    public void reduce_mortgage_term_rejects_request_if_accountId_length_is_null() {
        //when
        mortgageTermReductionController
                .reduceMortgageTerm("IF", Channel.DIGITAL.name(), "123-456-789-12", "Bearer 122", "ALL", new HashMap<String, String>(),
                        null);
    }

    @Test(expected = ConstraintViolationException.class)
    public void reduce_mortgage_term_rejects_request_if_brand_header_is_violates() {
        //when
        mortgageTermReductionController
                .reduceMortgageTerm("IFF", Channel.DIGITAL.name(),"123-456-789-12", "Bearer 122", "ALL", new HashMap<String, String>(),
                         "5a688301-6d00-485c-0242-1ee03844a5c4");

    }

    @Test(expected = ConstraintViolationException.class)
    public void reduce_mortgage_term_rejects_request_if_txnCorrelationId_header_violates() {
        //when
        mortgageTermReductionController
                .reduceMortgageTerm("IF",Channel.DIGITAL.name(), null, "Bearer 122", "ALL", new HashMap<String, String>(),
                        "5a688301-6d00-485c-0242-1ee03844a5c4");
    }
}
