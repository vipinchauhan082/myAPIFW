package com.lbg.epscw.mortgagesrvc.restclient;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.json.JsonMapper;
import com.lbg.epscw.mortgagesrvc.exception.MortgageCTLValidationException;
import com.lbg.epscw.mortgagesrvc.helper.MortgageCTLHelper;
import com.lbg.epscw.mortgagesrvc.model.VaultMetadataOptionsResponse;
import com.lbg.epscw.mortgagesrvc.service.RestClientService;
import com.lbg.epscw.mortgagesrvc.util.MortgageServiceUtil;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.internal.util.reflection.FieldSetter;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;

import java.text.MessageFormat;
import java.util.HashMap;
import java.util.Map;

import static org.junit.Assert.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.powermock.api.mockito.PowerMockito.when;

@RunWith(PowerMockRunner.class)
@PrepareForTest({ MessageFormat.class })
public class MortgageMetadataRestClientTest {

    @Value("${vault.account.metadata.update.endpoint}")
    private String accountMetadataUpdateEndpoint;

    @Value("${vault.account.metadata.get.endpoint}")
    private String accountMetadataGetEndpoint;

    @Mock
    RestClientService restClientService;

    @Mock
    MortgageServiceUtil mortgageServiceUtil;

    @Autowired
    private ObjectMapper mapper;

    private MortgageCTLHelper mortgageCTLHelper = new MortgageCTLHelper();

    private MortgageMetadataRestClient restClient;

    @Before
    public void setup() {
        this.mapper = new ObjectMapper();
    }

    @Test
    public void update_metadata_options() throws NoSuchFieldException {
        MortgageServiceUtil util = new MortgageServiceUtil(new JsonMapper());
        restClient = new MortgageMetadataRestClient(restClientService, util);
        String response = util.writeObjectAsString(mortgageCTLHelper.buildAccountCtlVaultResponse());
        FieldSetter.setField(restClient,
                restClient.getClass().getDeclaredField("accountMetadataUpdateEndpoint"),
                "mortgageAccountClosureEligibilityEndpoint");

        FieldSetter.setField(restClient,
                restClient.getClass().getDeclaredField("accountMetadataGetEndpoint"),
                "accountMetadataGetEndpoint");

        when(restClientService.put(any(String.class), any(HashMap.class), anyString())).thenReturn(response);

        VaultMetadataOptionsResponse responseReturned = restClient.updateMetadataOptions("1234", mortgageCTLHelper.buildAddCtlVaultRequest());

        assertNotNull(responseReturned);
        assertEquals(responseReturned, mortgageCTLHelper.buildAccountCtlVaultResponse());
    }

    @Test
    public void get_metadata_options() throws NoSuchFieldException {
        MortgageServiceUtil util = new MortgageServiceUtil(new JsonMapper());
        restClient = new MortgageMetadataRestClient(restClientService, util);
        String response = util.writeObjectAsString(mortgageCTLHelper.buildAccountCtlVaultResponse());

        FieldSetter.setField(restClient,
                restClient.getClass().getDeclaredField("accountMetadataGetEndpoint"),
                "accountMetadataGetEndpoint");

        when(restClientService.get(any(String.class), any(HashMap.class))).thenReturn(response);

        VaultMetadataOptionsResponse responseReturned = restClient.getMetadataOptions("1234");

        assertNotNull(responseReturned);
        assertEquals(responseReturned, mortgageCTLHelper.buildAccountCtlVaultResponse());
    }

    @Test
    public void validate_ctl_options() throws NoSuchFieldException {
        MortgageServiceUtil util = new MortgageServiceUtil(new JsonMapper());
        restClient = new MortgageMetadataRestClient(restClientService, util);
        String response = util.writeObjectAsString(mortgageCTLHelper.buildAccountCtlVaultResponse());

        FieldSetter.setField(restClient,
                restClient.getClass().getDeclaredField("accountMetadataGetEndpoint"),
                "accountMetadataGetEndpoint");

        when(restClientService.get(any(String.class), any(HashMap.class))).thenReturn(response);

        restClient.validateAccountCTL("1234");
        Map<String, String> headers = new HashMap<>();
        headers.put("X-Auth-Token", null);
        headers.put("Content-Type","application/json");
        verify(restClientService, times(1)).get("accountMetadataGetEndpoint",headers);
    }

    @Test(expected = MortgageCTLValidationException.class)
    public void validate_ctl_options_exception() throws NoSuchFieldException {
        MortgageServiceUtil util = new MortgageServiceUtil(new JsonMapper());
        restClient = new MortgageMetadataRestClient(restClientService, util);
        String response = util.writeObjectAsString(mortgageCTLHelper.buildAccountCtlVaultResponseNoIndicator());

        FieldSetter.setField(restClient,
                restClient.getClass().getDeclaredField("accountMetadataGetEndpoint"),
                "accountMetadataGetEndpoint");

        when(restClientService.get(any(String.class), any(HashMap.class))).thenReturn(response);

        restClient.validateAccountCTL("1234");
    }
}