package com.lbg.epscw.mortgagesrvc.service;

import com.lbg.epscw.mortgagesrvc.enums.MortgageOptionInstructionEnum;
import com.lbg.epscw.mortgagesrvc.enums.RepaymentType;
import com.lbg.epscw.mortgagesrvc.exception.CircuitBreakerOpenException;
import com.lbg.epscw.mortgagesrvc.exception.InvalidUpdateRequestException;
import com.lbg.epscw.mortgagesrvc.helper.MortgageAccountDataHelper;
import com.lbg.epscw.mortgagesrvc.helper.MortgageAccountOptionDataHelper;
import com.lbg.epscw.mortgagesrvc.model.AccountOptionsUpdateRequest;
import com.lbg.epscw.mortgagesrvc.model.AccountOptionsUpdateResponse;
import com.lbg.epscw.mortgagesrvc.model.MortgageOptionsUpdateResponse;
import com.lbg.epscw.mortgagesrvc.model.VaultAccountOptionsUpdateRequest;
import com.lbg.epscw.mortgagesrvc.restclient.MortgageAccountInfoRestClient;
import com.lbg.epscw.mortgagesrvc.restclient.MortgageAccountOptionRestClient;
import com.lbg.epscw.mortgagesrvc.restclient.MortgageTermReductionCalcRestClient;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;

import java.util.HashMap;
import java.util.Map;

import static com.lbg.epscw.mortgagesrvc.constants.CommonConstants.KEY_MORTGAGE_TERM;
import static com.lbg.epscw.mortgagesrvc.constants.CommonConstants.KEY_MORTGAGE_TYPE;
import static org.junit.Assert.assertNotNull;
import static org.mockito.ArgumentMatchers.any;
import static org.powermock.api.mockito.PowerMockito.mock;
import static org.powermock.api.mockito.PowerMockito.when;

public class MortgageAccountOptionsServiceTest {
	
	@Mock
	private MortgageAccountInfoRestClient mortgageAccountInfoRestClient;
	
	@Mock
	private MortgageAccountOptionRestClient mortgageAccountOptionRestClient;

	@Mock
	private MortgageTermReductionCalcRestClient mortgageTermReductionCalcRestClient;


	private MortgageAccountOptionDataHelper mortgageAccountOptionDataHelper = new MortgageAccountOptionDataHelper();
	private MortgageAccountDataHelper mortgageAccountDataHelper = new MortgageAccountDataHelper();
	
	@Before
	public void setup() {
		mortgageAccountInfoRestClient = mock(MortgageAccountInfoRestClient.class);
		mortgageAccountOptionRestClient = mock(MortgageAccountOptionRestClient.class);
		mortgageTermReductionCalcRestClient = mock(MortgageTermReductionCalcRestClient.class);
	}

	@Test
	public void update_acc_option_for_mortgage_type() {

		AccountOptionsUpdateResponse accountOptionsUpdateResponse = mortgageAccountOptionDataHelper.buildAccountOptionsUpdateResponse( KEY_MORTGAGE_TYPE, RepaymentType.CAPITAL_REPAYMENT.name());
		AccountOptionsUpdateRequest accountUpdateReq =  mortgageAccountOptionDataHelper.buildAccountOptionsUpdateRequestForMortgageType(RepaymentType.CAPITAL_REPAYMENT.name());

		MortgageAccountOptionService mortgageAccountOptionService = new MortgageAccountOptionServiceImpl(mortgageAccountOptionRestClient, mortgageAccountInfoRestClient, mortgageTermReductionCalcRestClient);
		when(mortgageAccountInfoRestClient.getMortgageAccountInfo(any(String.class), any(Map.class))).thenReturn(mortgageAccountDataHelper.buildViewAccountInfo());
		when(mortgageAccountOptionRestClient.updateAccountOptions(any(VaultAccountOptionsUpdateRequest.class))).thenReturn(accountOptionsUpdateResponse);

		MortgageOptionsUpdateResponse response = mortgageAccountOptionService.updateAccountOptions(accountUpdateReq, "1601d0e5-e336-64d9-64ad-89ba6fdc2677", new HashMap<>());
		assertNotNull(response);;
	}
	
	@Test
	public void update_acc_option_for_mortgage_term_extend() {
		
		AccountOptionsUpdateResponse accountOptionsUpdateResponse = mortgageAccountOptionDataHelper.buildAccountOptionsUpdateResponse(KEY_MORTGAGE_TERM,"30");
		AccountOptionsUpdateRequest accountUpdateReq =  mortgageAccountOptionDataHelper.buildAccountOptionsUpdateRequestForMortgageTerm(MortgageOptionInstructionEnum.MortgageTermExtend,"30");
		
		MortgageAccountOptionService mortgageAccountOptionService = new MortgageAccountOptionServiceImpl(mortgageAccountOptionRestClient, mortgageAccountInfoRestClient, mortgageTermReductionCalcRestClient);
		when(mortgageAccountInfoRestClient.getMortgageAccountInfo(any(String.class), any(Map.class))).thenReturn(mortgageAccountDataHelper.buildViewAccountInfo());
		when(mortgageAccountOptionRestClient.updateAccountOptions(any(VaultAccountOptionsUpdateRequest.class))).thenReturn(accountOptionsUpdateResponse);
		
		MortgageOptionsUpdateResponse response = mortgageAccountOptionService.updateAccountOptions(accountUpdateReq,"1601d0e5-e336-64d9-64ad-89ba6fdc2677", new HashMap<>());
		assertNotNull(response);;
	}
	
	@Test
	public void update_acc_option_for_mortgage_term_reduce() {
		
		AccountOptionsUpdateResponse accountOptionsUpdateResponse = mortgageAccountOptionDataHelper.buildAccountOptionsUpdateResponse(KEY_MORTGAGE_TERM,"12");
		AccountOptionsUpdateRequest accountUpdateReq =  mortgageAccountOptionDataHelper.buildAccountOptionsUpdateRequestForMortgageTerm(MortgageOptionInstructionEnum.MortgageTermReduce,"12");

		MortgageAccountOptionService mortgageAccountOptionService = new MortgageAccountOptionServiceImpl(mortgageAccountOptionRestClient, mortgageAccountInfoRestClient, mortgageTermReductionCalcRestClient);
		when(mortgageAccountInfoRestClient.getMortgageAccountInfo(any(String.class), any(Map.class))).thenReturn(mortgageAccountDataHelper.buildViewAccountInfo());
		when(mortgageAccountOptionRestClient.updateAccountOptions(any(VaultAccountOptionsUpdateRequest.class))).thenReturn(accountOptionsUpdateResponse);
		
		MortgageOptionsUpdateResponse response = mortgageAccountOptionService.updateAccountOptions(accountUpdateReq,"1601d0e5-e336-64d9-64ad-89ba6fdc2677", new HashMap<>());
		assertNotNull(response);;
	}
	
	@Test(expected = InvalidUpdateRequestException.class)
	public void update_acc_option_for_invalid_instruction_reduce() {
		
		AccountOptionsUpdateResponse accountOptionsUpdateResponse = mortgageAccountOptionDataHelper.buildAccountOptionsUpdateResponse(KEY_MORTGAGE_TERM,"18");
		AccountOptionsUpdateRequest accountUpdateReq =  mortgageAccountOptionDataHelper.buildAccountOptionsUpdateRequestForMortgageTerm(MortgageOptionInstructionEnum.MortgageTermReduce,"18");

		MortgageAccountOptionService mortgageAccountOptionService = new MortgageAccountOptionServiceImpl(mortgageAccountOptionRestClient, mortgageAccountInfoRestClient, mortgageTermReductionCalcRestClient);
		when(mortgageAccountInfoRestClient.getMortgageAccountInfo(any(String.class), any(Map.class))).thenReturn(mortgageAccountDataHelper.buildViewAccountInfo());
		when(mortgageAccountOptionRestClient.updateAccountOptions(any(VaultAccountOptionsUpdateRequest.class))).thenReturn(accountOptionsUpdateResponse);
		
		MortgageOptionsUpdateResponse response = mortgageAccountOptionService.updateAccountOptions(accountUpdateReq,"1601d0e5-e336-64d9-64ad-89ba6fdc2677", new HashMap<>());
		assertNotNull(response);;
	}
	
	@Test(expected = InvalidUpdateRequestException.class)
	public void update_acc_option_for_invalid_mortgage_type() {
		
		AccountOptionsUpdateResponse accountOptionsUpdateResponse = mortgageAccountOptionDataHelper.buildAccountOptionsUpdateResponse(KEY_MORTGAGE_TYPE, "CAPITAL");
		AccountOptionsUpdateRequest accountUpdateReq =  mortgageAccountOptionDataHelper.buildAccountOptionsUpdateRequestForMortgageType("CAPITAL");
		
		MortgageAccountOptionService mortgageAccountOptionService = new MortgageAccountOptionServiceImpl(mortgageAccountOptionRestClient, mortgageAccountInfoRestClient, mortgageTermReductionCalcRestClient);
		when(mortgageAccountInfoRestClient.getMortgageAccountInfo(any(String.class), any(Map.class))).thenReturn(mortgageAccountDataHelper.buildViewAccountInfo());
		when(mortgageAccountOptionRestClient.updateAccountOptions(any(VaultAccountOptionsUpdateRequest.class))).thenReturn(accountOptionsUpdateResponse);
		
		MortgageOptionsUpdateResponse response = mortgageAccountOptionService.updateAccountOptions(accountUpdateReq,"1601d0e5-e336-64d9-64ad-89ba6fdc2677", new HashMap<>());
		assertNotNull(response);;
	}
	
	@Test(expected = InvalidUpdateRequestException.class)
	public void update_acc_option_for_invalid_instruction_type() {
		
		AccountOptionsUpdateResponse accountOptionsUpdateResponse = mortgageAccountOptionDataHelper.buildAccountOptionsUpdateResponse(RepaymentType.INTEREST_ONLY.name(), KEY_MORTGAGE_TYPE);
		AccountOptionsUpdateRequest accountUpdateReq =  mortgageAccountOptionDataHelper.buildAccountOptionsUpdateRequestForMortgageType(RepaymentType.INTEREST_ONLY.name());
		
		MortgageAccountOptionService mortgageAccountOptionService = new MortgageAccountOptionServiceImpl(mortgageAccountOptionRestClient, mortgageAccountInfoRestClient, mortgageTermReductionCalcRestClient);
		when(mortgageAccountInfoRestClient.getMortgageAccountInfo(any(String.class), any(Map.class))).thenReturn(mortgageAccountDataHelper.buildViewAccountInfo());
		when(mortgageAccountOptionRestClient.updateAccountOptions(any(VaultAccountOptionsUpdateRequest.class))).thenReturn(accountOptionsUpdateResponse);
		
		MortgageOptionsUpdateResponse response = mortgageAccountOptionService.updateAccountOptions(accountUpdateReq,"1601d0e5-e336-64d9-64ad-89ba6fdc2677", new HashMap<>());
		assertNotNull(response);;
	}
	
	@Test(expected = InvalidUpdateRequestException.class)
	public void update_acc_option_for_invalid_instruction_reduce_to_zero() {
		
		AccountOptionsUpdateResponse accountOptionsUpdateResponse = mortgageAccountOptionDataHelper.buildAccountOptionsUpdateResponse(KEY_MORTGAGE_TERM,"0");
		AccountOptionsUpdateRequest accountUpdateReq =  mortgageAccountOptionDataHelper.buildAccountOptionsUpdateRequestForMortgageTerm(MortgageOptionInstructionEnum.MortgageTermReduce,"0");

		MortgageAccountOptionService mortgageAccountOptionService = new MortgageAccountOptionServiceImpl(mortgageAccountOptionRestClient, mortgageAccountInfoRestClient, mortgageTermReductionCalcRestClient);
		when(mortgageAccountInfoRestClient.getMortgageAccountInfo(any(String.class), any(Map.class))).thenReturn(mortgageAccountDataHelper.buildViewAccountInfo());
		when(mortgageAccountOptionRestClient.updateAccountOptions(any(VaultAccountOptionsUpdateRequest.class))).thenReturn(accountOptionsUpdateResponse);
		
		MortgageOptionsUpdateResponse response = mortgageAccountOptionService.updateAccountOptions(accountUpdateReq,"1601d0e5-e336-64d9-64ad-89ba6fdc2677", new HashMap<>());
		assertNotNull(response);;
	}
	
	@Test(expected = InvalidUpdateRequestException.class)
	public void update_acc_option_for_invalid_instruction_extend_to_zero() {
		
		AccountOptionsUpdateResponse accountOptionsUpdateResponse = mortgageAccountOptionDataHelper.buildAccountOptionsUpdateResponse(KEY_MORTGAGE_TERM,"0");
		AccountOptionsUpdateRequest accountUpdateReq =  mortgageAccountOptionDataHelper.buildAccountOptionsUpdateRequestForMortgageTerm(MortgageOptionInstructionEnum.MortgageTermExtend,"0");

		MortgageAccountOptionService mortgageAccountOptionService = new MortgageAccountOptionServiceImpl(mortgageAccountOptionRestClient, mortgageAccountInfoRestClient, mortgageTermReductionCalcRestClient);
		when(mortgageAccountInfoRestClient.getMortgageAccountInfo(any(String.class), any(Map.class))).thenReturn(mortgageAccountDataHelper.buildViewAccountInfo());
		when(mortgageAccountOptionRestClient.updateAccountOptions(any(VaultAccountOptionsUpdateRequest.class))).thenReturn(accountOptionsUpdateResponse);
		
		MortgageOptionsUpdateResponse response = mortgageAccountOptionService.updateAccountOptions(accountUpdateReq,"1601d0e5-e336-64d9-64ad-89ba6fdc2677", new HashMap<>());
		assertNotNull(response);;
	}

	@Test(expected = CircuitBreakerOpenException.class)
    public void hystrix_test_on_update_account_options() {
		MortgageAccountOptionService service = new MortgageAccountOptionServiceImpl(mortgageAccountOptionRestClient, mortgageAccountInfoRestClient, mortgageTermReductionCalcRestClient);
		when(mortgageAccountInfoRestClient.getMortgageAccountInfo(any(String.class), any(Map.class))).thenReturn(null);
		AccountOptionsUpdateRequest req = mortgageAccountOptionDataHelper.buildAccountOptionsUpdateRequestForMortgageTerm(MortgageOptionInstructionEnum.MortgageTermExtend,"0");
		service.fallbackUpdateMortgageAccountOptions(req,"f76ca840-2553-d536-1ab8-9fa85c99db05", new HashMap<>(), new Throwable("Circuit open on update account options"));
    }

    // Test cases to reduce mortgage term by Bank The Term calculation

	@Test
	public void update_acc_option_for_mortgage_term_reduce_banking_the_term() {

		AccountOptionsUpdateResponse accountOptionsUpdateResponse = mortgageAccountOptionDataHelper.buildAccountOptionsUpdateResponse(KEY_MORTGAGE_TERM,"12");

		MortgageAccountOptionService mortgageAccountOptionService = new MortgageAccountOptionServiceImpl(mortgageAccountOptionRestClient, mortgageAccountInfoRestClient, mortgageTermReductionCalcRestClient);
		when(mortgageTermReductionCalcRestClient.getMortgageTermReductionInfo(any(String.class), any(Map.class))).thenReturn(mortgageAccountDataHelper.buildViewMortgageTermReductionResponse("22","18","6"));
		when(mortgageAccountOptionRestClient.updateAccountOptions(any(VaultAccountOptionsUpdateRequest.class))).thenReturn(accountOptionsUpdateResponse);

		MortgageOptionsUpdateResponse response = mortgageAccountOptionService.reduceMortgageTerm("1601d0e5-e336-64d9-64ad-89ba6fdc2677", new HashMap<>());
		assertNotNull(response);;
	}

	@Test(expected = InvalidUpdateRequestException.class)
	public void update_acc_option_for_mortgage_term_reduce_banking_the_term_when_updated_total_term_is_equal_to_remaining_term() {

		AccountOptionsUpdateResponse accountOptionsUpdateResponse = mortgageAccountOptionDataHelper.buildAccountOptionsUpdateResponse(KEY_MORTGAGE_TERM,"12");

		MortgageAccountOptionService mortgageAccountOptionService = new MortgageAccountOptionServiceImpl(mortgageAccountOptionRestClient, mortgageAccountInfoRestClient, mortgageTermReductionCalcRestClient);
		when(mortgageTermReductionCalcRestClient.getMortgageTermReductionInfo(any(String.class), any(Map.class))).thenReturn(mortgageAccountDataHelper.buildViewMortgageTermReductionResponse("22","18","4"));
		when(mortgageAccountOptionRestClient.updateAccountOptions(any(VaultAccountOptionsUpdateRequest.class))).thenReturn(accountOptionsUpdateResponse);

		MortgageOptionsUpdateResponse response = mortgageAccountOptionService.reduceMortgageTerm("1601d0e5-e336-64d9-64ad-89ba6fdc2677", new HashMap<>());
		assertNotNull(response);;
	}

	@Test(expected = InvalidUpdateRequestException.class)
	public void update_acc_option_for_mortgage_term_reduce_banking_the_term_when_updated_total_term_is_greater_than_remaining_term() {

		AccountOptionsUpdateResponse accountOptionsUpdateResponse = mortgageAccountOptionDataHelper.buildAccountOptionsUpdateResponse(KEY_MORTGAGE_TERM,"12");

		MortgageAccountOptionService mortgageAccountOptionService = new MortgageAccountOptionServiceImpl(mortgageAccountOptionRestClient, mortgageAccountInfoRestClient, mortgageTermReductionCalcRestClient);
		when(mortgageTermReductionCalcRestClient.getMortgageTermReductionInfo(any(String.class), any(Map.class))).thenReturn(mortgageAccountDataHelper.buildViewMortgageTermReductionResponse("22","18","1"));
		when(mortgageAccountOptionRestClient.updateAccountOptions(any(VaultAccountOptionsUpdateRequest.class))).thenReturn(accountOptionsUpdateResponse);

		MortgageOptionsUpdateResponse response = mortgageAccountOptionService.reduceMortgageTerm("1601d0e5-e336-64d9-64ad-89ba6fdc2677", new HashMap<>());
		assertNotNull(response);
	}

	@Test(expected = InvalidUpdateRequestException.class)
	public void update_acc_option_for_mortgage_term_reduce_banking_the_term_when_reduced_term_is_null() {

		AccountOptionsUpdateResponse accountOptionsUpdateResponse = mortgageAccountOptionDataHelper.buildAccountOptionsUpdateResponse(KEY_MORTGAGE_TERM,"12");

		MortgageAccountOptionService mortgageAccountOptionService = new MortgageAccountOptionServiceImpl(mortgageAccountOptionRestClient, mortgageAccountInfoRestClient, mortgageTermReductionCalcRestClient);
		when(mortgageTermReductionCalcRestClient.getMortgageTermReductionInfo(any(String.class), any(Map.class))).thenReturn(mortgageAccountDataHelper.buildViewMortgageTermReductionResponse("22","18",null));
		when(mortgageAccountOptionRestClient.updateAccountOptions(any(VaultAccountOptionsUpdateRequest.class))).thenReturn(accountOptionsUpdateResponse);

		MortgageOptionsUpdateResponse response = mortgageAccountOptionService.reduceMortgageTerm("1601d0e5-e336-64d9-64ad-89ba6fdc2677", new HashMap<>());
		assertNotNull(response);
	}

	@Test(expected = InvalidUpdateRequestException.class)
	public void update_acc_option_for_mortgage_term_reduce_banking_the_term_when_reduced_term_is_empty() {

		AccountOptionsUpdateResponse accountOptionsUpdateResponse = mortgageAccountOptionDataHelper.buildAccountOptionsUpdateResponse(KEY_MORTGAGE_TERM,"12");

		MortgageAccountOptionService mortgageAccountOptionService = new MortgageAccountOptionServiceImpl(mortgageAccountOptionRestClient, mortgageAccountInfoRestClient, mortgageTermReductionCalcRestClient);
		when(mortgageTermReductionCalcRestClient.getMortgageTermReductionInfo(any(String.class), any(Map.class))).thenReturn(mortgageAccountDataHelper.buildViewMortgageTermReductionResponse("22","18",""));
		when(mortgageAccountOptionRestClient.updateAccountOptions(any(VaultAccountOptionsUpdateRequest.class))).thenReturn(accountOptionsUpdateResponse);

		MortgageOptionsUpdateResponse response = mortgageAccountOptionService.reduceMortgageTerm("1601d0e5-e336-64d9-64ad-89ba6fdc2677", new HashMap<>());
		assertNotNull(response);
	}

	@Test(expected = CircuitBreakerOpenException.class)
	public void hystrix_test_on_update_acc_option_for_mortgage_term_reduce_banking_the_term() {
		MortgageAccountOptionService mortgageAccountOptionService = new MortgageAccountOptionServiceImpl(mortgageAccountOptionRestClient, mortgageAccountInfoRestClient, mortgageTermReductionCalcRestClient);

		when(mortgageTermReductionCalcRestClient.getMortgageTermReductionInfo(any(String.class), any(Map.class))).thenReturn(null);

		AccountOptionsUpdateRequest req = mortgageAccountOptionDataHelper.buildAccountOptionsUpdateRequestForMortgageTerm(MortgageOptionInstructionEnum.MortgageTermExtend,"0");
		mortgageAccountOptionService.fallbackReduceMortgageTerm("f76ca840-2553-d536-1ab8-9fa85c99db05", new HashMap<>(), new Throwable("Circuit open on update account options"));
	}
}
