package com.lbg.epscw.mortgagesrvc.restclient;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.lbg.epscw.mortgagesrvc.dto.MortgageClosureEligibility;
import com.lbg.epscw.mortgagesrvc.helper.MortgageAccountClosureHelper;
import com.lbg.epscw.mortgagesrvc.service.RestClientService;
import com.lbg.epscw.mortgagesrvc.util.MortgageServiceUtil;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.internal.util.reflection.FieldSetter;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;

import java.text.MessageFormat;
import java.util.HashMap;

import static org.junit.Assert.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.powermock.api.mockito.PowerMockito.when;

@RunWith(PowerMockRunner.class)
@PrepareForTest({ MessageFormat.class })
public class MortgageAccountClosureEligibilityRestClientTest {

    @Value("${mortgage.account.closure.eligibility.endpoint}")
    private String mortgageAccountClosureEligibilityEndpoint;

    @Mock
    RestClientService restClientService;

    @Mock
    MortgageServiceUtil mortgageServiceUtil;

    @Autowired
    private ObjectMapper mapper;

    private MortgageAccountClosureHelper mortgageAccountClosureHelper = new MortgageAccountClosureHelper();

    @InjectMocks
    private MortgageAccountClosureEligibilityRestClient mortgageAccountClosureEligibilityRestClient;

    @Before
    public void setup() {
        this.mapper = new ObjectMapper();
    }

    @Test
    public void get_account_closure_eligibility_info_by_accoundId() throws JsonProcessingException, NoSuchFieldException, SecurityException {

        MortgageClosureEligibility accountClosureEligibilityInfo = mortgageAccountClosureHelper.buildMortgageClosureEligibilityInfo(true);
        FieldSetter.setField(mortgageAccountClosureEligibilityRestClient,
                mortgageAccountClosureEligibilityRestClient.getClass().getDeclaredField("mortgageAccountClosureEligibilityEndpoint"),
                "mortgageAccountClosureEligibilityEndpoint");

        String stringyfyResponse = mapper.writeValueAsString(accountClosureEligibilityInfo);
        when(mortgageServiceUtil.fetchDefaultVaultHeaders()).thenReturn(new HashMap<String, String>());
        when(mortgageServiceUtil.readObject(any(String.class), any(Class.class))).thenReturn(accountClosureEligibilityInfo);
        when(restClientService.get(any(String.class), any(HashMap.class))).thenReturn(stringyfyResponse);
        MortgageClosureEligibility response = mortgageAccountClosureEligibilityRestClient.getMortgageAccountClosureEligibilityInfo("1b69ad2f-63b3-c70f-6f52-ee85b97e314d", new HashMap<>());
        assertNotNull(response);
        assertEquals(true, response.isEligibleForClosure());
    }
}