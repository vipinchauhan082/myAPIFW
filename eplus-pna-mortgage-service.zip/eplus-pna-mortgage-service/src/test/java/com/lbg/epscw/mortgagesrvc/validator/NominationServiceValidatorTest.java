package com.lbg.epscw.mortgagesrvc.validator;

import com.lbg.epscw.mortgagesrvc.exception.InvalidUpdateRequestException;
import com.lbg.epscw.mortgagesrvc.helper.MortgageNominationHelper;
import com.lbg.epscw.mortgagesrvc.model.NominationRequest;
import com.lbg.epscw.mortgagesrvc.restclient.MortgageAccountInfoRestClient;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.HashMap;

import static org.mockito.ArgumentMatchers.any;
import static org.powermock.api.mockito.PowerMockito.when;

@RunWith(SpringRunner.class)
public class NominationServiceValidatorTest {

    @Mock
    private MortgageAccountInfoRestClient mortgageAccountInfoRestClient;

    @InjectMocks
    private NominationServiceValidator nominationServiceValidator;

    @Mock
    private NominationRequest nominationRequest;

    private final MortgageNominationHelper mortgageNominationHelper = new MortgageNominationHelper();

    @Test
    public void shouldValidateNominationRequest() {
        //when
        when(mortgageAccountInfoRestClient.getMortgageAccountInfo(any(String.class), any(HashMap.class))).thenReturn(mortgageNominationHelper.getMortgageAccountInfo());
        when(nominationRequest.getNominatedAdhocOverpaymentAccount()).thenReturn("1b69ad2f-63b3-c70f-6f52-ee85b97e314d");
        //given
        nominationServiceValidator.validateNominationRequest(nominationRequest, "f76ca840-2553-d536-1ab8-9fa85c99db05", new HashMap<>());
    }

    @Test(expected = InvalidUpdateRequestException.class)
    public void shouldThrowExceptionWhenSubAccountIsInPath() {
        //when
        when(mortgageAccountInfoRestClient.getMortgageAccountInfo(any(String.class), any(HashMap.class))).thenReturn(mortgageNominationHelper.getMortgageAccountInfo());
        when(nominationRequest.getNominatedAdhocOverpaymentAccount()).thenReturn("f76ca840-2553-d536-1ab8-9fa85c99db05");
        //given
        nominationServiceValidator.validateNominationRequest(nominationRequest, "1601d0e5-e336-64d9-64ad-89ba6fdc2677", new HashMap<>());
    }

    @Test(expected = InvalidUpdateRequestException.class)
    public void shouldThrowExceptionWhenSubAccountNotBelongsToRepaymentAccount() {
        //when
        when(mortgageAccountInfoRestClient.getMortgageAccountInfo(any(String.class), any(HashMap.class))).thenReturn(mortgageNominationHelper.getMortgageAccountInfo());
        when(nominationRequest.getNominatedAdhocOverpaymentAccount()).thenReturn("f76ca840-2553-d536-1ab8-9fa85c99db05");
        //given
        nominationServiceValidator.validateNominationRequest(nominationRequest, "90e804ab-5dad-7f7c-1d71-ab914545ebcc", new HashMap<>());
    }

    @Test(expected = InvalidUpdateRequestException.class)
    public void shouldThrowExceptionWhenRepaymentAccountIsSentInRequest() {
        //when
        when(mortgageAccountInfoRestClient.getMortgageAccountInfo(any(String.class), any(HashMap.class))).thenReturn(mortgageNominationHelper.getMortgageAccountInfo());
        when(nominationRequest.getNominatedAdhocOverpaymentAccount()).thenReturn("f76ca840-2553-d536-1ab8-9fa85c99db05");
        //given
        nominationServiceValidator.validateNominationRequest(nominationRequest, "f76ca840-2553-d536-1ab8-9fa85c99db05", new HashMap<>());
    }

}