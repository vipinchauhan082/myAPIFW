package com.lbg.epscw.mortgagesrvc.controller;


import com.lbg.epscw.mortgagesrvc.enums.MortgageOptionInstructionEnum;
import com.lbg.epscw.mortgagesrvc.enums.RepaymentType;
import com.lbg.epscw.mortgagesrvc.exception.MortgageServiceException;
import com.lbg.epscw.mortgagesrvc.helper.MortgageAccountOptionDataHelper;
import com.lbg.epscw.mortgagesrvc.model.AccountOptionsUpdateRequest;
import com.lbg.epscw.mortgagesrvc.model.Channel;
import com.lbg.epscw.mortgagesrvc.model.MortgageOptionsUpdateResponse;
import com.lbg.epscw.mortgagesrvc.service.MortgageAccountOptionsUpdateService;
import com.lbg.epscw.mortgagesrvc.util.MortgageServiceUtil;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.HashMap;
import java.util.Map;

import static org.junit.Assert.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.powermock.api.mockito.PowerMockito.when;

@RunWith(SpringRunner.class)
@WebMvcTest(controllers = { MortgageServiceUtil.class, MortgageAccountOptionsUpdateController.class })
public class MortgageAccountOptionsUpdateControllerTest {

    @MockBean
    private MortgageAccountOptionsUpdateService mortgageAccountOptionService;

    private MortgageAccountOptionDataHelper mortgageAccountDataHelper = new MortgageAccountOptionDataHelper();


    @Autowired
    private MortgageAccountOptionsUpdateController mortgageAccountOptionsUpdateController;

    @Test
    public void update_mortgage_term_successful() {
        when(mortgageAccountOptionService.updateAccountOptions(any(AccountOptionsUpdateRequest.class), any(String.class), any(Map.class)))
                .thenReturn(mortgageAccountDataHelper.buildMortgageOptionsUpdateResponse("TotalTerm", "15"));

        //when
        ResponseEntity<MortgageOptionsUpdateResponse> responseEntity = mortgageAccountOptionsUpdateController
                .updateMortgageAccountOptions("IF", Channel.DIGITAL.name(), "123-456-789-12", "Bearer 122", "ALL", new HashMap<String, String>(),
                        mortgageAccountDataHelper.buildAccountOptionsUpdateRequestForMortgageTerm(MortgageOptionInstructionEnum.MortgageTermExtend, "15"),"1601d0e5-e336-64d9-64ad-89ba6fdc2677");
        MortgageOptionsUpdateResponse accountOptionsUpdateResponse = responseEntity.getBody();

        //then
        assertEquals("15", accountOptionsUpdateResponse.getInstanceParamVals().get("TotalTerm"));
    }

    @Test
    public void update_mortgage_type_successful() {
        when(mortgageAccountOptionService.updateAccountOptions(any(AccountOptionsUpdateRequest.class),any(String.class), any(Map.class)))
                .thenReturn(mortgageAccountDataHelper.buildMortgageOptionsUpdateResponse("RepaymentType", RepaymentType.INTEREST_ONLY.name()));

        //when
        ResponseEntity<MortgageOptionsUpdateResponse> responseEntity = mortgageAccountOptionsUpdateController
                .updateMortgageAccountOptions("IF", Channel.DIGITAL.name(),"123-456-789-12", "Bearer 122", "ALL", new HashMap<String, String>(),
                        mortgageAccountDataHelper.buildAccountOptionsUpdateRequestForMortgageType( RepaymentType.INTEREST_ONLY.name()),"1601d0e5-e336-64d9-64ad-89ba6fdc2677");
        MortgageOptionsUpdateResponse accountOptionsUpdateResponse = responseEntity.getBody();

        //then
        assertEquals("INTEREST_ONLY", accountOptionsUpdateResponse.getInstanceParamVals().get("RepaymentType"));
    }

    @Test
    public void update_account_options_successful() {
        when(mortgageAccountOptionService.updateAccountOptions(any(AccountOptionsUpdateRequest.class),any(String.class), any(Map.class)))
                .thenReturn(mortgageAccountDataHelper.buildMortgageOptionsUpdateResponse());

        //when
        ResponseEntity<MortgageOptionsUpdateResponse> responseEntity = mortgageAccountOptionsUpdateController
                .updateMortgageAccountOptions("IF", Channel.DIGITAL.name(),"123-456-789-12", "Bearer 122", "ALL", new HashMap<String, String>(),
                        mortgageAccountDataHelper.buildAccountOptionsUpdateRequest(),"1601d0e5-e336-64d9-64ad-89ba6fdc2677");
        MortgageOptionsUpdateResponse accountOptionsUpdateResponse = responseEntity.getBody();

        //then
        assertEquals("CAPITAL_REPAYMENT", accountOptionsUpdateResponse.getInstanceParamVals().get("RepaymentType"));
        assertEquals("8", accountOptionsUpdateResponse.getInstanceParamVals().get("TotalTerm"));
    }


    @Test(expected = MortgageServiceException.class)
    public void update_mortgage_option_fails_when_service_layer_fails() {

        when(mortgageAccountOptionService.updateAccountOptions(any(AccountOptionsUpdateRequest.class), any(String.class), any(Map.class))).thenReturn(null);

        //when
        mortgageAccountOptionsUpdateController.updateMortgageAccountOptions("IF", Channel.DIGITAL.name(),"123-456-789-12", null, "ALL", new HashMap<String, String>(),
                mortgageAccountDataHelper.buildAccountOptionsUpdateRequestForMortgageType( RepaymentType.INTEREST_ONLY.name()), "1601d0e5-e336-64d9-64ad-89ba6fdc2677");

    }
}
