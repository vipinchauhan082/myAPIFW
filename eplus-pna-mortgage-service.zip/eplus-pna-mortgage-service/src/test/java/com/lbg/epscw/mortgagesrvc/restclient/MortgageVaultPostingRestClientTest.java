package com.lbg.epscw.mortgagesrvc.restclient;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.lbg.epscw.mortgagesrvc.dto.PostingsInstructionsBatch;
import com.lbg.epscw.mortgagesrvc.dto.VaultPostingsInstructionsBatchRequest;
import com.lbg.epscw.mortgagesrvc.dto.VaultPostingsInstructionsBatchResponse;
import com.lbg.epscw.mortgagesrvc.helper.ComponentHelper;
import com.lbg.epscw.mortgagesrvc.helper.MortgageAccountOptionDataHelper;
import com.lbg.epscw.mortgagesrvc.helper.MortgageArrearsCapitalizeHelper;
import com.lbg.epscw.mortgagesrvc.model.VaultAccountOptionsUpdateRequest;
import com.lbg.epscw.mortgagesrvc.service.RestClientService;
import com.lbg.epscw.mortgagesrvc.util.MortgageServiceUtil;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.internal.util.reflection.FieldSetter;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;

import java.text.MessageFormat;
import java.util.HashMap;

import static org.junit.Assert.*;
import static org.mockito.ArgumentMatchers.any;
import static org.powermock.api.mockito.PowerMockito.when;

@RunWith(PowerMockRunner.class)
@PrepareForTest({ MessageFormat.class })
public class MortgageVaultPostingRestClientTest {

    @Mock
    private RestClientService restClientService;

    @Mock
    private MortgageServiceUtil mortgageServiceUtil;

    @Value("vaultPostingsEndpoint")
    private String vaultPostingsEndpoint;

    @Autowired
    private ObjectMapper mapper;

    private MortgageArrearsCapitalizeHelper mortgageArrearsCapitalizeHelper = new MortgageArrearsCapitalizeHelper();

    @InjectMocks
    private MortgageVaultPostingRestClient mortgageVaultPostingRestClient;

    @Before
    public void setup() {
        this.mapper = new ObjectMapper();
    }

    @Test
    public void postingInstructionBatch() throws JsonProcessingException, NoSuchFieldException {
        //given
        VaultPostingsInstructionsBatchRequest vaultPostingsInstructionsBatchRequest = VaultPostingsInstructionsBatchRequest.builder()
                .postingsInstructionsBatch(PostingsInstructionsBatch.builder().clientBatchId("123").build()).build();

        String stringyfyResponse = null;

        FieldSetter.setField(mortgageVaultPostingRestClient,
                mortgageVaultPostingRestClient.getClass().getDeclaredField("vaultPostingsEndpoint"),"");


        VaultPostingsInstructionsBatchResponse vaultPostingsInstructionsBatchResponse = mortgageArrearsCapitalizeHelper.buildPostingInstructionBatchVaultResponse();
        stringyfyResponse = mapper.writeValueAsString(vaultPostingsInstructionsBatchResponse);
        when(mortgageServiceUtil.fetchDefaultVaultHeaders()).thenReturn(new HashMap<String, String>());
        when(mortgageServiceUtil.writeObjectAsString(any(VaultPostingsInstructionsBatchRequest.class)))
                .thenReturn(stringyfyResponse);

        when(mortgageServiceUtil.readObject(any(String.class), any(Class.class)))
                .thenReturn(vaultPostingsInstructionsBatchResponse);

        when(restClientService.post(any(String.class), any(HashMap.class), any(String.class)))
                .thenReturn(stringyfyResponse);

        //when
        VaultPostingsInstructionsBatchResponse postingResponse = mortgageVaultPostingRestClient.postingsInstructionsBatch(vaultPostingsInstructionsBatchRequest);

        //then
        assertEquals("123",postingResponse.getId());
        assertEquals("2020-12-01",postingResponse.getCreateEventTimestamp());
    }

}