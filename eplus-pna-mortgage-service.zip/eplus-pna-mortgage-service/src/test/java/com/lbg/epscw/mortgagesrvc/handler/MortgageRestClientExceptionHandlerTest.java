package com.lbg.epscw.mortgagesrvc.handler;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.lbg.epscw.handler.exception.RestServiceException;
import org.junit.Test;

import static org.junit.jupiter.api.Assertions.assertAll;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.springframework.http.HttpStatus.BAD_REQUEST;
import static org.springframework.http.HttpStatus.FORBIDDEN;
import static org.springframework.http.HttpStatus.INTERNAL_SERVER_ERROR;
import static org.springframework.http.HttpStatus.NOT_FOUND;
import static org.springframework.http.HttpStatus.UNAUTHORIZED;
import static org.springframework.http.HttpStatus.SERVICE_UNAVAILABLE;

public class MortgageRestClientExceptionHandlerTest {

    private MortgageRestClientExceptionHandler handler = new MortgageRestClientExceptionHandler(new ObjectMapper());

    @Test
    public void shouldThrowExceptionForBadRequest() {
        RestServiceException exception = assertThrows(RestServiceException.class,
                () -> handler.throwServiceSpecificException(BAD_REQUEST, ".Bad.Request", "Invalid request"));
        assertAll(
                () -> assertEquals(".Bad.Request", exception.getReasonCodeSuffix()),
                () -> assertEquals("Invalid request", exception.getMessage()),
                () -> assertEquals(BAD_REQUEST, exception.getHttpStatus())
        );
    }

    @Test
    public void shouldThrowExceptionForUnauthorized() {
        RestServiceException exception = assertThrows(RestServiceException.class,
                () -> handler.throwServiceSpecificException(UNAUTHORIZED, ".Generic.Error", "No authentication token provided"));
        assertAll(
                () -> assertEquals(".Generic.Error", exception.getReasonCodeSuffix()),
                () -> assertEquals("No authentication token provided", exception.getMessage()),
                () -> assertEquals(UNAUTHORIZED, exception.getHttpStatus())
        );
    }

    @Test
    public void shouldThrowExceptionForForbidden() {
        RestServiceException exception = assertThrows(RestServiceException.class,
                () -> handler.throwServiceSpecificException(FORBIDDEN, ".Access.Forbidden", "Access denied"));
        assertAll(
                () -> assertEquals(".Access.Forbidden", exception.getReasonCodeSuffix()),
                () -> assertEquals("Access denied", exception.getMessage()),
                () ->assertEquals(FORBIDDEN, exception.getHttpStatus())
        );
    }

    @Test
    public void shouldThrowExceptionForNotFound() {
        RestServiceException exception = assertThrows(RestServiceException.class,
                () -> handler.throwServiceSpecificException(NOT_FOUND, ".Account.NotFound", "Resource not found"));
        assertAll(
                () -> assertEquals(".Account.NotFound", exception.getReasonCodeSuffix()),
                () -> assertEquals("Resource not found", exception.getMessage()),
                () -> assertEquals(NOT_FOUND, exception.getHttpStatus())
        );
    }

    @Test
    public void shouldThrowExceptionForInternalServerError() {
        RestServiceException exception = assertThrows(RestServiceException.class,
                () -> handler.throwServiceSpecificException(INTERNAL_SERVER_ERROR, ".Server.Error", "Internal Server Error"));
        assertAll(
                () -> assertEquals(".Server.Error", exception.getReasonCodeSuffix()),
                () -> assertEquals("Internal Server Error", exception.getMessage()),
                () -> assertEquals(INTERNAL_SERVER_ERROR, exception.getHttpStatus())
        );
    }


    @Test
    public void shouldThrowExceptionForServiceUnavailable() {
        RestServiceException exception = assertThrows(RestServiceException.class,
                () -> handler.throwServiceSpecificException(SERVICE_UNAVAILABLE, ".Account.NotFound", "Service Unavailable"));
        assertAll(
                () -> assertEquals(".Account.NotFound", exception.getReasonCodeSuffix()),
                () -> assertEquals("Service Unavailable", exception.getMessage()),
                () -> assertEquals(SERVICE_UNAVAILABLE, exception.getHttpStatus())
        );
    }
}
