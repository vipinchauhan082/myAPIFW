package com.lbg.epscw.mortgagesrvc.controller;

import com.lbg.epscw.mortgagesrvc.exception.MortgageServiceException;
import com.lbg.epscw.mortgagesrvc.exception.MortgageValidationException;
import com.lbg.epscw.mortgagesrvc.model.CreditDecisionRequest;
import com.lbg.epscw.mortgagesrvc.model.PortingApplicationStatusResponse;
import com.lbg.epscw.mortgagesrvc.service.MortgagePortingApplicationInfoService;
import com.lbg.epscw.mortgagesrvc.service.MortgagePortingCreditDecisionService;
import com.lbg.epscw.mortgagesrvc.util.MortgageServiceUtil;
import com.lbg.epscw.mortgagesrvc.validator.MortgagePortingApplicationValidator;
import org.junit.Before;
import org.junit.Test;
import org.springframework.http.ResponseEntity;

import static com.lbg.epscw.mortgagesrvc.helper.MortgagePortingHelper.*;
import static com.lbg.epscw.mortgagesrvc.model.MortgagePortingApplicationStatus.APPROVED;
import static com.lbg.epscw.mortgagesrvc.model.MortgagePortingApplicationStatus.OPEN;
import static io.opencensus.trace.Tracing.getTracer;
import static io.opencensus.trace.samplers.Samplers.alwaysSample;
import static java.util.Collections.emptyMap;
import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;
import static org.springframework.http.ResponseEntity.ok;

public class MortgagePortingCreditDecisionControllerTest {
    private MortgagePortingApplicationValidator validator;
    private MortgagePortingCreditDecisionService service;

    private MortgagePortingCreditDecisionController underTest;

    @Before
    public void setup() {
        validator = mock(MortgagePortingApplicationValidator.class);
        MortgageServiceUtil utility = mock(MortgageServiceUtil.class);
        when(utility.buildSpan(anyString())).thenReturn(getTracer().spanBuilder("any").setSampler(alwaysSample()));
        service = mock(MortgagePortingCreditDecisionService.class);
        MortgagePortingApplicationInfoService infoService = mock(MortgagePortingApplicationInfoService.class);
        underTest = new MortgagePortingCreditDecisionController(validator, infoService, service, utility);
    }

    @Test
    public void verify_action_permitted() {
        //given
        PortingApplicationStatusResponse expected = PortingApplicationStatusResponse.builder().applicationNumber(APPLICATION_NUMBER).status(APPROVED).build();
        when(service.updateCreditDecision(any(), any(), anyMap())).thenReturn(expected);
        //when
        CreditDecisionRequest request = CreditDecisionRequest.builder().action(APPROVED.name()).notes("Notes").build();
        ResponseEntity<PortingApplicationStatusResponse> response = underTest.creditDecision(BRAND, CHANNEL, CORRELATION_ID, JWT, INTERNAL_SYS_ID, emptyMap(), ACCOUNT_ID, request);
        //then
        assertThat(response, is(ok(expected)));
    }

    @Test(expected = MortgageValidationException.class)
    public void verify_action_not_permitted() {
        //given
        doThrow(MortgageValidationException.class).when(validator).validateNextState(any(), any());
        //when
        CreditDecisionRequest request = CreditDecisionRequest.builder().action(OPEN.name()).notes("Notes").build();
        underTest.creditDecision(BRAND, CHANNEL, CORRELATION_ID, JWT, INTERNAL_SYS_ID, emptyMap(), ACCOUNT_ID, request);
        //then expect exception
    }

    @Test(expected = MortgageServiceException.class)
    public void service_fails_to_update_application() {
        //given
        doThrow(MortgageServiceException.class).when(service).updateCreditDecision(any(), any(), anyMap());
        //when
        CreditDecisionRequest request = CreditDecisionRequest.builder().action(OPEN.name()).notes("Notes").build();
        underTest.creditDecision(BRAND, CHANNEL, CORRELATION_ID, JWT, INTERNAL_SYS_ID, emptyMap(), ACCOUNT_ID, request);
        //then expect exception
    }
}