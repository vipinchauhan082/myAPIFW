package com.lbg.epscw.mortgagesrvc.component;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.lbg.epscw.entitlement.service.EntitlementValidationServiceImpl;
import com.lbg.epscw.handler.constants.SystemErrors;
import com.lbg.epscw.handler.exception.RestServiceException;
import com.lbg.epscw.handler.model.ErrorInfo;
import com.lbg.epscw.handler.model.ErrorResponse;
import com.lbg.epscw.mortgagesrvc.constants.CommonConstants;
import com.lbg.epscw.mortgagesrvc.enums.MortgageOptionInstructionEnum;
import com.lbg.epscw.mortgagesrvc.enums.RepaymentType;
import com.lbg.epscw.mortgagesrvc.helper.ComponentHelper;
import com.lbg.epscw.mortgagesrvc.helper.MortgageAccountDataHelper;
import com.lbg.epscw.mortgagesrvc.helper.MortgageAccountOptionDataHelper;
import com.lbg.epscw.mortgagesrvc.logger.HystrixContextCopyStrategy;
import com.lbg.epscw.mortgagesrvc.model.AccountOptionsUpdateRequest;
import com.lbg.epscw.mortgagesrvc.model.MortgageOptionsUpdateResponse;
import com.lbg.epscw.mortgagesrvc.model.VaultAccountOptionsUpdateRequest;
import com.lbg.epscw.mortgagesrvc.restclient.MortgageAccountInfoRestClient;
import com.lbg.epscw.mortgagesrvc.restclient.MortgageAccountOptionRestClient;
import com.lbg.epscw.mortgagesrvc.service.RestClientService;
import org.apache.commons.lang.RandomStringUtils;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mockito;
import org.mockito.internal.util.MockUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.context.ApplicationContext;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import java.util.HashMap;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertAll;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.powermock.api.mockito.PowerMockito.when;

@Tag("component")
@ExtendWith(SpringExtension.class)
@SpringBootTest
@AutoConfigureMockMvc
public class UpdateMortgageOptionsComponentTest extends WebMVCTest {

    private static final String UPDATE_ACCOUNT_OPTIONS =
        "/mortgages/1601d0e5-e336-64d9-64ad-89ba6fdc2677/repayment-schedule";

    private MortgageAccountOptionDataHelper accountOptionHelper = new MortgageAccountOptionDataHelper();
    
    private MortgageAccountDataHelper accountHelper = new MortgageAccountDataHelper();
    
    private ComponentHelper componentHelper;

    @MockBean
    private MortgageAccountOptionRestClient mortgageAccountOptionRestClient;
    
    @MockBean
    private MortgageAccountInfoRestClient mortgageAccountInfoRestClient;
    
    @MockBean
    private EntitlementValidationServiceImpl entitlementValidationService;
    
    @Value("vault.access.token")
    private String vaultAccessToken;

    @Value("workflow.username")
    private String workFlowUserName;

    @Value("workflow.password")
    private String workflowPassword;

    @MockBean
    RestClientService restClientService;

    @Autowired
    private ApplicationContext context;
    
    
    @MockBean
    private HystrixContextCopyStrategy hystrixContextCopyStrategy;


    @BeforeEach
    public void beforeEach() {
    	componentHelper = new ComponentHelper();
        for (String name : context.getBeanDefinitionNames()) {
            Object bean = context.getBean(name);
            if (MockUtil.isMock(bean)) {
                Mockito.reset(bean);
            }
        }
    }

    @Test
    public void shouldAmendMortgageType() throws NoSuchFieldException, SecurityException, JsonProcessingException {
    	
    	AccountOptionsUpdateRequest req = accountOptionHelper.buildAccountOptionsUpdateRequestForMortgageType(RepaymentType.CAPITAL_REPAYMENT.name());

    	when(mortgageAccountInfoRestClient.getMortgageAccountInfo(any(String.class), any(HashMap.class))).thenReturn(accountHelper.buildViewAccountInfo());

    	when(mortgageAccountOptionRestClient.updateAccountOptions(any(VaultAccountOptionsUpdateRequest.class)))
        .thenReturn(accountOptionHelper.buildAccountOptionsUpdateResponse(CommonConstants.KEY_MORTGAGE_TYPE, RepaymentType.CAPITAL_REPAYMENT.name()));
        
        //given
        String payload = componentHelper.writeValueAsString(req);
        // when
        MockHttpServletResponse servletResponse = doPUT(UPDATE_ACCOUNT_OPTIONS, payload, accountOptionHelper.getAccountInfoHeaders());
        String responseString = componentHelper.getServletResponseAsString(servletResponse);
        MortgageOptionsUpdateResponse viewAccountOptions = (MortgageOptionsUpdateResponse) readObject(responseString, MortgageOptionsUpdateResponse.class);
        Map<String, String> accountOptions = viewAccountOptions.getInstanceParamVals();

        //then
        assertEquals("1601d0e5-e336-64d9-64ad-89ba6fdc2677", viewAccountOptions.getAccountId());
        assertEquals("ACCOUNT_UPDATE_STATUS_PENDING_EXECUTION", viewAccountOptions.getStatus());
        assertEquals(RepaymentType.CAPITAL_REPAYMENT.name(), accountOptions.get(MortgageOptionInstructionEnum.RepaymentType.name()));
    }
    
    @Test
    public void shouldExtendMortgageTerm() throws NoSuchFieldException, SecurityException {
    	
    	when(mortgageAccountInfoRestClient.getMortgageAccountInfo(any(String.class), any(HashMap.class))).thenReturn(accountHelper.buildViewAccountInfo());
    	AccountOptionsUpdateRequest req = 
    			accountOptionHelper.buildAccountOptionsUpdateRequestForMortgageTerm(MortgageOptionInstructionEnum.MortgageTermExtend, "15");
    	
        when(mortgageAccountOptionRestClient.updateAccountOptions(any(VaultAccountOptionsUpdateRequest.class)))
        .thenReturn(accountOptionHelper.buildAccountOptionsUpdateResponse(CommonConstants.KEY_MORTGAGE_TERM, "15"));
        
        //given
        String payload = componentHelper.writeValueAsString(req);
        // when
        MockHttpServletResponse servletResponse = doPUT(UPDATE_ACCOUNT_OPTIONS, payload, accountOptionHelper.getAccountInfoHeaders());
        String responseString = componentHelper.getServletResponseAsString(servletResponse);
        MortgageOptionsUpdateResponse viewAccountOptions = (MortgageOptionsUpdateResponse) readObject(responseString, MortgageOptionsUpdateResponse.class);
        Map<String, String> accountOptions = viewAccountOptions.getInstanceParamVals();

        //then
        assertEquals("1601d0e5-e336-64d9-64ad-89ba6fdc2677", viewAccountOptions.getAccountId());
        assertEquals("ACCOUNT_UPDATE_STATUS_PENDING_EXECUTION", viewAccountOptions.getStatus());
        assertEquals("15", accountOptions.get(CommonConstants.KEY_TOTAL_TERM));
    }
    
    @Test
    public void shouldReduceMortgageTerm() throws NoSuchFieldException, SecurityException {
    	
    	when(mortgageAccountInfoRestClient.getMortgageAccountInfo(any(String.class), any(HashMap.class))).thenReturn(accountHelper.buildViewAccountInfo());
    	AccountOptionsUpdateRequest req = 
    			accountOptionHelper.buildAccountOptionsUpdateRequestForMortgageTerm(MortgageOptionInstructionEnum.MortgageTermReduce, "12");
    	
        when(mortgageAccountOptionRestClient.updateAccountOptions(any(VaultAccountOptionsUpdateRequest.class)))
        .thenReturn(accountOptionHelper.buildAccountOptionsUpdateResponse(CommonConstants.KEY_MORTGAGE_TERM, "12"));
        
        //given
        String payload = componentHelper.writeValueAsString(req);
        // when
        MockHttpServletResponse servletResponse = doPUT(UPDATE_ACCOUNT_OPTIONS, payload, accountOptionHelper.getAccountInfoHeaders());
        String responseString = componentHelper.getServletResponseAsString(servletResponse);
        MortgageOptionsUpdateResponse viewAccountOptions = (MortgageOptionsUpdateResponse) readObject(responseString, MortgageOptionsUpdateResponse.class);
        Map<String, String> accountOptions = viewAccountOptions.getInstanceParamVals();

        //then
        assertEquals("1601d0e5-e336-64d9-64ad-89ba6fdc2677", viewAccountOptions.getAccountId());
        assertEquals("ACCOUNT_UPDATE_STATUS_PENDING_EXECUTION", viewAccountOptions.getStatus());
        assertEquals("12", accountOptions.get(CommonConstants.KEY_TOTAL_TERM));
    }
    
    
    @Test
    public void shouldNotUpdateMortgageTypeIfCurrentValueSameAsRequested() {
        //given
        when(mortgageAccountInfoRestClient.getMortgageAccountInfo(any(String.class), any(HashMap.class))).thenReturn(accountHelper.buildViewAccountInfo());
        
        when(mortgageAccountOptionRestClient.updateAccountOptions(any(VaultAccountOptionsUpdateRequest.class)))
        .thenReturn(accountOptionHelper.buildAccountOptionsUpdateResponse(CommonConstants.KEY_MORTGAGE_TYPE, RepaymentType.INTEREST_ONLY.name()));

        AccountOptionsUpdateRequest req = accountOptionHelper.buildAccountOptionsUpdateRequestForMortgageType(RepaymentType.INTEREST_ONLY.name());
        String payload = componentHelper.writeValueAsString(req);

        //when
        MockHttpServletResponse servletResponse = doPUT(UPDATE_ACCOUNT_OPTIONS, payload, accountOptionHelper.getAccountInfoHeaders());
        String responseString = componentHelper.getServletResponseAsString(servletResponse);
        MortgageOptionsUpdateResponse viewAccountOptions = (MortgageOptionsUpdateResponse) readObject(responseString, MortgageOptionsUpdateResponse.class);
        
        ErrorResponse errorResponse = (ErrorResponse) readObject(responseString, ErrorResponse.class);
        ErrorInfo errorInfo = errorResponse.getErrors().get(0);

        //then
        assertAll(
                () -> assertEquals(400, servletResponse.getStatus()),
                () -> assertEquals("PNA.MORTGAGE_API.BUS.601", errorResponse.getCode()),
                () -> assertEquals("Invalid Update Request", errorResponse.getMessage()),
                () -> assertEquals("PNA.MORTGAGE_API.PUT_MORTGAGES_REPAYMENT_SCHEDULE.RepaymentScheduleParams.Invalid", errorInfo.getReasonCode()),
                () -> assertEquals("Invalid value provided for amend repayment param: RepaymentType", errorInfo.getMessage())
        );
    }
    
    @Test
    public void shouldNotExtendMortgageTermIfRequestedValueIsZero() throws NoSuchFieldException, SecurityException {
    	
    	when(mortgageAccountInfoRestClient.getMortgageAccountInfo(any(String.class), any(HashMap.class))).thenReturn(accountHelper.buildViewAccountInfo());
    	AccountOptionsUpdateRequest req = 
    			accountOptionHelper.buildAccountOptionsUpdateRequestForMortgageTerm(MortgageOptionInstructionEnum.MortgageTermExtend, "0");
    	
        when(mortgageAccountOptionRestClient.updateAccountOptions(any(VaultAccountOptionsUpdateRequest.class)))
        .thenReturn(accountOptionHelper.buildAccountOptionsUpdateResponse(CommonConstants.KEY_MORTGAGE_TERM, "0"));
        
        //given
        String payload = componentHelper.writeValueAsString(req);
        // when
        MockHttpServletResponse servletResponse = doPUT(UPDATE_ACCOUNT_OPTIONS, payload, accountOptionHelper.getAccountInfoHeaders());
        String responseString = componentHelper.getServletResponseAsString(servletResponse);
        MortgageOptionsUpdateResponse viewAccountOptions = (MortgageOptionsUpdateResponse) readObject(responseString, MortgageOptionsUpdateResponse.class);
        
        ErrorResponse errorResponse = (ErrorResponse) readObject(responseString, ErrorResponse.class);
        ErrorInfo errorInfo = errorResponse.getErrors().get(0);

        //then
        assertAll(
                () -> assertEquals(400, servletResponse.getStatus()),
                () -> assertEquals("PNA.MORTGAGE_API.BUS.601", errorResponse.getCode()),
                () -> assertEquals("Invalid Update Request", errorResponse.getMessage()),
                () -> assertEquals("PNA.MORTGAGE_API.PUT_MORTGAGES_REPAYMENT_SCHEDULE.RepaymentScheduleParams.Invalid", errorInfo.getReasonCode()),
                () -> assertEquals("Invalid value provided for amend repayment param: MortgageTermExtend", errorInfo.getMessage())
        );
    }
    
    @Test
    public void shouldNotReduceMortgageTermIfRequestedValueIsZero() throws NoSuchFieldException, SecurityException {
    	
    	when(mortgageAccountInfoRestClient.getMortgageAccountInfo(any(String.class), any(HashMap.class))).thenReturn(accountHelper.buildViewAccountInfo());
    	AccountOptionsUpdateRequest req = 
    			accountOptionHelper.buildAccountOptionsUpdateRequestForMortgageTerm(MortgageOptionInstructionEnum.MortgageTermReduce, "0");
    	
        when(mortgageAccountOptionRestClient.updateAccountOptions(any(VaultAccountOptionsUpdateRequest.class)))
        .thenReturn(accountOptionHelper.buildAccountOptionsUpdateResponse(CommonConstants.KEY_MORTGAGE_TERM, "0"));
        
        //given
        String payload = componentHelper.writeValueAsString(req);
        // when
        MockHttpServletResponse servletResponse = doPUT(UPDATE_ACCOUNT_OPTIONS, payload, accountOptionHelper.getAccountInfoHeaders());
        String responseString = componentHelper.getServletResponseAsString(servletResponse);
        MortgageOptionsUpdateResponse viewAccountOptions = (MortgageOptionsUpdateResponse) readObject(responseString, MortgageOptionsUpdateResponse.class);
        
        ErrorResponse errorResponse = (ErrorResponse) readObject(responseString, ErrorResponse.class);
        ErrorInfo errorInfo = errorResponse.getErrors().get(0);

        //then
        assertAll(
                () -> assertEquals(400, servletResponse.getStatus()),
                () -> assertEquals("PNA.MORTGAGE_API.BUS.601", errorResponse.getCode()),
                () -> assertEquals("Invalid Update Request", errorResponse.getMessage()),
                () -> assertEquals("PNA.MORTGAGE_API.PUT_MORTGAGES_REPAYMENT_SCHEDULE.RepaymentScheduleParams.Invalid", errorInfo.getReasonCode()),
                () -> assertEquals("Invalid value provided for amend repayment param: MortgageTermReduce", errorInfo.getMessage())
        );
    }
    
    @Test
    public void shouldNotReduceMortgageTermIfRequestedValueIsMoreThanCurrent() throws NoSuchFieldException, SecurityException {
    	
    	when(mortgageAccountInfoRestClient.getMortgageAccountInfo(any(String.class), any(HashMap.class))).thenReturn(accountHelper.buildViewAccountInfo());
    	AccountOptionsUpdateRequest req = 
    			accountOptionHelper.buildAccountOptionsUpdateRequestForMortgageTerm(MortgageOptionInstructionEnum.MortgageTermReduce, "18");
    	
        when(mortgageAccountOptionRestClient.updateAccountOptions(any(VaultAccountOptionsUpdateRequest.class)))
        .thenReturn(accountOptionHelper.buildAccountOptionsUpdateResponse(CommonConstants.KEY_MORTGAGE_TERM, "18"));
        
        //given
        String payload = componentHelper.writeValueAsString(req);
        // when
        MockHttpServletResponse servletResponse = doPUT(UPDATE_ACCOUNT_OPTIONS, payload, accountOptionHelper.getAccountInfoHeaders());
        String responseString = componentHelper.getServletResponseAsString(servletResponse);
        MortgageOptionsUpdateResponse viewAccountOptions = (MortgageOptionsUpdateResponse) readObject(responseString, MortgageOptionsUpdateResponse.class);
        
        ErrorResponse errorResponse = (ErrorResponse) readObject(responseString, ErrorResponse.class);
        ErrorInfo errorInfo = errorResponse.getErrors().get(0);

        //then
        assertAll(
                () -> assertEquals(400, servletResponse.getStatus()),
                () -> assertEquals("PNA.MORTGAGE_API.BUS.601", errorResponse.getCode()),
                () -> assertEquals("Invalid Update Request", errorResponse.getMessage()),
                () -> assertEquals("PNA.MORTGAGE_API.PUT_MORTGAGES_REPAYMENT_SCHEDULE.RepaymentScheduleParams.Invalid", errorInfo.getReasonCode()),
                () -> assertEquals("Invalid value provided for amend repayment param: MortgageTermReduce", errorInfo.getMessage())
        );
    }
    
    @Test
    public void shouldNotUpdateMortgageOptionIfRequestedValueEmpty() throws NoSuchFieldException, SecurityException {
    	
    	when(mortgageAccountInfoRestClient.getMortgageAccountInfo(any(String.class), any(HashMap.class))).thenReturn(accountHelper.buildViewAccountInfo());
    	AccountOptionsUpdateRequest req = 
    			accountOptionHelper.buildAccountOptionsUpdateRequestForMortgageTerm(MortgageOptionInstructionEnum.MortgageTermReduce, "");
    	
        when(mortgageAccountOptionRestClient.updateAccountOptions(any(VaultAccountOptionsUpdateRequest.class)))
        .thenReturn(accountOptionHelper.buildAccountOptionsUpdateResponse(CommonConstants.KEY_MORTGAGE_TERM, ""));
        
        //given
        String payload = componentHelper.writeValueAsString(req);
        // when
        MockHttpServletResponse servletResponse = doPUT(UPDATE_ACCOUNT_OPTIONS, payload, accountOptionHelper.getAccountInfoHeaders());
        String responseString = componentHelper.getServletResponseAsString(servletResponse);
        MortgageOptionsUpdateResponse viewAccountOptions = (MortgageOptionsUpdateResponse) readObject(responseString, MortgageOptionsUpdateResponse.class);
        
        ErrorResponse errorResponse = (ErrorResponse) readObject(responseString, ErrorResponse.class);
        ErrorInfo errorInfo = errorResponse.getErrors().get(0);
        //then
        assertAll(
                () -> assertEquals(400, servletResponse.getStatus()),
                () -> assertEquals("PNA.MORTGAGE_API.SYS.001", errorResponse.getCode()),
                () -> assertEquals("Bad Request", errorResponse.getMessage()),
                () -> assertEquals("PNA.MORTGAGE_API.PUT_MORTGAGES_REPAYMENT_SCHEDULE.Argument.Invalid", errorInfo.getReasonCode()),
                () -> assertEquals("RepaymentScheduleParamVals[MortgageTermReduce] must not be empty", errorInfo.getMessage())
        );
    }
    
    @Test
    public void shouldNotUpdateMortgageOptionIfRequestedValueNull() throws NoSuchFieldException, SecurityException {
    	
    	when(mortgageAccountInfoRestClient.getMortgageAccountInfo(any(String.class), any(HashMap.class))).thenReturn(accountHelper.buildViewAccountInfo());
    	AccountOptionsUpdateRequest req = 
    			accountOptionHelper.buildAccountOptionsUpdateRequestForMortgageTerm(MortgageOptionInstructionEnum.MortgageTermReduce, null);
    	
        when(mortgageAccountOptionRestClient.updateAccountOptions(any(VaultAccountOptionsUpdateRequest.class)))
        .thenReturn(accountOptionHelper.buildAccountOptionsUpdateResponse(CommonConstants.KEY_MORTGAGE_TERM, null));
        
        //given
        String payload = componentHelper.writeValueAsString(req);
        // when
        MockHttpServletResponse servletResponse = doPUT(UPDATE_ACCOUNT_OPTIONS, payload, accountOptionHelper.getAccountInfoHeaders());
        String responseString = componentHelper.getServletResponseAsString(servletResponse);
        MortgageOptionsUpdateResponse viewAccountOptions = (MortgageOptionsUpdateResponse) readObject(responseString, MortgageOptionsUpdateResponse.class);
        ErrorResponse errorResponse = (ErrorResponse) readObject(responseString, ErrorResponse.class);
        ErrorInfo errorInfo = errorResponse.getErrors().get(0);

        //then
        assertAll(
                () -> assertEquals(400, servletResponse.getStatus()),
                () -> assertEquals("PNA.MORTGAGE_API.SYS.001", errorResponse.getCode()),
                () -> assertEquals("Bad Request", errorResponse.getMessage()),
                () -> assertEquals("PNA.MORTGAGE_API.PUT_MORTGAGES_REPAYMENT_SCHEDULE.Argument.Invalid", errorInfo.getReasonCode()),
                () -> assertEquals("RepaymentScheduleParamVals[MortgageTermReduce] must not be empty", errorInfo.getMessage())
        );
    }
    
    @Test
    public void shouldReturnErrorForUpdateWhenMortgageQueryServiceThrowsException() throws NoSuchFieldException, SecurityException {
    	
    	when(mortgageAccountInfoRestClient.getMortgageAccountInfo(any(String.class), any(HashMap.class))).thenThrow(new RestServiceException(SystemErrors.INTERNAL_SERVER_ERROR.getErrorCode(),
                HttpStatus.INTERNAL_SERVER_ERROR,".Generic.Error",
                "Internal Server Error"));
    	AccountOptionsUpdateRequest req = 
    			accountOptionHelper.buildAccountOptionsUpdateRequestForMortgageTerm(MortgageOptionInstructionEnum.MortgageTermReduce, "12");
    	
        when(mortgageAccountOptionRestClient.updateAccountOptions(any(VaultAccountOptionsUpdateRequest.class)))
        .thenReturn(accountOptionHelper.buildAccountOptionsUpdateResponse(CommonConstants.KEY_MORTGAGE_TERM, null));
        
        //given
        String payload = componentHelper.writeValueAsString(req);
        // when
        MockHttpServletResponse servletResponse = doPUT(UPDATE_ACCOUNT_OPTIONS, payload, accountOptionHelper.getAccountInfoHeaders());
        String responseString = componentHelper.getServletResponseAsString(servletResponse);
        MortgageOptionsUpdateResponse viewAccountOptions = (MortgageOptionsUpdateResponse) readObject(responseString, MortgageOptionsUpdateResponse.class);
        ErrorResponse errorResponse = (ErrorResponse) readObject(responseString, ErrorResponse.class);
        ErrorInfo errorInfo = errorResponse.getErrors().get(0);

        //then
        assertAll(
        		() -> assertEquals(500, servletResponse.getStatus()),
                () -> assertEquals("PNA.MORTGAGE_API.SYS.006", errorResponse.getCode()),
                () -> assertEquals("Internal server error", errorResponse.getMessage()),
                () -> assertEquals("PNA.MORTGAGE_API.PUT_MORTGAGES_REPAYMENT_SCHEDULE.Generic.Error", errorInfo.getReasonCode()),
                () -> assertEquals("Internal Server Error", errorInfo.getMessage())
        );
    }
    
    @Test
    public void shouldReturnErrorForUpdateWhenVaultThrowsException() throws NoSuchFieldException, SecurityException {
    	
    	when(mortgageAccountInfoRestClient.getMortgageAccountInfo(any(String.class), any(HashMap.class))).thenThrow(new RestServiceException(SystemErrors.INTERNAL_SERVER_ERROR.getErrorCode(),
                HttpStatus.INTERNAL_SERVER_ERROR,".Generic.Error",
                "Internal Server Error"));
    	AccountOptionsUpdateRequest req = 
    			accountOptionHelper.buildAccountOptionsUpdateRequestForMortgageTerm(MortgageOptionInstructionEnum.MortgageTermReduce, "12");
    	
        when(mortgageAccountOptionRestClient.updateAccountOptions(any(VaultAccountOptionsUpdateRequest.class)))
        .thenThrow(new RestServiceException(SystemErrors.INTERNAL_SERVER_ERROR.getErrorCode(),HttpStatus.INTERNAL_SERVER_ERROR,".Generic.Error","Internal Server Error"));
        
        //given
        String payload = componentHelper.writeValueAsString(req);
        // when
        MockHttpServletResponse servletResponse = doPUT(UPDATE_ACCOUNT_OPTIONS, payload, accountOptionHelper.getAccountInfoHeaders());
        String responseString = componentHelper.getServletResponseAsString(servletResponse);
        MortgageOptionsUpdateResponse viewAccountOptions = (MortgageOptionsUpdateResponse) readObject(responseString, MortgageOptionsUpdateResponse.class);
        ErrorResponse errorResponse = (ErrorResponse) readObject(responseString, ErrorResponse.class);
        ErrorInfo errorInfo = errorResponse.getErrors().get(0);

        //then
        assertAll(
                () -> assertEquals(500, servletResponse.getStatus()),
                () -> assertEquals("PNA.MORTGAGE_API.SYS.006", errorResponse.getCode()),
                () -> assertEquals("Internal server error", errorResponse.getMessage()),
                () -> assertEquals("PNA.MORTGAGE_API.PUT_MORTGAGES_REPAYMENT_SCHEDULE.Generic.Error", errorInfo.getReasonCode()),
                () -> assertEquals("Internal Server Error", errorInfo.getMessage())
        );
    }
    
    @Test
    public void shouldReturnErrorForEmptyRequestBody() {
        //when
        MockHttpServletResponse servletResponse = doPUT(UPDATE_ACCOUNT_OPTIONS, "", accountOptionHelper.getAccountInfoHeaders());
        String responseString = componentHelper.getServletResponseAsString(servletResponse);
        ErrorResponse errorResponse = (ErrorResponse) readObject(responseString, ErrorResponse.class);
        ErrorInfo errorInfo = errorResponse.getErrors().get(0);

        //then
        assertAll(
                () -> assertEquals(400, servletResponse.getStatus()),
                () -> assertEquals("PNA.MORTGAGE_API.SYS.001", errorResponse.getCode()),
                () -> assertEquals("Bad Request", errorResponse.getMessage()),
                () -> assertEquals("PNA.MORTGAGE_API.PUT_MORTGAGES_REPAYMENT_SCHEDULE.Message.NotReadable", errorInfo.getReasonCode()),
                () -> assertEquals("Required request body is missing", errorInfo.getMessage())
        );
    }

    
    @Test
    public void shouldReturnErrorForUpdateWhenBrandIsMissing() {
        //given
    	AccountOptionsUpdateRequest req = 
    			accountOptionHelper.buildAccountOptionsUpdateRequestForMortgageTerm(MortgageOptionInstructionEnum.MortgageTermReduce, "12");
    	
        String payload = componentHelper.writeValueAsString(req);
        HttpHeaders accountInfoHeaders = accountOptionHelper.getAccountInfoHeaders();
        accountInfoHeaders.remove("x-lbg-brand");

        //when
        MockHttpServletResponse servletResponse = doPUT(UPDATE_ACCOUNT_OPTIONS, payload, accountInfoHeaders);
        String responseString = componentHelper.getServletResponseAsString(servletResponse);
        ErrorResponse errorResponse = (ErrorResponse) readObject(responseString, ErrorResponse.class);
        ErrorInfo errorInfo = errorResponse.getErrors().get(0);

        //then
        assertAll(
                () -> assertEquals(400, servletResponse.getStatus()),
                () -> assertEquals("PNA.MORTGAGE_API.SYS.001", errorResponse.getCode()),
                () -> assertEquals("Bad Request", errorResponse.getMessage()),
                () -> assertEquals("PNA.MORTGAGE_API.PUT_MORTGAGES_REPAYMENT_SCHEDULE.Header.Missing.x-lbg-brand", errorInfo.getReasonCode()),
                () -> assertEquals("Missing request header 'x-lbg-brand' for method parameter of type String", errorInfo.getMessage())
        );
    }

    @Test
    public void shouldReturnErrorForUpdateWhenBrandIsIncorrect() {
        //given
    	AccountOptionsUpdateRequest req = 
    			accountOptionHelper.buildAccountOptionsUpdateRequestForMortgageTerm(MortgageOptionInstructionEnum.MortgageTermReduce, "12");
    	
        String payload = componentHelper.writeValueAsString(req);
        HttpHeaders accountInfoHeaders = accountOptionHelper.getAccountInfoHeaders();
        accountInfoHeaders.set("x-lbg-brand", "xxx");

        //when
        MockHttpServletResponse servletResponse = doPUT(UPDATE_ACCOUNT_OPTIONS, payload, accountInfoHeaders);
        String responseString = componentHelper.getServletResponseAsString(servletResponse);
        ErrorResponse errorResponse = (ErrorResponse) readObject(responseString, ErrorResponse.class);
        ErrorInfo errorInfo = errorResponse.getErrors().get(0);

        //then
        assertAll(
                () -> assertEquals(400, servletResponse.getStatus()),
                () -> assertEquals("PNA.MORTGAGE_API.SYS.001", errorResponse.getCode()),
                () -> assertEquals("Bad Request", errorResponse.getMessage()),
                () -> assertEquals("PNA.MORTGAGE_API.PUT_MORTGAGES_REPAYMENT_SCHEDULE.Header.Invalid", errorInfo.getReasonCode()),
                () -> assertEquals("Invalid enum value for type x-lbg-brand", errorInfo.getMessage())
        );
    }

    @Test
    public void shouldReturnErrorForUpdateWhenCorrelationIdIsMissing() {
        //given
    	AccountOptionsUpdateRequest req = 
    			accountOptionHelper.buildAccountOptionsUpdateRequestForMortgageTerm(MortgageOptionInstructionEnum.MortgageTermReduce, "12");
        String payload = componentHelper.writeValueAsString(req);
        HttpHeaders accountInfoHeaders = accountOptionHelper.getAccountInfoHeaders();
        accountInfoHeaders.remove("x-lbg-txn-correlation-id");

        //when
        MockHttpServletResponse servletResponse = doPUT(UPDATE_ACCOUNT_OPTIONS, payload, accountInfoHeaders);
        String responseString = componentHelper.getServletResponseAsString(servletResponse);
        ErrorResponse errorResponse = (ErrorResponse) readObject(responseString, ErrorResponse.class);
        ErrorInfo errorInfo = errorResponse.getErrors().get(0);

        //then
        assertAll(
                () -> assertEquals(400, servletResponse.getStatus()),
                () -> assertEquals("PNA.MORTGAGE_API.SYS.001", errorResponse.getCode()),
                () -> assertEquals("Bad Request", errorResponse.getMessage()),
                () -> assertEquals("PNA.MORTGAGE_API.PUT_MORTGAGES_REPAYMENT_SCHEDULE.Header.Missing.x-lbg-txn-correlation-id", errorInfo.getReasonCode()),
                () -> assertEquals("Missing request header x-lbg-txn-correlation-id for method parameter of type String", errorInfo.getMessage())
        );
    }

    @Test
    public void shouldReturnErrorForUpdateWhenCorrelationIdIsLessThanTenCharacters() {
        //given
    	AccountOptionsUpdateRequest req = 
    			accountOptionHelper.buildAccountOptionsUpdateRequestForMortgageTerm(MortgageOptionInstructionEnum.MortgageTermReduce, "12");
        String payload = componentHelper.writeValueAsString(req);
        HttpHeaders accountInfoHeaders = accountOptionHelper.getAccountInfoHeaders();
        accountInfoHeaders.set("x-lbg-txn-correlation-id", RandomStringUtils.random(9));

        //when
        MockHttpServletResponse servletResponse = doPUT(UPDATE_ACCOUNT_OPTIONS, payload, accountInfoHeaders);
        String responseString = componentHelper.getServletResponseAsString(servletResponse);
        ErrorResponse errorResponse = (ErrorResponse) readObject(responseString, ErrorResponse.class);
        ErrorInfo errorInfo = errorResponse.getErrors().get(0);

        //then
        assertAll(
                () -> assertEquals(400, servletResponse.getStatus()),
                () -> assertEquals("PNA.MORTGAGE_API.SYS.001", errorResponse.getCode()),
                () -> assertEquals("Bad Request", errorResponse.getMessage()),
                () -> assertEquals("PNA.MORTGAGE_API.PUT_MORTGAGES_REPAYMENT_SCHEDULE.Header.Invalid", errorInfo.getReasonCode()),
                () -> assertEquals("x-lbg-txn-correlation-id size should be between 10 and 40", errorInfo.getMessage())
        );
    }

    @Test
    public void shouldReturnErrorForUpdateWhenCorrelationIdIsGreaterThanFortyCharacters() {
        //given
    	AccountOptionsUpdateRequest req = 
    			accountOptionHelper.buildAccountOptionsUpdateRequestForMortgageTerm(MortgageOptionInstructionEnum.MortgageTermReduce, "12");
        String payload = componentHelper.writeValueAsString(req);
        HttpHeaders accountInfoHeaders = accountOptionHelper.getAccountInfoHeaders();
        accountInfoHeaders.set("x-lbg-txn-correlation-id", RandomStringUtils.random(50));


        //when
        MockHttpServletResponse servletResponse = doPUT(UPDATE_ACCOUNT_OPTIONS, payload, accountInfoHeaders);
        String responseString = componentHelper.getServletResponseAsString(servletResponse);
        ErrorResponse errorResponse = (ErrorResponse) readObject(responseString, ErrorResponse.class);
        ErrorInfo errorInfo = errorResponse.getErrors().get(0);

        //then
        assertAll(
                () -> assertEquals(400, servletResponse.getStatus()),
                () -> assertEquals("PNA.MORTGAGE_API.SYS.001", errorResponse.getCode()),
                () -> assertEquals("Bad Request", errorResponse.getMessage()),
                () -> assertEquals("PNA.MORTGAGE_API.PUT_MORTGAGES_REPAYMENT_SCHEDULE.Header.Invalid", errorInfo.getReasonCode()),
                () -> assertEquals("x-lbg-txn-correlation-id size should be between 10 and 40", errorInfo.getMessage())
        );
    }

    @Test
    public void shouldReturnErrorForUpdateWhenAuthorisationIsMissing() {
        //given
    	AccountOptionsUpdateRequest req = 
    			accountOptionHelper.buildAccountOptionsUpdateRequestForMortgageTerm(MortgageOptionInstructionEnum.MortgageTermReduce, "12");
        String payload = componentHelper.writeValueAsString(req);
        HttpHeaders accountInfoHeaders = accountOptionHelper.getAccountInfoHeaders();
        accountInfoHeaders.remove("x-lbg-internal-system-id");
        accountInfoHeaders.remove("Authorization");

        //when
        MockHttpServletResponse servletResponse = doPUT(UPDATE_ACCOUNT_OPTIONS, payload, accountInfoHeaders);
        String responseString = componentHelper.getServletResponseAsString(servletResponse);
        ErrorResponse errorResponse = (ErrorResponse) readObject(responseString, ErrorResponse.class);
        ErrorInfo errorInfo = errorResponse.getErrors().get(0);

        //then
        assertAll(
                () -> assertEquals(401, servletResponse.getStatus()),
                () -> assertEquals("PNA.MORTGAGE_API.SYS.002", errorResponse.getCode()),
                () -> assertEquals("Resource Unauthorised", errorResponse.getMessage()),
                () -> assertEquals("PNA.MORTGAGE_API.PUT_MORTGAGES_REPAYMENT_SCHEDULE.Access.Unauthorised", errorInfo.getReasonCode()),
                () -> assertEquals("Please Supply headers : 'Authorization' or 'x-lbg-internal-system-id'", errorInfo.getMessage())
        );
    }
   
    @Test
    public void shouldReturnErrorForUpdateWhenAccountIdIsMoreThan36Chars() {
        //given
        AccountOptionsUpdateRequest req = accountOptionHelper.buildAccountOptionsUpdateRequestForMortgageType(RepaymentType.INTEREST_ONLY.name());;
        String payload = componentHelper.writeValueAsString(req);

        //when
        MockHttpServletResponse servletResponse = doPUT("/mortgages/"+RandomStringUtils.random(50)+"/repayment-schedule",
                payload, accountOptionHelper.getAccountInfoHeaders());
        String responseString = componentHelper.getServletResponseAsString(servletResponse);
        ErrorResponse errorResponse = (ErrorResponse) readObject(responseString, ErrorResponse.class);
        ErrorInfo errorInfo = errorResponse.getErrors().get(0);

        //then
        assertAll(
                () -> assertEquals(400, servletResponse.getStatus()),
                () -> assertEquals("PNA.MORTGAGE_API.SYS.001", errorResponse.getCode()),
                () -> assertEquals("Bad Request", errorResponse.getMessage()),
                () -> assertEquals("PNA.MORTGAGE_API.PUT_MORTGAGES_REPAYMENT_SCHEDULE.Param.Invalid", errorInfo.getReasonCode()),
                () -> assertEquals("AccountId should be max 36 characters", errorInfo.getMessage())
        );
    }

    @Test
    public void shouldReturnErrorForUpdateWhenAccountIdIsLessThan36Chars() {
        //given
        AccountOptionsUpdateRequest req = accountOptionHelper.buildAccountOptionsUpdateRequestForMortgageType(RepaymentType.INTEREST_ONLY.name());;
        String payload = componentHelper.writeValueAsString(req);

        //when
        MockHttpServletResponse servletResponse = doPUT("/mortgages/"+RandomStringUtils.random(5)+"/repayment-schedule",
                payload, accountOptionHelper.getAccountInfoHeaders());
        String responseString = componentHelper.getServletResponseAsString(servletResponse);
        ErrorResponse errorResponse = (ErrorResponse) readObject(responseString, ErrorResponse.class);
        ErrorInfo errorInfo = errorResponse.getErrors().get(0);

        //then
        assertAll(
                () -> assertEquals(400, servletResponse.getStatus()),
                () -> assertEquals("PNA.MORTGAGE_API.SYS.001", errorResponse.getCode()),
                () -> assertEquals("Bad Request", errorResponse.getMessage()),
                () -> assertEquals("PNA.MORTGAGE_API.PUT_MORTGAGES_REPAYMENT_SCHEDULE.Param.Invalid", errorInfo.getReasonCode()),
                () -> assertEquals("AccountId should be min 36 characters", errorInfo.getMessage())
        );
    }

}
