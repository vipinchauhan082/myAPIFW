package com.lbg.epscw.mortgagesrvc.component;

import com.lbg.epscw.entitlement.service.EntitlementValidationServiceImpl;
import com.lbg.epscw.handler.model.ErrorInfo;
import com.lbg.epscw.mortgagesrvc.dto.MortgageAccountInfo;
import com.lbg.epscw.mortgagesrvc.helper.ComponentHelper;
import com.lbg.epscw.mortgagesrvc.helper.MortgagePortingHelper;
import com.lbg.epscw.mortgagesrvc.logger.HystrixContextCopyStrategy;
import com.lbg.epscw.mortgagesrvc.model.CreatePortingApplicationResponse;
import com.lbg.epscw.mortgagesrvc.restclient.MortgageAccountInfoRestClient;
import com.lbg.epscw.mortgagesrvc.service.MortgagePortingCreateApplicationService;
import com.lbg.epscw.mortgagesrvc.validator.MortgagePortingCreateApplicationValidator;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpHeaders;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import static com.lbg.epscw.mortgagesrvc.helper.MortgagePortingHelper.APPLICATION_NUMBER;
import static com.lbg.epscw.mortgagesrvc.helper.MortgagePortingHelper.CREATE_APPLICATION_ENDPOINT;
import static com.lbg.epscw.mortgagesrvc.model.MortgagePortingApplicationStatus.OPEN;
import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.when;


@Tag("component")
@ExtendWith(SpringExtension.class)
@SpringBootTest
@AutoConfigureMockMvc
public class MortgagePortingCreateApplicationComponentTest extends WebMVCTest {
    private final MortgagePortingHelper portingHelper = new MortgagePortingHelper();
    private final ComponentHelper componentHelper = new ComponentHelper();
    @MockBean
    private EntitlementValidationServiceImpl entitlement;
    @MockBean
    private HystrixContextCopyStrategy hystrix;
    @MockBean
    private MortgagePortingCreateApplicationValidator validator;
    @MockBean
    private MortgageAccountInfoRestClient client;
    @MockBean
    private MortgagePortingCreateApplicationService service;

    @Test
    public void create_application_successful() {
        //given
        HttpHeaders headers = portingHelper.getAccountInfoHeaders();
        String payload = componentHelper.writeValueAsString(portingHelper.createApplicationPayloadBuilder().build());
        when(client.getMortgageInfoByMortgageNumber(anyString(), anyMap())).thenReturn(MortgageAccountInfo.builder().build());
        CreatePortingApplicationResponse expected = CreatePortingApplicationResponse.builder().applicationNumber(APPLICATION_NUMBER).status(OPEN).build();
        when(service.createApplication(any())).thenReturn(expected);

        //when
        MockHttpServletResponse response = doPOST(CREATE_APPLICATION_ENDPOINT, payload, headers);
        String responseString = componentHelper.getServletResponseAsString(response);
        CreatePortingApplicationResponse actual = readObject(responseString, CreatePortingApplicationResponse.class);

        //then
        assertThat(response.getStatus(), is(200));
        assertThat(actual.getApplicationNumber(), is(APPLICATION_NUMBER));
        assertThat(actual.getStatus(), is(OPEN));
    }

    @Test
    public void create_application_fails_with_invalid_purpose() {
        //given
        HttpHeaders headers = portingHelper.getAccountInfoHeaders();
        String payload = componentHelper.writeValueAsString(portingHelper.createApplicationPayloadBuilder()
                .purpose("INVALID")
                .build());

        // when
        MockHttpServletResponse response = doPOST(CREATE_APPLICATION_ENDPOINT, payload, headers);
        ErrorInfo error = readErrorInfo(componentHelper.getServletResponseAsString(response));

        // then
        assertEquals(400, response.getStatus());
        assertEquals("PNA.MORTGAGE_API.POST_MORTGAGES_APPLICATION.Argument.Invalid", error.getReasonCode());
        assertEquals("Purpose is not a valid. Must be PORTING", error.getMessage());
    }

    @Test
    public void number_of_dependents_is_mandatory() {
        //given
        HttpHeaders headers = portingHelper.getAccountInfoHeaders();
        String payload = componentHelper.writeValueAsString(portingHelper.createApplicationPayloadBuilder()
                .numberOfDependents(null)
                .build());

        // when
        MockHttpServletResponse response = doPOST(CREATE_APPLICATION_ENDPOINT, payload, headers);
        ErrorInfo error = readErrorInfo(componentHelper.getServletResponseAsString(response));

        // then
        assertEquals(400, response.getStatus());
        assertEquals("PNA.MORTGAGE_API.POST_MORTGAGES_APPLICATION.Argument.Invalid", error.getReasonCode());
        assertEquals("NumberOfDependents is required", error.getMessage());
    }

    @Test
    public void customer_id_is_mandatory() {
        //given
        HttpHeaders headers = portingHelper.getAccountInfoHeaders();
        String payload = componentHelper.writeValueAsString(portingHelper.createApplicationPayloadBuilder()
                .customerId(null)
                .build());

        // when
        MockHttpServletResponse response = doPOST(CREATE_APPLICATION_ENDPOINT, payload, headers);
        ErrorInfo error = readErrorInfo(componentHelper.getServletResponseAsString(response));

        // then
        assertEquals(400, response.getStatus());
        assertEquals("PNA.MORTGAGE_API.POST_MORTGAGES_APPLICATION.Argument.Invalid", error.getReasonCode());
        assertEquals("CustomerId is required", error.getMessage());
    }

    @Test
    public void existing_account_number_is_mandatory() {
        //given
        HttpHeaders headers = portingHelper.getAccountInfoHeaders();
        String payload = componentHelper.writeValueAsString(portingHelper.createApplicationPayloadBuilder()
                .previousMortgageNumber(null)
                .build());

        // when
        MockHttpServletResponse response = doPOST(CREATE_APPLICATION_ENDPOINT, payload, headers);
        ErrorInfo error = readErrorInfo(componentHelper.getServletResponseAsString(response));

        // then
        assertEquals(400, response.getStatus());
        assertEquals("PNA.MORTGAGE_API.POST_MORTGAGES_APPLICATION.Argument.Invalid", error.getReasonCode());
        assertEquals("PreviousMortgageNumber is required", error.getMessage());
    }


    @Test
    public void create_application_fails_with_invalid_account_number() {
        //given
        HttpHeaders headers = portingHelper.getAccountInfoHeaders();
        String payload = componentHelper.writeValueAsString(portingHelper.createApplicationPayloadBuilder()
                .previousMortgageNumber("1234")
                .build());

        // when
        MockHttpServletResponse response = doPOST(CREATE_APPLICATION_ENDPOINT, payload, headers);
        ErrorInfo error = readErrorInfo(componentHelper.getServletResponseAsString(response));

        // then
        assertEquals(400, response.getStatus());
        assertEquals("PNA.MORTGAGE_API.POST_MORTGAGES_APPLICATION.Argument.Invalid", error.getReasonCode());
        assertEquals("PreviousMortgageNumber must be a valid GUID", error.getMessage());
    }

    @Test
    public void create_application_fails_with_invalid_number_of_dependents() {
        //given
        HttpHeaders headers = portingHelper.getAccountInfoHeaders();
        String payload = componentHelper.writeValueAsString(portingHelper.createApplicationPayloadBuilder()
                .numberOfDependents(-1)
                .build());

        // when
        MockHttpServletResponse response = doPOST(CREATE_APPLICATION_ENDPOINT, payload, headers);
        ErrorInfo error = readErrorInfo(componentHelper.getServletResponseAsString(response));

        // then
        assertEquals(400, response.getStatus());
        assertEquals("PNA.MORTGAGE_API.POST_MORTGAGES_APPLICATION.Argument.Invalid", error.getReasonCode());
        assertEquals("NumberOfDependents must be greater than or equal to 0", error.getMessage());
    }

    @Test
    public void throws_exception_when_correlationId_is_missing() {
        //given
        HttpHeaders headers = portingHelper.getAccountInfoHeaders();
        headers.remove("x-lbg-txn-correlation-id");

        // when
        String payload = componentHelper.writeValueAsString(portingHelper.createApplicationPayloadBuilder().build());
        MockHttpServletResponse response = doPOST(CREATE_APPLICATION_ENDPOINT, payload, headers);
        ErrorInfo error = readErrorInfo(componentHelper.getServletResponseAsString(response));

        // then
        assertEquals(400, response.getStatus());
        assertEquals("PNA.MORTGAGE_API.POST_MORTGAGES_APPLICATION.Header.Missing.x-lbg-txn-correlation-id", error.getReasonCode());
        assertEquals("Missing request header x-lbg-txn-correlation-id for method parameter of type String", error.getMessage());
    }

    @Test
    public void throws_exception_when_brand_is_missing() {
        //given
        HttpHeaders headers = portingHelper.getAccountInfoHeaders();
        headers.remove("x-lbg-brand");

        // when
        String payload = componentHelper.writeValueAsString(portingHelper.createApplicationPayloadBuilder().build());
        MockHttpServletResponse response = doPOST(CREATE_APPLICATION_ENDPOINT, payload, headers);
        ErrorInfo error = readErrorInfo(componentHelper.getServletResponseAsString(response));

        // then
        assertEquals(400, response.getStatus());
        assertEquals("PNA.MORTGAGE_API.POST_MORTGAGES_APPLICATION.Header.Missing.x-lbg-brand", error.getReasonCode());
        assertEquals("Missing request header 'x-lbg-brand' for method parameter of type String", error.getMessage());
    }

    @Test
    public void throws_exception_when_channel_is_missing() {
        //given
        HttpHeaders headers = portingHelper.getAccountInfoHeaders();
        headers.remove("x-lbg-channel");

        // when
        String payload = componentHelper.writeValueAsString(portingHelper.createApplicationPayloadBuilder().build());
        MockHttpServletResponse response = doPOST(CREATE_APPLICATION_ENDPOINT, payload, headers);
        ErrorInfo error = readErrorInfo(componentHelper.getServletResponseAsString(response));

        // then
        assertEquals(400, response.getStatus());
        assertEquals("PNA.MORTGAGE_API.POST_MORTGAGES_APPLICATION.Header.Missing.x-lbg-channel", error.getReasonCode());
        assertEquals("Missing request header 'x-lbg-channel' for method parameter of type String", error.getMessage());
    }

    @Test
    public void throws_exception_when_brand_name_is_invalid() {
        //given
        HttpHeaders headers = portingHelper.getAccountInfoHeaders();
        headers.set("x-lbg-brand", "invalid");

        // when
        String payload = componentHelper.writeValueAsString(portingHelper.createApplicationPayloadBuilder().build());
        MockHttpServletResponse response = doPOST(CREATE_APPLICATION_ENDPOINT, payload, headers);
        ErrorInfo error = readErrorInfo(componentHelper.getServletResponseAsString(response));

        // then
        assertEquals(400, response.getStatus());
        assertEquals("PNA.MORTGAGE_API.POST_MORTGAGES_APPLICATION.Header.Invalid", error.getReasonCode());
        assertEquals("Invalid enum value for type x-lbg-brand", error.getMessage());
    }
}