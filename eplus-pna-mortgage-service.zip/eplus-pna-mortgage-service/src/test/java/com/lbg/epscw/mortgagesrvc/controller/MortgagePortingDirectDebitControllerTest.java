package com.lbg.epscw.mortgagesrvc.controller;

import com.lbg.epscw.mortgagesrvc.exception.MortgageServiceException;
import com.lbg.epscw.mortgagesrvc.exception.MortgageValidationException;
import com.lbg.epscw.mortgagesrvc.model.DirectDebitDetailsRequest;
import com.lbg.epscw.mortgagesrvc.model.PortingApplicationStatusResponse;
import com.lbg.epscw.mortgagesrvc.service.MortgagePortingApplicationInfoService;
import com.lbg.epscw.mortgagesrvc.service.MortgagePortingDirectDebitService;
import com.lbg.epscw.mortgagesrvc.util.MortgageServiceUtil;
import com.lbg.epscw.mortgagesrvc.validator.MortgagePortingApplicationValidator;
import org.junit.Before;
import org.junit.Test;
import org.springframework.http.ResponseEntity;

import static com.lbg.epscw.mortgagesrvc.helper.MortgagePortingHelper.*;
import static com.lbg.epscw.mortgagesrvc.model.MortgagePortingApplicationStatus.OPEN;
import static com.lbg.epscw.mortgagesrvc.model.MortgagePortingApplicationStatus.REOPEN;
import static io.opencensus.trace.Tracing.getTracer;
import static io.opencensus.trace.samplers.Samplers.alwaysSample;
import static java.util.Collections.emptyMap;
import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.mock;
import static org.powermock.api.mockito.PowerMockito.when;
import static org.springframework.http.ResponseEntity.ok;

    public class MortgagePortingDirectDebitControllerTest {
    private MortgagePortingApplicationValidator validator;
    private MortgagePortingDirectDebitService service;
    private MortgagePortingDirectDebitDetailsController underTest;

    @Before
    public void setup() {
        validator = mock(MortgagePortingApplicationValidator.class);
        MortgageServiceUtil utility = mock(MortgageServiceUtil.class);
        when(utility.buildSpan(anyString())).thenReturn(getTracer().spanBuilder("any").setSampler(alwaysSample()));
        service = mock(MortgagePortingDirectDebitService.class);
        MortgagePortingApplicationInfoService infoService = mock(MortgagePortingApplicationInfoService.class);
        underTest = new MortgagePortingDirectDebitDetailsController(infoService, validator, service, utility);
    }

    @Test
    public void verify_application_status_permitted_reopen() {
        //given
        PortingApplicationStatusResponse expected = PortingApplicationStatusResponse.builder().
                applicationNumber(APPLICATION_NUMBER).status(REOPEN).build();
        when(service.updateDirectDebitDetails(any(), any())).thenReturn(expected);
        //when
        DirectDebitDetailsRequest directDebitDetailsRequest = DirectDebitDetailsRequest.builder().mainAccountHolder("Jack").
                secondAccountHolder("Mill").schemeName("SortCodeAccountNumber").identification("80200110203348").build();
        ResponseEntity<PortingApplicationStatusResponse> response = underTest.directDebit(BRAND, CHANNEL, CORRELATION_ID, JWT, INTERNAL_SYS_ID,
                emptyMap(), APPLICATION_NUMBER, directDebitDetailsRequest);
        //then
        assertThat(response, is(ok(expected)));
    }
    @Test
    public void verify_application_status_permitted_open() {
        //given
        PortingApplicationStatusResponse expected = PortingApplicationStatusResponse.builder().
                applicationNumber(APPLICATION_NUMBER).status(OPEN).build();
        when(service.updateDirectDebitDetails(any(), any())).thenReturn(expected);
        //when
        DirectDebitDetailsRequest directDebitDetailsRequest = DirectDebitDetailsRequest.builder().mainAccountHolder("Jack").
                secondAccountHolder("Mill").schemeName("SortCodeAccountNumber").identification("80200110203348").build();
        ResponseEntity<PortingApplicationStatusResponse> response = underTest.directDebit(BRAND, CHANNEL, CORRELATION_ID, JWT, INTERNAL_SYS_ID,
                emptyMap(), APPLICATION_NUMBER, directDebitDetailsRequest);
        //then
        assertThat(response, is(ok(expected)));
    }


    @Test(expected = MortgageValidationException.class)
    public void verify_status_not_permitted() {
        //given
        doThrow(MortgageValidationException.class).when(validator).validateCurrentState(any(), any());
        //when
        DirectDebitDetailsRequest directDebitDetailsRequest =DirectDebitDetailsRequest.builder().mainAccountHolder("Jack").
                secondAccountHolder("Mill").schemeName("SortCodeAccountNumber").identification("80200110203348").build();
        underTest.directDebit(BRAND, CHANNEL, CORRELATION_ID, JWT, INTERNAL_SYS_ID, emptyMap(), APPLICATION_NUMBER,
                directDebitDetailsRequest);
        //then expect exception
    }

    @Test(expected = MortgageServiceException.class)
    public void when_service_returns_null_response() {
        //given
        doThrow(MortgageServiceException.class).when(service).updateDirectDebitDetails(any(), any());
        //when
        DirectDebitDetailsRequest directDebitDetailsRequest =DirectDebitDetailsRequest.builder().mainAccountHolder("Jack").
                secondAccountHolder("Mill").schemeName("SortCodeAccountNumber").identification("80200110203348").build();
        underTest.directDebit(BRAND, CHANNEL, CORRELATION_ID, JWT, INTERNAL_SYS_ID, emptyMap(), APPLICATION_NUMBER,
                directDebitDetailsRequest);
        //then expect exception
    }
}
