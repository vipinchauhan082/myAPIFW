package com.lbg.epscw.mortgagesrvc.component;

import com.lbg.epscw.entitlement.service.EntitlementValidationServiceImpl;
import com.lbg.epscw.handler.model.ErrorInfo;
import com.lbg.epscw.handler.model.ErrorResponse;
import com.lbg.epscw.mortgagesrvc.helper.ComponentHelper;
import com.lbg.epscw.mortgagesrvc.helper.MortgageAccountDataHelper;
import com.lbg.epscw.mortgagesrvc.logger.HystrixContextCopyStrategy;
import com.lbg.epscw.mortgagesrvc.model.BenefitsRequest;
import com.lbg.epscw.mortgagesrvc.model.BenefitsResponse;
import com.lbg.epscw.mortgagesrvc.service.RestClientService;
import org.apache.commons.lang.RandomStringUtils;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mockito;
import org.mockito.internal.util.MockUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.context.ApplicationContext;
import org.springframework.http.HttpHeaders;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import java.util.HashMap;

import static org.junit.Assert.assertEquals;
import static org.junit.jupiter.api.Assertions.assertAll;
import static org.mockito.ArgumentMatchers.any;
import static org.powermock.api.mockito.PowerMockito.when;

@Tag("component")
@ExtendWith(SpringExtension.class)
@SpringBootTest
@AutoConfigureMockMvc
class UpdateBenefitsDetailsComponentTest extends WebMVCTest {

    private static final String MORTGAGES_BENEFITS =
            "/mortgages/1601d0e5-e336-64d9-64ad-89ba6fdc2677/benefits";

    @MockBean
    private EntitlementValidationServiceImpl entitlementValidationService;

    @MockBean
    RestClientService restClientService;

    @MockBean
    private HystrixContextCopyStrategy hystrixContextCopyStrategy;

    private ComponentHelper componentHelper;

    private MortgageAccountDataHelper accountDataHelper;

    @Autowired
    private ApplicationContext context;

    @BeforeEach
    public void beforeEach() {
        this.componentHelper = new ComponentHelper();
        this.accountDataHelper = new MortgageAccountDataHelper();
        for (String name : context.getBeanDefinitionNames()) {
            Object bean = context.getBean(name);
            if (MockUtil.isMock(bean)) {
                Mockito.reset(bean);
            }
        }
    }


    @Test
    public void shouldUpdateBenefitDetails() {

        //given
        when(restClientService.get(any(String.class), any(HashMap.class)))
                .thenReturn(componentHelper.writeValueAsString(
                        accountDataHelper.mortgageAccountInfo_TrueResponseMock()));
        when(restClientService.put(any(String.class), any(HashMap.class), any(String.class)))
                .thenReturn(componentHelper.writeValueAsString(
                        accountDataHelper.buildAccountBenefitsTrueUpdateResponse()));

        String payload = componentHelper.writeValueAsString(
                accountDataHelper.mockRequest_TrueBenefits());

        //when
        MockHttpServletResponse servletResponse = doPOST(MORTGAGES_BENEFITS, payload, accountDataHelper.getAccountInfoHeaders());
        String responseString = componentHelper.getServletResponseAsString(servletResponse);
        BenefitsResponse response = (BenefitsResponse) readObject(responseString, BenefitsResponse.class);

        //then
        assertAll(
                () -> assertEquals("1601d0e5-e336-64d9-64ad-89ba6fdc2677", response.getAccountId()),
                () -> assertEquals("ACCOUNT_STATUS_OPEN", response.getStatus()),
                () -> assertEquals(2, response.getBenefitsDetails().size())
        );
    }

    @Test
    public void shouldReturnErrorForInvalidAccountId() {

        //given
        when(restClientService.get(any(String.class), any(HashMap.class)))
                .thenReturn(componentHelper.writeValueAsString(
                        accountDataHelper.mortgageAccountInfo_FalseResponseMock()));

        String payload = componentHelper.writeValueAsString(
                accountDataHelper.mockRequest_TrueBenefits());

        //when
        MockHttpServletResponse servletResponse = doPOST(MORTGAGES_BENEFITS, payload, accountDataHelper.getAccountInfoHeaders());
        String responseString = componentHelper.getServletResponseAsString(servletResponse);
        ErrorResponse errorResponse = (ErrorResponse) readObject(responseString, ErrorResponse.class);
        ErrorInfo errorInfo = errorResponse.getErrors().get(0);

        //then
        assertAll(
                () -> assertEquals(400, servletResponse.getStatus()),
                () -> assertEquals("PNA.MORTGAGE_API.BUS.601", errorResponse.getCode()),
                () -> assertEquals("Invalid Update Request", errorResponse.getMessage()),
                () -> assertEquals("PNA.MORTGAGE_API.POST_MORTGAGES_BENEFITS.AccountId.RequestInvalid", errorInfo.getReasonCode()),
                () -> assertEquals("Not an overarching account", errorInfo.getMessage())
        );
    }

    @Test
    public void shouldReturnErrorForInvalidBenefitRequest() {

        String payload = componentHelper.writeValueAsString(
                accountDataHelper.invalidRequest_TrueBenefits());

        //when
        MockHttpServletResponse servletResponse = doPOST(MORTGAGES_BENEFITS, payload, accountDataHelper.getAccountInfoHeaders());
        String responseString = componentHelper.getServletResponseAsString(servletResponse);
        ErrorResponse errorResponse = (ErrorResponse) readObject(responseString, ErrorResponse.class);
        ErrorInfo errorInfo = errorResponse.getErrors().get(0);

        //then
        assertAll(
                () -> assertEquals(400, servletResponse.getStatus()),
                () -> assertEquals("PNA.MORTGAGE_API.BUS.601", errorResponse.getCode()),
                () -> assertEquals("Invalid Update Request", errorResponse.getMessage()),
                () -> assertEquals("PNA.MORTGAGE_API.POST_MORTGAGES_BENEFITS.BenefitsSource.RequestInvalid", errorInfo.getReasonCode()),
                () -> assertEquals("Required when IsOnBenefits positively set", errorInfo.getMessage())
        );
    }

    @Test
    public void shouldReturnErrorForInvalidBenefitsSource(){

        String payload = componentHelper.writeValueAsString(accountDataHelper.invalidSourceRequest_TrueBenefits());

        MockHttpServletResponse servletResponse = doPOST(MORTGAGES_BENEFITS, payload, accountDataHelper.getAccountInfoHeaders());
        String responseString = componentHelper.getServletResponseAsString(servletResponse);
        ErrorResponse errorResponse = (ErrorResponse) readObject(responseString, ErrorResponse.class);
        ErrorInfo errorInfo = errorResponse.getErrors().get(0);

        //then
        assertAll(
                () -> assertEquals(400, servletResponse.getStatus()),
                () -> assertEquals("PNA.MORTGAGE_API.SYS.001", errorResponse.getCode()),
                () -> assertEquals("Bad Request", errorResponse.getMessage()),
                () -> assertEquals("PNA.MORTGAGE_API.POST_MORTGAGES_BENEFITS.Argument.Invalid", errorInfo.getReasonCode()),
                () -> assertEquals("BenefitsSource is not valid as per defined enum", errorInfo.getMessage())
        );
    }

    @Test
    public void shouldReturnErrorForEmptyRequestBody() {
        //when
        MockHttpServletResponse servletResponse = doPOST(MORTGAGES_BENEFITS, "", accountDataHelper.getAccountInfoHeaders());
        String responseString = componentHelper.getServletResponseAsString(servletResponse);
        ErrorResponse errorResponse = (ErrorResponse) readObject(responseString, ErrorResponse.class);
        ErrorInfo errorInfo = errorResponse.getErrors().get(0);

        //then
        assertAll(
                () -> assertEquals(400, servletResponse.getStatus()),
                () -> assertEquals("PNA.MORTGAGE_API.SYS.001", errorResponse.getCode()),
                () -> assertEquals("Bad Request", errorResponse.getMessage()),
                () -> assertEquals("PNA.MORTGAGE_API.POST_MORTGAGES_BENEFITS.Message.NotReadable", errorInfo.getReasonCode()),
                () -> assertEquals("Required request body is missing", errorInfo.getMessage())
        );
    }

    @Test
    public void shouldReturnErrorForEmptyJson() {
        //when
        MockHttpServletResponse servletResponse = doPOST(MORTGAGES_BENEFITS, "{}", accountDataHelper.getAccountInfoHeaders());
        String responseString = componentHelper.getServletResponseAsString(servletResponse);
        ErrorResponse errorResponse = (ErrorResponse) readObject(responseString, ErrorResponse.class);
        ErrorInfo errorInfo = errorResponse.getErrors().get(0);
        System.out.println(errorInfo.getMessage());

        //then
        assertAll(
                () -> assertEquals(400, servletResponse.getStatus()),
                () -> assertEquals("PNA.MORTGAGE_API.SYS.001", errorResponse.getCode()),
                () -> assertEquals("Bad Request", errorResponse.getMessage()),
                () -> assertEquals("PNA.MORTGAGE_API.POST_MORTGAGES_BENEFITS.Argument.Invalid", errorInfo.getReasonCode()),
                () -> assertEquals("IsOnBenefits must not be null", errorInfo.getMessage())
        );
    }


    @Test
    public void shouldReturnErrorForUpdateWhenBrandIsMissing() {
        //given
        BenefitsRequest benefitsRequest = accountDataHelper.mockRequest_TrueBenefits();
        String payload = componentHelper.writeValueAsString(benefitsRequest);
        HttpHeaders accountInfoHeaders = accountDataHelper.getAccountInfoHeaders();
        accountInfoHeaders.remove("x-lbg-brand");

        //when
        MockHttpServletResponse servletResponse = doPOST(MORTGAGES_BENEFITS, payload, accountInfoHeaders);
        String responseString = componentHelper.getServletResponseAsString(servletResponse);
        ErrorResponse errorResponse = (ErrorResponse) readObject(responseString, ErrorResponse.class);
        ErrorInfo errorInfo = errorResponse.getErrors().get(0);

        //then
        assertAll(
                () -> assertEquals(400, servletResponse.getStatus()),
                () -> assertEquals("PNA.MORTGAGE_API.SYS.001", errorResponse.getCode()),
                () -> assertEquals("Bad Request", errorResponse.getMessage()),
                () -> assertEquals("PNA.MORTGAGE_API.POST_MORTGAGES_BENEFITS.Header.Missing.x-lbg-brand", errorInfo.getReasonCode()),
                () -> assertEquals("Missing request header 'x-lbg-brand' for method parameter of type String", errorInfo.getMessage())
        );
    }

    @Test
    public void shouldReturnErrorForUpdateWhenBrandIsIncorrect() {
        //given
        BenefitsRequest benefitsRequest = accountDataHelper.mockRequest_TrueBenefits();
        String payload = componentHelper.writeValueAsString(benefitsRequest);
        HttpHeaders accountInfoHeaders = accountDataHelper.getAccountInfoHeaders();
        accountInfoHeaders.set("x-lbg-brand", "xxx");

        //when
        MockHttpServletResponse servletResponse = doPOST(MORTGAGES_BENEFITS, payload, accountInfoHeaders);
        String responseString = componentHelper.getServletResponseAsString(servletResponse);
        ErrorResponse errorResponse = (ErrorResponse) readObject(responseString, ErrorResponse.class);
        ErrorInfo errorInfo = errorResponse.getErrors().get(0);

        //then
        assertAll(
                () -> assertEquals(400, servletResponse.getStatus()),
                () -> assertEquals("PNA.MORTGAGE_API.SYS.001", errorResponse.getCode()),
                () -> assertEquals("Bad Request", errorResponse.getMessage()),
                () -> assertEquals("PNA.MORTGAGE_API.POST_MORTGAGES_BENEFITS.Header.Invalid", errorInfo.getReasonCode()),
                () -> assertEquals("Invalid enum value for type x-lbg-brand", errorInfo.getMessage())
        );
    }

    @Test
    public void shouldReturnErrorForUpdateWhenCorrelationIdIsMissing() {
        //given
        BenefitsRequest benefitsRequest = accountDataHelper.mockRequest_TrueBenefits();
        String payload = componentHelper.writeValueAsString(benefitsRequest);
        HttpHeaders accountInfoHeaders = accountDataHelper.getAccountInfoHeaders();
        accountInfoHeaders.remove("x-lbg-txn-correlation-id");

        //when
        MockHttpServletResponse servletResponse = doPOST(MORTGAGES_BENEFITS, payload, accountInfoHeaders);
        String responseString = componentHelper.getServletResponseAsString(servletResponse);
        ErrorResponse errorResponse = (ErrorResponse) readObject(responseString, ErrorResponse.class);
        ErrorInfo errorInfo = errorResponse.getErrors().get(0);

        //then
        assertAll(
                () -> assertEquals(400, servletResponse.getStatus()),
                () -> assertEquals("PNA.MORTGAGE_API.SYS.001", errorResponse.getCode()),
                () -> assertEquals("Bad Request", errorResponse.getMessage()),
                () -> assertEquals("PNA.MORTGAGE_API.POST_MORTGAGES_BENEFITS.Header.Missing.x-lbg-txn-correlation-id", errorInfo.getReasonCode()),
                () -> assertEquals("Missing request header x-lbg-txn-correlation-id for method parameter of type String", errorInfo.getMessage())
        );
    }

    @Test
    public void shouldReturnErrorForUpdateWhenCorrelationIdIsLessThanTenCharacters() {
        //given
        BenefitsRequest benefitsRequest = accountDataHelper.mockRequest_TrueBenefits();
        String payload = componentHelper.writeValueAsString(benefitsRequest);
        HttpHeaders accountInfoHeaders = accountDataHelper.getAccountInfoHeaders();
        accountInfoHeaders.set("x-lbg-txn-correlation-id", RandomStringUtils.random(9));

        //when
        MockHttpServletResponse servletResponse = doPOST(MORTGAGES_BENEFITS, payload, accountInfoHeaders);
        String responseString = componentHelper.getServletResponseAsString(servletResponse);
        ErrorResponse errorResponse = (ErrorResponse) readObject(responseString, ErrorResponse.class);
        ErrorInfo errorInfo = errorResponse.getErrors().get(0);

        //then
        assertAll(
                () -> assertEquals(400, servletResponse.getStatus()),
                () -> assertEquals("PNA.MORTGAGE_API.SYS.001", errorResponse.getCode()),
                () -> assertEquals("Bad Request", errorResponse.getMessage()),
                () -> assertEquals("PNA.MORTGAGE_API.POST_MORTGAGES_BENEFITS.Header.Invalid", errorInfo.getReasonCode()),
                () -> assertEquals("x-lbg-txn-correlation-id size should be between 10 and 40", errorInfo.getMessage())
        );
    }

    @Test
    public void shouldReturnErrorForUpdateWhenCorrelationIdIsGreaterThanFortyCharacters() {
        //given
        BenefitsRequest benefitsRequest = accountDataHelper.mockRequest_TrueBenefits();
        String payload = componentHelper.writeValueAsString(benefitsRequest);
        HttpHeaders accountInfoHeaders = accountDataHelper.getAccountInfoHeaders();
        accountInfoHeaders.set("x-lbg-txn-correlation-id", RandomStringUtils.random(50));


        //when
        MockHttpServletResponse servletResponse = doPOST(MORTGAGES_BENEFITS, payload, accountInfoHeaders);
        String responseString = componentHelper.getServletResponseAsString(servletResponse);
        ErrorResponse errorResponse = (ErrorResponse) readObject(responseString, ErrorResponse.class);
        ErrorInfo errorInfo = errorResponse.getErrors().get(0);

        //then
        assertAll(
                () -> assertEquals(400, servletResponse.getStatus()),
                () -> assertEquals("PNA.MORTGAGE_API.SYS.001", errorResponse.getCode()),
                () -> assertEquals("Bad Request", errorResponse.getMessage()),
                () -> assertEquals("PNA.MORTGAGE_API.POST_MORTGAGES_BENEFITS.Header.Invalid", errorInfo.getReasonCode()),
                () -> assertEquals("x-lbg-txn-correlation-id size should be between 10 and 40", errorInfo.getMessage())
        );
    }

    @Test
    public void shouldReturnErrorForUpdateWhenAuthorisationIsMissing() {
        //given
        BenefitsRequest benefitsRequest = accountDataHelper.mockRequest_TrueBenefits();
        String payload = componentHelper.writeValueAsString(benefitsRequest);
        HttpHeaders accountInfoHeaders = accountDataHelper.getAccountInfoHeaders();
        accountInfoHeaders.remove("x-lbg-internal-system-id");
        accountInfoHeaders.remove("Authorization");

        //when
        MockHttpServletResponse servletResponse = doPOST(MORTGAGES_BENEFITS, payload, accountInfoHeaders);
        String responseString = componentHelper.getServletResponseAsString(servletResponse);
        ErrorResponse errorResponse = (ErrorResponse) readObject(responseString, ErrorResponse.class);
        ErrorInfo errorInfo = errorResponse.getErrors().get(0);

        //then
        assertAll(
                () -> assertEquals(401, servletResponse.getStatus()),
                () -> assertEquals("PNA.MORTGAGE_API.SYS.002", errorResponse.getCode()),
                () -> assertEquals("Resource Unauthorised", errorResponse.getMessage()),
                () -> assertEquals("PNA.MORTGAGE_API.POST_MORTGAGES_BENEFITS.Access.Unauthorised", errorInfo.getReasonCode()),
                () -> assertEquals("Please Supply headers : 'Authorization' or 'x-lbg-internal-system-id'", errorInfo.getMessage())
        );
    }

    @Test
    public void shouldReturnErrorForUpdateWhenAccountIdIsMoreThan36Chars() {
        //given
        BenefitsRequest benefitsRequest = accountDataHelper.mockRequest_TrueBenefits();
        String payload = componentHelper.writeValueAsString(benefitsRequest);

        //when
        MockHttpServletResponse servletResponse = doPOST("/mortgages/"+RandomStringUtils.random(50)+"/benefits",
                payload,
                accountDataHelper.getAccountInfoHeaders());
        String responseString = componentHelper.getServletResponseAsString(servletResponse);
        ErrorResponse errorResponse = (ErrorResponse) readObject(responseString, ErrorResponse.class);
        ErrorInfo errorInfo = errorResponse.getErrors().get(0);

        //then
        assertAll(
                () -> assertEquals(400, servletResponse.getStatus()),
                () -> assertEquals("PNA.MORTGAGE_API.SYS.001", errorResponse.getCode()),
                () -> assertEquals("Bad Request", errorResponse.getMessage()),
                () -> assertEquals("PNA.MORTGAGE_API.POST_MORTGAGES_BENEFITS.Param.Invalid", errorInfo.getReasonCode()),
                () -> assertEquals("AccountId should be max 36 characters", errorInfo.getMessage())
        );
    }

    @Test
    public void shouldReturnErrorForUpdateWhenAccountIdIsLessThan36Chars() {
        //given
        BenefitsRequest benefitsRequest = accountDataHelper.mockRequest_TrueBenefits();
        String payload = componentHelper.writeValueAsString(benefitsRequest);

        //when
        MockHttpServletResponse servletResponse = doPOST("/mortgages/"+RandomStringUtils.random(5)+"/benefits",
                payload,
                accountDataHelper.getAccountInfoHeaders());
        String responseString = componentHelper.getServletResponseAsString(servletResponse);
        ErrorResponse errorResponse = (ErrorResponse) readObject(responseString, ErrorResponse.class);
        ErrorInfo errorInfo = errorResponse.getErrors().get(0);

        //then
        assertAll(
                () -> assertEquals(400, servletResponse.getStatus()),
                () -> assertEquals("PNA.MORTGAGE_API.SYS.001", errorResponse.getCode()),
                () -> assertEquals("Bad Request", errorResponse.getMessage()),
                () -> assertEquals("PNA.MORTGAGE_API.POST_MORTGAGES_BENEFITS.Param.Invalid", errorInfo.getReasonCode()),
                () -> assertEquals("AccountId should be min 36 characters", errorInfo.getMessage())
        );
    }

    @Test
    public void shouldReturnErrorForUpdateWhenIncorrectEndpointIsCalled() {
        //given
        BenefitsRequest benefitsRequest = accountDataHelper.mockRequest_TrueBenefits();
        String payload = componentHelper.writeValueAsString(benefitsRequest);
        HttpHeaders accountInfoHeaders = accountDataHelper.getAccountInfoHeaders();

        //when
        MockHttpServletResponse servletResponse = doPOST(MORTGAGES_BENEFITS.concat("s"), payload, accountInfoHeaders);

        //then
        assertAll(
                () -> assertEquals(404, servletResponse.getStatus())
        );
    }

}
