package com.lbg.epscw.mortgagesrvc.restclient;

import static com.lbg.epscw.mortgagesrvc.constants.CommonConstants.KEY_MORTGAGE_TERM;
import static com.lbg.epscw.mortgagesrvc.constants.CommonConstants.KEY_MORTGAGE_TYPE;
import static org.junit.Assert.assertNotNull;
import static org.mockito.ArgumentMatchers.any;
import static org.powermock.api.mockito.PowerMockito.when;

import java.text.MessageFormat;
import java.util.HashMap;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.internal.util.reflection.FieldSetter;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.lbg.epscw.mortgagesrvc.enums.RepaymentType;
import com.lbg.epscw.mortgagesrvc.helper.MortgageAccountOptionDataHelper;
import com.lbg.epscw.mortgagesrvc.model.AccountOptionsUpdateResponse;
import com.lbg.epscw.mortgagesrvc.model.VaultAccountOptionsUpdateRequest;
import com.lbg.epscw.mortgagesrvc.service.RestClientService;
import com.lbg.epscw.mortgagesrvc.util.MortgageServiceUtil;

@RunWith(PowerMockRunner.class)
@PrepareForTest({ MessageFormat.class })
public class MortgageAccountOptionRestClientTest {

	@Value("accountInstanceParamUpdateEndpoint")
	private String accountInstanceParamUpdateEndpoint;

	@Mock
	RestClientService restClientService;

	@Mock
	MortgageServiceUtil mortgageServiceUtil;

	@Autowired
	private ObjectMapper mapper;

	private MortgageAccountOptionDataHelper mortgageAccountDataHelper = new MortgageAccountOptionDataHelper();

	@InjectMocks
	private MortgageAccountOptionRestClient mortgageAccountOptionRestClient;

	@Before
	public void setup() {
		this.mapper = new ObjectMapper();
	}

	@Test
	public void update_acc_option_for_mortgage_type() throws JsonProcessingException, NoSuchFieldException, SecurityException {

		AccountOptionsUpdateResponse accountOptionsUpdateResponse = mortgageAccountDataHelper
				.buildAccountOptionsUpdateResponse(RepaymentType.INTEREST_ONLY.name(), KEY_MORTGAGE_TYPE);
		String stringyfyResponse = null;
		FieldSetter.setField(mortgageAccountOptionRestClient,
				mortgageAccountOptionRestClient.getClass().getDeclaredField("accountInstanceParamUpdateEndpoint"),"");

			stringyfyResponse = mapper.writeValueAsString(accountOptionsUpdateResponse);
		
		when(mortgageServiceUtil.fetchDefaultVaultHeaders()).thenReturn(new HashMap<String, String>());
		when(mortgageServiceUtil.writeObjectAsString(any(VaultAccountOptionsUpdateRequest.class)))
				.thenReturn(stringyfyResponse);

		when(mortgageServiceUtil.readObject(any(String.class), any(Class.class)))
				.thenReturn(accountOptionsUpdateResponse);

		when(restClientService.post(any(String.class), any(HashMap.class), any(String.class)))
				.thenReturn(stringyfyResponse);

		VaultAccountOptionsUpdateRequest vaultRequest = mortgageAccountDataHelper
				.buildVaultAccountOptionsUpdateRequest(RepaymentType.INTEREST_ONLY.name(), KEY_MORTGAGE_TYPE);
		
		String stringyfyRequest = mapper.writeValueAsString(accountOptionsUpdateResponse);
		
		
		AccountOptionsUpdateResponse response = mortgageAccountOptionRestClient.updateAccountOptions(vaultRequest);
		assertNotNull(response);
	}

	@Test
	public void update_acc_option_for_mortgage_term() throws NoSuchFieldException, SecurityException, JsonProcessingException {

		AccountOptionsUpdateResponse accountOptionsUpdateResponse = mortgageAccountDataHelper
				.buildAccountOptionsUpdateResponse("60", KEY_MORTGAGE_TERM);
		String stringyfyResponse = null;
			FieldSetter.setField(mortgageAccountOptionRestClient,
					mortgageAccountOptionRestClient.getClass().getDeclaredField("accountInstanceParamUpdateEndpoint"),"accountInstanceParamUpdateEndpoint");

			stringyfyResponse = mapper.writeValueAsString(accountOptionsUpdateResponse);
		
		when(mortgageServiceUtil.fetchDefaultVaultHeaders()).thenReturn(new HashMap<String, String>());
		when(mortgageServiceUtil.writeObjectAsString(any(VaultAccountOptionsUpdateRequest.class)))
				.thenReturn(stringyfyResponse);

		when(mortgageServiceUtil.readObject(any(String.class), any(Class.class)))
				.thenReturn(accountOptionsUpdateResponse);

		when(restClientService.post(any(String.class), any(HashMap.class), any(String.class)))
				.thenReturn(stringyfyResponse);

		VaultAccountOptionsUpdateRequest vaultRequest = mortgageAccountDataHelper
				.buildVaultAccountOptionsUpdateRequest("60", KEY_MORTGAGE_TERM);
		AccountOptionsUpdateResponse response = mortgageAccountOptionRestClient.updateAccountOptions(vaultRequest);
		assertNotNull(response);
	}
	
}
