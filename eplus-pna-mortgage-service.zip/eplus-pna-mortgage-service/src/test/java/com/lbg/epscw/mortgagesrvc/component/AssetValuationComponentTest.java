package com.lbg.epscw.mortgagesrvc.component;

import com.lbg.epscw.entitlement.service.EntitlementValidationServiceImpl;
import com.lbg.epscw.handler.model.ErrorInfo;
import com.lbg.epscw.handler.model.ErrorResponse;
import com.lbg.epscw.mortgagesrvc.helper.ComponentHelper;
import com.lbg.epscw.mortgagesrvc.helper.MortgagePortingHelper;
import com.lbg.epscw.mortgagesrvc.logger.HystrixContextCopyStrategy;
import com.lbg.epscw.mortgagesrvc.model.MortgageApplicationInfo;
import com.lbg.epscw.mortgagesrvc.model.MortgagePortingApplicationStatus;
import com.lbg.epscw.mortgagesrvc.model.PortingApplicationStatusResponse;
import com.lbg.epscw.mortgagesrvc.service.AssetValuationService;
import com.lbg.epscw.mortgagesrvc.service.MortgagePortingApplicationInfoService;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpHeaders;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import static com.lbg.epscw.mortgagesrvc.helper.MortgagePortingHelper.*;
import static com.lbg.epscw.mortgagesrvc.model.MortgagePortingApplicationStatus.*;
import static javax.servlet.http.HttpServletResponse.SC_BAD_REQUEST;
import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;

@Tag("component")
@ExtendWith(SpringExtension.class)
@SpringBootTest
@AutoConfigureMockMvc
public class AssetValuationComponentTest extends WebMVCTest {
    private final MortgagePortingHelper portingHelper = new MortgagePortingHelper();
    private final ComponentHelper componentHelper = new ComponentHelper();
    @MockBean
    private EntitlementValidationServiceImpl entitlement;
    @MockBean
    private HystrixContextCopyStrategy hystrixContextCopyStrategy;

    @MockBean
    private MortgagePortingApplicationInfoService infoService;

    @MockBean
    private AssetValuationService service;

    @Test
    public void verify_application_is_ready_for_valuation() {
        //given
        String payload = portingHelper.assetValuationPayload();
        HttpHeaders headers = portingHelper.getAccountInfoHeaders();
        MortgageApplicationInfo info = portingHelper.getMortgagePortingApplicationDetails();
        PortingApplicationStatusResponse expected = PortingApplicationStatusResponse.builder()
                .applicationNumber(APPLICATION_NUMBER).status(VALUATION_RECEIVED).build();
        when(service.captureAssetValuation(any(), any())).thenReturn(expected);
        when(infoService.getApplicationInfo(anyString())).thenReturn(info);

        //when
        MockHttpServletResponse response = doPOST(ASSET_VALUATION_ENDPOINT, payload, headers);
        String responseString = componentHelper.getServletResponseAsString(response);
        PortingApplicationStatusResponse actual = readObject(responseString, PortingApplicationStatusResponse.class);

        //then
        assertThat(response.getStatus(), is(200));
        assertThat(actual.getApplicationNumber(), is(APPLICATION_NUMBER));
        assertThat(actual.getStatus(), is(VALUATION_RECEIVED));
    }

    @Test
    public void reject_verification_when_application_has_empty_original_valuation() {
        //given
        MortgageApplicationInfo info = portingHelper.getMortgagePortingApplicationDetails();
        when(infoService.getApplicationInfo(anyString())).thenReturn(info);

        //when
        String payload = portingHelper.assetValuationPayloadWithoutOriginalValuation();
        HttpHeaders headers = portingHelper.getAccountInfoHeaders();

        MockHttpServletResponse response = doPOST(ASSET_VALUATION_ENDPOINT, payload, headers);
        String responseString = componentHelper.getServletResponseAsString(response);
        ErrorResponse actual = readObject(responseString, ErrorResponse.class);
        //then
        assertThat(response.getStatus(), is(400));
        assertThat(actual.getMessage(), is("Bad Request"));
    }

    @Test
    public void reject_verification_when_application_has_empty_date_original_valuation() {
        //given
        MortgageApplicationInfo info = portingHelper.getMortgagePortingApplicationDetails();
        when(infoService.getApplicationInfo(anyString())).thenReturn(info);

        //when
        String payload = portingHelper.assetValuationPayloadWithoutDateOriginalValuation();
        HttpHeaders headers = portingHelper.getAccountInfoHeaders();

        MockHttpServletResponse response = doPOST(ASSET_VALUATION_ENDPOINT, payload, headers);
        String responseString = componentHelper.getServletResponseAsString(response);
        ErrorResponse actual = readObject(responseString, ErrorResponse.class);
        System.out.println(actual);
        //then
        assertThat(response.getStatus(), is(400));
        assertThat(actual.getMessage(), is("Bad Request"));
    }

    @Test
    public void reject_verification_when_application_has_empty_amount_value_after_improvement() {
        //given
        MortgageApplicationInfo info = portingHelper.getMortgagePortingApplicationDetails();
        when(infoService.getApplicationInfo(anyString())).thenReturn(info);

        //when
        String payload = portingHelper.assetValuationPayloadWithoutAmountValueAfterImprovement();
        HttpHeaders headers = portingHelper.getAccountInfoHeaders();

        MockHttpServletResponse response = doPOST(ASSET_VALUATION_ENDPOINT, payload, headers);
        String responseString = componentHelper.getServletResponseAsString(response);
        ErrorResponse actual = readObject(responseString, ErrorResponse.class);
        System.out.println(actual);
        //then
        assertThat(response.getStatus(), is(400));
        assertThat(actual.getMessage(), is("Bad Request"));
    }

    @Test
    public void reject_verification_when_application_has_empty_insurance_valuation_amount() {
        //given
        MortgageApplicationInfo info = portingHelper.getMortgagePortingApplicationDetails();
        when(infoService.getApplicationInfo(anyString())).thenReturn(info);

        //when
        String payload = portingHelper.assetValuationPayloadWithoutInsuranceValuationAmount();
        HttpHeaders headers = portingHelper.getAccountInfoHeaders();

        MockHttpServletResponse response = doPOST(ASSET_VALUATION_ENDPOINT, payload, headers);
        String responseString = componentHelper.getServletResponseAsString(response);
        ErrorResponse actual = readObject(responseString, ErrorResponse.class);
        System.out.println(actual);
        //then
        assertThat(response.getStatus(), is(400));
        assertThat(actual.getMessage(), is("Bad Request"));
    }

    @Test
    public void reject_verification_when_application_has_incorrect_application_number() {
        //given
        MortgageApplicationInfo info = portingHelper.getMortgagePortingApplicationDetailsIncorrectApplicationNumber();
        when(infoService.getApplicationInfo(anyString())).thenReturn(info);

        //when
        String payload = portingHelper.assetValuationPayload();
        HttpHeaders headers = portingHelper.getAccountInfoHeaders();

        MockHttpServletResponse response = doPOST(ASSET_VALUATION_ENDPOINT_INCORRECT_APPLICATION_NUMBER, payload, headers);
        String responseString = componentHelper.getServletResponseAsString(response);
        ErrorResponse actual = readObject(responseString, ErrorResponse.class);
        System.out.println(actual);
        //then
        assertThat(response.getStatus(), is(400));
        assertThat(actual.getMessage(), is("Bad Request"));
    }

    @Test
    public void reject_verification_when_application_in_incorrect_state() {
        //given
        MortgageApplicationInfo info = portingHelper.getMortgagePortingApplicationDetailsIncorrectState();
        when(infoService.getApplicationInfo(anyString())).thenReturn(info);

        //when
        String payload = portingHelper.assetValuationPayload();
        HttpHeaders headers = portingHelper.getAccountInfoHeaders();

        MockHttpServletResponse response = doPOST(ASSET_VALUATION_ENDPOINT, payload, headers);
        String responseString = componentHelper.getServletResponseAsString(response);
        ErrorResponse actual = readObject(responseString, ErrorResponse.class);

        //then
        assertThat(response.getStatus(), is(400));
        assertThat(actual.getMessage(), is("Bad Request"));
    }

    @Test
    public void return_error_when_application_status_not_available() {
        //given
        MortgageApplicationInfo info = portingHelper.getMortgagePortingApplicationDetailsStateUnavailable();
        when(infoService.getApplicationInfo(anyString())).thenReturn(info);

        //when
        String payload = portingHelper.assetValuationPayload();
        HttpHeaders headers = portingHelper.getAccountInfoHeaders();
        MockHttpServletResponse response = doPOST(ASSET_VALUATION_ENDPOINT, payload, headers);

        //then
        assertThat(response.getStatus(), is(400));
    }

    @Test
    public void throws_exception_when_correlationId_is_missing() {
        //given
        HttpHeaders headers = portingHelper.getAccountInfoHeaders();
        headers.remove("x-lbg-txn-correlation-id");

        // when
        String payload = portingHelper.assetValuationPayload();
        MockHttpServletResponse response = doPOST(ASSET_VALUATION_ENDPOINT, payload, headers);
        ErrorInfo error = readErrorInfo(componentHelper.getServletResponseAsString(response));

        // then
        assertEquals(400, response.getStatus());
        assertEquals("PNA.MORTGAGE_API.POST_MORTGAGES_APPLICATION_ASSET_VALUATION.Header.Missing.x-lbg-txn-correlation-id", error.getReasonCode());
        assertEquals("Missing request header x-lbg-txn-correlation-id for method parameter of type String", error.getMessage());
    }

    @Test
    public void throws_exception_when_brand_is_missing() {
        //given
        HttpHeaders headers = portingHelper.getAccountInfoHeaders();
        headers.remove("x-lbg-brand");

        // when
        String payload = portingHelper.assetValuationPayload();
        MockHttpServletResponse response = doPOST(ASSET_VALUATION_ENDPOINT, payload, headers);
        ErrorInfo error = readErrorInfo(componentHelper.getServletResponseAsString(response));

        // then
        assertEquals(400, response.getStatus());
        assertEquals("PNA.MORTGAGE_API.POST_MORTGAGES_APPLICATION_ASSET_VALUATION.Header.Missing.x-lbg-brand", error.getReasonCode());
        assertEquals("Missing request header 'x-lbg-brand' for method parameter of type String", error.getMessage());
    }

    @Test
    public void throws_exception_when_channel_is_missing() {
        //given
        HttpHeaders headers = portingHelper.getAccountInfoHeaders();
        headers.remove("x-lbg-channel");

        // when
        String payload = portingHelper.assetValuationPayload();
        MockHttpServletResponse response = doPOST(ASSET_VALUATION_ENDPOINT, payload, headers);
        ErrorInfo error = readErrorInfo(componentHelper.getServletResponseAsString(response));

        // then
        assertEquals(400, response.getStatus());
        assertEquals("PNA.MORTGAGE_API.POST_MORTGAGES_APPLICATION_ASSET_VALUATION.Header.Missing.x-lbg-channel", error.getReasonCode());
        assertEquals("Missing request header 'x-lbg-channel' for method parameter of type String", error.getMessage());
    }

    @Test
    public void throws_exception_when_brand_name_is_invalid() {
        //given
        HttpHeaders headers = portingHelper.getAccountInfoHeaders();
        headers.set("x-lbg-brand", "invalid");

        // when
        String payload = portingHelper.assetValuationPayload();
        MockHttpServletResponse response = doPOST(ASSET_VALUATION_ENDPOINT, payload, headers);
        ErrorInfo error = readErrorInfo(componentHelper.getServletResponseAsString(response));

        // then
        assertEquals(400, response.getStatus());
        assertEquals("PNA.MORTGAGE_API.POST_MORTGAGES_APPLICATION_ASSET_VALUATION.Header.Invalid", error.getReasonCode());
        assertEquals("Invalid enum value for type x-lbg-brand", error.getMessage());
    }

    @Test
    public void reject_verification_when_application_invalid_status() {
        assertThatInvalidStatusThrowsError(OPEN);
        assertThatInvalidStatusThrowsError(SUBMITTED);
        assertThatInvalidStatusThrowsError(APPROVED);
        assertThatInvalidStatusThrowsError(DECLINED);
        assertThatInvalidStatusThrowsError(APPROVED_WITH_CONDITIONS);
        assertThatInvalidStatusThrowsError(VALUATION_RECEIVED);
        assertThatInvalidStatusThrowsError(REPROCESS);
        assertThatInvalidStatusThrowsError(OFFERED);
        assertThatInvalidStatusThrowsError(FUNDS_RELEASED);
        assertThatInvalidStatusThrowsError(REOPEN);
        assertThatInvalidStatusThrowsError(RESUBMITTED);
    }

    private void assertThatInvalidStatusThrowsError(MortgagePortingApplicationStatus fromStatus) {
        //given
        MortgageApplicationInfo info = MortgageApplicationInfo.builder().status(fromStatus).build();
        when(infoService.getApplicationInfo(anyString())).thenReturn(info);
        String payload = portingHelper.assetValuationPayload();
        //when
        HttpHeaders headers = portingHelper.getAccountInfoHeaders();
        MockHttpServletResponse response = doPOST(ASSET_VALUATION_ENDPOINT, payload, headers);
        ErrorInfo error = readErrorInfo(componentHelper.getServletResponseAsString(response));
        //then
        assertThat(response.getStatus(), is(SC_BAD_REQUEST));
        assertEquals("PNA.MORTGAGE_API.POST_MORTGAGES_APPLICATION_ASSET_VALUATION.MortgagePortingApplication.InvalidStatus", error.getReasonCode());
        assertEquals("Invalid Data", error.getMessage());
    }
}