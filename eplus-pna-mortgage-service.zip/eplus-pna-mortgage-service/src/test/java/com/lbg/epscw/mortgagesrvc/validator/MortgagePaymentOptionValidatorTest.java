package com.lbg.epscw.mortgagesrvc.validator;

import com.lbg.epscw.mortgagesrvc.dto.MortgageAccountInfo;
import com.lbg.epscw.mortgagesrvc.exception.InvalidUpdateRequestException;
import com.lbg.epscw.mortgagesrvc.helper.MortgagePaymentOptionHelper;
import com.lbg.epscw.mortgagesrvc.model.MortgagePaymentOptionRequest;
import com.lbg.epscw.mortgagesrvc.restclient.MortgageAccountInfoRestClient;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.HashMap;
import java.util.Map;

import static org.mockito.ArgumentMatchers.any;
import static org.powermock.api.mockito.PowerMockito.mock;
import static org.powermock.api.mockito.PowerMockito.when;

@RunWith(SpringRunner.class)
public class MortgagePaymentOptionValidatorTest {

    @Mock
    private MortgageAccountInfoRestClient mortgageAccountInfoRestClient;

    @Before
    public void setup() {
        mortgageAccountInfoRestClient = mock(MortgageAccountInfoRestClient.class);
    }

    MortgagePaymentOptionHelper mortgagePaymentOptionHelper = new MortgagePaymentOptionHelper();

    @Test(expected = InvalidUpdateRequestException.class)
    public void validateUpdateMortgagePaymentOption_SetupMPOAtSubAccLevel(){
        MortgagePaymentOptionRequest mortgagePaymentOptionRequest = mortgagePaymentOptionHelper.getMortgagePaymentRequest();
        MortgageAccountInfo mortgageAccountInfo=mortgagePaymentOptionHelper.mortgageAccountInfo_mortgagePaymentOptionMock();
        Map<String,String> reqMap= new HashMap<>();
        String accountId="5a688301-6d00-485c-0242-1ee03844a5c4";
        MortgagePaymentOptionValidator mortgagePaymentOptionValidator= new MortgagePaymentOptionValidator(mortgageAccountInfoRestClient);
        when(mortgageAccountInfoRestClient.getMortgageAccountInfo(any(String.class),any(Map.class))).thenReturn(mortgageAccountInfo);
        mortgagePaymentOptionValidator.validateUpdateMortgagePaymentOption(accountId,reqMap);
    }

    @Test(expected = InvalidUpdateRequestException.class)
    public void validateUpdateMortgagePaymentOption_SetupMPOAtOffsettingOption2(){
        MortgagePaymentOptionRequest mortgagePaymentOptionRequest = mortgagePaymentOptionHelper.getMortgagePaymentRequest();
        MortgageAccountInfo mortgageAccountInfo=mortgagePaymentOptionHelper.mortgageAccountInfo_mortgagePaymentOptionMock2();
        Map<String,String> reqMap= new HashMap<>();
        String accountId="5a688301-6d00-485c-0242-1ee03844a5c4";
        MortgagePaymentOptionValidator mortgagePaymentOptionValidator= new MortgagePaymentOptionValidator(mortgageAccountInfoRestClient);
        when(mortgageAccountInfoRestClient.getMortgageAccountInfo(any(String.class),any(Map.class))).thenReturn(mortgageAccountInfo);
        mortgagePaymentOptionValidator.validateUpdateMortgagePaymentOption(accountId,reqMap);
    }

    @Test
    public void validateUpdateMortgagePaymentOption_SetupMPOAtOffsettingOption1(){
        MortgagePaymentOptionRequest mortgagePaymentOptionRequest = mortgagePaymentOptionHelper.getMortgagePaymentRequest();
        MortgageAccountInfo mortgageAccountInfo=mortgagePaymentOptionHelper.mortgageAccountInfo_withOffsetting();
        Map<String,String> reqMap= new HashMap<>();
        String accountId="6965d050-d8fd-7fc3-4b66-41e72168be27";
        MortgagePaymentOptionValidator mortgagePaymentOptionValidator= new MortgagePaymentOptionValidator(mortgageAccountInfoRestClient);
        when(mortgageAccountInfoRestClient.getMortgageAccountInfo(any(String.class),any(Map.class))).thenReturn(mortgageAccountInfo);
        mortgagePaymentOptionValidator.validateUpdateMortgagePaymentOption(accountId,reqMap);
    }
}
