package com.lbg.epscw.mortgagesrvc.component;

import com.lbg.epscw.entitlement.service.EntitlementValidationServiceImpl;
import com.lbg.epscw.handler.model.ErrorInfo;
import com.lbg.epscw.handler.model.ErrorResponse;
import com.lbg.epscw.mortgagesrvc.helper.ComponentHelper;
import com.lbg.epscw.mortgagesrvc.helper.MortgageAccountClosureHelper;
import com.lbg.epscw.mortgagesrvc.logger.HystrixContextCopyStrategy;
import com.lbg.epscw.mortgagesrvc.model.AccountClosureResponse;
import com.lbg.epscw.mortgagesrvc.service.RestClientService;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.invocation.InvocationOnMock;
import org.mockito.stubbing.Answer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.context.ApplicationContext;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import java.util.HashMap;

import static org.junit.jupiter.api.Assertions.assertAll;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.powermock.api.mockito.PowerMockito.when;

@Tag("component")
@ExtendWith(SpringExtension.class)
@SpringBootTest
@AutoConfigureMockMvc
public class AccountClosureComponentTest extends WebMVCTest{

    private static final String ACCOUNT_CLOSURE_ENDPOINT =
            "/mortgages/b2c9119f-09e5-4ac9-9738-9e28b334d3fa/account-closure/";

    @MockBean
    RestClientService restClientService;

    @MockBean
    private HystrixContextCopyStrategy hystrixContextCopyStrategy;

    @MockBean
    private EntitlementValidationServiceImpl entitlementValidationService;

    @Autowired
    private ApplicationContext context;

    private ComponentHelper componentHelper = new ComponentHelper();

    private MortgageAccountClosureHelper mortgageAccountClosureHelper = new MortgageAccountClosureHelper();

    @Test
    public void shouldCloseOverarchingAccount() {
        //given
        when(restClientService.get(any(String.class), any(HashMap.class)))
                .thenReturn(mortgageAccountClosureHelper.getMortgageQueryServiceResponse());

        when(restClientService.put(any(String.class), any(HashMap.class), any(String.class))).thenAnswer(new Answer() {
            private int count = 0;

            public Object answer(InvocationOnMock invocation) {
                if (count++ == 1)
                    return mortgageAccountClosureHelper.getAccountStatusUpdateVaultResponseWithCloseStatus();

                return mortgageAccountClosureHelper.getAccountStatusUpdateVaultResponse();
            }
        });

        //when
        MockHttpServletResponse servletResponse = doPOST(ACCOUNT_CLOSURE_ENDPOINT,
                "",
                mortgageAccountClosureHelper.getAccountInfoHeaders());
        String responseString = componentHelper.getServletResponseAsString(servletResponse);
        AccountClosureResponse response = (AccountClosureResponse) readObject(responseString, AccountClosureResponse.class);

        //then
        assertAll(
                () -> assertEquals("b2c9119f-09e5-4ac9-9738-9e28b334d3fa", response.getAccountId()),
                () -> assertEquals("ACCOUNT_STATUS_CLOSED", response.getStatus())

        );
    }

    @Test
    public void shouldCloseOverarchingAccountWithStatusPendingClosure() {
        //given
        when(restClientService.get(any(String.class), any(HashMap.class)))
                .thenReturn(mortgageAccountClosureHelper.getMortgageQueryServiceResponseWithStatusPendingClosure());
        when(restClientService.put(any(String.class), any(HashMap.class), any(String.class)))
                .thenReturn(mortgageAccountClosureHelper.getAccountStatusUpdateVaultResponseWithCloseStatus());

        //when
        MockHttpServletResponse servletResponse = doPOST(ACCOUNT_CLOSURE_ENDPOINT,
                "",
                mortgageAccountClosureHelper.getAccountInfoHeaders());
        String responseString = componentHelper.getServletResponseAsString(servletResponse);
        AccountClosureResponse response = (AccountClosureResponse) readObject(responseString, AccountClosureResponse.class);

        //then
        assertAll(
                () -> assertEquals("b2c9119f-09e5-4ac9-9738-9e28b334d3fa", response.getAccountId()),
                () -> assertEquals("ACCOUNT_STATUS_CLOSED", response.getStatus())

        );
    }


    @Test
    public void shouldNotAllowClosingOverarchingAccountWithPendingOpenSubAccount() {
        //given
        when(restClientService.get(any(String.class), any(HashMap.class)))
                .thenReturn(mortgageAccountClosureHelper.getMortgageQueryServiceResponseWithPendingOpenSubAccount());

        //when
        MockHttpServletResponse servletResponse = doPOST(ACCOUNT_CLOSURE_ENDPOINT,
                "",
                mortgageAccountClosureHelper.getAccountInfoHeaders());
        String responseString = componentHelper.getServletResponseAsString(servletResponse);
        ErrorResponse errorResponse = (ErrorResponse) readObject(responseString, ErrorResponse.class);
        ErrorInfo errorInfo = errorResponse.getErrors().get(0);

        //then
        assertAll(
                () -> assertEquals(400, servletResponse.getStatus()),
                () -> assertEquals("PNA.MORTGAGE_API.SYS.001", errorResponse.getCode()),
                () -> assertEquals("Bad Request", errorResponse.getMessage()),
                () -> assertEquals("PNA.MORTGAGE_API.POST_MORTGAGES_ACCOUNT_CLOSURE.PENDING_OPEN_SUBACCOUNT.Error", errorInfo.getReasonCode())

        );
    }

    @Test
    public void shouldNotAllowClosingOverarchingAccountWithPendingOverarchingBalance() {
        //given
        when(restClientService.get(any(String.class), any(HashMap.class)))
                .thenReturn(mortgageAccountClosureHelper.getMortgageQueryServiceResponseWithPendingBalance());

        //when
        MockHttpServletResponse servletResponse = doPOST(ACCOUNT_CLOSURE_ENDPOINT,
                "",
                mortgageAccountClosureHelper.getAccountInfoHeaders());
        String responseString = componentHelper.getServletResponseAsString(servletResponse);
        ErrorResponse errorResponse = (ErrorResponse) readObject(responseString, ErrorResponse.class);
        ErrorInfo errorInfo = errorResponse.getErrors().get(0);

        //then
        assertAll(
                () -> assertEquals(400, servletResponse.getStatus()),
                () -> assertEquals("PNA.MORTGAGE_API.SYS.001", errorResponse.getCode()),
                () -> assertEquals("Bad Request", errorResponse.getMessage()),
                () -> assertEquals("PNA.MORTGAGE_API.POST_MORTGAGES_ACCOUNT_CLOSURE.PENDING_BAL_OVERARCHING_ACC.Error", errorInfo.getReasonCode())

        );
    }
}
