package com.lbg.epscw.mortgagesrvc.component;

import com.lbg.epscw.entitlement.service.EntitlementValidationServiceImpl;
import com.lbg.epscw.handler.model.ErrorInfo;
import com.lbg.epscw.handler.model.ErrorResponse;
import com.lbg.epscw.mortgagesrvc.helper.ComponentHelper;
import com.lbg.epscw.mortgagesrvc.helper.MortgagePortingHelper;
import com.lbg.epscw.mortgagesrvc.logger.HystrixContextCopyStrategy;
import com.lbg.epscw.mortgagesrvc.model.AccountPortingStatusResponse;
import com.lbg.epscw.mortgagesrvc.model.AccountStatusUpdateRequest;
import com.lbg.epscw.mortgagesrvc.service.RestClientService;
import org.apache.commons.lang.RandomStringUtils;
import org.junit.Assert;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.invocation.InvocationOnMock;
import org.mockito.stubbing.Answer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.context.ApplicationContext;
import org.springframework.http.HttpHeaders;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import java.util.HashMap;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertAll;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.powermock.api.mockito.PowerMockito.when;

@Tag("component")
@ExtendWith(SpringExtension.class)
@SpringBootTest
@AutoConfigureMockMvc
public class MortgagePortingAccountStatusComponentTest extends WebMVCTest{

    private static final String ACCOUNT_STATUS_UPDATE_ENDPOINT =
            "/mortgages/account-status/";

    @MockBean
    RestClientService restClientService;

    @MockBean
    private HystrixContextCopyStrategy hystrixContextCopyStrategy;

    @MockBean
    private EntitlementValidationServiceImpl entitlementValidationService;

    @Autowired
    private ApplicationContext context;

    private ComponentHelper componentHelper = new ComponentHelper();

    private MortgagePortingHelper mortgagePortingHelper = new MortgagePortingHelper();

    @Test
    public void shouldUpdateAccountStatusForNewlyPortedMortgage() {
        //given
        AccountStatusUpdateRequest accountStatusUpdateRequest = mortgagePortingHelper.buildAccountStatusUpdateRequestWithOverarchingAndSubAccountAndStatusOpen();
        when(restClientService.get(any(String.class), any(HashMap.class)))
                .thenReturn(mortgagePortingHelper.getMortgageInfoServiceResponse());

        when(restClientService.put(any(String.class), any(HashMap.class), any(String.class))).thenAnswer(new Answer() {
            private int count = 0;

            public Object answer(InvocationOnMock invocation) {
                if (count++ == 1)
                    return mortgagePortingHelper.getAccountStatusUpdateVaultResponseRepaymentAccount();

                return mortgagePortingHelper.getAccountStatusUpdateVaultResponseSubAccount();
            }
        });

        //when
        MockHttpServletResponse servletResponse = doPUT(ACCOUNT_STATUS_UPDATE_ENDPOINT,
                componentHelper.writeValueAsString(accountStatusUpdateRequest),
                mortgagePortingHelper.getAccountInfoHeaders());
        String responseString = componentHelper.getServletResponseAsString(servletResponse);
        List<AccountPortingStatusResponse> response = readList(responseString, AccountPortingStatusResponse.class);

        //then
        assertAll(
                () -> assertEquals("1601d0e5-e336-64d9-64ad-89ba6fdc2677", response.get(0).getAccountId()),
                () -> assertEquals("ACCOUNT_STATUS_OPEN", response.get(0).getStatus())


        );
    }

    @Test
    public void shouldUpdateAccountStatusAsPerRequest() {
        //given
        AccountStatusUpdateRequest accountStatusUpdateRequest = mortgagePortingHelper.buildAccountStatusUpdateRequestWithOverarchingAndSubAccountAndStatusCancel();
        when(restClientService.get(any(String.class), any(HashMap.class)))
                .thenReturn(mortgagePortingHelper.getMortgageInfoServiceResponse());

        when(restClientService.put(any(String.class), any(HashMap.class), any(String.class))).thenAnswer(new Answer() {
            private int count = 0;

            public Object answer(InvocationOnMock invocation) {
                if (count++ == 1)
                    return mortgagePortingHelper.getAccountStatusUpdateVaultResponseRepaymentAccountWithStatusCancelled();

                return mortgagePortingHelper.getAccountStatusUpdateVaultResponseSubAccountWithStatusCancelled();
            }
        });

        //when
        MockHttpServletResponse servletResponse = doPUT(ACCOUNT_STATUS_UPDATE_ENDPOINT,
                componentHelper.writeValueAsString(accountStatusUpdateRequest),
                mortgagePortingHelper.getAccountInfoHeaders());
        String responseString = componentHelper.getServletResponseAsString(servletResponse);
        List<AccountPortingStatusResponse> response = readList(responseString, AccountPortingStatusResponse.class);

        //then
        assertAll(
                () -> assertEquals("1601d0e5-e336-64d9-64ad-89ba6fdc2677", response.get(0).getAccountId()),
                () -> assertEquals("ACCOUNT_STATUS_CANCELLED", response.get(0).getStatus())


        );
    }

    @Test
    public void shouldUpdateAccountStatusForAllSubaccountWhenOnlyPassedMortgageOverarchingAccount() {
        //given
        AccountStatusUpdateRequest accountStatusUpdateRequest = mortgagePortingHelper.buildAccountStatusUpdateRequestWithOnlyOverarchingAndCancelStatus();

        when(restClientService.get(any(String.class), any(HashMap.class)))
                .thenReturn(mortgagePortingHelper.getMortgageInfoServiceResponse());

        when(restClientService.put(any(String.class), any(HashMap.class), any(String.class))).thenAnswer(new Answer() {
            private int count = 0;

            public Object answer(InvocationOnMock invocation) {
                if (count++ == 1)
                    return mortgagePortingHelper.getAccountStatusUpdateVaultResponseRepaymentAccountWithStatusCancelled();

                return mortgagePortingHelper.getAccountStatusUpdateVaultResponseSubAccountWithStatusCancelled();
            }
        });

        //when
        MockHttpServletResponse servletResponse = doPUT(ACCOUNT_STATUS_UPDATE_ENDPOINT,
                componentHelper.writeValueAsString(accountStatusUpdateRequest),
                mortgagePortingHelper.getAccountInfoHeaders());
        String responseString = componentHelper.getServletResponseAsString(servletResponse);
        List<AccountPortingStatusResponse> response = readList(responseString, AccountPortingStatusResponse.class);

        //then
        assertAll(
                () -> assertEquals("1601d0e5-e336-64d9-64ad-89ba6fdc2677", response.get(0).getAccountId()),
                () -> assertEquals("ACCOUNT_STATUS_CANCELLED", response.get(0).getStatus())



        );
    }

    @Test
    public void shouldNotAllowUpdateAccountStatusForNewlyPortedMortgage() {
        //given
        AccountStatusUpdateRequest accountStatusUpdateRequest = mortgagePortingHelper.buildAccountStatusUpdateRequestWithOnlyOverarchingAndCancelStatus();

        when(restClientService.get(any(String.class), any(HashMap.class)))
           .thenReturn(mortgagePortingHelper.getMortgageInfoServiceResponseWithPendingClosureStatus());

        //when
        MockHttpServletResponse servletResponse = doPUT(ACCOUNT_STATUS_UPDATE_ENDPOINT,
                componentHelper.writeValueAsString(accountStatusUpdateRequest),
                mortgagePortingHelper.getAccountInfoHeaders());
        String responseString = componentHelper.getServletResponseAsString(servletResponse);
        ErrorResponse errorResponse =  readObject(responseString, ErrorResponse.class);
        ErrorInfo errorInfo = errorResponse.getErrors().get(0);

        //then
        assertAll(
                () -> assertEquals(400, servletResponse.getStatus()),
                () -> assertEquals("PNA.MORTGAGE_API.BUS.601", errorResponse.getCode()),
                () -> assertEquals("Invalid Update Request", errorResponse.getMessage()),
                () -> assertEquals("PNA.MORTGAGE_API.PUT_MORTGAGES_ACCOUNT_STATUS.Status.Invalid", errorInfo.getReasonCode())

        );
    }

    @Test
    public void shouldReturnErrorForEmptyJson() {
        //when
        MockHttpServletResponse servletResponse = doPUT(ACCOUNT_STATUS_UPDATE_ENDPOINT,
                "{}",
                mortgagePortingHelper.getAccountInfoHeaders());

        String responseString = componentHelper.getServletResponseAsString(servletResponse);
        ErrorResponse errorResponse = (ErrorResponse) readObject(responseString, ErrorResponse.class);
        ErrorInfo errorInfo = errorResponse.getErrors().get(0);

        //then
        assertAll(
                () -> Assert.assertEquals(400, servletResponse.getStatus()),
                () -> Assert.assertEquals("PNA.MORTGAGE_API.SYS.001", errorResponse.getCode()),
                () -> Assert.assertEquals("Bad Request", errorResponse.getMessage())

        );
    }

    @Test
    public void shouldReturnErrorForEmptyRequestBody() {
        //given
        //when
        MockHttpServletResponse servletResponse = doPUT(ACCOUNT_STATUS_UPDATE_ENDPOINT,
                "",
                mortgagePortingHelper.getAccountInfoHeaders());

        String responseString = componentHelper.getServletResponseAsString(servletResponse);
        ErrorResponse errorResponse = (ErrorResponse) readObject(responseString, ErrorResponse.class);
        ErrorInfo errorInfo = errorResponse.getErrors().get(0);

        //then
        assertAll(
                () -> Assert.assertEquals(400, servletResponse.getStatus()),
                () -> Assert.assertEquals("PNA.MORTGAGE_API.SYS.001", errorResponse.getCode()),
                () -> Assert.assertEquals("Bad Request", errorResponse.getMessage())

        );
    }

    @Test
    public void shouldReturnErrorForUpdateWhenOverarchingAccountIdIsLessThan36Chars() {

        //given
        AccountStatusUpdateRequest accountStatusUpdateRequest = mortgagePortingHelper.buildAccountStatusUpdateRequestWithOnlyOverarchingAndCancelStatus();
        accountStatusUpdateRequest.setOverarchingAccount("b2c9119f-09e5-4ac9-9738-9e28b334fa");

        //when
        MockHttpServletResponse servletResponse = doPUT("/mortgages/account-status",
                componentHelper.writeValueAsString(accountStatusUpdateRequest),
                mortgagePortingHelper.getAccountInfoHeaders());
        String responseString = componentHelper.getServletResponseAsString(servletResponse);
        ErrorResponse errorResponse = (ErrorResponse) readObject(responseString, ErrorResponse.class);
        ErrorInfo errorInfo = errorResponse.getErrors().get(0);

        //then
        assertAll(
                () -> Assert.assertEquals(400, servletResponse.getStatus()),
                () -> Assert.assertEquals("PNA.MORTGAGE_API.SYS.001", errorResponse.getCode()),
                () -> Assert.assertEquals("Bad Request", errorResponse.getMessage()),
                () -> Assert.assertEquals("OverarchingAccount AccountId should be min 36 characters", errorInfo.getMessage())
        );
    }

    @Test
    public void shouldReturnErrorForUpdateWhenOverarchingAccountIdIsMoreThan36Chars() {

        //given
        AccountStatusUpdateRequest accountStatusUpdateRequest = mortgagePortingHelper.buildAccountStatusUpdateRequestWithOnlyOverarchingAndCancelStatus();
        accountStatusUpdateRequest.setOverarchingAccount("b2c9119f-09e5-4ac9-9738-9e28b334d3fa34");

        //when
        MockHttpServletResponse servletResponse = doPUT("/mortgages/account-status",
                componentHelper.writeValueAsString(accountStatusUpdateRequest),
                mortgagePortingHelper.getAccountInfoHeaders());
        String responseString = componentHelper.getServletResponseAsString(servletResponse);
        ErrorResponse errorResponse = (ErrorResponse) readObject(responseString, ErrorResponse.class);
        ErrorInfo errorInfo = errorResponse.getErrors().get(0);

        //then
        assertAll(
                () -> Assert.assertEquals(400, servletResponse.getStatus()),
                () -> Assert.assertEquals("PNA.MORTGAGE_API.SYS.001", errorResponse.getCode()),
                () -> Assert.assertEquals("Bad Request", errorResponse.getMessage()),
                () -> Assert.assertEquals("OverarchingAccount AccountId should be max 36 characters", errorInfo.getMessage())
        );
    }


    @Test
    public void shouldReturnErrorForUpdateWhenCorrelationIdIsGreaterThanFortyCharacters() {
        //given

        AccountStatusUpdateRequest accountStatusUpdateRequest = mortgagePortingHelper.buildAccountStatusUpdateRequestWithOnlyOverarchingAndCancelStatus();

        HttpHeaders accountInfoHeaders = mortgagePortingHelper.getAccountInfoHeaders();
        accountInfoHeaders.set("x-lbg-txn-correlation-id", RandomStringUtils.random(50));
        //when
        MockHttpServletResponse servletResponse = doPUT(ACCOUNT_STATUS_UPDATE_ENDPOINT,
                componentHelper.writeValueAsString(accountStatusUpdateRequest),
                accountInfoHeaders);
        String responseString = componentHelper.getServletResponseAsString(servletResponse);
        ErrorResponse errorResponse = (ErrorResponse) readObject(responseString, ErrorResponse.class);
        ErrorInfo errorInfo = errorResponse.getErrors().get(0);

        //then
        assertAll(
                () -> Assert.assertEquals(400, servletResponse.getStatus()),
                () -> Assert.assertEquals("PNA.MORTGAGE_API.SYS.001", errorResponse.getCode()),
                () -> Assert.assertEquals("Bad Request", errorResponse.getMessage()),
                () -> Assert.assertEquals("x-lbg-txn-correlation-id size should be between 10 and 40", errorInfo.getMessage())
        );
    }

    @Test
    public void shouldReturnErrorForUpdateWhenCorrelationIdIsLessThanTenCharacters() {
        //given
        AccountStatusUpdateRequest accountStatusUpdateRequest = mortgagePortingHelper.buildAccountStatusUpdateRequestWithOnlyOverarchingAndCancelStatus();
        HttpHeaders accountInfoHeaders = mortgagePortingHelper.getAccountInfoHeaders();
        accountInfoHeaders.set("x-lbg-txn-correlation-id", RandomStringUtils.random(50));
        //when
        MockHttpServletResponse servletResponse = doPUT(ACCOUNT_STATUS_UPDATE_ENDPOINT,
                componentHelper.writeValueAsString(accountStatusUpdateRequest),
                accountInfoHeaders);
        String responseString = componentHelper.getServletResponseAsString(servletResponse);
        ErrorResponse errorResponse = (ErrorResponse) readObject(responseString, ErrorResponse.class);
        ErrorInfo errorInfo = errorResponse.getErrors().get(0);

        //then
        assertAll(
                () -> Assert.assertEquals(400, servletResponse.getStatus()),
                () -> Assert.assertEquals("PNA.MORTGAGE_API.SYS.001", errorResponse.getCode()),
                () -> Assert.assertEquals("Bad Request", errorResponse.getMessage()),
                () -> Assert.assertEquals("x-lbg-txn-correlation-id size should be between 10 and 40", errorInfo.getMessage())
        );
    }

    @Test
    public void shouldReturnErrorForUpdateWhenCorrelationIdIsMissing() {
        //given
        AccountStatusUpdateRequest accountStatusUpdateRequest = mortgagePortingHelper.buildAccountStatusUpdateRequestWithOnlyOverarchingAndCancelStatus();
        HttpHeaders accountInfoHeaders = mortgagePortingHelper.getAccountInfoHeaders();
        accountInfoHeaders.remove("x-lbg-txn-correlation-id");
        //when
        MockHttpServletResponse servletResponse = doPUT(ACCOUNT_STATUS_UPDATE_ENDPOINT,
                componentHelper.writeValueAsString(accountStatusUpdateRequest),
                accountInfoHeaders);
        String responseString = componentHelper.getServletResponseAsString(servletResponse);
        ErrorResponse errorResponse = (ErrorResponse) readObject(responseString, ErrorResponse.class);
        ErrorInfo errorInfo = errorResponse.getErrors().get(0);

        //then
        assertAll(
                () -> Assert.assertEquals(400, servletResponse.getStatus()),
                () -> Assert.assertEquals("PNA.MORTGAGE_API.SYS.001", errorResponse.getCode()),
                () -> Assert.assertEquals("Bad Request", errorResponse.getMessage()),
                () -> Assert.assertEquals("Missing request header x-lbg-txn-correlation-id for method parameter of type String", errorInfo.getMessage())
        );
    }


    @Test
    public void shouldReturnErrorForUpdateWhenBrandIsMissing() {
        //given
        HttpHeaders accountInfoHeaders = mortgagePortingHelper.getAccountInfoHeaders();
        accountInfoHeaders.remove("x-lbg-brand");
        //when
        MockHttpServletResponse servletResponse = doPUT(ACCOUNT_STATUS_UPDATE_ENDPOINT,
                "",
                accountInfoHeaders);
        String responseString = componentHelper.getServletResponseAsString(servletResponse);
        ErrorResponse errorResponse = (ErrorResponse) readObject(responseString, ErrorResponse.class);
        ErrorInfo errorInfo = errorResponse.getErrors().get(0);

        //then
        assertAll(
                () -> Assert.assertEquals(400, servletResponse.getStatus()),
                () -> Assert.assertEquals("PNA.MORTGAGE_API.SYS.001", errorResponse.getCode()),
                () -> Assert.assertEquals("Bad Request", errorResponse.getMessage()),
                () -> Assert.assertEquals("Missing request header 'x-lbg-brand' for method parameter of type String", errorInfo.getMessage())
        );
    }

}
