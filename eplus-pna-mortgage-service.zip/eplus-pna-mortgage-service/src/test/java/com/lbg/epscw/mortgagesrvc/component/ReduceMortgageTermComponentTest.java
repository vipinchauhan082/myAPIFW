package com.lbg.epscw.mortgagesrvc.component;

import com.lbg.epscw.entitlement.service.EntitlementValidationServiceImpl;
import com.lbg.epscw.handler.constants.SystemErrors;
import com.lbg.epscw.handler.exception.RestServiceException;
import com.lbg.epscw.handler.model.ErrorInfo;
import com.lbg.epscw.handler.model.ErrorResponse;
import com.lbg.epscw.mortgagesrvc.constants.CommonConstants;
import com.lbg.epscw.mortgagesrvc.helper.ComponentHelper;
import com.lbg.epscw.mortgagesrvc.helper.MortgageAccountDataHelper;
import com.lbg.epscw.mortgagesrvc.helper.MortgageAccountOptionDataHelper;
import com.lbg.epscw.mortgagesrvc.logger.HystrixContextCopyStrategy;
import com.lbg.epscw.mortgagesrvc.model.MortgageOptionsUpdateResponse;
import com.lbg.epscw.mortgagesrvc.model.VaultAccountOptionsUpdateRequest;
import com.lbg.epscw.mortgagesrvc.restclient.MortgageAccountOptionRestClient;
import com.lbg.epscw.mortgagesrvc.restclient.MortgageTermReductionCalcRestClient;
import com.lbg.epscw.mortgagesrvc.service.RestClientService;
import org.apache.commons.lang.RandomStringUtils;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mockito;
import org.mockito.internal.util.MockUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.context.ApplicationContext;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import java.util.HashMap;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertAll;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.powermock.api.mockito.PowerMockito.when;

@Tag("component")
@ExtendWith(SpringExtension.class)
@SpringBootTest
@AutoConfigureMockMvc
public class ReduceMortgageTermComponentTest extends WebMVCTest{

    private static final String REDUCE_MORTGAGE_TERM =
            "/mortgages/1601d0e5-e336-64d9-64ad-89ba6fdc2677/term-reduction";

    private MortgageAccountOptionDataHelper accountOptionHelper = new MortgageAccountOptionDataHelper();

    private MortgageAccountDataHelper accountHelper = new MortgageAccountDataHelper();

    private ComponentHelper componentHelper;

    @MockBean
    private MortgageTermReductionCalcRestClient mortgageTermReductionCalcRestClient;

    @MockBean
    private MortgageAccountOptionRestClient mortgageAccountOptionRestClient;

    @Value("vault.access.token")
    private String vaultAccessToken;

    @Value("workflow.username")
    private String workFlowUserName;

    @Value("workflow.password")
    private String workflowPassword;

    @MockBean
    private EntitlementValidationServiceImpl entitlementValidationService;

    @MockBean
    RestClientService restClientService;

    @Autowired
    private ApplicationContext context;


    @MockBean
    private HystrixContextCopyStrategy hystrixContextCopyStrategy;

    @BeforeEach
    public void beforeEach() {
        componentHelper = new ComponentHelper();
        for (String name : context.getBeanDefinitionNames()) {
            Object bean = context.getBean(name);
            if (MockUtil.isMock(bean)) {
                Mockito.reset(bean);
            }
        }
    }

    @Test
    public void shouldReduceMortgageTerm() throws NoSuchFieldException, SecurityException {

        when(mortgageTermReductionCalcRestClient.getMortgageTermReductionInfo(any(String.class), any(HashMap.class))).thenReturn(accountHelper.buildViewMortgageTermReductionResponse("22","20","3"));

        when(mortgageAccountOptionRestClient.updateAccountOptions(any(VaultAccountOptionsUpdateRequest.class)))
                .thenReturn(accountOptionHelper.buildAccountOptionsUpdateResponse(CommonConstants.KEY_MORTGAGE_TERM, "12"));

        // when
        MockHttpServletResponse servletResponse = doPUT(REDUCE_MORTGAGE_TERM, null, accountOptionHelper.getAccountInfoHeaders());
        String responseString = componentHelper.getServletResponseAsString(servletResponse);
        MortgageOptionsUpdateResponse viewAccountOptions = (MortgageOptionsUpdateResponse) readObject(responseString, MortgageOptionsUpdateResponse.class);
        Map<String, String> accountOptions = viewAccountOptions.getInstanceParamVals();

        //then
        assertEquals("1601d0e5-e336-64d9-64ad-89ba6fdc2677", viewAccountOptions.getAccountId());
        assertEquals("ACCOUNT_UPDATE_STATUS_PENDING_EXECUTION", viewAccountOptions.getStatus());
        assertEquals("12", accountOptions.get(CommonConstants.KEY_TOTAL_TERM));
    }

    @Test
    public void shouldNotReduceMortgageTermIfUpdatedTotalTermIsEqualToRemainingTerm() throws NoSuchFieldException, SecurityException {

        when(mortgageTermReductionCalcRestClient.getMortgageTermReductionInfo(any(String.class), any(HashMap.class))).thenReturn(accountHelper.buildViewMortgageTermReductionResponse("22","18","4"));

        when(mortgageAccountOptionRestClient.updateAccountOptions(any(VaultAccountOptionsUpdateRequest.class)))
                .thenReturn(accountOptionHelper.buildAccountOptionsUpdateResponse(CommonConstants.KEY_MORTGAGE_TERM, "12"));

        // when
        MockHttpServletResponse servletResponse = doPUT(REDUCE_MORTGAGE_TERM, null, accountOptionHelper.getAccountInfoHeaders());
        String responseString = componentHelper.getServletResponseAsString(servletResponse);
        ErrorResponse errorResponse = (ErrorResponse) readObject(responseString, ErrorResponse.class);
        ErrorInfo errorInfo = errorResponse.getErrors().get(0);

        //then
        assertAll(
                () -> assertEquals(400, servletResponse.getStatus()),
                () -> assertEquals("PNA.MORTGAGE_API.BUS.601", errorResponse.getCode()),
                () -> assertEquals("Invalid Update Request", errorResponse.getMessage()),
                () -> assertEquals("PNA.MORTGAGE_API.PUT_MORTGAGES_TERM_REDUCTION.ReduceMortgageTerm.Invalid", errorInfo.getReasonCode()),
                () -> assertEquals("New mortgage term cannot be equal or more than the remaining term", errorInfo.getMessage())
        );
    }

    @Test
    public void shouldNotReduceMortgageTermIfUpdatedTotalTermIsGreaterThanToRemainingTerm() throws NoSuchFieldException, SecurityException {

        when(mortgageTermReductionCalcRestClient.getMortgageTermReductionInfo(any(String.class), any(HashMap.class))).thenReturn(accountHelper.buildViewMortgageTermReductionResponse("22","18","1"));

        when(mortgageAccountOptionRestClient.updateAccountOptions(any(VaultAccountOptionsUpdateRequest.class)))
                .thenReturn(accountOptionHelper.buildAccountOptionsUpdateResponse(CommonConstants.KEY_MORTGAGE_TERM, "12"));

        // when
        MockHttpServletResponse servletResponse = doPUT(REDUCE_MORTGAGE_TERM, null, accountOptionHelper.getAccountInfoHeaders());
        String responseString = componentHelper.getServletResponseAsString(servletResponse);
        ErrorResponse errorResponse = (ErrorResponse) readObject(responseString, ErrorResponse.class);
        ErrorInfo errorInfo = errorResponse.getErrors().get(0);

        //then
        assertAll(
                () -> assertEquals(400, servletResponse.getStatus()),
                () -> assertEquals("PNA.MORTGAGE_API.BUS.601", errorResponse.getCode()),
                () -> assertEquals("Invalid Update Request", errorResponse.getMessage()),
                () -> assertEquals("PNA.MORTGAGE_API.PUT_MORTGAGES_TERM_REDUCTION.ReduceMortgageTerm.Invalid", errorInfo.getReasonCode()),
                () -> assertEquals("New mortgage term cannot be equal or more than the remaining term", errorInfo.getMessage())
        );
    }

    @Test
    public void shouldNotReduceMortgageTermIfReducedTermIsNull() throws NoSuchFieldException, SecurityException {

        when(mortgageTermReductionCalcRestClient.getMortgageTermReductionInfo(any(String.class), any(HashMap.class))).thenReturn(accountHelper.buildViewMortgageTermReductionResponse("22","18",null));

        when(mortgageAccountOptionRestClient.updateAccountOptions(any(VaultAccountOptionsUpdateRequest.class)))
                .thenReturn(accountOptionHelper.buildAccountOptionsUpdateResponse(CommonConstants.KEY_MORTGAGE_TERM, "12"));

        // when
        MockHttpServletResponse servletResponse = doPUT(REDUCE_MORTGAGE_TERM, null, accountOptionHelper.getAccountInfoHeaders());
        String responseString = componentHelper.getServletResponseAsString(servletResponse);
        ErrorResponse errorResponse = (ErrorResponse) readObject(responseString, ErrorResponse.class);
        ErrorInfo errorInfo = errorResponse.getErrors().get(0);

        //then
        assertAll(
                () -> assertEquals(400, servletResponse.getStatus()),
                () -> assertEquals("PNA.MORTGAGE_API.BUS.601", errorResponse.getCode()),
                () -> assertEquals("Invalid Update Request", errorResponse.getMessage()),
                () -> assertEquals("PNA.MORTGAGE_API.PUT_MORTGAGES_TERM_REDUCTION.RepaymentScheduleParams.Invalid", errorInfo.getReasonCode()),
                () -> assertEquals("Invalid value provided for amend repayment param: MortgageTermReduce", errorInfo.getMessage())
        );
    }

    @Test
    public void shouldNotReduceMortgageTermIfReducedTermIsEmpty() throws NoSuchFieldException, SecurityException {

        when(mortgageTermReductionCalcRestClient.getMortgageTermReductionInfo(any(String.class), any(HashMap.class))).thenReturn(accountHelper.buildViewMortgageTermReductionResponse("22","18",""));

        when(mortgageAccountOptionRestClient.updateAccountOptions(any(VaultAccountOptionsUpdateRequest.class)))
                .thenReturn(accountOptionHelper.buildAccountOptionsUpdateResponse(CommonConstants.KEY_MORTGAGE_TERM, "12"));

        // when
        MockHttpServletResponse servletResponse = doPUT(REDUCE_MORTGAGE_TERM, null, accountOptionHelper.getAccountInfoHeaders());
        String responseString = componentHelper.getServletResponseAsString(servletResponse);
        ErrorResponse errorResponse = (ErrorResponse) readObject(responseString, ErrorResponse.class);
        ErrorInfo errorInfo = errorResponse.getErrors().get(0);

        //then
        assertAll(
                () -> assertEquals(400, servletResponse.getStatus()),
                () -> assertEquals("PNA.MORTGAGE_API.BUS.601", errorResponse.getCode()),
                () -> assertEquals("Invalid Update Request", errorResponse.getMessage()),
                () -> assertEquals("PNA.MORTGAGE_API.PUT_MORTGAGES_TERM_REDUCTION.RepaymentScheduleParams.Invalid", errorInfo.getReasonCode()),
                () -> assertEquals("Invalid value provided for amend repayment param: MortgageTermReduce", errorInfo.getMessage())
        );
    }

    @Test
    public void shouldNotReduceMortgageTermIfReducedTermIsZero() throws NoSuchFieldException, SecurityException {

        when(mortgageTermReductionCalcRestClient.getMortgageTermReductionInfo(any(String.class), any(HashMap.class))).thenReturn(accountHelper.buildViewMortgageTermReductionResponse("22","18","0"));

        when(mortgageAccountOptionRestClient.updateAccountOptions(any(VaultAccountOptionsUpdateRequest.class)))
                .thenReturn(accountOptionHelper.buildAccountOptionsUpdateResponse(CommonConstants.KEY_MORTGAGE_TERM, "12"));

        // when
        MockHttpServletResponse servletResponse = doPUT(REDUCE_MORTGAGE_TERM, null, accountOptionHelper.getAccountInfoHeaders());
        String responseString = componentHelper.getServletResponseAsString(servletResponse);
        ErrorResponse errorResponse = (ErrorResponse) readObject(responseString, ErrorResponse.class);
        ErrorInfo errorInfo = errorResponse.getErrors().get(0);

        //then
        assertAll(
                () -> assertEquals(400, servletResponse.getStatus()),
                () -> assertEquals("PNA.MORTGAGE_API.BUS.601", errorResponse.getCode()),
                () -> assertEquals("Invalid Update Request", errorResponse.getMessage()),
                () -> assertEquals("PNA.MORTGAGE_API.PUT_MORTGAGES_TERM_REDUCTION.RepaymentScheduleParams.Invalid", errorInfo.getReasonCode()),
                () -> assertEquals("Invalid value provided for amend repayment param: MortgageTermReduce", errorInfo.getMessage())
        );
    }

    @Test
    public void shouldReturnErrorForReduceMortgageTermWhenMortgageQueryServiceThrowsException() throws NoSuchFieldException, SecurityException {

        when(mortgageTermReductionCalcRestClient.getMortgageTermReductionInfo(any(String.class), any(HashMap.class))).thenThrow(new RestServiceException(SystemErrors.INTERNAL_SERVER_ERROR.getErrorCode(),
                HttpStatus.INTERNAL_SERVER_ERROR,".Generic.Error",
                "Internal Server Error"));

        when(mortgageAccountOptionRestClient.updateAccountOptions(any(VaultAccountOptionsUpdateRequest.class)))
                .thenReturn(accountOptionHelper.buildAccountOptionsUpdateResponse(CommonConstants.KEY_MORTGAGE_TERM, null));

        // when
        MockHttpServletResponse servletResponse = doPUT(REDUCE_MORTGAGE_TERM, null, accountOptionHelper.getAccountInfoHeaders());
        String responseString = componentHelper.getServletResponseAsString(servletResponse);
        ErrorResponse errorResponse = (ErrorResponse) readObject(responseString, ErrorResponse.class);
        ErrorInfo errorInfo = errorResponse.getErrors().get(0);

        //then
        assertAll(
                () -> assertEquals(500, servletResponse.getStatus()),
                () -> assertEquals("PNA.MORTGAGE_API.SYS.006", errorResponse.getCode()),
                () -> assertEquals("Internal server error", errorResponse.getMessage()),
                () -> assertEquals("PNA.MORTGAGE_API.PUT_MORTGAGES_TERM_REDUCTION.Generic.Error", errorInfo.getReasonCode()),
                () -> assertEquals("Internal Server Error", errorInfo.getMessage())
        );
    }

    @Test
    public void shouldReturnErrorForReduceMortgageTermWhenVaultThrowsException() throws NoSuchFieldException, SecurityException {

        when(mortgageTermReductionCalcRestClient.getMortgageTermReductionInfo(any(String.class), any(HashMap.class))).thenThrow(new RestServiceException(SystemErrors.INTERNAL_SERVER_ERROR.getErrorCode(),
                HttpStatus.INTERNAL_SERVER_ERROR,".Generic.Error",
                "Internal Server Error"));

        when(mortgageAccountOptionRestClient.updateAccountOptions(any(VaultAccountOptionsUpdateRequest.class)))
                .thenThrow(new RestServiceException(SystemErrors.INTERNAL_SERVER_ERROR.getErrorCode(),HttpStatus.INTERNAL_SERVER_ERROR,".Generic.Error","Internal Server Error"));

        // when
        MockHttpServletResponse servletResponse = doPUT(REDUCE_MORTGAGE_TERM, null, accountOptionHelper.getAccountInfoHeaders());
        String responseString = componentHelper.getServletResponseAsString(servletResponse);
        ErrorResponse errorResponse = (ErrorResponse) readObject(responseString, ErrorResponse.class);
        ErrorInfo errorInfo = errorResponse.getErrors().get(0);

        //then
        assertAll(
                () -> assertEquals(500, servletResponse.getStatus()),
                () -> assertEquals("PNA.MORTGAGE_API.SYS.006", errorResponse.getCode()),
                () -> assertEquals("Internal server error", errorResponse.getMessage()),
                () -> assertEquals("PNA.MORTGAGE_API.PUT_MORTGAGES_TERM_REDUCTION.Generic.Error", errorInfo.getReasonCode()),
                () -> assertEquals("Internal Server Error", errorInfo.getMessage())
        );
    }

    @Test
    public void shouldReturnErrorForReduceMortgageTermWhenBrandIsMissing() throws NoSuchFieldException, SecurityException {

        when(mortgageTermReductionCalcRestClient.getMortgageTermReductionInfo(any(String.class), any(HashMap.class))).thenReturn(accountHelper.buildViewMortgageTermReductionResponse("22","18","0"));

        HttpHeaders accountInfoHeaders = accountOptionHelper.getAccountInfoHeaders();
        accountInfoHeaders.remove("x-lbg-brand");

        // when
        MockHttpServletResponse servletResponse = doPUT(REDUCE_MORTGAGE_TERM, null, accountInfoHeaders);
        String responseString = componentHelper.getServletResponseAsString(servletResponse);
        ErrorResponse errorResponse = (ErrorResponse) readObject(responseString, ErrorResponse.class);
        ErrorInfo errorInfo = errorResponse.getErrors().get(0);

        //then
        assertAll(
                () -> assertEquals(400, servletResponse.getStatus()),
                () -> assertEquals("PNA.MORTGAGE_API.SYS.001", errorResponse.getCode()),
                () -> assertEquals("Bad Request", errorResponse.getMessage()),
                () -> assertEquals("PNA.MORTGAGE_API.PUT_MORTGAGES_TERM_REDUCTION.Header.Missing.x-lbg-brand", errorInfo.getReasonCode()),
                () -> assertEquals("Missing request header 'x-lbg-brand' for method parameter of type String", errorInfo.getMessage())
        );
    }

    @Test
    public void shouldReturnErrorForReduceMortgageTermWhenBrandIsIncorrect() throws NoSuchFieldException, SecurityException {

        when(mortgageTermReductionCalcRestClient.getMortgageTermReductionInfo(any(String.class), any(HashMap.class))).thenReturn(accountHelper.buildViewMortgageTermReductionResponse("22","18","0"));

        HttpHeaders accountInfoHeaders = accountOptionHelper.getAccountInfoHeaders();
        accountInfoHeaders.set("x-lbg-brand", "xxx");

        // when
        MockHttpServletResponse servletResponse = doPUT(REDUCE_MORTGAGE_TERM, null, accountInfoHeaders);
        String responseString = componentHelper.getServletResponseAsString(servletResponse);
        ErrorResponse errorResponse = (ErrorResponse) readObject(responseString, ErrorResponse.class);
        ErrorInfo errorInfo = errorResponse.getErrors().get(0);

        //then
        assertAll(
                () -> assertEquals(400, servletResponse.getStatus()),
                () -> assertEquals("PNA.MORTGAGE_API.SYS.001", errorResponse.getCode()),
                () -> assertEquals("Bad Request", errorResponse.getMessage()),
                () -> assertEquals("PNA.MORTGAGE_API.PUT_MORTGAGES_TERM_REDUCTION.Header.Invalid", errorInfo.getReasonCode()),
                () -> assertEquals("Invalid enum value for type x-lbg-brand", errorInfo.getMessage())
        );
    }

    @Test
    public void shouldReturnErrorForReduceMortgageTermWhenCorrelationIdIsMissing() throws NoSuchFieldException, SecurityException {

        when(mortgageTermReductionCalcRestClient.getMortgageTermReductionInfo(any(String.class), any(HashMap.class))).thenReturn(accountHelper.buildViewMortgageTermReductionResponse("22","18","0"));

        HttpHeaders accountInfoHeaders = accountOptionHelper.getAccountInfoHeaders();
        accountInfoHeaders.remove("x-lbg-txn-correlation-id");

        // when
        MockHttpServletResponse servletResponse = doPUT(REDUCE_MORTGAGE_TERM, null, accountInfoHeaders);
        String responseString = componentHelper.getServletResponseAsString(servletResponse);
        ErrorResponse errorResponse = (ErrorResponse) readObject(responseString, ErrorResponse.class);
        ErrorInfo errorInfo = errorResponse.getErrors().get(0);

        //then
        assertAll(
                () -> assertEquals(400, servletResponse.getStatus()),
                () -> assertEquals("PNA.MORTGAGE_API.SYS.001", errorResponse.getCode()),
                () -> assertEquals("Bad Request", errorResponse.getMessage()),
                () -> assertEquals("PNA.MORTGAGE_API.PUT_MORTGAGES_TERM_REDUCTION.Header.Missing.x-lbg-txn-correlation-id", errorInfo.getReasonCode()),
                () -> assertEquals("Missing request header x-lbg-txn-correlation-id for method parameter of type String", errorInfo.getMessage())
        );
    }

    @Test
    public void shouldReturnErrorForReduceMortgageTermWhenCorrelationIdIsLessThanTenCharacters() throws NoSuchFieldException, SecurityException {

        when(mortgageTermReductionCalcRestClient.getMortgageTermReductionInfo(any(String.class), any(HashMap.class))).thenReturn(accountHelper.buildViewMortgageTermReductionResponse("22","18","0"));

        HttpHeaders accountInfoHeaders = accountOptionHelper.getAccountInfoHeaders();
        accountInfoHeaders.set("x-lbg-txn-correlation-id", RandomStringUtils.random(9));

        // when
        MockHttpServletResponse servletResponse = doPUT(REDUCE_MORTGAGE_TERM, null, accountInfoHeaders);
        String responseString = componentHelper.getServletResponseAsString(servletResponse);
        ErrorResponse errorResponse = (ErrorResponse) readObject(responseString, ErrorResponse.class);
        ErrorInfo errorInfo = errorResponse.getErrors().get(0);

        //then
        assertAll(
                () -> assertEquals(400, servletResponse.getStatus()),
                () -> assertEquals("PNA.MORTGAGE_API.SYS.001", errorResponse.getCode()),
                () -> assertEquals("Bad Request", errorResponse.getMessage()),
                () -> assertEquals("PNA.MORTGAGE_API.PUT_MORTGAGES_TERM_REDUCTION.Header.Invalid", errorInfo.getReasonCode()),
                () -> assertEquals("x-lbg-txn-correlation-id size should be between 10 and 40", errorInfo.getMessage())
        );
    }

    @Test
    public void shouldReturnErrorForReduceMortgageTermWhenCorrelationIdIsGreaterThanFortyCharacters() throws NoSuchFieldException, SecurityException {

        when(mortgageTermReductionCalcRestClient.getMortgageTermReductionInfo(any(String.class), any(HashMap.class))).thenReturn(accountHelper.buildViewMortgageTermReductionResponse("22","18","0"));

        HttpHeaders accountInfoHeaders = accountOptionHelper.getAccountInfoHeaders();
        accountInfoHeaders.set("x-lbg-txn-correlation-id", RandomStringUtils.random(50));

        // when
        MockHttpServletResponse servletResponse = doPUT(REDUCE_MORTGAGE_TERM, null, accountInfoHeaders);
        String responseString = componentHelper.getServletResponseAsString(servletResponse);
        ErrorResponse errorResponse = (ErrorResponse) readObject(responseString, ErrorResponse.class);
        ErrorInfo errorInfo = errorResponse.getErrors().get(0);

        //then
        assertAll(
                () -> assertEquals(400, servletResponse.getStatus()),
                () -> assertEquals("PNA.MORTGAGE_API.SYS.001", errorResponse.getCode()),
                () -> assertEquals("Bad Request", errorResponse.getMessage()),
                () -> assertEquals("PNA.MORTGAGE_API.PUT_MORTGAGES_TERM_REDUCTION.Header.Invalid", errorInfo.getReasonCode()),
                () -> assertEquals("x-lbg-txn-correlation-id size should be between 10 and 40", errorInfo.getMessage())
        );
    }

    @Test
    public void shouldReturnErrorForReduceMortgageTermWhenAuthorisationIsMissing() throws NoSuchFieldException, SecurityException {

        when(mortgageTermReductionCalcRestClient.getMortgageTermReductionInfo(any(String.class), any(HashMap.class))).thenReturn(accountHelper.buildViewMortgageTermReductionResponse("22","18","0"));

        HttpHeaders accountInfoHeaders = accountOptionHelper.getAccountInfoHeaders();
        accountInfoHeaders.remove("x-lbg-internal-system-id");
        accountInfoHeaders.remove("Authorization");

        // when
        MockHttpServletResponse servletResponse = doPUT(REDUCE_MORTGAGE_TERM, null, accountInfoHeaders);
        String responseString = componentHelper.getServletResponseAsString(servletResponse);
        ErrorResponse errorResponse = (ErrorResponse) readObject(responseString, ErrorResponse.class);
        ErrorInfo errorInfo = errorResponse.getErrors().get(0);

        //then
        assertAll(
                () -> assertEquals(401, servletResponse.getStatus()),
                () -> assertEquals("PNA.MORTGAGE_API.SYS.002", errorResponse.getCode()),
                () -> assertEquals("Resource Unauthorised", errorResponse.getMessage()),
                () -> assertEquals("PNA.MORTGAGE_API.PUT_MORTGAGES_TERM_REDUCTION.Access.Unauthorised", errorInfo.getReasonCode()),
                () -> assertEquals("Please Supply headers : 'Authorization' or 'x-lbg-internal-system-id'", errorInfo.getMessage())
        );
    }

    @Test
    public void shouldReturnErrorForReduceMortgageTermWhenAccountIdIsMoreThan36Chars() throws NoSuchFieldException, SecurityException {

        when(mortgageTermReductionCalcRestClient.getMortgageTermReductionInfo(any(String.class), any(HashMap.class))).thenReturn(accountHelper.buildViewMortgageTermReductionResponse("22","18","0"));

        HttpHeaders accountInfoHeaders = accountOptionHelper.getAccountInfoHeaders();
        String accountId = RandomStringUtils.random(50);
        // when
        MockHttpServletResponse servletResponse = doPUT("/mortgages/"+ accountId +"/term-reduction", null, accountInfoHeaders);
        String responseString = componentHelper.getServletResponseAsString(servletResponse);
        ErrorResponse errorResponse = (ErrorResponse) readObject(responseString, ErrorResponse.class);
        ErrorInfo errorInfo = errorResponse.getErrors().get(0);

        //then
        assertAll(
                () -> assertEquals(400, servletResponse.getStatus()),
                () -> assertEquals("PNA.MORTGAGE_API.SYS.001", errorResponse.getCode()),
                () -> assertEquals("Bad Request", errorResponse.getMessage()),
                () -> assertEquals("PNA.MORTGAGE_API.PUT_MORTGAGES_TERM_REDUCTION.Param.Invalid", errorInfo.getReasonCode()),
                () -> assertEquals("AccountId should be max 36 characters", errorInfo.getMessage())
        );
    }

    @Test
    public void shouldReturnErrorForReduceMortgageTermWhenAccountIdIsLessThan36Chars() throws NoSuchFieldException, SecurityException {

        when(mortgageTermReductionCalcRestClient.getMortgageTermReductionInfo(any(String.class), any(HashMap.class))).thenReturn(accountHelper.buildViewMortgageTermReductionResponse("22","18","0"));

        HttpHeaders accountInfoHeaders = accountOptionHelper.getAccountInfoHeaders();

        // when
        MockHttpServletResponse servletResponse = doPUT("/mortgages/"+RandomStringUtils.random(5)+"/term-reduction", null, accountInfoHeaders);
        String responseString = componentHelper.getServletResponseAsString(servletResponse);
        ErrorResponse errorResponse = (ErrorResponse) readObject(responseString, ErrorResponse.class);
        ErrorInfo errorInfo = errorResponse.getErrors().get(0);

        //then
        assertAll(
                () -> assertEquals(400, servletResponse.getStatus()),
                () -> assertEquals("PNA.MORTGAGE_API.SYS.001", errorResponse.getCode()),
                () -> assertEquals("Bad Request", errorResponse.getMessage()),
                () -> assertEquals("PNA.MORTGAGE_API.PUT_MORTGAGES_TERM_REDUCTION.Param.Invalid", errorInfo.getReasonCode()),
                () -> assertEquals("AccountId should be min 36 characters", errorInfo.getMessage())
        );
    }
}
