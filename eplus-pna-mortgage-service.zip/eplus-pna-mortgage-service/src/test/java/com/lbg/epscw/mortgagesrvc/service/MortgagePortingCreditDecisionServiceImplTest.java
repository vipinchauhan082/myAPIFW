package com.lbg.epscw.mortgagesrvc.service;

import com.lbg.epscw.mortgagesrvc.constants.CommonConstants;
import com.lbg.epscw.mortgagesrvc.exception.CircuitBreakerOpenException;
import com.lbg.epscw.mortgagesrvc.exception.MortgageServiceException;
import com.lbg.epscw.mortgagesrvc.helper.MortgagePortingApplicationHelper;
import com.lbg.epscw.mortgagesrvc.model.AccountStatusUpdateRequest;
import com.lbg.epscw.mortgagesrvc.model.CreditDecisionRequest;
import com.lbg.epscw.mortgagesrvc.model.MortgageApplicationInfo;
import com.lbg.epscw.mortgagesrvc.model.PortingApplicationStatusResponse;
import com.lbg.epscw.mortgagesrvc.restclient.MortgageAccountInfoRestClient;
import com.lbg.epscw.mortgagesrvc.restclient.MortgageAccountStatusRestClient;
import com.lbg.epscw.mortgagesrvc.restclient.MortgagePortingApplicationInfoRestClient;
import org.junit.Before;
import org.junit.Test;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import static com.lbg.epscw.mortgagesrvc.helper.MortgagePortingHelper.APPLICATION_NUMBER;
import static com.lbg.epscw.mortgagesrvc.model.MortgagePortingApplicationStatus.*;
import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

public class MortgagePortingCreditDecisionServiceImplTest {
    private MortgagePortingApplicationInfoRestClient applicationClient;
    private MortgageAccountStatusRestClient accountStatusRestClient;
    private MortgageAccountInfoRestClient accountInfoRestClient;
    private MortgagePortingCreditDecisionServiceImpl underTest;
    private MortgagePortingApplicationHelper mortgagePortingApplicationHelper = new MortgagePortingApplicationHelper();

    @Before
    public void setup() {
        applicationClient = mock(MortgagePortingApplicationInfoRestClient.class);
        accountStatusRestClient = mock(MortgageAccountStatusRestClient.class);
        accountInfoRestClient = mock(MortgageAccountInfoRestClient.class);
        underTest = new MortgagePortingCreditDecisionServiceImpl(applicationClient, accountStatusRestClient,accountInfoRestClient);
    }

    @Test
    public void update_application_success() {
        MortgageApplicationInfo expected = MortgageApplicationInfo.builder().applicationNumber(APPLICATION_NUMBER).status(APPROVED).build();
        when(applicationClient.updateApplication(anyString(), any())).thenReturn(expected);
        PortingApplicationStatusResponse actual = underTest.updateCreditDecision(expected, CreditDecisionRequest.builder().action(APPROVED.name()).build(), mortgagePortingApplicationHelper.generateRequiredHeaders());
        assertThat(actual, is(PortingApplicationStatusResponse.builder().applicationNumber(APPLICATION_NUMBER).status(APPROVED).build()));
    }

    @Test
    public void update_application_success_with_credit_decision_decline_and_application_status_submitted() {
        MortgageApplicationInfo expected = MortgageApplicationInfo.builder().status(SUBMITTED).applicationNumber(APPLICATION_NUMBER).mortgageNumber("b4407ec4-8ea9-49a5-9262-69c82e750720").build();
        MortgageApplicationInfo updatedApplicationInfo = MortgageApplicationInfo.builder().applicationNumber(APPLICATION_NUMBER).status(DECLINED).mortgageNumber("b4407ec4-8ea9-49a5-9262-69c82e750720").build();
        when(applicationClient.getApplicationInfo(any())).thenReturn(expected);
        when(applicationClient.updateApplication(anyString(), any())).thenReturn(updatedApplicationInfo);
        when(accountInfoRestClient.getMortgageInfoByMortgageNumber(anyString(),anyMap())).thenReturn(mortgagePortingApplicationHelper.getMortgageAccountInfo());
        when(accountStatusRestClient.mortgageAccountStatusUpdate(any(AccountStatusUpdateRequest.class),anyMap())).thenReturn(new ArrayList<>());
        PortingApplicationStatusResponse actual = underTest.updateCreditDecision(expected, CreditDecisionRequest.builder().action(DECLINED.name()).build(), mortgagePortingApplicationHelper.generateRequiredHeaders());
        assertThat(actual, is(PortingApplicationStatusResponse.builder().applicationNumber(APPLICATION_NUMBER).status(DECLINED).build()));
    }

    @Test(expected = MortgageServiceException.class)
    public void update_application_fails_with_credit_decision_decline_and_application_status_submitted_when_status_update_fail() {
        MortgageApplicationInfo expected = MortgageApplicationInfo.builder().status(SUBMITTED).applicationNumber(APPLICATION_NUMBER).accountIdToBePorted("b4407ec4-8ea9-49a5-9262-69c82e750720").build();
        when(applicationClient.getApplicationInfo(any())).thenReturn(expected);
        when(applicationClient.updateApplication(anyString(), any())).thenReturn(expected);
        when(accountInfoRestClient.getMortgageInfoByMortgageNumber(anyString(),anyMap())).thenReturn(mortgagePortingApplicationHelper.getMortgageAccountInfo());
        when(accountStatusRestClient.mortgageAccountStatusUpdate(any(AccountStatusUpdateRequest.class),anyMap())).thenThrow(new MortgageServiceException(CommonConstants.SUB_ACCOUNT,CommonConstants.FAILED));
        underTest.updateCreditDecision(expected, CreditDecisionRequest.builder().action(DECLINED.name()).build(), mortgagePortingApplicationHelper.generateRequiredHeaders());
    }

    @Test(expected = MortgageServiceException.class)
    public void update_application_fails_when_application_status_does_not_match() {
        MortgageApplicationInfo applicationInfo = MortgageApplicationInfo.builder().applicationNumber(APPLICATION_NUMBER).status(APPROVED).build();
        when(applicationClient.updateApplication(anyString(), any())).thenReturn(MortgageApplicationInfo.builder().status(OPEN).build());
        underTest.updateCreditDecision(applicationInfo, CreditDecisionRequest.builder().action(APPROVED.name()).build(), mortgagePortingApplicationHelper.generateRequiredHeaders());
    }

    @Test(expected = CircuitBreakerOpenException.class)
    public void update_fallback_throws_exception_on_broken_circuit() {
        Map<String,String> header = new HashMap<String,String>();
        underTest.fallbackUpdateCreditDecision(new MortgageApplicationInfo(), CreditDecisionRequest.builder().action(APPROVED.name()).build(), header, new IllegalArgumentException());
    }
}
