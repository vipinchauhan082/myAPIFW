package com.lbg.epscw.mortgagesrvc.controller;


import com.lbg.epscw.mortgagesrvc.exception.MortgageValidationException;
import com.lbg.epscw.mortgagesrvc.helper.MortgagePortingHelper;
import com.lbg.epscw.mortgagesrvc.model.ApplicationMortgageDetailsUpdateRequest;

import com.lbg.epscw.mortgagesrvc.model.MortgageApplicationInfo;
import com.lbg.epscw.mortgagesrvc.service.MortgagePortingApplicationInfoService;
import com.lbg.epscw.mortgagesrvc.service.MortgagePortingSubAccountDetailsService;
import com.lbg.epscw.mortgagesrvc.util.MortgageServiceUtil;
import com.lbg.epscw.mortgagesrvc.validator.MortgagePortingSubAccountDetailsValidator;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit4.SpringRunner;

import static com.lbg.epscw.mortgagesrvc.constants.CommonConstants.INVALID_STATUS;
import static com.lbg.epscw.mortgagesrvc.constants.CommonConstants.MORTGAGE_DETAILS_INFO;
import static com.lbg.epscw.mortgagesrvc.helper.MortgagePortingHelper.*;
import static com.lbg.epscw.mortgagesrvc.model.MortgagePortingApplicationStatus.OPEN;
import static com.lbg.epscw.mortgagesrvc.model.MortgagePortingApplicationStatus.REOPEN;
import static java.util.Collections.emptyMap;
import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.when;
import static org.springframework.http.ResponseEntity.ok;

@RunWith(SpringRunner.class)
@WebMvcTest(controllers = { MortgageServiceUtil.class, MortgagePortingSubAccountDetailsController.class })
public class MortgagePortingSubAccountDetailsControllerTest {

    @Autowired
    private MortgagePortingSubAccountDetailsController mortgagePortingSubAccountDetailsController;

    @MockBean
    private  MortgagePortingSubAccountDetailsValidator validator;

    @MockBean
    private  MortgagePortingSubAccountDetailsService service;

    @MockBean
    private MortgagePortingApplicationInfoService mortgagePortingApplicationInfoService;

    private final MortgagePortingHelper portingHelper = new MortgagePortingHelper();



    @Test
    public void update_application_mortgage_details() {
        //given


        MortgageApplicationInfo mortgageAccountInfo = portingHelper.mortgageApplicationInfoWithStatus(OPEN.name());
        when(service.updateMortgageDetailsForApplication(any(MortgageApplicationInfo.class),
                any(ApplicationMortgageDetailsUpdateRequest.class))).thenReturn(mortgageAccountInfo);
        //when
        when(mortgagePortingApplicationInfoService.getApplicationInfo(anyString())).thenReturn(mortgageAccountInfo);

        ResponseEntity<MortgageApplicationInfo> response = mortgagePortingSubAccountDetailsController.subAccountDetailsInfo(BRAND, CHANNEL, CORRELATION_ID, JWT, INTERNAL_SYS_ID, emptyMap(), ACCOUNT_ID, portingHelper.applicationMortgageDetailsUpdateRequestPayload());
        //then
        assertThat(response, is(ok(mortgageAccountInfo)));
    }

    @Test
    public void update_application_mortgage_details_reopen_status() {
        //given
        MortgageApplicationInfo mortgageAccountInfo = portingHelper.mortgageApplicationInfoWithStatus(REOPEN.name());
        when(service.updateMortgageDetailsForApplication(any(MortgageApplicationInfo.class),
                any(ApplicationMortgageDetailsUpdateRequest.class))).thenReturn(mortgageAccountInfo);
        //when
        when(mortgagePortingApplicationInfoService.getApplicationInfo(anyString())).thenReturn(mortgageAccountInfo);

        ResponseEntity<MortgageApplicationInfo> response = mortgagePortingSubAccountDetailsController.subAccountDetailsInfo(BRAND, CHANNEL, CORRELATION_ID, JWT, INTERNAL_SYS_ID, emptyMap(), ACCOUNT_ID, portingHelper.applicationMortgageDetailsUpdateRequestPayload());
        //then
        assertThat(response, is(ok(mortgageAccountInfo)));
    }

    @Test(expected = MortgageValidationException.class)
    public void update_application_mortgage_details_throws_exception_when_validation_fails() {
        //given

        doThrow(new MortgageValidationException(MORTGAGE_DETAILS_INFO, INVALID_STATUS)).when(validator).validate(any(MortgageApplicationInfo.class),any(ApplicationMortgageDetailsUpdateRequest.class),anyMap());

        MortgageApplicationInfo mortgageAccountInfo = portingHelper.mortgageApplicationInfoWithStatus(OPEN.name());
        when(service.updateMortgageDetailsForApplication(any(MortgageApplicationInfo.class),
                any(ApplicationMortgageDetailsUpdateRequest.class))).thenReturn(mortgageAccountInfo);
        //when
        when(mortgagePortingApplicationInfoService.getApplicationInfo(anyString())).thenReturn(mortgageAccountInfo);

        ResponseEntity<MortgageApplicationInfo> response = mortgagePortingSubAccountDetailsController.subAccountDetailsInfo(BRAND, CHANNEL, CORRELATION_ID, JWT, INTERNAL_SYS_ID, emptyMap(), ACCOUNT_ID, portingHelper.applicationMortgageDetailsUpdateRequestPayload());
        //then

    }


    @Test(expected = RuntimeException.class)
    public void update_application_mortgage_details_throws_exception_when_service_fails() {
        //given



        MortgageApplicationInfo mortgageAccountInfo = portingHelper.mortgageApplicationInfoWithStatus(OPEN.name());
        when(service.updateMortgageDetailsForApplication(any(MortgageApplicationInfo.class),
                any(ApplicationMortgageDetailsUpdateRequest.class))).thenThrow(new RuntimeException("Internal Server error"));
        //when
        when(mortgagePortingApplicationInfoService.getApplicationInfo(anyString())).thenReturn(mortgageAccountInfo);

        ResponseEntity<MortgageApplicationInfo> response = mortgagePortingSubAccountDetailsController.subAccountDetailsInfo(BRAND, CHANNEL, CORRELATION_ID, JWT, INTERNAL_SYS_ID, emptyMap(), ACCOUNT_ID, portingHelper.applicationMortgageDetailsUpdateRequestPayload());
        //then

    }
}
