package com.lbg.epscw.mortgagesrvc.validator;

import com.lbg.epscw.mortgagesrvc.dto.MortgageAccountData;
import com.lbg.epscw.mortgagesrvc.dto.MortgageAccountInfo;
import com.lbg.epscw.mortgagesrvc.exception.InvalidUpdateRequestException;
import com.lbg.epscw.mortgagesrvc.helper.MortgagePortingHelper;
import com.lbg.epscw.mortgagesrvc.model.AccountStatus;
import com.lbg.epscw.mortgagesrvc.model.AccountStatusUpdateRequest;
import com.lbg.epscw.mortgagesrvc.restclient.MortgageAccountInfoRestClient;
import com.lbg.epscw.mortgagesrvc.service.MortgageAccountStatusStateMachine;
import org.junit.Before;
import org.junit.Test;
import org.springframework.boot.test.mock.mockito.MockBean;

import java.util.*;

import static org.junit.Assert.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.powermock.api.mockito.PowerMockito.mock;
import static org.powermock.api.mockito.PowerMockito.when;

public class MortgagePortingValidatorTest {

    @MockBean
    private MortgageAccountInfoRestClient mortgageAccountInfoRestClient;

    @MockBean
    private MortgageAccountStatusStateMachine mortgageAccountStatusStateMachine;

    private MortgagePortingHelper mortgagePortingHelper = new MortgagePortingHelper();

    @Before
    public void setUp() {
        mortgageAccountInfoRestClient=mock(MortgageAccountInfoRestClient.class);
        mortgageAccountStatusStateMachine=mock(MortgageAccountStatusStateMachine.class);
    }

    @Test
    public void validate_account_status_update_to_cancelled_status_for_mortgage_overarching_account(){
        //given
        MortgageAccountInfo mortgageAccountInfo=mortgagePortingHelper.buildMortgageAccountInfoWithSubAccount(true);
        AccountStatusUpdateRequest accountStatusUpdateRequest = mortgagePortingHelper.buildAccountStatusUpdateRequestWithOnlyOverarchingAndCancelStatus();
        Map<String,String> reqMap= new HashMap<>();
        String accountId="b2c9119f-09e5-4ac9-9738-9e28b334d3fa";
        MortgagePortingValidator mortgagePortingValidator= new MortgagePortingValidator(mortgageAccountInfoRestClient, mortgageAccountStatusStateMachine );
        when(mortgageAccountInfoRestClient.getMortgageAccountInfo(any(String.class), any(Map.class))).thenReturn(mortgageAccountInfo);
        when(mortgageAccountStatusStateMachine.next(any(AccountStatus.class))).thenReturn(Arrays.asList(AccountStatus.ACCOUNT_STATUS_CANCELLED,AccountStatus.ACCOUNT_STATUS_OPEN));

        //when
        List<MortgageAccountData> mortgageAccountData = mortgagePortingValidator.validateAccountStatus(accountStatusUpdateRequest, reqMap);

        //then
        assertEquals("b2c9119f-09e5-4ac9-9738-9e28b334d3fa",mortgageAccountData.get(1).getAccountId());
        assertEquals("b2c9119f-09e5-4ac9-9738-9e28b334d4ty",mortgageAccountData.get(0).getAccountId());

    }

    @Test(expected = InvalidUpdateRequestException.class)
    public void validate_account_status_update_for_mortgage_overarching_account_fails_if_having_same_existing_status(){
        //given
        MortgageAccountInfo mortgageAccountInfo=mortgagePortingHelper.buildMortgageAccountInfoWithSubAccount(true);
        AccountStatusUpdateRequest accountStatusUpdateRequest = mortgagePortingHelper.buildAccountStatusUpdateRequestWithPendingStatus();
        Map<String,String> reqMap= new HashMap<>();
        String accountId="b2c9119f-09e5-4ac9-9738-9e28b334d3fa";
        MortgagePortingValidator mortgagePortingValidator= new MortgagePortingValidator(mortgageAccountInfoRestClient, mortgageAccountStatusStateMachine );
        when(mortgageAccountInfoRestClient.getMortgageAccountInfo(any(String.class), any(Map.class))).thenReturn(mortgageAccountInfo);
        when(mortgageAccountStatusStateMachine.next(any(AccountStatus.class))).thenReturn(Arrays.asList(AccountStatus.ACCOUNT_STATUS_CANCELLED,AccountStatus.ACCOUNT_STATUS_OPEN));

        //when
        List<MortgageAccountData> mortgageAccountData = mortgagePortingValidator.validateAccountStatus(accountStatusUpdateRequest, reqMap);

        //then
        assertEquals("b2c9119f-09e5-4ac9-9738-9e28b334d3fa",mortgageAccountData.get(1).getAccountId());
        assertEquals("b2c9119f-09e5-4ac9-9738-9e28b334d4ty",mortgageAccountData.get(0).getAccountId());

    }

    @Test
    public void validate_account_status_update_to_cancel_status_when_all_sub_account_list_is_passed(){
        //given
        MortgageAccountInfo mortgageAccountInfo=mortgagePortingHelper.buildMortgageAccountInfoWithSubAccount(true);
        AccountStatusUpdateRequest accountStatusUpdateRequest = mortgagePortingHelper.buildAccountStatusUpdateRequestWithOverarchingSubAccountAndCancelStatus();
        Map<String,String> reqMap= new HashMap<>();
        String accountId="b2c9119f-09e5-4ac9-9738-9e28b334d3fa";
        MortgagePortingValidator mortgagePortingValidator= new MortgagePortingValidator(mortgageAccountInfoRestClient, mortgageAccountStatusStateMachine );
        when(mortgageAccountInfoRestClient.getMortgageAccountInfo(any(String.class), any(Map.class))).thenReturn(mortgageAccountInfo);
        when(mortgageAccountStatusStateMachine.next(any(AccountStatus.class))).thenReturn(Arrays.asList(AccountStatus.ACCOUNT_STATUS_CANCELLED,AccountStatus.ACCOUNT_STATUS_OPEN));

        //when
        List<MortgageAccountData> mortgageAccountData = mortgagePortingValidator.validateAccountStatus(accountStatusUpdateRequest, reqMap);

        //then
        assertEquals("b2c9119f-09e5-4ac9-9738-9e28b334d3fa",mortgageAccountData.get(1).getAccountId());
        assertEquals("b2c9119f-09e5-4ac9-9738-9e28b334d4ty",mortgageAccountData.get(0).getAccountId());

    }

    @Test
    public void validate_account_status_update_to_open_status_when_all_sub_account_list_is_passed(){
        //given
        MortgageAccountInfo mortgageAccountInfo=mortgagePortingHelper.buildMortgageAccountInfoWithSubAccount(true);
        AccountStatusUpdateRequest accountStatusUpdateRequest = mortgagePortingHelper.buildAccountStatusUpdateRequestWithOverarchingSubAccountAndOpenStatus();
        Map<String,String> reqMap= new HashMap<>();
        String accountId="b2c9119f-09e5-4ac9-9738-9e28b334d3fa";
        MortgagePortingValidator mortgagePortingValidator= new MortgagePortingValidator(mortgageAccountInfoRestClient, mortgageAccountStatusStateMachine );
        when(mortgageAccountInfoRestClient.getMortgageAccountInfo(any(String.class), any(Map.class))).thenReturn(mortgageAccountInfo);
        when(mortgageAccountStatusStateMachine.next(any(AccountStatus.class))).thenReturn(Arrays.asList(AccountStatus.ACCOUNT_STATUS_CANCELLED,AccountStatus.ACCOUNT_STATUS_OPEN));

        //when
        List<MortgageAccountData> mortgageAccountData = mortgagePortingValidator.validateAccountStatus(accountStatusUpdateRequest, reqMap);

        //then
        assertEquals("b2c9119f-09e5-4ac9-9738-9e28b334d3fa",mortgageAccountData.get(1).getAccountId());
        assertEquals("b2c9119f-09e5-4ac9-9738-9e28b334d4ty",mortgageAccountData.get(0).getAccountId());

    }

    @Test
    public void validate_account_status_update_when_partial_sub_account_list_of_overarching_is_passed(){
        //given
        MortgageAccountInfo mortgageAccountInfo=mortgagePortingHelper.buildMortgageAccountInfoWithMultipleSubAccount(true);
        AccountStatusUpdateRequest accountStatusUpdateRequest = mortgagePortingHelper.buildAccountStatusUpdateRequestWithOverarchingPartialSubAccountAndCancelStatus();
        Map<String,String> reqMap= new HashMap<>();
        String accountId="b2c9119f-09e5-4ac9-9738-9e28b334d3fa";
        MortgagePortingValidator mortgagePortingValidator= new MortgagePortingValidator(mortgageAccountInfoRestClient, mortgageAccountStatusStateMachine );
        when(mortgageAccountInfoRestClient.getMortgageAccountInfo(any(String.class), any(Map.class))).thenReturn(mortgageAccountInfo);
        when(mortgageAccountStatusStateMachine.next(any(AccountStatus.class))).thenReturn(Arrays.asList(AccountStatus.ACCOUNT_STATUS_CANCELLED,AccountStatus.ACCOUNT_STATUS_OPEN));

        //when
        List<MortgageAccountData> mortgageAccountData = mortgagePortingValidator.validateAccountStatus(accountStatusUpdateRequest, reqMap);

        //then
        assertEquals("b2c9119f-09e5-4ac9-9738-9e28b334d4t1",mortgageAccountData.get(1).getAccountId());
        assertEquals("b2c9119f-09e5-4ac9-9738-9e28b334d4t0",mortgageAccountData.get(0).getAccountId());

    }

    @Test
    public void validate_account_status_update_when_partial_sub_account_list_of_overarching_is_passed_and_return_sub_account_plus_overarching(){
        //given
        MortgageAccountInfo mortgageAccountInfo=mortgagePortingHelper.buildMortgageAccountInfoWithMultipleSubAccount(true);
        mortgageAccountInfo.getMortgageAccountData().get(3).setStatus(AccountStatus.ACCOUNT_STATUS_CANCELLED.name());
        mortgageAccountInfo.getMortgageAccountData().get(4).setStatus(AccountStatus.ACCOUNT_STATUS_CANCELLED.name());
        AccountStatusUpdateRequest accountStatusUpdateRequest = mortgagePortingHelper.buildAccountStatusUpdateRequestWithOverarchingPartialSubAccountAndCancelStatus();
        Map<String,String> reqMap= new HashMap<>();
        String accountId="b2c9119f-09e5-4ac9-9738-9e28b334d3fa";
        MortgagePortingValidator mortgagePortingValidator= new MortgagePortingValidator(mortgageAccountInfoRestClient, mortgageAccountStatusStateMachine );
        when(mortgageAccountInfoRestClient.getMortgageAccountInfo(any(String.class), any(Map.class))).thenReturn(mortgageAccountInfo);
        when(mortgageAccountStatusStateMachine.next(AccountStatus.ACCOUNT_STATUS_PENDING)).thenReturn(Arrays.asList(AccountStatus.ACCOUNT_STATUS_CANCELLED,AccountStatus.ACCOUNT_STATUS_OPEN));
        when(mortgageAccountStatusStateMachine.next(AccountStatus.ACCOUNT_STATUS_CANCELLED)).thenReturn(Collections.emptyList());
        when(mortgageAccountStatusStateMachine.next(AccountStatus.ACCOUNT_STATUS_PENDING_CLOSURE)).thenReturn(Arrays.asList(AccountStatus.ACCOUNT_STATUS_CLOSED));

        //when
        List<MortgageAccountData> mortgageAccountData = mortgagePortingValidator.validateAccountStatus(accountStatusUpdateRequest, reqMap);

        //then
        assertEquals("b2c9119f-09e5-4ac9-9738-9e28b334d4t1",mortgageAccountData.get(1).getAccountId());
        assertEquals("b2c9119f-09e5-4ac9-9738-9e28b334d4t0",mortgageAccountData.get(0).getAccountId());

    }

    @Test
    public void validate_account_status_update_when_partial_sub_account_list_of_overarching_having_diff_status_is_passed_then_return_sub_account(){
        //given
        MortgageAccountInfo mortgageAccountInfo=mortgagePortingHelper.buildMortgageAccountInfoWithMultipleSubAccount(true);
        mortgageAccountInfo.getMortgageAccountData().get(3).setStatus(AccountStatus.ACCOUNT_STATUS_CANCELLED.name());
        mortgageAccountInfo.getMortgageAccountData().get(4).setStatus(AccountStatus.ACCOUNT_STATUS_CLOSED.name());
        AccountStatusUpdateRequest accountStatusUpdateRequest = mortgagePortingHelper.buildAccountStatusUpdateRequestWithOverarchingPartialSubAccountAndCancelStatus();
        Map<String,String> reqMap= new HashMap<>();
        String accountId="b2c9119f-09e5-4ac9-9738-9e28b334d3fa";
        MortgagePortingValidator mortgagePortingValidator= new MortgagePortingValidator(mortgageAccountInfoRestClient, mortgageAccountStatusStateMachine );
        when(mortgageAccountInfoRestClient.getMortgageAccountInfo(any(String.class), any(Map.class))).thenReturn(mortgageAccountInfo);
        when(mortgageAccountStatusStateMachine.next(AccountStatus.ACCOUNT_STATUS_PENDING)).thenReturn(Arrays.asList(AccountStatus.ACCOUNT_STATUS_CANCELLED,AccountStatus.ACCOUNT_STATUS_OPEN));
        when(mortgageAccountStatusStateMachine.next(AccountStatus.ACCOUNT_STATUS_CANCELLED)).thenReturn(Collections.emptyList());
        when(mortgageAccountStatusStateMachine.next(AccountStatus.ACCOUNT_STATUS_PENDING_CLOSURE)).thenReturn(Arrays.asList(AccountStatus.ACCOUNT_STATUS_CLOSED));

        //when
        List<MortgageAccountData> mortgageAccountData = mortgagePortingValidator.validateAccountStatus(accountStatusUpdateRequest, reqMap);

        //then
        assertEquals("b2c9119f-09e5-4ac9-9738-9e28b334d4t1",mortgageAccountData.get(1).getAccountId());
        assertEquals("b2c9119f-09e5-4ac9-9738-9e28b334d4t0",mortgageAccountData.get(0).getAccountId());

    }


    @Test(expected = InvalidUpdateRequestException.class)
    public void validate_account_status_update_for_newly_ported_mortgage_throws_exception_when_status_is_not_pending(){
        //given
        MortgageAccountInfo mortgageAccountInfo=mortgagePortingHelper.buildMortgageAccountInfoWithSubAccount(false);
        AccountStatusUpdateRequest accountStatusUpdateRequest = mortgagePortingHelper.buildAccountStatusUpdateRequestWithOverarchingSubAccountAndOpenStatus();
        Map<String,String> reqMap= new HashMap<>();
        MortgagePortingValidator mortgagePortingValidator= new MortgagePortingValidator(mortgageAccountInfoRestClient, mortgageAccountStatusStateMachine);
        when(mortgageAccountInfoRestClient.getMortgageAccountInfo(any(String.class), any(Map.class))).thenReturn(mortgageAccountInfo);
        when(mortgageAccountStatusStateMachine.next(any(AccountStatus.class))).thenReturn(Arrays.asList(AccountStatus.ACCOUNT_STATUS_CANCELLED,AccountStatus.ACCOUNT_STATUS_OPEN));

        //when
        mortgagePortingValidator.validateAccountStatus(accountStatusUpdateRequest, reqMap);

    }

}