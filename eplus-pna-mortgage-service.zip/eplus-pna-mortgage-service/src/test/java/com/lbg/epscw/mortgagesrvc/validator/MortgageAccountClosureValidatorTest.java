package com.lbg.epscw.mortgagesrvc.validator;

import com.lbg.epscw.mortgagesrvc.dto.MortgageClosureEligibility;
import com.lbg.epscw.mortgagesrvc.exception.AccountClosureValidationException;
import com.lbg.epscw.mortgagesrvc.helper.MortgageAccountClosureHelper;
import com.lbg.epscw.mortgagesrvc.restclient.MortgageAccountClosureEligibilityRestClient;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;

import java.util.HashMap;
import java.util.Map;

import static org.mockito.ArgumentMatchers.any;
import static org.powermock.api.mockito.PowerMockito.mock;
import static org.powermock.api.mockito.PowerMockito.when;

public class MortgageAccountClosureValidatorTest {

    @Mock
    private MortgageAccountClosureEligibilityRestClient mortgageAccountClosureEligibilityRestClient;

    private MortgageAccountClosureHelper mortgageAccountClosureHelper=new MortgageAccountClosureHelper();

    @Before
    public void setUp() {
        mortgageAccountClosureEligibilityRestClient=mock(MortgageAccountClosureEligibilityRestClient.class);
    }


    @Test
    public void validate_overarching_account_closure_when_account_is_eligible(){
        //give
        MortgageClosureEligibility mortgageClosureEligibility=mortgageAccountClosureHelper.buildMortgageClosureEligibilityInfo(true);
        Map<String,String> reqMap= new HashMap<>();
        String accountId="ceabb62f-ee67-85da-fb0d-00415c349f89";
        MortgageAccountClosureValidator mortgageAccountClosureValidator= new MortgageAccountClosureValidator(mortgageAccountClosureEligibilityRestClient);
        when(mortgageAccountClosureEligibilityRestClient.getMortgageAccountClosureEligibilityInfo(any(String.class), any(Map.class))).thenReturn(mortgageClosureEligibility);

        //when
        mortgageAccountClosureValidator.validateAccountClosure(accountId, reqMap,new MortgageClosureEligibility());

    }

    @Test(expected = AccountClosureValidationException.class)
    public void validate_overarching_account_closure_when_account_is_not_eligible(){
        //give
        MortgageClosureEligibility mortgageClosureEligibility=mortgageAccountClosureHelper.buildMortgageClosureEligibilityInfo(false);
        Map<String,String> reqMap= new HashMap<>();
        String accountId="ceabb62f-ee67-85da-fb0d-00415c349f89";
        MortgageAccountClosureValidator mortgageAccountClosureValidator= new MortgageAccountClosureValidator(mortgageAccountClosureEligibilityRestClient);
        when(mortgageAccountClosureEligibilityRestClient.getMortgageAccountClosureEligibilityInfo(any(String.class), any(Map.class))).thenReturn(mortgageClosureEligibility);

        //when
        mortgageAccountClosureValidator.validateAccountClosure(accountId, reqMap,new MortgageClosureEligibility());

    }


}