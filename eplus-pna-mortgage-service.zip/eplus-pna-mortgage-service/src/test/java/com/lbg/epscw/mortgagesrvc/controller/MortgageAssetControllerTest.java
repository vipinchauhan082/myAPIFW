package com.lbg.epscw.mortgagesrvc.controller;

import com.lbg.epscw.mortgagesrvc.dto.CapitalizeArrearsResponse;
import com.lbg.epscw.mortgagesrvc.dto.MortgageAccountData;
import com.lbg.epscw.mortgagesrvc.exception.MortgageServiceException;
import com.lbg.epscw.mortgagesrvc.helper.AccountCreationHelper;
import com.lbg.epscw.mortgagesrvc.helper.MortgageAssetDataHelper;
import com.lbg.epscw.mortgagesrvc.helper.MortgagePortingHelper;
import com.lbg.epscw.mortgagesrvc.model.*;
import com.lbg.epscw.mortgagesrvc.service.MortgageAssetService;
import com.lbg.epscw.mortgagesrvc.service.MortgagePortingApplicationInfoService;
import com.lbg.epscw.mortgagesrvc.util.MortgageServiceUtil;
import com.lbg.epscw.mortgagesrvc.validator.MortgageAssetValidator;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mockito;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.ResponseEntity;

import java.util.List;
import java.util.Map;

import static com.lbg.epscw.mortgagesrvc.helper.MortgagePortingHelper.*;
import static com.lbg.epscw.mortgagesrvc.model.MortgagePortingApplicationStatus.REOPEN;
import static com.lbg.epscw.mortgagesrvc.model.MortgagePortingApplicationStatus.DECLINED;
import static java.util.Collections.emptyMap;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;
import static io.opencensus.trace.Tracing.getTracer;
import static io.opencensus.trace.samplers.Samplers.alwaysSample;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.CoreMatchers.is;
import static org.powermock.api.mockito.PowerMockito.when;
import static org.springframework.http.ResponseEntity.ok;

public class MortgageAssetControllerTest {

    public static final String APPLICATION_ID = "1324235";

    private MortgageAssetService service;

    private MortgageAssetController underTest;

    private MortgagePortingApplicationInfoService applicationInfoService;

    private MortgageAssetValidator mortgageAssetValidator;

    public MortgageAssetDataHelper mortgageAssetDataHelper = new MortgageAssetDataHelper();

    private final MortgagePortingHelper portingHelper = new MortgagePortingHelper();

    @Before
    public void setUp() {
        MortgageServiceUtil utility = mock(MortgageServiceUtil.class);
        when(utility.buildSpan(anyString())).thenReturn(getTracer().spanBuilder("any").setSampler(alwaysSample()));
        service = mock(MortgageAssetService.class);
        applicationInfoService = mock(MortgagePortingApplicationInfoService.class);
        mortgageAssetValidator = mock(MortgageAssetValidator.class);
        underTest = new MortgageAssetController(utility, service, applicationInfoService, mortgageAssetValidator);
    }

    @Test
    public void updateAssetInfo() {
        //given
        Asset expected = MortgageAssetDataHelper.generateMortgageAssetUpdateRequest();
        when(service.updateAssetInfo(any(), any())).thenReturn(expected);

        //when
        Asset request = MortgageAssetDataHelper.generateMortgageAssetUpdateRequest();
        ResponseEntity<Asset> response = underTest.updateAssetInfo(BRAND, CHANNEL, CORRELATION_ID, JWT, INTERNAL_SYS_ID, emptyMap(), APPLICATION_ID, request);

        //then
        assertThat(response.getBody(), is(expected));
    }

    @Test
    public void update_Asset_Info_reopen_status() {
        //given
        MortgageApplicationInfo mortgageAccountInfo = portingHelper.mortgageApplicationInfoWithStatus(REOPEN.name());
        when(applicationInfoService.getApplicationInfo(anyString())).thenReturn(mortgageAccountInfo);
        Asset expected = MortgageAssetDataHelper.generateMortgageAssetUpdateRequest();
        when(service.updateAssetInfo(any(), any())).thenReturn(expected);

        //when
        Asset request = MortgageAssetDataHelper.generateMortgageAssetUpdateRequest();
        ResponseEntity<Asset> response = underTest.updateAssetInfo(BRAND, CHANNEL, CORRELATION_ID, JWT, INTERNAL_SYS_ID, emptyMap(), APPLICATION_ID, request);

        //then
        assertThat(response.getBody(), is(expected));
    }

    @Test(expected = MortgageServiceException.class)
    public void mortgage_asset_info_throw_exception_if_service_return_null(){

        when(service.updateAssetInfo(any(),any())).thenReturn(null);
        Asset request = MortgageAssetDataHelper.generateMortgageAssetUpdateRequest();
        ResponseEntity<Asset> responseEntity = underTest.updateAssetInfo("IF","DIGITAL",
                "txnCorrelationId","jwttoken","internalSystemId",emptyMap(),APPLICATION_ID,request);


    }

    @Test(expected = IllegalArgumentException.class)
    public void verify_action_not_permitted() {
        //given
        doThrow(IllegalArgumentException.class).when(service).updateAssetInfo(any(), any());
        //when
        Asset request = new Asset();
        underTest.updateAssetInfo(BRAND, CHANNEL, CORRELATION_ID, JWT, INTERNAL_SYS_ID, emptyMap(), anyString(), request);
        //then expect exception
    }
}