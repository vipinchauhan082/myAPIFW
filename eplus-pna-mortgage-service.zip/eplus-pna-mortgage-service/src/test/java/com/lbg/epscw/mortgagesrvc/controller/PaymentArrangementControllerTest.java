package com.lbg.epscw.mortgagesrvc.controller;

import com.lbg.epscw.mortgagesrvc.constants.CommonConstants;
import com.lbg.epscw.mortgagesrvc.exception.MortgageServiceException;
import com.lbg.epscw.mortgagesrvc.helper.MortgagePaymentArrangementDataHelper;
import com.lbg.epscw.mortgagesrvc.helper.SetupMortgageHelper;
import com.lbg.epscw.mortgagesrvc.model.Channel;
import com.lbg.epscw.mortgagesrvc.model.PaymentArrangementRequest;
import com.lbg.epscw.mortgagesrvc.model.PaymentArrangementResponse;
import com.lbg.epscw.mortgagesrvc.model.PaymentArrangementUpdateRequest;
import com.lbg.epscw.mortgagesrvc.service.MortgagePaymentArrangementService;
import com.lbg.epscw.mortgagesrvc.service.MortgagePaymentHolidayService;
import com.lbg.epscw.mortgagesrvc.util.MortgageServiceUtil;
import com.lbg.epscw.mortgagesrvc.validator.MortgagePaymentArrangementValidator;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.test.context.junit4.SpringRunner;

import javax.validation.ConstraintViolationException;
import java.util.HashMap;
import java.util.Map;

import static org.junit.Assert.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.powermock.api.mockito.PowerMockito.*;

@RunWith(SpringRunner.class)
@WebMvcTest(controllers = { MortgageServiceUtil.class, PaymentArrangementController.class })
public class PaymentArrangementControllerTest {

    @MockBean
    private MortgagePaymentArrangementService mortgagePaymentArrangementService;

    @MockBean
    private MortgagePaymentArrangementValidator mortgagePaymentArrangementValidator;

    @MockBean
    private com.lbg.epscw.mortgagesrvc.validator.MortgagePaymentHolidayValidator mortgagePaymentHolidayValidator;

    @MockBean
    private MortgagePaymentHolidayService mortgagePaymentHolidayService;

    @Autowired
    private PaymentArrangementController paymentArrangementController;

    private MortgagePaymentArrangementDataHelper mortgagePaymentArrangementDataHelper = new MortgagePaymentArrangementDataHelper();

    private SetupMortgageHelper setupMortgageHelper= new SetupMortgageHelper();

    @Test
    public void cancel_payment_arrangement_successful() {
        //given
        doNothing().when(mortgagePaymentArrangementValidator).validateCancelPaymentArrangement(any(String.class), any(Map.class));

        when(mortgagePaymentArrangementService.cancelPaymentArrangement(any(String.class)))
                .thenReturn(mortgagePaymentArrangementDataHelper.buildPaymentArrangementCancelResponse("100"));

        //when
        ResponseEntity<PaymentArrangementResponse> responseEntity = paymentArrangementController
                .cancelPaymentArrangement("IF", Channel.DIGITAL.name(), "123-456-789-12", "Bearer 122", "ALL", new HashMap<String, String>(),
                        "b2c9119f-09e5-4ac9-9738-9e28b334d3fa");
        PaymentArrangementResponse accountOptionsUpdateResponse = responseEntity.getBody();

        //then
        assertEquals("b2c9119f-09e5-4ac9-9738-9e28b334d3fa", accountOptionsUpdateResponse.getAccountId());
        assertEquals("", accountOptionsUpdateResponse.getInstanceParamVals().get(CommonConstants.PAYMENT_ARRANGEMENT_END_MONTH));
    }

    @Test
    public void cancel_payment_arrangement_with_system_id_header() {
        //given
        doNothing().when(mortgagePaymentArrangementValidator).validateCancelPaymentArrangement(any(String.class), any(Map.class));

        when(mortgagePaymentArrangementService.cancelPaymentArrangement(any(String.class)))
                .thenReturn(mortgagePaymentArrangementDataHelper.buildPaymentArrangementCancelResponse("100"));

        //when
        ResponseEntity<PaymentArrangementResponse> responseEntity = paymentArrangementController
                .cancelPaymentArrangement("IF",Channel.DIGITAL.name(), "123-456-789-12", null, "ALL", new HashMap<String, String>(),
                        "b2c9119f-09e5-4ac9-9738-9e28b334d3fa");
        PaymentArrangementResponse accountOptionsUpdateResponse = responseEntity.getBody();

        //then
        assertEquals("b2c9119f-09e5-4ac9-9738-9e28b334d3fa", accountOptionsUpdateResponse.getAccountId());
        assertEquals("100", accountOptionsUpdateResponse.getInstanceParamVals().get(CommonConstants.PAYMENT_ARRANGEMENT_AMOUNT));
        assertEquals("", accountOptionsUpdateResponse.getInstanceParamVals().get(CommonConstants.PAYMENT_ARRANGEMENT_END_MONTH));

    }


    @Test(expected = MortgageServiceException.class)
    public void cancel_payment_arrangement_when_service_layer_fails() {

        //given
        doNothing().when(mortgagePaymentArrangementValidator).validateCancelPaymentArrangement(any(String.class), any(Map.class));

        when(mortgagePaymentArrangementService.cancelPaymentArrangement(any(String.class)))
                .thenReturn(null);

        //when
        ResponseEntity<PaymentArrangementResponse> responseEntity = paymentArrangementController
                .cancelPaymentArrangement("IF",Channel.DIGITAL.name(), "123-456-789-12", null, "ALL", new HashMap<String, String>(),
                        "b2c9119f-09e5-4ac9-9738-9e28b334d3fa");
    }

    @Test(expected = AccessDeniedException.class)
    public void cancel_payment_arrangement_when_validation_fails() {
        //given
        doThrow(new AccessDeniedException("Entitlement rejected request")).when(mortgagePaymentArrangementValidator)
                .validateCancelPaymentArrangement(any(String.class),any(Map.class));

        //when
        ResponseEntity<PaymentArrangementResponse> responseEntity = paymentArrangementController
                .cancelPaymentArrangement("IF",Channel.DIGITAL.name(), "123-456-789-12", null, "ALL", new HashMap<String, String>(),
                        "b2c9119f-09e5-4ac9-9738-9e28b334d3fa");

    }

    @Test(expected = ConstraintViolationException.class)
    public void cancel_payment_arrangement_rejects_request_if_account_id_length_is_small() {

        //when
        ResponseEntity<PaymentArrangementResponse> responseEntity = paymentArrangementController
                .cancelPaymentArrangement("IF",Channel.DIGITAL.name(), "123-456-789-12", null, "ALL", new HashMap<String, String>(),
                        "b2c9119f-09e5-4ac9-9738-9e28b334fa");

    }

    @Test(expected = ConstraintViolationException.class)
    public void cancel_payment_arrangement_rejects_request_if_account_id_length_is_big() {

        //when
        ResponseEntity<PaymentArrangementResponse> responseEntity = paymentArrangementController
                .cancelPaymentArrangement("IF",Channel.DIGITAL.name(), "123-456-789-12", null, "ALL", new HashMap<String, String>(),
                        "b2c9119f-09e5-4ac9-9738-9e28b334d3fa23");

    }

    @Test(expected = ConstraintViolationException.class)
    public void cancel_payment_arrangement_rejects_request_if_account_id_length_is_null() {

        //when
        ResponseEntity<PaymentArrangementResponse> responseEntity = paymentArrangementController
                .cancelPaymentArrangement("IF",Channel.DIGITAL.name(), "123-456-789-12", null, "ALL", new HashMap<String, String>(),
                        null);

    }

    @Test(expected = ConstraintViolationException.class)
    public void cancel_payment_arrangement_rejects_request_if_account_id_length_is_empty() {

        //when
        ResponseEntity<PaymentArrangementResponse> responseEntity = paymentArrangementController
                .cancelPaymentArrangement("IF",Channel.DIGITAL.name(), "123-456-789-12", null, "ALL", new HashMap<String, String>(),
                        "");

    }

    @Test
    public void update_payment_arrangement_amount_start_date_and_end_date_options_successful() {
        //given
        doNothing().when(mortgagePaymentArrangementValidator).validateUpdatePaymentArrangementRequest(any(PaymentArrangementUpdateRequest.class),any(String.class),any(Map.class));

        when(mortgagePaymentArrangementService.updatePaymentArrangement(any(PaymentArrangementUpdateRequest.class), any(String.class)))
                .thenReturn(mortgagePaymentArrangementDataHelper.buildPaymentArrangementUpdateAmountAndEndDateUserResponse("100","10/2020"));

        //when
        ResponseEntity<PaymentArrangementResponse> responseEntity = paymentArrangementController
                .amendPaymentArrangement("IF", Channel.DIGITAL.name(), "123-456-789-12", "Bearer 122", "ALL", new HashMap<String, String>(),
                        mortgagePaymentArrangementDataHelper.buildOPaymentArrangementUpdateRequestAmendAmountStartDateAndEndDate("100", "10/2050", "11/2051"), "b2c9119f-09e5-4ac9-9738-9e28b334d3fa");
        PaymentArrangementResponse accountOptionsUpdateResponse = responseEntity.getBody();

        //then
        assertEquals("b2c9119f-09e5-4ac9-9738-9e28b334d3fa", accountOptionsUpdateResponse.getAccountId());
        assertEquals("100", accountOptionsUpdateResponse.getInstanceParamVals().get(CommonConstants.PAYMENT_ARRANGEMENT_AMOUNT));
        assertEquals("10/2020", accountOptionsUpdateResponse.getInstanceParamVals().get(CommonConstants.PAYMENT_ARRANGEMENT_END_MONTH));
    }


    @Test
    public void update_payment_arrangement_with_system_id_header() {
        //given
        doNothing().when(mortgagePaymentArrangementValidator).validateUpdatePaymentArrangementRequest(any(PaymentArrangementUpdateRequest.class),any(String.class),any(Map.class));

        when(mortgagePaymentArrangementService.updatePaymentArrangement(any(PaymentArrangementUpdateRequest.class), any(String.class)))
                .thenReturn(mortgagePaymentArrangementDataHelper.buildPaymentArrangementUpdateAmountAndEndDateUserResponse("100","10/2020"));
        //when
        ResponseEntity<PaymentArrangementResponse> responseEntity = paymentArrangementController
                .amendPaymentArrangement("IF",Channel.DIGITAL.name(), "123-456-789-12", null, "ALL", new HashMap<String, String>(),
                        mortgagePaymentArrangementDataHelper.buildOPaymentArrangementUpdateRequestAmendAmountStartDateAndEndDate("100", "10/2050", "11/2051"), "b2c9119f-09e5-4ac9-9738-9e28b334d3fa");
        PaymentArrangementResponse accountOptionsUpdateResponse = responseEntity.getBody();

        //then
        assertEquals("b2c9119f-09e5-4ac9-9738-9e28b334d3fa", accountOptionsUpdateResponse.getAccountId());
        assertEquals("100", accountOptionsUpdateResponse.getInstanceParamVals().get(CommonConstants.PAYMENT_ARRANGEMENT_AMOUNT));
    }


    @Test(expected = MortgageServiceException.class)
    public void update_payment_arrangement_when_service_layer_fails() {
        //given
        doNothing().when(mortgagePaymentArrangementValidator).validateUpdatePaymentArrangementRequest(any(PaymentArrangementUpdateRequest.class),any(String.class),any(Map.class));

        when(mortgagePaymentArrangementService.updatePaymentArrangement(any(PaymentArrangementUpdateRequest.class), any(String.class)))
                .thenReturn(null);

        //when
        ResponseEntity<PaymentArrangementResponse> responseEntity = paymentArrangementController
                .amendPaymentArrangement("IF",Channel.DIGITAL.name(), "123-456-789-12", null, "ALL", new HashMap<String, String>(),
                        mortgagePaymentArrangementDataHelper.buildOPaymentArrangementUpdateRequestAmendAmountStartDateAndEndDate("100", "10/2050", "11/2051"), "b2c9119f-09e5-4ac9-9738-9e28b334d3fa");
    }

    @Test(expected = AccessDeniedException.class)
    public void update_payment_arrangement_when_validation_fails() {
        //given
        doThrow(new AccessDeniedException("Entitlement rejected request")).when(mortgagePaymentArrangementValidator)
                .validateUpdatePaymentArrangementRequest(any(PaymentArrangementUpdateRequest.class),any(String.class),any(Map.class));

        //when
        ResponseEntity<PaymentArrangementResponse> responseEntity = paymentArrangementController
                .amendPaymentArrangement("IF",Channel.DIGITAL.name(), "123-456-789-12", null, "ALL", new HashMap<String, String>(),
                        mortgagePaymentArrangementDataHelper.buildOPaymentArrangementUpdateRequestAmendAmountStartDateAndEndDate("100", "10/2050", "11/2051"), "b2c9119f-09e5-4ac9-9738-9e28b334d3fa");

    }

    @Test(expected = ConstraintViolationException.class)
    public void update_payment_arrangement_rejects_request_if_account_id_length_is_small() {

        //when
        ResponseEntity<PaymentArrangementResponse> responseEntity = paymentArrangementController
            .amendPaymentArrangement("IF",Channel.DIGITAL.name(), "123-456-789-12", null, "ALL", new HashMap<String, String>(),
                mortgagePaymentArrangementDataHelper.buildOPaymentArrangementUpdateRequestAmendAmountStartDateAndEndDate("100", "10/2050", "11/2051"), "b2c9119f-09e5-4ac9-9738-9e28b334fa");
    }

    @Test(expected = ConstraintViolationException.class)
    public void update_payment_arrangement_rejects_request_if_account_id_length_is_big() {

        //when
        ResponseEntity<PaymentArrangementResponse> responseEntity = paymentArrangementController
                .amendPaymentArrangement("IF",Channel.DIGITAL.name(), "123-456-789-12", null, "ALL", new HashMap<String, String>(),
                        mortgagePaymentArrangementDataHelper.buildOPaymentArrangementUpdateRequestAmendAmountStartDateAndEndDate("100", "10/2050", "11/2051"), "b2c9119f-09e5big-4ac9-9738-9e28b334d3fa");

    }

    @Test(expected = ConstraintViolationException.class)
    public void update_payment_arrangement_rejects_request_if_account_id_length_is_null() {
        //when
        ResponseEntity<PaymentArrangementResponse> responseEntity = paymentArrangementController
                .amendPaymentArrangement("IF",Channel.DIGITAL.name(), "123-456-789-12", null, "ALL", new HashMap<String, String>(),
                        mortgagePaymentArrangementDataHelper.buildOPaymentArrangementUpdateRequestAmendAmountStartDateAndEndDate("100", "10/2050", "11/2051"), null);
    }

    @Test(expected = ConstraintViolationException.class)
    public void update_payment_arrangement_rejects_request_if_account_id_length_is_empty() {

        //when
        ResponseEntity<PaymentArrangementResponse> responseEntity = paymentArrangementController
                .amendPaymentArrangement("IF",Channel.DIGITAL.name(), "123-456-789-12", null, "ALL", new HashMap<String, String>(),
                        mortgagePaymentArrangementDataHelper.buildOPaymentArrangementUpdateRequestAmendAmountStartDateAndEndDate("100", "10/2050", "11/2051"), "");

    }

    @Test(expected = ConstraintViolationException.class)
    public void update_payment_arrangement_rejects_request_if_payment_arrangement_amount_is_empty() {

        //when
        ResponseEntity<PaymentArrangementResponse> responseEntity = paymentArrangementController
                .amendPaymentArrangement("IF",Channel.DIGITAL.name(), "123-456-789-12", null, "ALL", new HashMap<String, String>(),
                        mortgagePaymentArrangementDataHelper.buildOPaymentArrangementUpdateRequestAmendAmountStartDateAndEndDate("", "10/2050", "11/2051"), "");

    }

    @Test(expected = ConstraintViolationException.class)
    public void update_payment_arrangement_rejects_request_if_payment_arrangement_amount_is_null() {

        //when
        ResponseEntity<PaymentArrangementResponse> responseEntity = paymentArrangementController
                .amendPaymentArrangement("IF",Channel.DIGITAL.name(), "123-456-789-12", null, "ALL", new HashMap<String, String>(),
                        mortgagePaymentArrangementDataHelper.buildOPaymentArrangementUpdateRequestAmendAmountStartDateAndEndDate(null, "10/2050", "11/2051"), "");

    }

    @Test(expected = ConstraintViolationException.class)
    public void update_payment_arrangement_rejects_request_if_payment_arrangement_start_date_is_empty() {

        //when
        ResponseEntity<PaymentArrangementResponse> responseEntity = paymentArrangementController
                .amendPaymentArrangement("IF",Channel.DIGITAL.name(), "123-456-789-12", null, "ALL", new HashMap<String, String>(),
                        mortgagePaymentArrangementDataHelper.buildOPaymentArrangementUpdateRequestAmendAmountStartDateAndEndDate("100", "", "11/2051"), "");

    }

    @Test(expected = ConstraintViolationException.class)
    public void update_payment_arrangement_rejects_request_if_payment_arrangement_start_date_is_null() {

        //when
        ResponseEntity<PaymentArrangementResponse> responseEntity = paymentArrangementController
                .amendPaymentArrangement("IF",Channel.DIGITAL.name(), "123-456-789-12", null, "ALL", new HashMap<String, String>(),
                        mortgagePaymentArrangementDataHelper.buildOPaymentArrangementUpdateRequestAmendAmountStartDateAndEndDate("100", null, "11/2051"), "");

    }

    @Test
    public void setup_payment_arrangement_successful(){
        //given
        doNothing().when(mortgagePaymentArrangementValidator).validateSetupPaymentArrangementRequest(any(PaymentArrangementRequest.class),any(String.class),any(Map.class));

        //when
        when(mortgagePaymentArrangementService.setUpPaymentArrangement(any(PaymentArrangementRequest.class),any(String.class)))
                .thenReturn(setupMortgageHelper.mock_PaymentArrangementSetupResponse());

        //when
        ResponseEntity<PaymentArrangementResponse> responseEntity = paymentArrangementController
                .setUpPaymentArrangement("IF",Channel.DIGITAL.name(), "123-456-789-12", "Bearer 122", "ALL", new HashMap<String, String>(),
                        setupMortgageHelper.paymentArrangementRequest(), "ceabb62f-ee67-85da-fb0d-00415c349f89");
        PaymentArrangementResponse paymentArrangementResponse= responseEntity.getBody();

        //then
        assertEquals("ceabb62f-ee67-85da-fb0d-00415c349f89", paymentArrangementResponse.getAccountId());

    }

    @Test
    public void setup_payment_arrangement_successful_with_system_id_in_header() {
        //given
        doNothing().when(mortgagePaymentArrangementValidator).validateSetupPaymentArrangementRequest(any(PaymentArrangementRequest.class),any(String.class),any(Map.class));

        //when
        when(mortgagePaymentArrangementService.setUpPaymentArrangement(any(PaymentArrangementRequest.class),any(String.class)))
                .thenReturn(setupMortgageHelper.mock_PaymentArrangementSetupResponse());

        //when
        ResponseEntity<PaymentArrangementResponse> responseEntity = paymentArrangementController
                .setUpPaymentArrangement("IF",Channel.DIGITAL.name(), "123-456-789-12", null, "ALL", new HashMap<String, String>(),
                        setupMortgageHelper.paymentArrangementRequest(), "ceabb62f-ee67-85da-fb0d-00415c349f89");
        PaymentArrangementResponse paymentArrangementResponse= responseEntity.getBody();

        //then
        assertEquals("ceabb62f-ee67-85da-fb0d-00415c349f89", paymentArrangementResponse.getAccountId());

    }

    @Test(expected = MortgageServiceException.class)
    public void setup_payment_arrangement_when_service_layer_fails(){

        doNothing().when(mortgagePaymentArrangementValidator).validateSetupPaymentArrangementRequest(any(PaymentArrangementRequest.class),any(String.class),any(Map.class));

        when(mortgagePaymentArrangementService.setUpPaymentArrangement(any(PaymentArrangementRequest.class),any(String.class)))
                .thenReturn(null);

        ResponseEntity<PaymentArrangementResponse> responseEntity = paymentArrangementController
                .setUpPaymentArrangement("IF",Channel.DIGITAL.name(), "123-456-789-12", null, "ALL", new HashMap<String, String>(),
                        setupMortgageHelper.paymentArrangementRequest(), "ceabb62f-ee67-85da-fb0d-00415c349f89");


    }

    @Test(expected = AccessDeniedException.class)
    public void setup_payment_arrangement_fails_when_validation_fails() {
        //given
        doThrow(new AccessDeniedException("Entitlement rejected request")).when(mortgagePaymentArrangementValidator).
                validateSetupPaymentArrangementRequest(any(PaymentArrangementRequest.class),any(String.class),any(Map.class));

        //when
        paymentArrangementController
                .setUpPaymentArrangement("IF",Channel.DIGITAL.name(), "123-456-789-12", "Bearer 122", "ALL", new HashMap<String, String>(),
                        setupMortgageHelper.paymentArrangementRequest(), "ceabb62f-ee67-85da-fb0d-00415c349f89");
    }



    @Test(expected = ConstraintViolationException.class)
    public void setup_payment_arrangement_rejects_request_if_accountId_violates() {
        //when
        ResponseEntity<PaymentArrangementResponse> responseEntity = paymentArrangementController
                .setUpPaymentArrangement("IF",Channel.DIGITAL.name(), "123-456-789-12", "Bearer 122", "ALL", new HashMap<String, String>(),
                        setupMortgageHelper.paymentArrangementRequest(), "5c349f89");
    }

    @Test(expected = ConstraintViolationException.class)
    public void setup_payment_arrangement_rejects_request_if_brand_header_is_violates() {
        //when
        ResponseEntity<PaymentArrangementResponse> responseEntity = paymentArrangementController
                .setUpPaymentArrangement("IFF",Channel.DIGITAL.name(), "123-456-789-12", "Bearer 122", "ALL", new HashMap<String, String>(),
                        setupMortgageHelper.paymentArrangementRequest(), "ceabb62f-ee67-85da-fb0d-00415c349f89");
    }

    @Test(expected = ConstraintViolationException.class)
    public void setup_overpayment_options_rejects_request_if_txncorrelationId_header_violates() {
        //when
        ResponseEntity<PaymentArrangementResponse> responseEntity = paymentArrangementController
                .setUpPaymentArrangement("IF",Channel.DIGITAL.name(),null, "Bearer 122", "ALL", new HashMap<String, String>(),
                        setupMortgageHelper.paymentArrangementRequest(), "ceabb62f-ee67-85da-fb0d-00415c349f89");
    }

}
