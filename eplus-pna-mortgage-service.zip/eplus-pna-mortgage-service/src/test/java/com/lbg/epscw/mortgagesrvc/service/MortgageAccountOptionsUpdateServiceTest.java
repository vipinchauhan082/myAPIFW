package com.lbg.epscw.mortgagesrvc.service;

import com.lbg.epscw.mortgagesrvc.enums.MortgageOptionInstructionEnum;
import com.lbg.epscw.mortgagesrvc.enums.RepaymentType;
import com.lbg.epscw.mortgagesrvc.exception.CircuitBreakerOpenException;
import com.lbg.epscw.mortgagesrvc.helper.MortgageAccountDataHelper;
import com.lbg.epscw.mortgagesrvc.helper.MortgageAccountOptionDataHelper;
import com.lbg.epscw.mortgagesrvc.model.*;
import com.lbg.epscw.mortgagesrvc.restclient.MortgageAccountInfoRestClient;
import com.lbg.epscw.mortgagesrvc.restclient.MortgageAccountOptionRestClient;
import com.lbg.epscw.mortgagesrvc.util.MortgageServiceUtil;
import org.junit.Before;
import org.junit.Test;
import org.mockito.ArgumentCaptor;
import org.mockito.Mock;

import java.util.HashMap;
import java.util.Map;

import static com.lbg.epscw.mortgagesrvc.constants.CommonConstants.KEY_MORTGAGE_TYPE;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.mockito.ArgumentMatchers.*;
import static org.powermock.api.mockito.PowerMockito.mock;
import static org.powermock.api.mockito.PowerMockito.when;

public class MortgageAccountOptionsUpdateServiceTest {

    @Mock
    private MortgageServiceUtil mortgageServiceUtil;

    @Mock
    private MortgageAccountOptionRestClient mortgageAccountOptionRestClient;

    @Mock
    private MortgageAccountInfoRestClient mortgageAccountInfoRestClient;

    private MortgageAccountOptionDataHelper mortgageAccountOptionDataHelper = new MortgageAccountOptionDataHelper();
    private MortgageAccountDataHelper mortgageAccountDataHelper = new MortgageAccountDataHelper();

    @Before
    public void setup() {
        mortgageAccountInfoRestClient = mock(MortgageAccountInfoRestClient.class);
        mortgageAccountOptionRestClient = mock(MortgageAccountOptionRestClient.class);
        mortgageServiceUtil = mock(MortgageServiceUtil.class);
    }


    @Test
    public void update_acc_option_for_repayment_type() {

        AccountOptionsUpdateResponse accountOptionsUpdateResponse = mortgageAccountOptionDataHelper.buildAccountOptionsUpdateResponse( KEY_MORTGAGE_TYPE, RepaymentType.CAPITAL_REPAYMENT.name());
        AccountOptionsUpdateRequest accountUpdateReq =  mortgageAccountOptionDataHelper.buildAccountOptionsUpdateRequestForMortgageType(RepaymentType.CAPITAL_REPAYMENT.name());
        accountUpdateReq.setRepaymentType(RepaymentType.CAPITAL_REPAYMENT.name());
        MortgageAccountOptionsUpdateService mortgageAccountOptionService = new  MortgageAccountOptionsUpdateServiceImpl(mortgageServiceUtil,mortgageAccountOptionRestClient, mortgageAccountInfoRestClient);
        when(mortgageAccountInfoRestClient.getMortgageAccountInfo(any(String.class), any(Map.class))).thenReturn(mortgageAccountDataHelper.buildViewAccountInfo());
        when(mortgageAccountOptionRestClient.updateAccountOptions(any(VaultAccountOptionsUpdateRequest.class))).thenReturn(accountOptionsUpdateResponse);
        when(mortgageServiceUtil.writeObjectAsString(any())).thenReturn("");
        Map<String, String> reqAsObject = new HashMap<>();
        reqAsObject.put("RepaymentType","RepaymentType.CAPITAL_REPAYMENT.name()");
        when(mortgageServiceUtil.readObject(anyString(),any())).thenReturn(reqAsObject);
        MortgageOptionsUpdateResponse response = mortgageAccountOptionService.updateAccountOptions(accountUpdateReq, "1601d0e5-e336-64d9-64ad-89ba6fdc2677", new HashMap<>());
        assertNotNull(response);
        assertEquals("CAPITAL_REPAYMENT", response.getInstanceParamVals().get("RepaymentType"));
    }

    @Test
    public void update_acc_option_for_mortgage_term() {

        AccountOptionsUpdateResponse accountOptionsUpdateResponse = mortgageAccountOptionDataHelper.buildAccountOptionsUpdateResponse("TotalTerm","30");
        AccountOptionsUpdateRequest accountUpdateReq =  mortgageAccountOptionDataHelper.buildAccountOptionsUpdateRequestForMortgageTerm(MortgageOptionInstructionEnum.MortgageTermExtend,"30");
        accountUpdateReq.setTotalTerm("20");
        MortgageAccountOptionsUpdateService mortgageAccountOptionService = new  MortgageAccountOptionsUpdateServiceImpl(mortgageServiceUtil,mortgageAccountOptionRestClient, mortgageAccountInfoRestClient);
        when(mortgageAccountInfoRestClient.getMortgageAccountInfo(any(String.class), any(Map.class))).thenReturn(mortgageAccountDataHelper.buildViewAccountInfo());

        ArgumentCaptor<VaultAccountOptionsUpdateRequest> captor = ArgumentCaptor.forClass(VaultAccountOptionsUpdateRequest.class);
        when(mortgageAccountOptionRestClient.updateAccountOptions(captor.capture())).thenReturn(accountOptionsUpdateResponse);


        ArgumentCaptor<AccountOptionsUpdateRequest> accountOptionsUpdateRequestCaptor = ArgumentCaptor.forClass(AccountOptionsUpdateRequest.class);

        when(mortgageServiceUtil.writeObjectAsString(accountOptionsUpdateRequestCaptor.capture())).thenReturn("");
        Map<String, String> reqAsObject = new HashMap<>();
        reqAsObject.put("TotalTerm","4");
        when(mortgageServiceUtil.readObject(anyString(),any())).thenReturn(reqAsObject);
        MortgageOptionsUpdateResponse response = mortgageAccountOptionService.updateAccountOptions(accountUpdateReq,"1601d0e5-e336-64d9-64ad-89ba6fdc2677", new HashMap<>());
        assertNotNull(response);
        assertEquals("28", accountOptionsUpdateRequestCaptor.getValue().getTotalTerm());
    }


    @Test
    public void update_acc_option_should_skip_tye_param_if_no_matching_name_found() {

        AccountOptionsUpdateResponse accountOptionsUpdateResponse = mortgageAccountOptionDataHelper.buildAccountOptionsUpdateResponse("total_term","30");
        accountOptionsUpdateResponse.getInstanceParamValsUpdate().getInstanceParamVals().put("term","");

        AccountOptionsUpdateRequest accountUpdateReq =  mortgageAccountOptionDataHelper.buildAccountOptionsUpdateRequestForMortgageTerm(MortgageOptionInstructionEnum.MortgageTermExtend,"30");
        accountUpdateReq.setTotalTerm("20");
        MortgageAccountOptionsUpdateService mortgageAccountOptionService = new  MortgageAccountOptionsUpdateServiceImpl(mortgageServiceUtil,mortgageAccountOptionRestClient, mortgageAccountInfoRestClient);
        when(mortgageAccountInfoRestClient.getMortgageAccountInfo(any(String.class), any(Map.class))).thenReturn(mortgageAccountDataHelper.buildViewAccountInfo());

        ArgumentCaptor<VaultAccountOptionsUpdateRequest> captor = ArgumentCaptor.forClass(VaultAccountOptionsUpdateRequest.class);
        when(mortgageAccountOptionRestClient.updateAccountOptions(captor.capture())).thenReturn(accountOptionsUpdateResponse);


        ArgumentCaptor<AccountOptionsUpdateRequest> accountOptionsUpdateRequestCaptor = ArgumentCaptor.forClass(AccountOptionsUpdateRequest.class);

        when(mortgageServiceUtil.writeObjectAsString(accountOptionsUpdateRequestCaptor.capture())).thenReturn("");
        Map<String, String> reqAsObject = new HashMap<>();
        reqAsObject.put("TotalTerm","4");
        when(mortgageServiceUtil.readObject(anyString(),any())).thenReturn(reqAsObject);
        MortgageOptionsUpdateResponse response = mortgageAccountOptionService.updateAccountOptions(accountUpdateReq,"1601d0e5-e336-64d9-64ad-89ba6fdc2677", new HashMap<>());
        assertNotNull(response);
        assertEquals(1, response.getInstanceParamVals().size());
    }


    @Test(expected = CircuitBreakerOpenException.class)
    public void hystrix_test_on_update_acc_option() {
        MortgageAccountOptionsUpdateServiceImpl mortgageAccountOptionService = new  MortgageAccountOptionsUpdateServiceImpl(mortgageServiceUtil,mortgageAccountOptionRestClient, mortgageAccountInfoRestClient);



        AccountOptionsUpdateRequest req = mortgageAccountOptionDataHelper.buildAccountOptionsUpdateRequestForMortgageTerm(MortgageOptionInstructionEnum.MortgageTermExtend,"0");
        AccountOptionsUpdateRequest accountUpdateReq =  mortgageAccountOptionDataHelper.buildAccountOptionsUpdateRequestForMortgageTerm(MortgageOptionInstructionEnum.MortgageTermExtend,"30");
        mortgageAccountOptionService.fallbackUpdateMortgageAccountOptions(accountUpdateReq,"f76ca840-2553-d536-1ab8-9fa85c99db05", new HashMap<>(), new Throwable("Circuit open on update account options"));
    }
}
