package com.lbg.epscw.mortgagesrvc.service;

import com.lbg.epscw.mortgagesrvc.exception.CircuitBreakerOpenException;
import com.lbg.epscw.mortgagesrvc.helper.MortgagePaymentOptionHelper;
import com.lbg.epscw.mortgagesrvc.model.MortgagePaymentOptionRequest;
import com.lbg.epscw.mortgagesrvc.model.MortgagePaymentOptionUpdateResponse;
import com.lbg.epscw.mortgagesrvc.model.VaultAccountOptionsUpdateRequest;
import com.lbg.epscw.mortgagesrvc.restclient.MortgageAccountOptionRestClient;
import com.lbg.epscw.mortgagesrvc.util.MortgageServiceUtil;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.Map;

import static org.mockito.ArgumentMatchers.any;
import static org.powermock.api.mockito.PowerMockito.mock;
import static org.powermock.api.mockito.PowerMockito.when;

@RunWith(SpringRunner.class)
public class MortgagePaymentOptionServiceImplTest {

    @Mock
    private MortgageServiceUtil mortgageServiceUtil;

    @Mock
    private MortgageAccountOptionRestClient mortgageAccountOptionRestClient;

    @Before
    public void setup() {
        mortgageAccountOptionRestClient = mock(MortgageAccountOptionRestClient.class);
        mortgageServiceUtil=mock(MortgageServiceUtil.class);
    }

    private MortgagePaymentOptionHelper mortgagePaymentOptionHelper = new MortgagePaymentOptionHelper();

    @Test
    public void update_mortgage_payment_option_success(){

        MortgagePaymentOptionService mortgagePaymentOptionService= new MortgagePaymentOptionServiceImpl(mortgageAccountOptionRestClient, mortgageServiceUtil);

        when(mortgageServiceUtil.writeObjectAsString(any(MortgagePaymentOptionRequest.class))).thenReturn("tempString");

        Map<String,String> readObjectMap= mortgagePaymentOptionHelper.readObjectResponse();

        when(mortgageServiceUtil.readObject(any(String.class),any())).thenReturn(readObjectMap);

        when(mortgageAccountOptionRestClient.updateAccountOptions(any(VaultAccountOptionsUpdateRequest.class))).thenReturn(mortgagePaymentOptionHelper.mock_AccountOptionsUpdateResponse());

        MortgagePaymentOptionUpdateResponse mortgagePaymentOptionUpdateResponse = mortgagePaymentOptionService.updateMortgagePaymentOption(mortgagePaymentOptionHelper.getMortgagePaymentRequest(),mortgagePaymentOptionHelper.mortgageAccountInfo_withOffsetting(),"5a688301-6d00-485c-0242-1ee03844a5c4");

        Assert.assertEquals("5a688301-6d00-485c-0242-1ee03844a5c4", mortgagePaymentOptionUpdateResponse.getAccountId());
        Assert.assertEquals("LOWER_PAYMENTS",mortgagePaymentOptionUpdateResponse.getInstanceParamVals().get("MortgagePaymentOption"));
    }

    @Test
    public void update_mortgage_payment_option_returns_null(){

        MortgagePaymentOptionService mortgagePaymentOptionService= new MortgagePaymentOptionServiceImpl(mortgageAccountOptionRestClient, mortgageServiceUtil);

        when(mortgageServiceUtil.writeObjectAsString(any(MortgagePaymentOptionRequest.class))).thenReturn("tempString");

        Map<String,String> readObjectMap= mortgagePaymentOptionHelper.readObjectResponse();

        when(mortgageServiceUtil.readObject(any(String.class),any())).thenReturn(readObjectMap);

        when(mortgageAccountOptionRestClient.updateAccountOptions(any(VaultAccountOptionsUpdateRequest.class))).thenReturn(null);

        MortgagePaymentOptionUpdateResponse mortgagePaymentOptionUpdateResponse = mortgagePaymentOptionService.updateMortgagePaymentOption(mortgagePaymentOptionHelper.getMortgagePaymentRequest(),mortgagePaymentOptionHelper.mortgageAccountInfo_withOffsetting(),"5a688301-6d00-485c-0242-1ee03844a5c4");

        Assert.assertEquals(null,mortgagePaymentOptionUpdateResponse);

    }

    @Test(expected = CircuitBreakerOpenException.class)
    public void hystrix_test_on_fallbackUpdateMortgagePaymentOption() {

        MortgagePaymentOptionServiceImpl mortgagePaymentOptionService= new MortgagePaymentOptionServiceImpl(mortgageAccountOptionRestClient, mortgageServiceUtil);

        mortgagePaymentOptionService.fallbackUpdateMortgagePaymentOption(mortgagePaymentOptionHelper.getMortgagePaymentRequest(),mortgagePaymentOptionHelper.mortgageAccountInfo_withOffsetting(),"f76ca840-2553-d536-1ab8-9fa85c99db05",
                new Exception("Circuit open on update account options"));
    }
}
