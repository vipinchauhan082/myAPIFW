package com.lbg.epscw.mortgagesrvc.validator;

import com.lbg.epscw.mortgagesrvc.dto.MortgageAccountData;
import com.lbg.epscw.mortgagesrvc.dto.MortgageAccountInfo;
import com.lbg.epscw.mortgagesrvc.exception.MortgageValidationException;
import com.lbg.epscw.mortgagesrvc.helper.AccountCreationHelper;
import com.lbg.epscw.mortgagesrvc.model.OverarchingAccountInfo;
import com.lbg.epscw.mortgagesrvc.restclient.MortgageAccountBalanceRestClient;
import com.lbg.epscw.mortgagesrvc.restclient.MortgageAccountInfoRestClient;
import com.lbg.epscw.mortgagesrvc.util.MortgageServiceUtil;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.test.context.junit4.SpringRunner;
import org.junit.Test;

import java.util.List;

import static org.powermock.api.mockito.PowerMockito.when;
import static org.mockito.ArgumentMatchers.anyMap;
import static org.mockito.ArgumentMatchers.anyString;

@RunWith(SpringRunner.class)
public class MortgageArrearsCapitalizeValidatorTest {

    @InjectMocks
    private MortgageArrearsCapitalizeValidator mortgageArrearsCapitalizeValidator;

    @Mock
    private MortgageAccountInfoRestClient mortgageAccountInfoRestClient;

    @Mock
    private MortgageAccountBalanceRestClient mortgageAccountBalanceRestClient;

    @Mock
    private MortgageServiceUtil mortgageServiceUtil;


    @Test(expected = MortgageValidationException.class)
    public void validateCapitalizationOfArrearsForInvalidOverArchingAccount(){

        MortgageAccountInfo mortgageAccountInfo = new MortgageAccountInfo();
        mortgageAccountInfo.setMortgageAccountData(AccountCreationHelper.getMortgageSubAccountData());
        when(mortgageAccountInfoRestClient.getMortgageAccountInfo(anyString(), anyMap())).thenReturn(mortgageAccountInfo);
        OverarchingAccountInfo overarchingAccountInfo = new OverarchingAccountInfo();
        overarchingAccountInfo.setAccountId("5a688301-6d00-485c-0242-1ee03844a5c4");
        mortgageArrearsCapitalizeValidator.validateCapitalizationOfArrears(overarchingAccountInfo,AccountCreationHelper.generateRequiredHeaders());
    }


    @Test(expected = MortgageValidationException.class)
    public void capitalizationOfArrearsShouldResultInExceptionIfAccountIsNotInArrears(){

        MortgageAccountInfo mortgageAccountInfo = new MortgageAccountInfo();
        List<MortgageAccountData> mortgageSubAccountData = AccountCreationHelper.getMortgageSubAccountData();
        mortgageSubAccountData.get(0).setProductFamily("Mortgage Payment");
        mortgageSubAccountData.get(0).setMortgageInArrears(false);
        mortgageAccountInfo.setMortgageAccountData(mortgageSubAccountData);
        when(mortgageAccountInfoRestClient.getMortgageAccountInfo(anyString(), anyMap())).thenReturn(mortgageAccountInfo);
        when(mortgageAccountBalanceRestClient.getMortgageAccountBalanceInfo(anyString(),anyMap())).thenReturn(AccountCreationHelper.getMortgageOverarchingBalance());
        OverarchingAccountInfo overarchingAccountInfo = new OverarchingAccountInfo();
        overarchingAccountInfo.setAccountId("5a688301-6d00-485c-0242-1ee03844a5c4");
        mortgageArrearsCapitalizeValidator.validateCapitalizationOfArrears(overarchingAccountInfo,AccountCreationHelper.generateRequiredHeaders());
    }

    @Test
    public void capitalizationOfArrearsShouldNotResultInExceptionIfAccountIsInArrears(){

        MortgageAccountInfo mortgageAccountInfo = new MortgageAccountInfo();
        List<MortgageAccountData> mortgageSubAccountData = AccountCreationHelper.getMortgageSubAccountData();
        mortgageSubAccountData.get(0).setProductFamily("Mortgage Payment");
        mortgageSubAccountData.get(0).setMortgageInArrears(true);
        mortgageAccountInfo.setMortgageAccountData(mortgageSubAccountData);
        when(mortgageAccountInfoRestClient.getMortgageAccountInfo(anyString(), anyMap())).thenReturn(mortgageAccountInfo);
        when(mortgageAccountBalanceRestClient.getMortgageAccountBalanceInfo(anyString(),anyMap())).thenReturn(AccountCreationHelper.getMortgageOverarchingBalanceWithArrears());
        OverarchingAccountInfo overarchingAccountInfo = new OverarchingAccountInfo();
        overarchingAccountInfo.setAccountId("5a688301-6d00-485c-0242-1ee03844a5c4");
        mortgageArrearsCapitalizeValidator.validateCapitalizationOfArrears(overarchingAccountInfo,AccountCreationHelper.generateRequiredHeaders());
    }



}
