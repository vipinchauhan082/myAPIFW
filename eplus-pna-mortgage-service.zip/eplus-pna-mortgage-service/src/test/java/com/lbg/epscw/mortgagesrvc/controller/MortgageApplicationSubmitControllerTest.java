package com.lbg.epscw.mortgagesrvc.controller;

import com.lbg.epscw.mortgagesrvc.exception.MortgageServiceException;
import com.lbg.epscw.mortgagesrvc.exception.MortgageValidationException;
import com.lbg.epscw.mortgagesrvc.helper.MortgagePortingApplicationHelper;
import com.lbg.epscw.mortgagesrvc.helper.MortgagePortingHelper;
import com.lbg.epscw.mortgagesrvc.model.*;
import com.lbg.epscw.mortgagesrvc.service.MortgagePortingApplicationInfoService;
import com.lbg.epscw.mortgagesrvc.service.MortgagePortingService;
import com.lbg.epscw.mortgagesrvc.util.MortgageServiceUtil;
import com.lbg.epscw.mortgagesrvc.validator.MortgagePortingSubmitApplicationValidator;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.HashMap;
import java.util.Map;

import static com.lbg.epscw.mortgagesrvc.constants.CommonConstants.INVALID_BORROWING_AMOUNT;
import static com.lbg.epscw.mortgagesrvc.constants.CommonConstants.MORTGAGE_SUBMIT_APPLICATION;
import static com.lbg.epscw.mortgagesrvc.helper.MortgagePortingHelper.APPLICATION_NUMBER;
import static org.junit.Assert.assertEquals;
import static org.mockito.ArgumentMatchers.*;
import static org.powermock.api.mockito.PowerMockito.doThrow;
import static org.powermock.api.mockito.PowerMockito.when;

@RunWith(SpringRunner.class)
@WebMvcTest(controllers = {MortgageServiceUtil.class, MortgageApplicationSubmitController.class})
public class MortgageApplicationSubmitControllerTest {

    @MockBean
    private MortgagePortingService mortgagePortingService;

    @Autowired
    private MortgageApplicationSubmitController mortgageApplicationSubmitController;

    @MockBean
    private MortgagePortingSubmitApplicationValidator mortgagePortingApplicationValidator;

    @MockBean
    MortgagePortingApplicationInfoService mortgagePortingApplicationInfoService;

    private MortgagePortingHelper mortgagePortingHelper = new MortgagePortingHelper();

    private MortgagePortingApplicationHelper mortgagePortingApplicationHelper = new MortgagePortingApplicationHelper();


    @Test
    public void submit_porting_application_successfully() {
        //given

        MortgagePortingSubmitRequest mortgagePortingSubmitRequest = new MortgagePortingSubmitRequest();
        mortgagePortingSubmitRequest.setApplicationNumber("application");

        when(mortgagePortingApplicationInfoService.getApplicationInfo(any(String.class))).
                thenReturn(mortgagePortingApplicationHelper.getMortgagePortingApplicationDetails());

        when(mortgagePortingService.submitMortgagePortingApplication(any(MortgageApplicationInfo.class), any(MortgagePortingSubmitRequest.class), any(Map.class)))
                .thenReturn(mortgagePortingHelper.buildAccountStatusUpdateResponse());
        //when
        ResponseEntity<AccountPortingStatusResponse> responseEntity = mortgageApplicationSubmitController
                .submitMortgagePortingApplication("IF", Channel.DIGITAL.name(), "123-456-789-12", "Bearer 122", "ALL", new HashMap<String, String>(),
                        APPLICATION_NUMBER);
        AccountPortingStatusResponse accountPortingStatusResponseList = responseEntity.getBody();

        //then
        assertEquals("b2c9119f-09e5-4ac9-9738-9e28b334d3fa", accountPortingStatusResponseList.getAccountId());
        assertEquals(AccountStatus.ACCOUNT_STATUS_OPEN.name(), accountPortingStatusResponseList.getStatus());
    }


    @Test(expected = MortgageServiceException.class)
    public void submit_porting_application_throws_exception_for_service_failure() {
        //given

        MortgagePortingSubmitRequest mortgagePortingSubmitRequest = new MortgagePortingSubmitRequest();
        mortgagePortingSubmitRequest.setApplicationNumber("application");

        when(mortgagePortingApplicationInfoService.getApplicationInfo(any(String.class))).
                thenReturn(mortgagePortingApplicationHelper.getMortgagePortingApplicationDetails());

        when(mortgagePortingService.submitMortgagePortingApplication(any(MortgageApplicationInfo.class), any(MortgagePortingSubmitRequest.class), anyMap()))
                .thenReturn(null);
        //when
        ResponseEntity<AccountPortingStatusResponse> responseEntity = mortgageApplicationSubmitController
                .submitMortgagePortingApplication("IF", Channel.DIGITAL.name(), "123-456-789-12", "Bearer 122", "ALL", new HashMap<String, String>(),
                        APPLICATION_NUMBER);
        AccountPortingStatusResponse accountPortingStatusResponseList = responseEntity.getBody();


    }


    @Test(expected = MortgageValidationException.class)
    public void validation_failure_for_submit_porting_application_throws_validation_exception() {
        //given

        MortgagePortingSubmitRequest mortgagePortingSubmitRequest = new MortgagePortingSubmitRequest();
        mortgagePortingSubmitRequest.setApplicationNumber(APPLICATION_NUMBER);

        doThrow(new MortgageValidationException(MORTGAGE_SUBMIT_APPLICATION, INVALID_BORROWING_AMOUNT)).when(mortgagePortingApplicationValidator).validate(any(MortgageApplicationInfo.class));


        when(mortgagePortingApplicationInfoService.getApplicationInfo(anyString())).
                thenReturn(mortgagePortingApplicationHelper.getMortgagePortingApplicationDetails());

        //when
        ResponseEntity<AccountPortingStatusResponse> responseEntity = mortgageApplicationSubmitController
                .submitMortgagePortingApplication("IF", Channel.DIGITAL.name(), "123-456-789-12", "Bearer 122", "ALL", new HashMap<String, String>(),
                        APPLICATION_NUMBER);
        AccountPortingStatusResponse accountPortingStatusResponseList = responseEntity.getBody();


    }
}
