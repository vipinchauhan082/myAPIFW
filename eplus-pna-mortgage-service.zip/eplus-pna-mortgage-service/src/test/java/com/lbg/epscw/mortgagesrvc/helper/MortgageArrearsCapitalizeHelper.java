package com.lbg.epscw.mortgagesrvc.helper;

import com.lbg.epscw.mortgagesrvc.dto.AccountCreationResponse;
import com.lbg.epscw.mortgagesrvc.dto.MortgageBalance;
import com.lbg.epscw.mortgagesrvc.dto.MortgageResponse;
import com.lbg.epscw.mortgagesrvc.dto.VaultPostingsInstructionsBatchResponse;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

import static com.lbg.epscw.mortgagesrvc.constants.CommonConstants.*;

public class MortgageArrearsCapitalizeHelper {

    public String getMortgageInfoServiceResponse() {
        return "{\n" +
                "    \"Data\": [\n" +
                "        {\n" +
                "            \"mortgageNumber\": \"number_1112\",\n" +
                "            \"mortgagePrincipal\": \"4000\",\n" +
                "            \"keyDate\": \"7\",\n" +
                "            \"mortgageType\": \"INTEREST_ONLY\",\n" +
                "            \"accountStatus\": \"ACCOUNT_STATUS_OPEN\",\n" +
                "            \"totalTerm\": \"24\",\n" +
                "            \"productId\": \"lbg_mortgage\",\n" +
                "            \"productFamily\": \"Mortgage\",\n" +
                "            \"sequenceId\": \"1\",\n" +
                "            \"accountId\": \"1601d0e5-e336-64d9-64ad-89ba6fdc2677\"\n" +
                "        },\n" +
                "        {\n" +
                "            \"mortgageNumber\": \"number_1112\",\n" +
                "            \"productId\": \"lbg_mortgage_repayment\",\n" +
                "            \"accountStatus\": \"ACCOUNT_STATUS_OPEN\",\n" +
                "            \"productFamily\": \"Mortgage Payment\",\n" +
                "            \"mortgageInArrears\": \"true\",\n" +
                "            \"accountId\": \"f76ca840-2553-d536-1ab8-9fa85c99db05\"\n" +
                "        }\n" +
                "    ]\n" +
                "}";
    }


    public String getMortgageInfoServiceResponseWithPrimaryAccountClosed() {
        return "{\n" +
                "    \"Data\": [\n" +
                "        {\n" +
                "            \"mortgageNumber\": \"number_1112\",\n" +
                "            \"mortgagePrincipal\": \"4000\",\n" +
                "            \"keyDate\": \"7\",\n" +
                "            \"mortgageType\": \"INTEREST_ONLY\",\n" +
                "            \"accountStatus\": \"ACCOUNT_STATUS_CLOSED\",\n" +
                "            \"totalTerm\": \"24\",\n" +
                "            \"productId\": \"lbg_mortgage\",\n" +
                "            \"productFamily\": \"Mortgage\",\n" +
                "            \"sequenceId\": \"1\",\n" +
                "            \"accountOpeningDate\": \"2018-12-18\",\n" +
                "            \"accountId\": \"1601d0e5-e336-64d9-64ad-89ba6fdc2677\"\n" +
                "        },\n" +
                "        {\n" +
                "            \"mortgageNumber\": \"number_1112\",\n" +
                "            \"mortgagePrincipal\": \"4000\",\n" +
                "            \"keyDate\": \"7\",\n" +
                "            \"mortgageType\": \"INTEREST_ONLY\",\n" +
                "            \"accountStatus\": \"ACCOUNT_STATUS_OPEN\",\n" +
                "            \"totalTerm\": \"20\",\n" +
                "            \"productId\": \"lbg_mortgage\",\n" +
                "            \"productFamily\": \"Mortgage\",\n" +
                "            \"sequenceId\": \"2\",\n" +
                "            \"accountOpeningDate\": \"2020-12-18\",\n" +
                "            \"accountId\": \"1601d0e5-e336-64d9-64ad-89ba6fdc2689\"\n" +
                "        },\n" +
                "        {\n" +
                "            \"mortgageNumber\": \"number_1112\",\n" +
                "            \"mortgagePrincipal\": \"4000\",\n" +
                "            \"keyDate\": \"7\",\n" +
                "            \"mortgageType\": \"INTEREST_ONLY\",\n" +
                "            \"accountStatus\": \"ACCOUNT_STATUS_OPEN\",\n" +
                "            \"totalTerm\": \"22\",\n" +
                "            \"productId\": \"lbg_mortgage\",\n" +
                "            \"productFamily\": \"Mortgage\",\n" +
                "            \"sequenceId\": \"3\",\n" +
                "            \"accountOpeningDate\": \"2019-12-18\",\n" +
                "            \"accountId\": \"1601d0e5-e336-64d9-64ad-89ba6fdc2698\"\n" +
                "        },\n" +
                "        {\n" +
                "            \"mortgageNumber\": \"number_1112\",\n" +
                "            \"productId\": \"lbg_mortgage_repayment\",\n" +
                "            \"accountStatus\": \"ACCOUNT_STATUS_OPEN\",\n" +
                "            \"productFamily\": \"Mortgage Payment\",\n" +
                "            \"mortgageInArrears\": \"true\",\n" +
                "            \"accountId\": \"f76ca840-2553-d536-1ab8-9fa85c99db05\"\n" +
                "        }\n" +
                "    ]\n" +
                "}";
    }

    public String getMortgageInfoServiceResponseWithoutArrearsAccount() {
        return "{\n" +
                "    \"Data\": [\n" +
                "        {\n" +
                "            \"mortgageNumber\": \"number_1112\",\n" +
                "            \"mortgagePrincipal\": \"4000\",\n" +
                "            \"keyDate\": \"7\",\n" +
                "            \"mortgageType\": \"INTEREST_ONLY\",\n" +
                "            \"accountStatus\": \"ACCOUNT_STATUS_OPEN\",\n" +
                "            \"totalTerm\": \"24\",\n" +
                "            \"productId\": \"lbg_mortgage\",\n" +
                "            \"productFamily\": \"Mortgage\",\n" +
                "            \"accountId\": \"1601d0e5-e336-64d9-64ad-89ba6fdc2677\"\n" +
                "        },\n" +
                "        {\n" +
                "            \"mortgageNumber\": \"number_1112\",\n" +
                "            \"productId\": \"lbg_mortgage_repayment\",\n" +
                "            \"accountStatus\": \"ACCOUNT_STATUS_OPEN\",\n" +
                "            \"productFamily\": \"Mortgage Payment\",\n" +
                "            \"mortgageInArrears\": \"false\",\n" +
                "            \"accountId\": \"f76ca840-2553-d536-1ab8-9fa85c99db05\"\n" +
                "        }\n" +
                "    ]\n" +
                "}";
    }

    public String getMortgageInfoServiceResponseWithoutOverarchingAccount() {
        return "{\n" +
                "    \"Data\": [\n" +
                "        {\n" +
                "            \"mortgageNumber\": \"number_1112\",\n" +
                "            \"mortgagePrincipal\": \"4000\",\n" +
                "            \"keyDate\": \"7\",\n" +
                "            \"mortgageType\": \"INTEREST_ONLY\",\n" +
                "            \"accountStatus\": \"ACCOUNT_STATUS_OPEN\",\n" +
                "            \"totalTerm\": \"24\",\n" +
                "            \"productId\": \"lbg_mortgage\",\n" +
                "            \"productFamily\": \"Mortgage\",\n" +
                "            \"accountId\": \"1601d0e5-e336-64d9-64ad-89ba6fdc2677\"\n" +
                "        }\n" +
                "    ]\n" +
                "}";
    }

    public static VaultPostingsInstructionsBatchResponse buildVaultPostingInstructionResponse(){
        return VaultPostingsInstructionsBatchResponse.builder().id("567").createEventTimestamp("2020-12-02").build();

    }

    public static MortgageResponse getMortgageOverarchingBalanceWithArrears(){

        MortgageResponse mortgageResponse = new MortgageResponse();
        MortgageBalance mortgageBalance = new MortgageBalance();
        Map<String,String> aggregatedMap = new HashMap<>();
        aggregatedMap.put("ArrearAmount","50.0");
        mortgageBalance.setAggregatedMap(aggregatedMap);
        mortgageResponse.setMortgageBalance(mortgageBalance);
        return mortgageResponse;

    }

    public static MortgageResponse getMortgageOverarchingBalanceWithoutArrears(){

        MortgageResponse mortgageResponse = new MortgageResponse();
        MortgageBalance mortgageBalance = new MortgageBalance();
        Map<String,String> aggregatedMap = new HashMap<>();
        aggregatedMap.put("ArrearAmount","0.0");
        mortgageBalance.setAggregatedMap(aggregatedMap);
        mortgageResponse.setMortgageBalance(mortgageBalance);
        return mortgageResponse;

    }

    public VaultPostingsInstructionsBatchResponse buildPostingInstructionBatchVaultResponse(){
        return VaultPostingsInstructionsBatchResponse.builder().id("123").createEventTimestamp("2020-12-01").build();
    }

    public static HttpHeaders generateHttpHeaders(){
        HttpHeaders requiredHeaders = new HttpHeaders();
        requiredHeaders.add(X_LBG_BRAND, "IF");
        requiredHeaders.add(X_LBG_CHANNEL, "TELEPHONE");
        requiredHeaders.add(CORRELATION_ID, "txnCorrelationId");
        requiredHeaders.add(AUTHORIZATION, "Bearer VALID_STATIC_TOKEN");
        requiredHeaders.add(X_AUTH_TOKEN, "Bearer VALID_STATIC_TOKEN");
        requiredHeaders.add(CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE);
        return requiredHeaders;
    }

    public static AccountCreationResponse getAccountCreateResponse(){
        Map<Object,Object> instanceParams = new HashMap<>();
        instanceParams.put("mortgage_number","num-001");
        instanceParams.put("mortgage_type","CAPITAL_REPAYMENT");
        instanceParams.put("total_term","20");
        instanceParams.put("mortgage_calculation_principal","5000");
        instanceParams.put("key_date","23");
        instanceParams.put("interest_rate","2.5");
        instanceParams.put("deposit_account","deposit_001");
        instanceParams.put("mortgage_number","num-001");


        return AccountCreationResponse.builder().accountNumber("1234").externalAccountId("9876")
                .internalAccountId("5678").productId("lbg_mortgage").productName("Mortgage")
                .stakeholderId(Arrays.asList("1111")).status("ACCOUNT_STATUS_OPEN").sortCode("230545")
                .instanceParamVals(instanceParams).bankIdCode("666").build();

    }
}
