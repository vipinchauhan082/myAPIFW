package com.lbg.epscw.mortgagesrvc.controller;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.lbg.epscw.mortgagesrvc.exception.MortgageServiceException;
import com.lbg.epscw.mortgagesrvc.helper.MortgagePaymentHolidayHelper;
import com.lbg.epscw.mortgagesrvc.model.PaymentHolidayRequest;
import com.lbg.epscw.mortgagesrvc.model.PaymentHolidayResponse;
import com.lbg.epscw.mortgagesrvc.service.MortgagePaymentArrangementService;
import com.lbg.epscw.mortgagesrvc.service.MortgagePaymentHolidayService;
import com.lbg.epscw.mortgagesrvc.util.MortgageServiceUtil;
import com.lbg.epscw.mortgagesrvc.validator.MortgagePaymentArrangementValidator;
import com.lbg.epscw.mortgagesrvc.validator.MortgagePaymentHolidayValidator;
import lombok.extern.flogger.Flogger;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit4.SpringRunner;

import javax.validation.ConstraintViolationException;
import java.util.HashMap;

import static com.lbg.epscw.mortgagesrvc.constants.CommonConstants.*;
import static org.junit.Assert.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.powermock.api.mockito.PowerMockito.doNothing;
import static org.powermock.api.mockito.PowerMockito.when;

@Flogger
@RunWith(SpringRunner.class)
@WebMvcTest(controllers = {MortgageServiceUtil.class, PaymentArrangementController.class})
public class MortgagePaymentHolidayControllerTest {

    @MockBean
    private MortgagePaymentHolidayService mortgagePaymentHolidayService;

    @MockBean
    private MortgagePaymentHolidayValidator mortgagePaymentHolidayValidator;

    @MockBean
    private MortgagePaymentArrangementService mortgagePaymentArrangementService;

    @MockBean
    private MortgagePaymentArrangementValidator mortgagePaymentArrangementValidator;

    @Autowired
    private PaymentArrangementController paymentArrangementController;

    private final MortgagePaymentHolidayHelper mortgagePaymentHolidayHelper = new MortgagePaymentHolidayHelper();

    private static final String ACCOUNT_ID = "144a38f3-a7b3-a3aa-d656-ff98fbaaa565";

    public MortgagePaymentHolidayControllerTest() {
    }

    @Test
    public void addPaymentHoliday() throws JsonProcessingException {
        //given
        doNothing().when(mortgagePaymentHolidayValidator).validateAddPaymentHolidayRequest(any(PaymentHolidayRequest.class), any(String.class), any(HashMap.class));
        when(mortgagePaymentHolidayService.addPaymentHoliday(any(String.class), any(PaymentHolidayRequest.class), any(HashMap.class)))
                .thenReturn(mortgagePaymentHolidayHelper.getMockAddPaymentHolidayResponse());

        //when
        ResponseEntity<PaymentHolidayResponse> responseEntity = paymentArrangementController.addPaymentHoliday("IF", "asjdksajdkajdskjsadkajskjasa", "123-456-789-12", null, new HashMap<String, String>(),
                mortgagePaymentHolidayHelper.getPaymentHolidayRequest(),
                ACCOUNT_ID
        );
        PaymentHolidayResponse response = responseEntity.getBody();
        log.atInfo().log(new ObjectMapper().writeValueAsString(response));
        System.out.println(new ObjectMapper().writeValueAsString(response));
        //then
        assertEquals(ACCOUNT_ID, response.getAccountId());
        assertEquals(PAYMENT_HOLIDAY_ADD_SUCCESS, response.getStatus());
        assertEquals("10/2021", response.getInstanceParamVals().get(START_DATE));
        assertEquals("11/2021", response.getInstanceParamVals().get(END_DATE));

    }

    @Test
    public void cancelPaymentHoliday() throws JsonProcessingException {
        //given
        doNothing().when(mortgagePaymentHolidayValidator).validateCancelPaymentHolidayRequest(any(PaymentHolidayRequest.class), any(String.class), any(HashMap.class));
        when(mortgagePaymentHolidayService.cancelPaymentHoliday(any(String.class), any(PaymentHolidayRequest.class), any(HashMap.class)))
                .thenReturn(mortgagePaymentHolidayHelper.getMockCancelPaymentHolidayResponse());

        //when
        ResponseEntity<PaymentHolidayResponse> responseEntity = paymentArrangementController.cancelPaymentHoliday(
                "IF", "asjdksajdkajdskjsadkajskjasa", "123-456-789-12", null, new HashMap<String, String>(),
                mortgagePaymentHolidayHelper.getPaymentHolidayRequest(),
                ACCOUNT_ID
        );
        PaymentHolidayResponse response = responseEntity.getBody();
        log.atInfo().log(new ObjectMapper().writeValueAsString(response));
        System.out.println(new ObjectMapper().writeValueAsString(response));
        //then
        assertEquals(ACCOUNT_ID, response.getAccountId());
        assertEquals(PAYMENT_HOLIDAY_CANCEL_SUCCESS, response.getStatus());
        assertEquals("10/2021", response.getInstanceParamVals().get(START_DATE));
        assertEquals("11/2021", response.getInstanceParamVals().get(END_DATE));

    }

    @Test(expected = MortgageServiceException.class)
    public void shouldThrowExceptionWhenAddServiceMethodReturnsNull() {
        //given
        when(mortgagePaymentHolidayService.addPaymentHoliday(any(String.class), any(PaymentHolidayRequest.class), any(HashMap.class))).thenReturn(null);

        //when
        paymentArrangementController.addPaymentHoliday(
                "IF", "asjdksajdkajdskjsadkajskjasa", "123-456-789-12", null, new HashMap<String, String>(),
                mortgagePaymentHolidayHelper.getPaymentHolidayRequest(),
                ACCOUNT_ID
        );
    }

    @Test(expected = MortgageServiceException.class)
    public void shouldThrowExceptionWhenCancelServiceMethodReturnsNull() {
        //given
        when(mortgagePaymentHolidayService.cancelPaymentHoliday(any(String.class), any(PaymentHolidayRequest.class), any(HashMap.class))).thenReturn(null);

        //when
        paymentArrangementController.cancelPaymentHoliday(
                "IF", "asjdksajdkajdskjsadkajskjasa", "123-456-789-12", null, new HashMap<String, String>(),
                mortgagePaymentHolidayHelper.getPaymentHolidayRequest(),
                ACCOUNT_ID
        );
    }

    @Test(expected = ConstraintViolationException.class)
    public void shouldThrowExceptionWhenAccountIdLengthIsSmall() {
        //when
        paymentArrangementController.addPaymentHoliday(
                "IF", "asjdksajdkajdskjsadkajskjasa", "123-456-789-12", null, new HashMap<String, String>(),
                mortgagePaymentHolidayHelper.getPaymentHolidayRequest(),
                ACCOUNT_ID.substring(5)
        );
    }

    @Test(expected = ConstraintViolationException.class)
    public void shouldThrowExceptionWhenAccountIdLengthIsLong() {
        //when
        paymentArrangementController.addPaymentHoliday(
                "IF", "asjdksajdkajdskjsadkajskjasa", "123-456-789-12", null, new HashMap<String, String>(),
                mortgagePaymentHolidayHelper.getPaymentHolidayRequest(),
                ACCOUNT_ID.concat("123")
        );
    }

    @Test(expected = ConstraintViolationException.class)
    public void shouldThrowExceptionWhenAccountIdIsEmpty() {
        //when
        paymentArrangementController.addPaymentHoliday(
                "IF", "asjdksajdkajdskjsadkajskjasa", "123-456-789-12", null, new HashMap<String, String>(),
                mortgagePaymentHolidayHelper.getPaymentHolidayRequest(),
                ""
        );
    }

    @Test(expected = ConstraintViolationException.class)
    public void shouldThrowExceptionWhenAccountIdIsNull() {
        //when
        paymentArrangementController.addPaymentHoliday(
                "IF", "asjdksajdkajdskjsadkajskjasa", "123-456-789-12", null, new HashMap<String, String>(),
                mortgagePaymentHolidayHelper.getPaymentHolidayRequest(),
                null
        );
    }

    @Test(expected = ConstraintViolationException.class)
    public void shouldThrowExceptionWhenBrandHeaderIsNull() {
        //when
        paymentArrangementController.addPaymentHoliday(
                null, "asjdksajdkajdskjsadkajskjasa", "123-456-789-12", null, new HashMap<String, String>(),
                mortgagePaymentHolidayHelper.getPaymentHolidayRequest(),
                ACCOUNT_ID
        );
    }

    @Test(expected = ConstraintViolationException.class)
    public void shouldThrowExceptionWhenBrandHeaderIsInvalid() {
        //when
        paymentArrangementController.addPaymentHoliday(
                "IFF", "asjdksajdkajdskjsadkajskjasa", "123-456-789-12", null, new HashMap<String, String>(),
                mortgagePaymentHolidayHelper.getPaymentHolidayRequest(),
                ACCOUNT_ID
        );
    }

    @Test(expected = ConstraintViolationException.class)
    public void shouldThrowExceptionWhenCorrelationIdIsNull() {
        //when
        paymentArrangementController.addPaymentHoliday(
                "IF", null, "123-456-789-12", null, new HashMap<String, String>(),
                mortgagePaymentHolidayHelper.getPaymentHolidayRequest(),
                ACCOUNT_ID
        );
    }

    @Test(expected = ConstraintViolationException.class)
    public void shouldThrowExceptionWhenCorrelationIdIsEmpty() {
        //when
        paymentArrangementController.addPaymentHoliday(
                "IF", "", "123-456-789-12", null, new HashMap<String, String>(),
                mortgagePaymentHolidayHelper.getPaymentHolidayRequest(),
                ACCOUNT_ID
        );
    }

    @Test(expected = ConstraintViolationException.class)
    public void shouldThrowExceptionWhenCorrelationIdIsSmall() {
        //when
        paymentArrangementController.addPaymentHoliday(
                "IF", "asj", "123-456-789-12", null, new HashMap<String, String>(),
                mortgagePaymentHolidayHelper.getPaymentHolidayRequest(),
                ACCOUNT_ID
        );
    }

    @Test(expected = ConstraintViolationException.class)
    public void shouldThrowExceptionWhenCorrelationIdIsLong() {
        //when
        paymentArrangementController.addPaymentHoliday(
                "IF", "aabcdenvkjrnrvrnkvnrekjvnrekvnrkvnrkvnkrevnkjrevnrevkrnvkvn", "123-456-789-12", null, new HashMap<String, String>(),
                mortgagePaymentHolidayHelper.getPaymentHolidayRequest(),
                ACCOUNT_ID
        );
    }
}
