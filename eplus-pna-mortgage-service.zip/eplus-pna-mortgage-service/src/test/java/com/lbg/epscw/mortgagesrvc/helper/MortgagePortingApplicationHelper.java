package com.lbg.epscw.mortgagesrvc.helper;

import com.lbg.epscw.mortgagesrvc.dto.*;
import com.lbg.epscw.mortgagesrvc.model.MortgageApplicationInfo;
import com.lbg.epscw.mortgagesrvc.model.MortgagePortingApplicationStatus;
import com.lbg.epscw.mortgagesrvc.model.MortgagePortingSubmitRequest;
import org.springframework.http.MediaType;

import java.time.LocalDate;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static com.lbg.epscw.mortgagesrvc.constants.CommonConstants.*;
import static com.lbg.epscw.mortgagesrvc.constants.CommonConstants.CONTENT_TYPE;
import static java.util.UUID.randomUUID;

public class MortgagePortingApplicationHelper {


    public MortgageApplicationInfo getMortgagePortingApplicationDetails(){
        MortgageApplicationInfo mortgagePortingApplicationDetails =  new MortgageApplicationInfo();
        mortgagePortingApplicationDetails.setApplicationNumber(randomUUID().toString());
        mortgagePortingApplicationDetails.setStatus(MortgagePortingApplicationStatus.OPEN);
        mortgagePortingApplicationDetails.setBorrowingAmount("800");
        mortgagePortingApplicationDetails.setAccountIdToBePorted("08551cec-e7b0-cc5b-7026-d2e4b7fabf3a");
        mortgagePortingApplicationDetails.setPreviousMortgageNumber("08551cec-e7b0-cc5b-7026-d2e4b7fabf3a");

        mortgagePortingApplicationDetails.setSubAccountDetailsAsString("[\n" +
                " {\n" +
                "\"ProductId\":\"\",\n" +
                "\"RepaymentType\":\"\",\n" +
                "\"TotalTerm\":\"\",\n" +
                "\"LoanAmount\":\"800\",\n" +
                "\"InterestRate\":\"\",\n" +
                "\"SubAccountType\":\"\",\n" +
                "\"SubAccountSeqId\":\"\"\n" +
                " }\n" +
                " ]");

        List<MortgagePortingApplicationSubAccountDetails> subAccountDetails = new ArrayList<>();
        MortgagePortingApplicationSubAccountDetails mortgagePortingApplicationSubAccountDetails = new MortgagePortingApplicationSubAccountDetails();
        mortgagePortingApplicationSubAccountDetails.setLoanAmount("800");
        subAccountDetails.add(mortgagePortingApplicationSubAccountDetails);

        mortgagePortingApplicationDetails.setSubAccountDetails(subAccountDetails);
        return mortgagePortingApplicationDetails;
    }


    public MortgagePortingSubmitRequest getMortgagePortingSubmitRequest(){

        MortgagePortingSubmitRequest mortgagePortingSubmitRequest = new MortgagePortingSubmitRequest();

        return mortgagePortingSubmitRequest;
    }


    public MortgageAccountInfo getMortgageAccountInfo() {

        MortgageAccountInfo mortgageAccountInfo = new MortgageAccountInfo();
        List<MortgageAccountData> mortgageAccountDataList = new ArrayList<>();
        MortgageAccountData mortgageAccountData = new MortgageAccountData();
        mortgageAccountData.setAccountId("132a38f3-a7b3-a3aa-d656-ff98fbaaa565");
        mortgageAccountData.setProductId("lbg_mortgage");
        mortgageAccountData.setProductFamily("Mortgage Payment");
        mortgageAccountData.setKeyDate(String.valueOf(LocalDate.now(ZoneId.systemDefault()).getDayOfMonth()+4));
        mortgageAccountData.setPaymentHolidayMonths(new String[]{""});

        MortgageAccountData mortgageSubAccountData = new MortgageAccountData();
        mortgageSubAccountData.setAccountId("132a38f3-a7b3-a3aa-d656-ff98fbaaa565");
        mortgageSubAccountData.setProductId("lbg_mortgage");
        mortgageSubAccountData.setProductFamily("Mortgage");
        mortgageSubAccountData.setKeyDate(String.valueOf(LocalDate.now(ZoneId.systemDefault()).getDayOfMonth()+4));
        mortgageSubAccountData.setPaymentHolidayMonths(new String[]{""});
        mortgageAccountDataList.add(mortgageSubAccountData);
        mortgageAccountDataList.add(mortgageAccountData);
        mortgageAccountInfo.setMortgageAccountData(mortgageAccountDataList);
        return mortgageAccountInfo;
    }

    public static AccountCreationResponse buildCreateAccountResponse(){
        return AccountCreationResponse.builder()
                .internalAccountId("id1")
                .productId("lbg_mortgage")
                .productName("mortgage")
                .status("ACCOUNT_STATUS_OPEN")
                .accountNumber("1234566789")
                .build();
    }

    public static Map<String, String> generateRequiredHeaders() {

        Map<String, String> requiredHeaders = new HashMap<>();
        requiredHeaders.put(X_LBG_BRAND, "if");
        requiredHeaders.put(X_LBG_CHANNEL, "TELEPHONE");
        requiredHeaders.put(CORRELATION_ID, "txnCorrelationId");
        requiredHeaders.put(AUTHORIZATION, "jwtToken");
        requiredHeaders.put(X_AUTH_TOKEN, "vaultAccessToken");
        requiredHeaders.put(CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE);
        return requiredHeaders;
    }
}
