package com.lbg.epscw.mortgagesrvc.controller;

import com.lbg.epscw.mortgagesrvc.constants.CommonConstants;
import com.lbg.epscw.mortgagesrvc.dto.MortgageAccountInfo;
import com.lbg.epscw.mortgagesrvc.enums.MortgageOptionInstructionEnum;
import com.lbg.epscw.mortgagesrvc.enums.RepaymentType;
import com.lbg.epscw.mortgagesrvc.exception.MortgageServiceException;
import com.lbg.epscw.mortgagesrvc.helper.MortgageAccountOptionDataHelper;
import com.lbg.epscw.mortgagesrvc.helper.MortgageOffsettingHelper;
import com.lbg.epscw.mortgagesrvc.helper.MortgagePaymentOptionHelper;
import com.lbg.epscw.mortgagesrvc.model.*;
import com.lbg.epscw.mortgagesrvc.service.MortgageAccountOptionService;
import com.lbg.epscw.mortgagesrvc.service.MortgageOffsettingService;
import com.lbg.epscw.mortgagesrvc.service.MortgagePaymentOptionService;
import com.lbg.epscw.mortgagesrvc.util.MortgageServiceUtil;
import com.lbg.epscw.mortgagesrvc.validator.MortgageOffsettingValidator;
import com.lbg.epscw.mortgagesrvc.validator.MortgagePaymentOptionValidator;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.test.context.junit4.SpringRunner;

import javax.validation.ConstraintViolationException;
import java.util.HashMap;
import java.util.Map;

import static org.junit.Assert.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.powermock.api.mockito.PowerMockito.*;


@RunWith(SpringRunner.class)
@WebMvcTest(controllers = { MortgageServiceUtil.class, MortgageAccountOptionController.class })
public class MortgageAccountOptionControllerTest {

    @MockBean
    private MortgageAccountOptionService mortgageAccountOptionService;

    @MockBean
    private MortgageOffsettingService mortgageOffsettingService;

    @MockBean
    private MortgageOffsettingValidator offsettingValidator;

    @MockBean
    private MortgagePaymentOptionService mortgagePaymentOptionService;

    @MockBean
    private MortgagePaymentOptionValidator mortgagePaymentOptionValidator;


    private MortgageOffsettingHelper mortgageOffsettingHelper= new MortgageOffsettingHelper();

    private MortgagePaymentOptionHelper mortgagePaymentOptionHelper= new MortgagePaymentOptionHelper();


    @Autowired
    private MortgageAccountOptionController accountOptionController;

    private MortgageAccountOptionDataHelper mortgageAccountDataHelper = new MortgageAccountOptionDataHelper();


    @Test
    public void update_mortgage_term_successful() {
        when(mortgageAccountOptionService.updateAccountOptions(any(AccountOptionsUpdateRequest.class), any(String.class), any(Map.class)))
            .thenReturn(mortgageAccountDataHelper.buildMortgageOptionsUpdateResponse(CommonConstants.KEY_MORTGAGE_TERM, "15"));

        //when
        ResponseEntity<MortgageOptionsUpdateResponse> responseEntity = accountOptionController
            .repaymentSchedule("IF",Channel.DIGITAL.name(), "123-456-789-12", "Bearer 122", "ALL", new HashMap<String, String>(),
            		mortgageAccountDataHelper.buildAccountOptionsUpdateRequestForMortgageTerm(MortgageOptionInstructionEnum.MortgageTermExtend, "15"),"1601d0e5-e336-64d9-64ad-89ba6fdc2677");
        MortgageOptionsUpdateResponse accountOptionsUpdateResponse = responseEntity.getBody();

        //then
        assertEquals("1601d0e5-e336-64d9-64ad-89ba6fdc2677", accountOptionsUpdateResponse.getAccountId());
    }

    @Test
    public void update_mortgage_type_successful() {
        when(mortgageAccountOptionService.updateAccountOptions(any(AccountOptionsUpdateRequest.class),any(String.class), any(Map.class)))
            .thenReturn(mortgageAccountDataHelper.buildMortgageOptionsUpdateResponse(CommonConstants.KEY_MORTGAGE_TYPE, RepaymentType.INTEREST_ONLY.name()));

        //when
        ResponseEntity<MortgageOptionsUpdateResponse> responseEntity = accountOptionController
            .repaymentSchedule("IF", Channel.DIGITAL.name(),"123-456-789-12", "Bearer 122", "ALL", new HashMap<String, String>(),
            		mortgageAccountDataHelper.buildAccountOptionsUpdateRequestForMortgageType( RepaymentType.INTEREST_ONLY.name()),"1601d0e5-e336-64d9-64ad-89ba6fdc2677");
        MortgageOptionsUpdateResponse accountOptionsUpdateResponse = responseEntity.getBody();

        //then
        assertEquals("1601d0e5-e336-64d9-64ad-89ba6fdc2677", accountOptionsUpdateResponse.getAccountId());
    }

    @Test
    public void update_mortgage_type_successful_successful_with_system_id_in_header() {
        when(mortgageAccountOptionService.updateAccountOptions(any(AccountOptionsUpdateRequest.class),any(String.class), any(Map.class)))
            .thenReturn(mortgageAccountDataHelper.buildMortgageOptionsUpdateResponse(CommonConstants.KEY_MORTGAGE_TYPE, RepaymentType.INTEREST_ONLY.name()));

        //when
        ResponseEntity<MortgageOptionsUpdateResponse> responseEntity = accountOptionController
            .repaymentSchedule("IF", Channel.DIGITAL.name(),"123-456-789-12", null, "ALL", new HashMap<String, String>(),
            		mortgageAccountDataHelper.buildAccountOptionsUpdateRequestForMortgageType( RepaymentType.INTEREST_ONLY.name()),"1601d0e5-e336-64d9-64ad-89ba6fdc2677");
        MortgageOptionsUpdateResponse accountOptionsUpdateResponse = responseEntity.getBody();

        //then
        assertEquals("1601d0e5-e336-64d9-64ad-89ba6fdc2677", accountOptionsUpdateResponse.getAccountId());
    }

    @Test(expected = MortgageServiceException.class)
    public void update_mortgage_option_fails_when_service_layer_fails() {

    	 when(mortgageAccountOptionService.updateAccountOptions(any(AccountOptionsUpdateRequest.class), any(String.class), any(Map.class))).thenReturn(null);

    	 //when
         accountOptionController.repaymentSchedule("IF", Channel.DIGITAL.name(),"123-456-789-12", null, "ALL", new HashMap<String, String>(),
             		mortgageAccountDataHelper.buildAccountOptionsUpdateRequestForMortgageType( RepaymentType.INTEREST_ONLY.name()), "1601d0e5-e336-64d9-64ad-89ba6fdc2677");

    }

    @Test(expected = ConstraintViolationException.class)
    public void update_mortgage_option_rejects_request_if_accountId_length_is_small() {
    	AccountOptionsUpdateRequest accountOptionsUpdateRequest = mortgageAccountDataHelper.buildAccountOptionsUpdateRequestForMortgageType( RepaymentType.INTEREST_ONLY.name());
    	//when
    	accountOptionController.repaymentSchedule(
    			"IF",Channel.DIGITAL.name(), "123-456-789-12", null, "ALL", new HashMap<String, String>(), accountOptionsUpdateRequest, "1601d0e5-e336-64d9-64ad-89ba6fdc2");
    }

    @Test(expected = ConstraintViolationException.class)
    public void update_mortgage_option_rejects_request_if_accountId_length_is_big() {
    	AccountOptionsUpdateRequest accountOptionsUpdateRequest = mortgageAccountDataHelper.buildAccountOptionsUpdateRequestForMortgageType( RepaymentType.INTEREST_ONLY.name());
    	//when
    	accountOptionController.repaymentSchedule(
    			"IF",Channel.DIGITAL.name(), "123-456-789-12", null, "ALL", new HashMap<String, String>(), accountOptionsUpdateRequest, "1601d0e5-e336-64d9-64ad-89ba6fdc2677-qwe");
    }

    @Test(expected = ConstraintViolationException.class)
    public void update_mortgage_option_rejects_request_if_accountId_length_is_empty() {
    	AccountOptionsUpdateRequest accountOptionsUpdateRequest = mortgageAccountDataHelper.buildAccountOptionsUpdateRequestForMortgageType( RepaymentType.INTEREST_ONLY.name());
    	//when
    	accountOptionController.repaymentSchedule(
    			"IF",Channel.DIGITAL.name(), "123-456-789-12", null, "ALL", new HashMap<String, String>(), accountOptionsUpdateRequest, "");
    }

    @Test(expected = ConstraintViolationException.class)
    public void update_mortgage_option_rejects_request_if_accountId_length_is_null() {
    	AccountOptionsUpdateRequest accountOptionsUpdateRequest = mortgageAccountDataHelper.buildAccountOptionsUpdateRequestForMortgageType( RepaymentType.INTEREST_ONLY.name());
    	//when
    	accountOptionController.repaymentSchedule(
    			"IF",Channel.DIGITAL.name(), "123-456-789-12", null, "ALL", new HashMap<String, String>(), accountOptionsUpdateRequest, null);
    }


    @Test
    public void update_offsetting_option_successful(){
        //given
        when(offsettingValidator.validateUpdateOffsettingOption(any(String.class),any(Map.class)))
                .thenReturn(mortgageOffsettingHelper.mortgageAccountInfo_withOffsetting());
        //when
        when(mortgageOffsettingService.updateOffsettingOption(any(OffsettingRequest.class),any(MortgageAccountInfo.class),any(String.class)))
                .thenReturn(mortgageOffsettingHelper.mock_offsettingOptionUpdateResponse());

        //when
        ResponseEntity<OffsettingOptionUpdateResponse> responseEntity = accountOptionController
                .updateOffsettingOption("IF",Channel.DIGITAL.name(), "123-456-789-12", "Bearer 122", "ALL", new HashMap<String, String>(),
                        mortgageOffsettingHelper.getOffsettingRequest("OFFSET_DEBIT_BALANCES"), "5a688301-6d00-485c-0242-1ee03844a5c4");
        OffsettingOptionUpdateResponse  offsettingOptionUpdateResponse= responseEntity.getBody();
        //then
        assertEquals("5a688301-6d00-485c-0242-1ee03844a5c4", offsettingOptionUpdateResponse.getAccountId());
        assertEquals("OFFSET_DEBIT_BALANCES",offsettingOptionUpdateResponse.getInstanceParamVals().get("OffsettingOption"));


    }


    @Test(expected = MortgageServiceException.class)
    public void update_offsetting_option_when_service_layer_fails(){
        //given
        when(offsettingValidator.validateUpdateOffsettingOption(any(String.class),any(Map.class)))
                .thenReturn(null);
        //when
        when(mortgageOffsettingService.updateOffsettingOption(any(OffsettingRequest.class),any(MortgageAccountInfo.class),any(String.class)))
                .thenReturn(null);
        //when
        ResponseEntity<OffsettingOptionUpdateResponse> responseEntity = accountOptionController
                .updateOffsettingOption("IF",Channel.DIGITAL.name(), "123-456-789-12", "Bearer 122", "ALL", new HashMap<String, String>(),
                        mortgageOffsettingHelper.getOffsettingRequest("OFFSET_DEBIT_BALANCES"), "5a688301-6d00-485c-0242-1ee03844a5c4");


    }

    @Test(expected = AccessDeniedException.class)
    public void update_offsetting_option_fails_when_validation_fails() {
        //given
        doThrow(new AccessDeniedException("Entitlement rejected request")).when(offsettingValidator).validateUpdateOffsettingOption(any(String.class),any(Map.class));;

        //when
        accountOptionController
                .updateOffsettingOption("IF",Channel.DIGITAL.name(), "123-456-789-12", "Bearer 122", "ALL", new HashMap<String, String>(),
                        mortgageOffsettingHelper.getOffsettingRequest("OFFSET_DEBIT_BALANCES"), "5a688301-6d00-485c-0242-1ee03844a5c4");
    }



    @Test(expected = ConstraintViolationException.class)
    public void update_offsetting_option_rejects_request_if_accountId_violates() {
        //when
        ResponseEntity<OffsettingOptionUpdateResponse> responseEntity = accountOptionController
                .updateOffsettingOption("IF",Channel.DIGITAL.name(), "123-456-789-12", "Bearer 122", "ALL", new HashMap<String, String>(),
                        mortgageOffsettingHelper.getOffsettingRequest("OFFSET_DEBIT_BALANCES"), "ceabb62f");

    }

    @Test(expected = ConstraintViolationException.class)
    public void update_offsetting_option_rejects_request_if_brand_header_is_violates() {
        //when
        ResponseEntity<OffsettingOptionUpdateResponse> responseEntity = accountOptionController
                .updateOffsettingOption("IFF", Channel.DIGITAL.name(),"123-456-789-12", "Bearer 122", "ALL", new HashMap<String, String>(),
                        mortgageOffsettingHelper.getOffsettingRequest("OFFSET_DEBIT_BALANCES"), "5a688301-6d00-485c-0242-1ee03844a5c4");

    }

    @Test(expected = ConstraintViolationException.class)
    public void update_offsetting_option_rejects_request_if_txncorrelationId_header_violates() {
        //when
        ResponseEntity<OffsettingOptionUpdateResponse> responseEntity = accountOptionController
                .updateOffsettingOption("IF",Channel.DIGITAL.name(), null, "Bearer 122", "ALL", new HashMap<String, String>(),
                        mortgageOffsettingHelper.getOffsettingRequest("OFFSET_DEBIT_BALANCES"), "5a688301-6d00-485c-0242-1ee03844a5c4");
    }

    @Test
    public void update_mortgage_payment_option_successful(){
        //given
        when(mortgagePaymentOptionValidator.validateUpdateMortgagePaymentOption(any(String.class),any(Map.class)))
                .thenReturn(mortgageOffsettingHelper.mortgageAccountInfo_withOffsetting());
        //when
        when(mortgagePaymentOptionService.updateMortgagePaymentOption(any(MortgagePaymentOptionRequest.class),any(MortgageAccountInfo.class),any(String.class)))
                .thenReturn(mortgagePaymentOptionHelper.mock_mortgagePaymentOptionUpdateResponse());

        //when
        ResponseEntity<MortgagePaymentOptionUpdateResponse> responseEntity = accountOptionController
                .updateMortgagePaymentOption("IF",Channel.DIGITAL.name(), "123-456-789-12", "Bearer 122", "ALL", new HashMap<String, String>(),
                        mortgagePaymentOptionHelper.getMortgagePaymentRequest(), "5a688301-6d00-485c-0242-1ee03844a5c4");
        MortgagePaymentOptionUpdateResponse  mortgagePaymentOptionUpdateResponse= responseEntity.getBody();
        //then
        assertEquals("5a688301-6d00-485c-0242-1ee03844a5c4", mortgagePaymentOptionUpdateResponse.getAccountId());
        assertEquals("LOWER_PAYMENTS",mortgagePaymentOptionUpdateResponse.getInstanceParamVals().get("MortgagePaymentOption"));
    }

    @Test(expected = MortgageServiceException.class)
    public void update_mortgage_payment_option_when_service_layer_fails(){
        //given
        when(offsettingValidator.validateUpdateOffsettingOption(any(String.class),any(Map.class)))
                .thenReturn(mortgageOffsettingHelper.mortgageAccountInfo_withOffsetting());
        //when
        when(mortgagePaymentOptionService.updateMortgagePaymentOption(any(MortgagePaymentOptionRequest.class),any(MortgageAccountInfo.class),any(String.class)))
                .thenReturn(null);
        //when
        ResponseEntity<MortgagePaymentOptionUpdateResponse> responseEntity = accountOptionController
                .updateMortgagePaymentOption("IF",Channel.DIGITAL.name(), "123-456-789-12", "Bearer 122", "ALL", new HashMap<String, String>(),
                        mortgagePaymentOptionHelper.getMortgagePaymentRequest(), "5a688301-6d00-485c-0242-1ee03844a5c4");

    }

}


