package com.lbg.epscw.mortgagesrvc.controller;

import com.lbg.epscw.mortgagesrvc.model.AssetValuationRequest;
import com.lbg.epscw.mortgagesrvc.model.MortgageApplicationInfo;
import com.lbg.epscw.mortgagesrvc.model.PortingApplicationStatusResponse;
import com.lbg.epscw.mortgagesrvc.service.AssetValuationService;
import com.lbg.epscw.mortgagesrvc.service.MortgagePortingApplicationInfoService;
import com.lbg.epscw.mortgagesrvc.util.MortgageServiceUtil;
import com.lbg.epscw.mortgagesrvc.validator.MortgagePortingApplicationValidator;
import org.junit.Before;
import org.junit.Test;
import org.springframework.http.ResponseEntity;

import static com.lbg.epscw.mortgagesrvc.helper.MortgagePortingHelper.*;
import static com.lbg.epscw.mortgagesrvc.model.MortgagePortingApplicationStatus.*;
import static io.opencensus.trace.Tracing.getTracer;
import static io.opencensus.trace.samplers.Samplers.alwaysSample;
import static java.util.Collections.emptyMap;
import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.*;
import static org.springframework.http.ResponseEntity.ok;

public class AssetValuationControllerTest {
    private MortgagePortingApplicationValidator validator;
    private AssetValuationService service;
    private MortgagePortingApplicationInfoService infoService;
    private AssetValuationController underTest;

    @Before
    public void setup() {
        validator = mock(MortgagePortingApplicationValidator.class);
        MortgageServiceUtil utility = mock(MortgageServiceUtil.class);
        when(utility.buildSpan(anyString())).thenReturn(getTracer().spanBuilder("any").setSampler(alwaysSample()));
        service = mock(AssetValuationService.class);
        infoService = mock(MortgagePortingApplicationInfoService.class);
        underTest = new AssetValuationController(validator, service, utility, infoService);
    }

    @Test
    public void verify_action_permitted() {
        //given
        PortingApplicationStatusResponse expected = PortingApplicationStatusResponse.builder().applicationNumber(APPLICATION_NUMBER).status(VALUATION_RECEIVED).build();
        MortgageApplicationInfo info = MortgageApplicationInfo.builder().status(WELCOME_PACK_RECEIVED).build();
        when(service.captureAssetValuation(any(), any())).thenReturn(expected);
        doNothing().when(validator).validateNextState(any(), any());
        //when
        AssetValuationRequest request = AssetValuationRequest.builder().treeProblem(false).build();
        ResponseEntity<PortingApplicationStatusResponse> response = underTest.captureAssetValuation(BRAND, CHANNEL, CORRELATION_ID, JWT, INTERNAL_SYS_ID, emptyMap(), APPLICATION_NUMBER, request);
        //then
        assertThat(response, is(ok(expected)));
    }

    @Test(expected = IllegalArgumentException.class)
    public void verify_action_not_permitted() {
        //given
        doThrow(IllegalArgumentException.class).when(validator).validateNextState(any(), any());
        //when
        AssetValuationRequest request = AssetValuationRequest.builder().treeProblem(false).build();
        underTest.captureAssetValuation(BRAND, CHANNEL, CORRELATION_ID, JWT, INTERNAL_SYS_ID, emptyMap(), APPLICATION_NUMBER, request);
        //then expect exception
    }

    @Test(expected = IllegalArgumentException.class)
    public void service_fails_to_update_application() {
        //given
        doThrow(IllegalArgumentException.class).when(service).captureAssetValuation(any(), any());
        //when
        MortgageApplicationInfo info = MortgageApplicationInfo.builder().status(WELCOME_PACK_RECEIVED).build();
        doNothing().when(validator).validateNextState(any(), any());
        AssetValuationRequest request = AssetValuationRequest.builder().treeProblem(false).build();
        underTest.captureAssetValuation(BRAND, CHANNEL, CORRELATION_ID, JWT, INTERNAL_SYS_ID, emptyMap(), APPLICATION_NUMBER, request);
        //then expect exception
    }
}