package com.lbg.epscw.mortgagesrvc.controller;

import com.lbg.epscw.mortgagesrvc.dto.MortgageAccountInfo;
import com.lbg.epscw.mortgagesrvc.model.CreatePortingApplicationRequest;
import com.lbg.epscw.mortgagesrvc.model.CreatePortingApplicationResponse;
import com.lbg.epscw.mortgagesrvc.restclient.MortgageAccountInfoRestClient;
import com.lbg.epscw.mortgagesrvc.service.MortgagePortingCreateApplicationService;
import com.lbg.epscw.mortgagesrvc.util.MortgageServiceUtil;
import com.lbg.epscw.mortgagesrvc.validator.MortgagePortingCreateApplicationValidator;
import org.junit.Before;
import org.junit.Test;
import org.springframework.http.ResponseEntity;

import static com.lbg.epscw.mortgagesrvc.helper.MortgagePortingHelper.*;
import static com.lbg.epscw.mortgagesrvc.model.MortgagePortingApplicationStatus.OPEN;
import static io.opencensus.trace.Tracing.getTracer;
import static io.opencensus.trace.samplers.Samplers.alwaysSample;
import static java.util.Collections.emptyMap;
import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.*;
import static org.springframework.http.ResponseEntity.ok;

public class MortgagePortingCreateApplicationControllerTest {

    private MortgageAccountInfoRestClient client;
    private MortgagePortingCreateApplicationService service;

    private MortgagePortingCreateApplicationController underTest;

    @Before
    public void setup() {
        MortgageServiceUtil utility = mock(MortgageServiceUtil.class);
        when(utility.buildSpan(anyString())).thenReturn(getTracer().spanBuilder("any").setSampler(alwaysSample()));
        MortgagePortingCreateApplicationValidator validator = mock(MortgagePortingCreateApplicationValidator.class);
        client = mock(MortgageAccountInfoRestClient.class);
        service = mock(MortgagePortingCreateApplicationService.class);
        underTest = new MortgagePortingCreateApplicationController(service, validator, utility);
    }

    @Test
    public void create_application_successful() {
        //given
        when(client.getMortgageAccountInfo(anyString(), anyMap())).thenReturn(MortgageAccountInfo.builder().build());
        CreatePortingApplicationResponse expected = CreatePortingApplicationResponse.builder().applicationNumber(APPLICATION_NUMBER).status(OPEN).build();
        when(service.createApplication(any())).thenReturn(expected);
        //when
        CreatePortingApplicationRequest request = new CreatePortingApplicationRequest();
        ResponseEntity<CreatePortingApplicationResponse> response = underTest.createApplication(BRAND, CHANNEL, CORRELATION_ID, JWT, INTERNAL_SYS_ID, emptyMap(), request);
        //then
        assertThat(response, is(ok(expected)));
    }

    @Test(expected = IllegalArgumentException.class)
    public void verify_action_not_permitted() {
        //given
        doThrow(IllegalArgumentException.class).when(service).createApplication(any());
        //when
        CreatePortingApplicationRequest request = new CreatePortingApplicationRequest();
        underTest.createApplication(BRAND, CHANNEL, CORRELATION_ID, JWT, INTERNAL_SYS_ID, emptyMap(), request);
        //then expect exception
    }
}