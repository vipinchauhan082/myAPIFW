package com.lbg.epscw.mortgagesrvc.helper;

import com.lbg.epscw.mortgagesrvc.dto.AccountCreationResponse;
import com.lbg.epscw.mortgagesrvc.dto.MortgageAccountData;
import com.lbg.epscw.mortgagesrvc.dto.MortgageBalance;
import com.lbg.epscw.mortgagesrvc.dto.MortgageResponse;
import com.lbg.epscw.mortgagesrvc.enums.MortgageFamily;
import com.lbg.epscw.mortgagesrvc.model.AccountOpenRequest;
import com.lbg.epscw.mortgagesrvc.model.AccountStatus;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static com.lbg.epscw.mortgagesrvc.constants.CommonConstants.*;

public class AccountCreationHelper {

    public static AccountOpenRequest generateAccountOpenRequestMortgage(){
        List<String> valutStakeHolders = new ArrayList<>();
        valutStakeHolders.add("abcdeefg12345");
        Map<String,String> details=new HashMap<>();
        details.put(PLAN_NUMBER, "54321");

        return AccountOpenRequest.builder()
                .denomination("GBP")
                .productId("lbg_mortgage")
                .mortgageNumber("123456")
                .status(AccountStatus.ACCOUNT_STATUS_OPEN)
                .interestRate("1")
                .details(details)
                .vaultStakeholderIds(valutStakeHolders)
                .productFamily(MortgageFamily.MORTGAGE)
                .keyDate("7")
                .depositAccount("1234567890")
                .mortgageCalculationPrincipal("10000")
                .mortgageType("CAPITAL_REPAYMENT")
                .totalTerm("24")
                .build();
    }

    public static AccountOpenRequest generateRepaymentAccountWithoutPlan(){
        List<String> valutStakeHolders = new ArrayList<>();
        valutStakeHolders.add("abcdeefg12345");
        Map<String,String> details=new HashMap<>();
        details.put(PLAN_NUMBER, "54321");

        return AccountOpenRequest.builder()
                .denomination("GBP")
                .productId("lbg_mortgage")
                .mortgageNumber("123456")
                .status(AccountStatus.ACCOUNT_STATUS_OPEN)
                .interestRate("1")
                .vaultStakeholderIds(valutStakeHolders)
                .productFamily(MortgageFamily.MORTGAGE)
                .keyDate("7")
                .depositAccount("1234567890")
                .mortgageCalculationPrincipal("10000")
                .mortgageType("CAPITAL_REPAYMENT")
                .totalTerm("24")
                .build();
    }

    public static AccountOpenRequest generateRepaymentAccountOpenRequestMortgage(){
        List<String> valutStakeHolders = new ArrayList<>();
        valutStakeHolders.add("abcdeefg12345");
        Map<String,String> details=new HashMap<>();
        details.put(PLAN_NUMBER, "54321");

        return AccountOpenRequest.builder()
                .denomination("GBP")
                .productId("lbg_mortgage_repayment")
                .mortgageNumber("123456")
                .details(details)
                .status(AccountStatus.ACCOUNT_STATUS_OPEN)
                .vaultStakeholderIds(valutStakeHolders)
                .productFamily(MortgageFamily.MORTGAGE_PAYMENT)
                .offsettingOption("1")
                .totalTerm("24")
                .build();
    }

    public static AccountCreationResponse buildCreateAccountResponse(){
       return AccountCreationResponse.builder()
               .internalAccountId("id1")
               .productId("lbg_mortgage")
               .productName("mortgage")
               .status("ACCOUNT_STATUS_OPEN")
               .accountNumber("1234566789")
               .build();
    }

    public static AccountCreationResponse buildCreateRepaymentAccountResponse(){
        return AccountCreationResponse.builder()
                .internalAccountId("id1")
                .productId("lbg_mortgage_repayment")
                .productName("Mortgage Payment")
                .status("ACCOUNT_STATUS_OPEN")
                .accountNumber("1234566789")
                .build();
    }

    public static AccountOpenRequest generateBadRequestOneMissing(){
        List<String> valutStakeHolders = new ArrayList<>();
        valutStakeHolders.add("abcdeefg12345");
        Map<String,String> details=new HashMap<>();
        details.put(PLAN_NUMBER, "54321");

        return AccountOpenRequest.builder()
                .denomination("GBP")
                .productId("lbg_mortgage")
 //               .mortgageNumber("123456")
                .details(details)
                .vaultStakeholderIds(valutStakeHolders)
                .productFamily(MortgageFamily.MORTGAGE)
                .keyDate("7")
                .depositAccount("1234567890")
                .mortgageCalculationPrincipal("10000")
                .mortgageType("CAPITAL_REPAYMENT")
                .totalTerm("24")
                .build();
    }

    public static AccountOpenRequest generateBadRequestMultiMissing(){
        List<String> valutStakeHolders = new ArrayList<>();
        valutStakeHolders.add("abcdeefg12345");

        return AccountOpenRequest.builder()
                //.denomination("GBP")
                //.productId("lbg_mortgage")
                //               .mortgageNumber("123456")
                //.planNumber("54321")
                //.vaultStakeholderIds(valutStakeHolders)
                .productFamily(MortgageFamily.MORTGAGE)
                //.keyDate("7")
                //.depositAccount("1234567890")
                //.mortgageCalculation_principal("10000")
                //.mortgageType("CAPITAL_REPAYMENT")
                //.totalTerm("24")
                .build();
    }

    public static List<MortgageAccountData>  getMortgageSubAccountData(){

        List<MortgageAccountData> mortgageAccountDataList = new ArrayList<>();

        MortgageAccountData mortgageAccountData = new MortgageAccountData();
        mortgageAccountData.setProductId("lbg_mortgage");
        mortgageAccountData.setMortgageNumber("00113");
        mortgageAccountData.setStatus("ACCOUNT_STATUS_OPEN");
        mortgageAccountData.setTotalTerm("5");
        mortgageAccountData.setProductFamily(MortgageFamily.MORTGAGE.name());
        mortgageAccountData.setSequenceId("1");
        mortgageAccountDataList.add(mortgageAccountData);
        MortgageAccountData mortgageAccountData1 = new MortgageAccountData();
        mortgageAccountData1.setProductId("lbg_mortgage_repayment");
        mortgageAccountData1.setMortgageNumber("00113");
        mortgageAccountData1.setStatus("ACCOUNT_STATUS_OPEN");
        mortgageAccountData1.setTotalTerm("10");
        mortgageAccountData1.setProductFamily(MortgageFamily.MORTGAGE.name());
        mortgageAccountData1.setSequenceId("2");
        mortgageAccountDataList.add(mortgageAccountData1);

        return mortgageAccountDataList;

    }

    public static MortgageResponse getMortgageOverarchingBalance(){

        MortgageResponse mortgageResponse = new MortgageResponse();
        MortgageBalance mortgageBalance = new MortgageBalance();
        Map<String,String> aggregatedMap = new HashMap<>();
        aggregatedMap.put("ArrearAmount","0.0");
        mortgageBalance.setAggregatedMap(aggregatedMap);
        mortgageResponse.setMortgageBalance(mortgageBalance);
        return mortgageResponse;

    }

    public static MortgageResponse getMortgageOverarchingBalanceWithArrears(){

        MortgageResponse mortgageResponse = new MortgageResponse();
        MortgageBalance mortgageBalance = new MortgageBalance();
        Map<String,String> aggregatedMap = new HashMap<>();
        aggregatedMap.put("ArrearAmount","50.0");
        mortgageBalance.setAggregatedMap(aggregatedMap);
        mortgageResponse.setMortgageBalance(mortgageBalance);
        return mortgageResponse;

    }


    public static Map<String, String> generateRequiredHeaders() {

        Map<String, String> requiredHeaders = new HashMap<>();
        requiredHeaders.put(X_LBG_BRAND, "if");
        requiredHeaders.put(X_LBG_CHANNEL, "TELEPHONE");
        requiredHeaders.put(CORRELATION_ID, "txnCorrelationId");
        requiredHeaders.put(AUTHORIZATION, "jwtToken");
        requiredHeaders.put(X_AUTH_TOKEN, "vaultAccessToken");
        requiredHeaders.put(CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE);
        return requiredHeaders;
    }

    public static HttpHeaders generateHttpHeaders(){
        HttpHeaders requiredHeaders = new HttpHeaders();
        requiredHeaders.add(X_LBG_BRAND, "IF");
        requiredHeaders.add(X_LBG_CHANNEL, "TELEPHONE");
        requiredHeaders.add(CORRELATION_ID, "txnCorrelationId");
        requiredHeaders.add(AUTHORIZATION, "Bearer VALID_STATIC_TOKEN");
        requiredHeaders.add(X_AUTH_TOKEN, "Bearer VALID_STATIC_TOKEN");
        requiredHeaders.add(CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE);
        requiredHeaders.add(X_LBG_INTERNAL_SYSTEM_ID, "TEST");
        return requiredHeaders;
    }
}
