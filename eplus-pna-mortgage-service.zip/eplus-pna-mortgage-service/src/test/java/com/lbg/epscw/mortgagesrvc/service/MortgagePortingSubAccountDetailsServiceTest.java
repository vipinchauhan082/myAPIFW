package com.lbg.epscw.mortgagesrvc.service;

import com.lbg.epscw.mortgagesrvc.exception.CircuitBreakerOpenException;
import com.lbg.epscw.mortgagesrvc.helper.MortgagePortingHelper;
import com.lbg.epscw.mortgagesrvc.model.MortgageApplicationInfo;
import com.lbg.epscw.mortgagesrvc.restclient.MortgagePortingApplicationInfoRestClient;
import com.lbg.epscw.mortgagesrvc.util.MortgageServiceUtil;
import org.junit.Before;
import org.junit.Test;

import java.util.HashMap;
import static com.lbg.epscw.mortgagesrvc.model.MortgagePortingApplicationStatus.OPEN;

import static org.junit.Assert.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;


public class MortgagePortingSubAccountDetailsServiceTest {

    private MortgageServiceUtil mortgageServiceUtil;

    private MortgagePortingApplicationInfoRestClient applicationInfoRestClient;

    private MortgagePortingSubAccountDetailsServiceImpl underTest;

    private final MortgagePortingHelper portingHelper = new MortgagePortingHelper();

    @Before
    public void setup() {
        mortgageServiceUtil = mock(MortgageServiceUtil.class);
        applicationInfoRestClient = mock(MortgagePortingApplicationInfoRestClient.class);
        underTest = new MortgagePortingSubAccountDetailsServiceImpl(mortgageServiceUtil,applicationInfoRestClient);
    }

    @Test
    public void test_setMortgageDetailsForApplication(){
        MortgageApplicationInfo mortgageAccountInfo = portingHelper.mortgageApplicationInfoWithStatus(OPEN.name());
        when(applicationInfoRestClient.updateApplication(anyString(),any(MortgageApplicationInfo.class))).thenReturn(mortgageAccountInfo);

        MortgageApplicationInfo mortgageApplicationInfo = underTest.updateMortgageDetailsForApplication(portingHelper.mortgageApplicationInfoWithStatus(OPEN.name()),
                portingHelper.applicationMortgageDetailsUpdateRequestPayload());

        assertEquals(OPEN, mortgageApplicationInfo.getStatus());

    }


    @Test(expected = CircuitBreakerOpenException.class)
    public void test_fallbackSetMortgageDetailsForApplication(){
        underTest.fallbackSetMortgageDetailsForApplication(portingHelper.mortgageApplicationInfoWithStatus(OPEN.name()),
                portingHelper.applicationMortgageDetailsUpdateRequestPayload(),new Exception("Circuit open on update mortgage details"));

    }
}
