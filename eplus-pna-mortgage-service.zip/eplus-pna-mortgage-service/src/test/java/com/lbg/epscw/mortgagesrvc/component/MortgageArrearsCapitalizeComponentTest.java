package com.lbg.epscw.mortgagesrvc.component;

import com.lbg.epscw.entitlement.service.EntitlementValidationServiceImpl;
import com.lbg.epscw.handler.model.ErrorInfo;
import com.lbg.epscw.handler.model.ErrorResponse;
import com.lbg.epscw.mortgagesrvc.dto.CapitalizeArrearsResponse;
import com.lbg.epscw.mortgagesrvc.helper.ComponentHelper;
import com.lbg.epscw.mortgagesrvc.helper.MortgageArrearsCapitalizeHelper;
import com.lbg.epscw.mortgagesrvc.logger.HystrixContextCopyStrategy;
import com.lbg.epscw.mortgagesrvc.service.RestClientService;
import org.apache.commons.lang.RandomStringUtils;
import org.junit.Assert;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mockito;
import org.mockito.internal.util.MockUtil;
import org.mockito.invocation.InvocationOnMock;
import org.mockito.stubbing.Answer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.context.ApplicationContext;
import org.springframework.http.HttpHeaders;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import java.util.HashMap;

import static org.junit.Assert.assertEquals;
import static org.junit.jupiter.api.Assertions.assertAll;
import static org.mockito.ArgumentMatchers.any;
import static org.powermock.api.mockito.PowerMockito.when;

@Tag("component")
@ExtendWith(SpringExtension.class)
@SpringBootTest
@AutoConfigureMockMvc
public class MortgageArrearsCapitalizeComponentTest extends WebMVCTest{

    private static final String MORTGAGE_ARREARS_CAPITALIZE =
            "/mortgages/b2c9119f-09e5-4ac9-9738-9e28b334d3fa/capitalize-arrears";

    @MockBean
    RestClientService restClientService;

    @MockBean
    private HystrixContextCopyStrategy hystrixContextCopyStrategy;

    @MockBean
    private EntitlementValidationServiceImpl entitlementValidationService;

    @Autowired
    private ApplicationContext context;

    private ComponentHelper componentHelper = new ComponentHelper();

    private MortgageArrearsCapitalizeHelper mortgageArrearsCapitalizeHelper = new MortgageArrearsCapitalizeHelper();

    @BeforeEach
    public void beforeEach() {
        this.componentHelper = new ComponentHelper();
        for (String name : context.getBeanDefinitionNames()) {
            Object bean = context.getBean(name);
            if (MockUtil.isMock(bean)) {
                Mockito.reset(bean);
            }
        }
    }


    @Test
    public void shouldCreateNewSubAccountForArrearsCapitalization() {
        //given
        when(restClientService.get(any(String.class),any(HashMap.class))).thenAnswer(new Answer() {
            private int count = 0;

            public Object answer(InvocationOnMock invocation) {
                if (count++ == 1)
                    return componentHelper.writeValueAsString(
                            mortgageArrearsCapitalizeHelper.getMortgageOverarchingBalanceWithArrears());

                return mortgageArrearsCapitalizeHelper.getMortgageInfoServiceResponse();
            }
        });

        when(restClientService.post(any(String.class), any(HashMap.class), any(String.class))).thenAnswer(new Answer() {
            private int count = 0;

            public Object answer(InvocationOnMock invocation) {
                if (count++ == 1)
                    return componentHelper.writeValueAsString(
                            mortgageArrearsCapitalizeHelper.buildVaultPostingInstructionResponse());

                return componentHelper.writeValueAsString(mortgageArrearsCapitalizeHelper.getAccountCreateResponse());
            }
        });

        //when

        MockHttpServletResponse servletResponse = doPOST(MORTGAGE_ARREARS_CAPITALIZE, "", mortgageArrearsCapitalizeHelper.generateHttpHeaders());

        String responseString = componentHelper.getServletResponseAsString(servletResponse);
        CapitalizeArrearsResponse response = (CapitalizeArrearsResponse) readObject(responseString, CapitalizeArrearsResponse.class);

        //then
        assertAll(
                () -> assertEquals("ACCOUNT_STATUS_OPEN", response.getStatus()),
                () -> assertEquals("Mortgage", response.getProductName()),
                () -> assertEquals("lbg_mortgage", response.getProductId()),
                () -> assertEquals("5678", response.getInternalAccountId())
        );
    }

    @Test
    public void shouldCreateNewSubAccountForArrearsCapitalizationWithOldestTermIfPrimaryAccountClosed() {
        //given

        when(restClientService.get(any(String.class),any(HashMap.class))).thenAnswer(new Answer() {
            private int count = 0;

            public Object answer(InvocationOnMock invocation) {
                if (count++ == 1)
                    return componentHelper.writeValueAsString(
                            mortgageArrearsCapitalizeHelper.getMortgageOverarchingBalanceWithArrears());

                return mortgageArrearsCapitalizeHelper.getMortgageInfoServiceResponseWithPrimaryAccountClosed();
            }
        });

        when(restClientService.post(any(String.class), any(HashMap.class), any(String.class))).thenAnswer(new Answer() {
            private int count = 0;

            public Object answer(InvocationOnMock invocation) {
                if (count++ == 1)
                    return componentHelper.writeValueAsString(
                            mortgageArrearsCapitalizeHelper.buildVaultPostingInstructionResponse());

                return componentHelper.writeValueAsString(mortgageArrearsCapitalizeHelper.getAccountCreateResponse());
            }
        });

        //when

        MockHttpServletResponse servletResponse = doPOST(MORTGAGE_ARREARS_CAPITALIZE, "", mortgageArrearsCapitalizeHelper.generateHttpHeaders());

        String responseString = componentHelper.getServletResponseAsString(servletResponse);
        CapitalizeArrearsResponse response = (CapitalizeArrearsResponse) readObject(responseString, CapitalizeArrearsResponse.class);

        //then
        assertAll(
                () -> assertEquals("ACCOUNT_STATUS_OPEN", response.getStatus()),
                () -> assertEquals("Mortgage", response.getProductName()),
                () -> assertEquals("lbg_mortgage", response.getProductId()),
                () -> assertEquals("5678", response.getInternalAccountId())
        );
    }


    @Test
    public void shouldNotCreateNewSubAccountForArrearsCapitalizationIfNotArrearsAccount() {
        //given
        when(restClientService.get(any(String.class),any(HashMap.class))).thenAnswer(new Answer() {
            private int count = 0;

            public Object answer(InvocationOnMock invocation) {
                if (count++ == 1)
                    return componentHelper.writeValueAsString(
                            mortgageArrearsCapitalizeHelper.getMortgageOverarchingBalanceWithoutArrears());

                return mortgageArrearsCapitalizeHelper.getMortgageInfoServiceResponse();
            }
        });

        //when

        MockHttpServletResponse servletResponse = doPOST(MORTGAGE_ARREARS_CAPITALIZE, "", mortgageArrearsCapitalizeHelper.generateHttpHeaders());

        String responseString = componentHelper.getServletResponseAsString(servletResponse);
        ErrorResponse errorResponse = (ErrorResponse) readObject(responseString, ErrorResponse.class);
        ErrorInfo errorInfo = errorResponse.getErrors().get(0);

        //then
        assertAll(
                () -> assertEquals(400, servletResponse.getStatus()),
                () -> assertEquals("PNA.MORTGAGE_API.SYS.001", errorResponse.getCode()),
                () -> assertEquals("Bad Request", errorResponse.getMessage()),
                () -> assertEquals("PNA.MORTGAGE_API.POST_MORTGAGES_CAPITALIZE_ARREARS.MortgageCapitalizationArrears.NotEligible", errorInfo.getReasonCode()),
                () -> assertEquals("Mortgage Overarching account is not an arrears account", errorInfo.getMessage())
        );
    }

    @Test
    public void shouldNotCreateNewSubAccountForArrearsCapitalizationIfNotAnOverarchingAccount() {
        //given
        when(restClientService.get(any(String.class),any(HashMap.class))).thenReturn(mortgageArrearsCapitalizeHelper.getMortgageInfoServiceResponseWithoutOverarchingAccount());


        //when

        MockHttpServletResponse servletResponse = doPOST(MORTGAGE_ARREARS_CAPITALIZE, "", mortgageArrearsCapitalizeHelper.generateHttpHeaders());

        String responseString = componentHelper.getServletResponseAsString(servletResponse);
        ErrorResponse errorResponse = (ErrorResponse) readObject(responseString, ErrorResponse.class);
        ErrorInfo errorInfo = errorResponse.getErrors().get(0);

        //then
        assertAll(
                () -> assertEquals(400, servletResponse.getStatus()),
                () -> assertEquals("PNA.MORTGAGE_API.SYS.001", errorResponse.getCode()),
                () -> assertEquals("Bad Request", errorResponse.getMessage()),
                () -> assertEquals("PNA.MORTGAGE_API.POST_MORTGAGES_CAPITALIZE_ARREARS.MortgageOverarchingAccount.Invalid", errorInfo.getReasonCode()),
                () -> assertEquals("Account is not an overarching account", errorInfo.getMessage())
        );
    }


    @Test
    public void shouldReturnErrorForEmptyJson() {
        //when
        MockHttpServletResponse servletResponse = doPOST(MORTGAGE_ARREARS_CAPITALIZE,
                "{}",
                mortgageArrearsCapitalizeHelper.generateHttpHeaders());

        String responseString = componentHelper.getServletResponseAsString(servletResponse);
        ErrorResponse errorResponse = (ErrorResponse) readObject(responseString, ErrorResponse.class);
        ErrorInfo errorInfo = errorResponse.getErrors().get(0);

        //then
        assertAll(
                () -> Assert.assertEquals(400, servletResponse.getStatus()),
                () -> Assert.assertEquals("PNA.MORTGAGE_API.SYS.001", errorResponse.getCode()),
                () -> Assert.assertEquals("Bad Request", errorResponse.getMessage())

        );
    }

    @Test
    public void shouldReturnErrorForEmptyRequestBody() {
        //given
        //when
        MockHttpServletResponse servletResponse = doPOST(MORTGAGE_ARREARS_CAPITALIZE,
                "",
                mortgageArrearsCapitalizeHelper.generateHttpHeaders());

        String responseString = componentHelper.getServletResponseAsString(servletResponse);
        ErrorResponse errorResponse = (ErrorResponse) readObject(responseString, ErrorResponse.class);
        ErrorInfo errorInfo = errorResponse.getErrors().get(0);

        //then
        assertAll(
                () -> Assert.assertEquals(400, servletResponse.getStatus()),
                () -> Assert.assertEquals("PNA.MORTGAGE_API.SYS.001", errorResponse.getCode()),
                () -> Assert.assertEquals("Bad Request", errorResponse.getMessage())

        );
    }

    @Test
    public void shouldReturnErrorForUpdateWhenAccountIdIsMoreThan36Chars() {
        //given
        HttpHeaders accountInfoHeaders = mortgageArrearsCapitalizeHelper.generateHttpHeaders();
        //when
        MockHttpServletResponse servletResponse = doPOST("/mortgages/"+ org.apache.commons.lang3.RandomStringUtils.random(50)+"/capitalize-arrears",
                "",
                accountInfoHeaders);
        String responseString = componentHelper.getServletResponseAsString(servletResponse);
        ErrorResponse errorResponse = (ErrorResponse) readObject(responseString, ErrorResponse.class);
        ErrorInfo errorInfo = errorResponse.getErrors().get(0);

        //then
        assertAll(
                () -> Assertions.assertEquals(400, servletResponse.getStatus()),
                () -> Assertions.assertEquals("PNA.MORTGAGE_API.SYS.001", errorResponse.getCode()),
                () -> Assertions.assertEquals("Bad Request", errorResponse.getMessage()),
                () -> Assertions.assertEquals("AccountId should be max 36 characters", errorInfo.getMessage())
        );
    }

    @Test
    public void shouldReturnErrorForUpdateWhenAccountIdIsLessThan36Chars() {
        //given
        HttpHeaders accountInfoHeaders = mortgageArrearsCapitalizeHelper.generateHttpHeaders();
        //when
        MockHttpServletResponse servletResponse = doPOST("/mortgages/"+ org.apache.commons.lang3.RandomStringUtils.random(5)+"/capitalize-arrears",
                "",
                accountInfoHeaders);
        String responseString = componentHelper.getServletResponseAsString(servletResponse);
        ErrorResponse errorResponse = (ErrorResponse) readObject(responseString, ErrorResponse.class);
        ErrorInfo errorInfo = errorResponse.getErrors().get(0);

        //then
        assertAll(
                () -> Assertions.assertEquals(400, servletResponse.getStatus()),
                () -> Assertions.assertEquals("PNA.MORTGAGE_API.SYS.001", errorResponse.getCode()),
                () -> Assertions.assertEquals("Bad Request", errorResponse.getMessage()),
                () -> Assertions.assertEquals("AccountId should be min 36 characters", errorInfo.getMessage())
        );
    }


    @Test
    public void shouldReturnErrorForUpdateWhenCorrelationIdIsGreaterThanFortyCharacters() {
        //given

        HttpHeaders accountInfoHeaders = mortgageArrearsCapitalizeHelper.generateHttpHeaders();
        accountInfoHeaders.set("x-lbg-txn-correlation-id", RandomStringUtils.random(50));
        //when
        MockHttpServletResponse servletResponse = doPOST(MORTGAGE_ARREARS_CAPITALIZE,
                "",
                accountInfoHeaders);
        String responseString = componentHelper.getServletResponseAsString(servletResponse);
        ErrorResponse errorResponse = (ErrorResponse) readObject(responseString, ErrorResponse.class);
        ErrorInfo errorInfo = errorResponse.getErrors().get(0);

        //then
        assertAll(
                () -> Assert.assertEquals(400, servletResponse.getStatus()),
                () -> Assert.assertEquals("PNA.MORTGAGE_API.SYS.001", errorResponse.getCode()),
                () -> Assert.assertEquals("Bad Request", errorResponse.getMessage()),
                () -> Assert.assertEquals("x-lbg-txn-correlation-id size should be between 10 and 40", errorInfo.getMessage())
        );
    }

    @Test
    public void shouldReturnErrorForUpdateWhenCorrelationIdIsLessThanTenCharacters() {
        //given

        HttpHeaders accountInfoHeaders = mortgageArrearsCapitalizeHelper.generateHttpHeaders();
        accountInfoHeaders.set("x-lbg-txn-correlation-id", RandomStringUtils.random(9));
        //when
        MockHttpServletResponse servletResponse = doPOST(MORTGAGE_ARREARS_CAPITALIZE,
                "",
                accountInfoHeaders);
        String responseString = componentHelper.getServletResponseAsString(servletResponse);
        ErrorResponse errorResponse = (ErrorResponse) readObject(responseString, ErrorResponse.class);
        ErrorInfo errorInfo = errorResponse.getErrors().get(0);

        //then
        assertAll(
                () -> Assert.assertEquals(400, servletResponse.getStatus()),
                () -> Assert.assertEquals("PNA.MORTGAGE_API.SYS.001", errorResponse.getCode()),
                () -> Assert.assertEquals("Bad Request", errorResponse.getMessage()),
                () -> Assert.assertEquals("x-lbg-txn-correlation-id size should be between 10 and 40", errorInfo.getMessage())
        );
    }

    @Test
    public void shouldReturnErrorForUpdateWhenCorrelationIdIsMissing() {
        //given
        HttpHeaders accountInfoHeaders = mortgageArrearsCapitalizeHelper.generateHttpHeaders();
        accountInfoHeaders.remove("x-lbg-txn-correlation-id");
        //when
        MockHttpServletResponse servletResponse = doPOST(MORTGAGE_ARREARS_CAPITALIZE,
                "",
                accountInfoHeaders);
        String responseString = componentHelper.getServletResponseAsString(servletResponse);
        ErrorResponse errorResponse = (ErrorResponse) readObject(responseString, ErrorResponse.class);
        ErrorInfo errorInfo = errorResponse.getErrors().get(0);

        //then
        assertAll(
                () -> Assert.assertEquals(400, servletResponse.getStatus()),
                () -> Assert.assertEquals("PNA.MORTGAGE_API.SYS.001", errorResponse.getCode()),
                () -> Assert.assertEquals("Bad Request", errorResponse.getMessage()),
                () -> Assert.assertEquals("Missing request header x-lbg-txn-correlation-id for method parameter of type String", errorInfo.getMessage())
        );
    }


    @Test
    public void shouldReturnErrorForUpdateWhenBrandIsMissing() {
        //given
        HttpHeaders accountInfoHeaders = mortgageArrearsCapitalizeHelper.generateHttpHeaders();
        accountInfoHeaders.remove("x-lbg-brand");
        //when
        MockHttpServletResponse servletResponse = doPOST(MORTGAGE_ARREARS_CAPITALIZE,
                "",
                accountInfoHeaders);
        String responseString = componentHelper.getServletResponseAsString(servletResponse);
        ErrorResponse errorResponse = (ErrorResponse) readObject(responseString, ErrorResponse.class);
        ErrorInfo errorInfo = errorResponse.getErrors().get(0);

        //then
        assertAll(
                () -> Assert.assertEquals(400, servletResponse.getStatus()),
                () -> Assert.assertEquals("PNA.MORTGAGE_API.SYS.001", errorResponse.getCode()),
                () -> Assert.assertEquals("Bad Request", errorResponse.getMessage()),
                () -> Assert.assertEquals("Missing request header 'x-lbg-brand' for method parameter of type String", errorInfo.getMessage())
        );
    }
}
