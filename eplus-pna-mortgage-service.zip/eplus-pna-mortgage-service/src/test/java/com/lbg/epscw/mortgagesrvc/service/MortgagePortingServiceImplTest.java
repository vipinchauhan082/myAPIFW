package com.lbg.epscw.mortgagesrvc.service;

import com.lbg.epscw.mortgagesrvc.dto.MortgageAccountInfo;
import com.lbg.epscw.mortgagesrvc.dto.MortgageClosureEligibility;
import com.lbg.epscw.mortgagesrvc.dto.VaultAccountStatusUpdateRequest;
import com.lbg.epscw.mortgagesrvc.exception.CircuitBreakerOpenException;
import com.lbg.epscw.mortgagesrvc.exception.MortgageServiceException;
import com.lbg.epscw.mortgagesrvc.exception.VaultValidationException;
import com.lbg.epscw.mortgagesrvc.helper.MortgagePortingApplicationHelper;
import com.lbg.epscw.mortgagesrvc.helper.MortgagePortingHelper;
import com.lbg.epscw.mortgagesrvc.model.*;
import com.lbg.epscw.mortgagesrvc.restclient.MortgageAccountInfoRestClient;
import com.lbg.epscw.mortgagesrvc.restclient.MortgageAccountOpenRestClient;
import com.lbg.epscw.mortgagesrvc.restclient.MortgageAccountStatusRestClient;
import com.lbg.epscw.mortgagesrvc.restclient.MortgagePortingApplicationInfoRestClient;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.invocation.InvocationOnMock;
import org.mockito.stubbing.Answer;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static org.junit.Assert.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.*;
import static org.powermock.api.mockito.PowerMockito.mock;
import static org.powermock.api.mockito.PowerMockito.when;

@RunWith(SpringRunner.class)
public class MortgagePortingServiceImplTest {

    @MockBean
    private MortgageAccountStatusRestClient mortgageAccountStatusRestClient;


    @MockBean
    private MortgageAccountOpenRestClient mortgageAccountOpenRestClient;

    @MockBean
    private MortgageAccountInfoRestClient mortgageAccountInfoRestClient;

    @MockBean
    private MortgagePortingApplicationInfoRestClient applicationInfoRestClient;


    private MortgagePortingHelper mortgagePortingHelper = new MortgagePortingHelper();

    @Before
    public void setUp() throws Exception {
        mortgageAccountStatusRestClient = mock(MortgageAccountStatusRestClient.class);
        mortgageAccountOpenRestClient = mock(MortgageAccountOpenRestClient.class);
        mortgageAccountInfoRestClient = mock(MortgageAccountInfoRestClient.class);
        applicationInfoRestClient = mock(MortgagePortingApplicationInfoRestClient.class);
    }

    @Test
    public void account_status_update_for_newly_ported_mortgage() {
        //given
        MortgagePortingServiceImpl mortgagePortingService= new MortgagePortingServiceImpl(mortgageAccountStatusRestClient);
        MortgageAccountInfo mortgageAccountInfo=mortgagePortingHelper.buildMortgageAccountInfoWithSubAccount(true);
        AccountStatusUpdateRequest accountStatusUpdateRequest = mortgagePortingHelper.buildAccountStatusUpdateRequestWithOverarchingSubAccountAndOpenStatus();
        accountStatusUpdateRequest.setAccountStatus(AccountStatus.ACCOUNT_STATUS_CANCELLED);

        when(mortgageAccountStatusRestClient.updateAccountStatus(any(String.class), any(VaultAccountStatusUpdateRequest.class))).thenAnswer(new Answer() {
            private int count = 0;

            public Object answer(InvocationOnMock invocation) {
                if (count++ == 1)
                    return mortgagePortingHelper.buildAccountStatusUpdateVaultResponse1();

                return mortgagePortingHelper.buildAccountStatusUpdateVaultResponse();
            }
        });

        MortgageClosureEligibility mortgageClosureEligibility=new MortgageClosureEligibility();
        mortgageClosureEligibility.setAccountStatus(AccountStatus.ACCOUNT_STATUS_PENDING_CLOSURE.name());
        //when
        List<AccountPortingStatusResponse> response = mortgagePortingService.updateMortgageAccountStatus(accountStatusUpdateRequest, mortgageAccountInfo.getMortgageAccountData());
        //then
        assertNotNull(response);
        assertEquals("b2c9119f-09e5-4ac9-9738-9e28b334d3fa",response.get(0).getAccountId());
        assertEquals("b2c9119f-09e5-4ac9-9738-9e28b334d4ty",response.get(1).getAccountId());
        assertEquals(AccountStatus.ACCOUNT_STATUS_CANCELLED.name(),response.get(0).getStatus());
    }

    @Test
    public void account_status_update_for_newly_ported_mortgage_service_returns_empty_list_if_vault_return_null() {
        //given
        MortgagePortingServiceImpl mortgagePortingService= new MortgagePortingServiceImpl(mortgageAccountStatusRestClient);
        MortgageAccountInfo mortgageAccountInfo=mortgagePortingHelper.buildMortgageAccountInfoWithSubAccount(true);
        AccountStatusUpdateRequest accountStatusUpdateRequest = mortgagePortingHelper.buildAccountStatusUpdateRequestWithOnlyOverarchingAndCancelStatus();

        when(mortgageAccountStatusRestClient.updateAccountStatus(any(String.class), any(VaultAccountStatusUpdateRequest.class))).thenReturn(null);
        //when
        List<AccountPortingStatusResponse> response = mortgagePortingService.updateMortgageAccountStatus(accountStatusUpdateRequest, mortgageAccountInfo.getMortgageAccountData());
        //then
        assertEquals(0,response.size());
    }

    @Test(expected = MortgageServiceException.class)
    public void account_status_update_for_newly_ported_mortgage_fails_when_vault_throws_exception() {
        //given
        MortgagePortingServiceImpl mortgagePortingService= new MortgagePortingServiceImpl(mortgageAccountStatusRestClient);

        MortgageAccountInfo mortgageAccountInfo=mortgagePortingHelper.buildMortgageAccountInfoWithSubAccount(true);
        AccountStatusUpdateRequest accountStatusUpdateRequest = mortgagePortingHelper.buildAccountStatusUpdateRequestWithOverarchingSubAccountAndOpenStatus();

        when(mortgageAccountStatusRestClient.updateAccountStatus(any(String.class), any(VaultAccountStatusUpdateRequest.class))).thenThrow(new VaultValidationException("Status","Fail"));
        //when
        mortgagePortingService.updateMortgageAccountStatus(accountStatusUpdateRequest, mortgageAccountInfo.getMortgageAccountData());
    }

    @Test(expected = CircuitBreakerOpenException.class)
    public void hystrix_test_on_update_account_status_service() {
        //when
        MortgagePortingServiceImpl mortgagePortingService= new MortgagePortingServiceImpl(mortgageAccountStatusRestClient);
        MortgageAccountInfo mortgageAccountInfo=mortgagePortingHelper.buildMortgageAccountInfoWithSubAccount(true);
        AccountStatusUpdateRequest accountStatusUpdateRequest = mortgagePortingHelper.buildAccountStatusUpdateRequestWithOverarchingSubAccountAndOpenStatus();

        mortgagePortingService
                .fallbackUpdateMortgageAccountStatus(accountStatusUpdateRequest, mortgageAccountInfo.getMortgageAccountData(),
                        new Exception("Circuit open on update account status"));
    }


    @Test
    public void submit_Mortgage_Porting_Application(){
        MortgagePortingApplicationHelper mortgagePortingApplicationHelper = new MortgagePortingApplicationHelper();
        MortgagePortingServiceImpl mortgagePortingService= new MortgagePortingServiceImpl(mortgageAccountStatusRestClient
                ,mortgageAccountOpenRestClient,mortgageAccountInfoRestClient,applicationInfoRestClient);

        when(mortgageAccountInfoRestClient.getMortgageInfoByMortgageNumber(any(String.class),any(Map.class))).
                thenReturn(mortgagePortingApplicationHelper.getMortgageAccountInfo());

        when(mortgageAccountOpenRestClient.createMortgageAccount(any(AccountOpenRequest.class),any(Map.class))).
                thenReturn(mortgagePortingApplicationHelper.buildCreateAccountResponse());

        MortgageApplicationInfo mortgagePortingApplicationDetails = mortgagePortingApplicationHelper.getMortgagePortingApplicationDetails();
        mortgagePortingApplicationDetails.setStatus(MortgagePortingApplicationStatus.SUBMITTED);

        when(applicationInfoRestClient.updateApplication(anyString(),any(MortgageApplicationInfo.class))).
                thenReturn(mortgagePortingApplicationDetails);

        AccountPortingStatusResponse accountPortingStatusResponse = mortgagePortingService.
                submitMortgagePortingApplication(mortgagePortingApplicationHelper.getMortgagePortingApplicationDetails()
                , mortgagePortingApplicationHelper.getMortgagePortingSubmitRequest(), new HashMap<>());

        assertEquals("id1",accountPortingStatusResponse.getAccountId());
        assertEquals("SUBMITTED",accountPortingStatusResponse.getStatus());
    }

    @Test(expected = CircuitBreakerOpenException.class)
    public void hystrix_test_fallbackSubmitMortgagePortingApplication() {
        //when
        MortgagePortingServiceImpl mortgagePortingService= new MortgagePortingServiceImpl(mortgageAccountStatusRestClient);
        mortgagePortingService
                .fallbackSubmitMortgagePortingApplication(new MortgageApplicationInfo(),new MortgagePortingSubmitRequest(),new HashMap<>(),
                        new Exception("Circuit open on update jar name"));
    }

}