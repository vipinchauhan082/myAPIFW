package com.ep.testing.bdd.api.steps;

import com.ep.testing.bdd.parameters.DefaultParamTransformer;
import com.ep.testing.bdd.util.SpannerUtil;
import cucumber.api.java8.En;
import io.cucumber.datatable.DataTable;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

public class SpannerSteps implements En {

    private static final Logger CURL_LOG = LoggerFactory.getLogger("curl");
    SpannerUtil spannerUtil = new SpannerUtil();
    public static final String profile = System.getProperty("profileId");

    public SpannerSteps(DefaultParamTransformer paramTransformer) {

        When(
                "I should get {int} records in spanner table {string} for {string} = {string}",
                (Integer expected_no_of_records, String tableName, String columnName, String columnValue) -> {
                    if (profile == null || profile.equals("local")) {
                        String columnValueNew = paramTransformer.transform(columnValue);
                        Map<String, String> map = Stream.of(new String[][]{
                                {columnName, columnValueNew},
                        }).collect(Collectors.toMap(data -> data[0], data -> data[1]));
                        System.out.println(map);
                        List<Map<String, Object>> records = spannerUtil.getRecords(tableName, map);
                        Integer actual_no_of_records = records.size();
                        assertEquals(
                                String.format(
                                        "Mismatch in expected number of records in table %s", tableName),
                                expected_no_of_records,
                                actual_no_of_records);
                    } else {
                        CURL_LOG.info("Spanner will not run in build02 or integration environment");
                    }
                });

        When(
                "I should get the following columns in spanner table {string} for {string} = {string}",
                (String tableName, String columnName, String columnValue, DataTable table) -> {
                    if (profile == null || profile.equals("local")) {
                        Map<String, String> map = Stream.of(new String[][]{
                                {columnName, columnValue},
                        }).collect(Collectors.toMap(data -> data[0], data -> data[1]));
                        List<String> getListOfColumnsInResultSet = spannerUtil.getListOfColumnsInResultSet(tableName, map);
                        assertEquals(String.format(
                                "Mismatch in expected number of columns in table '%s'.", tableName),
                                getListOfColumnsInResultSet.size(), table.asList().size());
                        assertEquals(String.format(
                                "Mismatch in expected column names in table '%s'.", tableName),
                                getListOfColumnsInResultSet, table.asList());
                    } else {
                        CURL_LOG.info("Spanner will not run in build02 or integration environment");
                    }
                });

        When(
                "I should get {int} record in spanner table {string} matching the following criteria",
                (Integer expected_no_of_records, String tableName, DataTable table) -> {
                    if (profile == null || profile.equals("local")) {
                        Map<String, String> columns = table.asMap(String.class, String.class);

                        Map<String, String> map = columns.entrySet().stream()
                                .collect(Collectors.toMap(
                                        Map.Entry::getKey,
                                        Map.Entry::getValue)
                                );
                        map.replaceAll((k, v) -> paramTransformer.transform(map.get(k)));
                        List<Map<String, Object>> records = spannerUtil.getRecords(tableName, map);
                        Integer actual_no_of_records = records.size();
                        assertEquals(
                                String.format(
                                        "Mismatch in expected number of records in table %s", tableName),
                                expected_no_of_records,
                                actual_no_of_records);
                    } else {
                        CURL_LOG.info("Spanner will not run in build02 or integration environment");
                    }
                });
        Then("^I should get at least (\\d+) records in spanner table \"([^\"]*)\" for \"([^\"]*)\" = \"([^\"]*)\"$",
                (Integer expected_no_of_records, String tableName, String columnName, String columnValue) -> {
                    if (profile == null || profile.equals("local")) {
                        String columnValueNew = paramTransformer.transform(columnValue);
                        System.out.println("colval: " + columnValueNew);
                        Map<String, String> map = Stream.of(new String[][]{
                                {columnName, columnValueNew},
                        }).collect(Collectors.toMap(data -> data[0], data -> data[1]));
                        System.out.println(map);
                        List<Map<String, Object>> records = spannerUtil.getRecords(tableName, map);
                        int actual_no_of_records = records.size();
                        assertTrue(actual_no_of_records >= expected_no_of_records);
                    } else {
                        CURL_LOG.info("Spanner will not run in build02 or integration environment");
                    }

                });
    }
}