package com.ep.testing.bdd.api.httpcore;

public interface Options {

    String BASE_URI = "base_uri";
    String PROXY = "proxy";
    String AUTH_TYPE = "auth_type";
    String USERNAME = "username";
    String PASSWORD = "password";
    String URL_ENCODING_ENABLED = "url_encoding_enabled";
    String RELAXED_HTTPS = "relaxed_https";

    String GZIP_SUPPORT = "gzip_support";
    String FOLLOW_REDIRECTS = "follow_redirects";

    String DEFAULT_ENV = "build2";
    String SPANNER_PROJECT_ID = "spanner_projectID";
    String SPANNER_INSTANCE_ID = "spanner_instance";
    String SPANNER_DB_ID = "spanner_database";
    String DELETE_SPANNER_DATA = "delete_spanner_data";
}