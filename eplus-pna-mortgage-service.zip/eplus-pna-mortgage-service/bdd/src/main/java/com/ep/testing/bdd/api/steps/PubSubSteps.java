package com.ep.testing.bdd.api.steps;

import com.ep.testing.bdd.api.http.APIRequestState;
import com.ep.testing.bdd.http.ResponseState;
import com.ep.testing.bdd.model.MessageWrapper;
import com.ep.testing.bdd.parameters.DefaultParamTransformer;
import com.ep.testing.bdd.util.BDDConfig;
import com.ep.testing.bdd.util.YamlReader;
import com.jayway.jsonpath.matchers.JsonPathMatchers;
import com.typesafe.config.Config;
import cucumber.api.Scenario;
import cucumber.api.java8.En;
import io.restassured.path.json.JsonPath;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicBoolean;

import static org.junit.Assert.*;

public class PubSubSteps implements En {

    private static Config config = BDDConfig.getConfig();
    private static final Logger LOG = LoggerFactory.getLogger("curl");

    public PubSubSteps(DefaultParamTransformer paramTransformer) {

        Before(
                (Scenario scenario) -> {
                    LOG.debug("## SCENARIO: {}", scenario.getName());
                });


        When("^I extract the Pub/Sub Messages from \"([^\"]*)\" to \"([^\"]*)\"$",

                (String subsResponse, String messagesAsJson) -> {

                    ResponseState response = paramTransformer.getResponseState(subsResponse);
                    List<MessageWrapper> wrapperList =
                            Arrays.asList(response.getResponse().getBody().as(MessageWrapper[].class));

                    List<String> messageList = new ArrayList<>();
                    wrapperList.forEach(wrapper -> {
                        try {
                            String message = wrapper.getMessage();
                            messageList.add(message);
                        } catch (Exception ex) {
                            LOG.error("Failed to get message. Exception thrown: {} ", ex.getMessage());
                        }
                    });

                    paramTransformer.cacheAnObject(messagesAsJson, messageList);

                }
        );

        Then("^I verify \"([^\"]*)\" message for \"([^\"]*)\" with response \"([^\"]*)\"$",
                (String messagesAsJson, String ymlFile, String apiResponse) -> {
                    try {
                        String[] yml = ymlFile.split("-");
                        String ymlFileName = yml[0];
                        String ymlKey = yml[1];
                        YamlReader yamlReader = new YamlReader(ClassLoader.getSystemResourceAsStream(config
                                .getConfig("files").getString("testdata").replace("{testdata_name}", ymlFileName)));

                        String jsonPath = yamlReader.getValue("pubsubMsgKey").toString();
                        String responseKey= yamlReader.getValue("serviceResponseKey").toString();

                        Map<String, Object> schema  = yamlReader.getYamlObj(ymlKey);
                        String expectedVal = paramTransformer.transform("{{response::"+apiResponse+"->"+responseKey+"}}");
                        AtomicBoolean msgFound = new AtomicBoolean(false);
                        List<String> messageList = (List<String>) paramTransformer.getCachedObject(messagesAsJson);
                        messageList.forEach(message -> {
                                    String val = JsonPath.with(message).get(jsonPath);
                                    if (expectedVal.equals(val)) {
                                        msgFound.set(true);

                                        schema.entrySet().stream().forEach((entry) -> {
//                                        assertThat(entry.getKey() + " is not found in Pub/Sub Messgae", message, JsonPathMatchers.hasJsonPath("$." + (String)entry.getValue()));

                                            String protoValue = JsonPath.with(message).get((String)entry.getValue());
                                            String responseValue = (String) paramTransformer.transform("{{response::"+apiResponse+"->"+ (String)entry.getKey() + "}}");
//                                            System.out.println(">>>"+entry.getValue().toString()+">>>>>protoValue>>>>>>>>> "+ protoValue);
//                                            System.out.println(">>>"+entry.getKey().toString()+">>>>responseValue>>>>>>>>> "+ responseValue);
                                            String assertionReason = String.format("Response field '%s' value is not equal to '%s' expected value.", entry.getKey(), entry.getValue());
//                                        assertEquals(assertionReason, responseValue, protoValue);
                                            if(!responseValue.equals(protoValue)) {
                                                msgFound.set(false);
                                            }

                                        });
                                    }

                                    if(!msgFound.get()) {
                                        return;
                                    }

                                }
                        );
                        assertTrue("Message not found.", msgFound.get());
                    } catch (Exception ex) {
                        LOG.error("Failed to read messages. Exception thrown: {} ", ex.getMessage());
                    }
                }
        );
    }
}