# Products and Accounts Performance tests
Performance test framework for Products and accounts microservices 

Based on [gradle-gatling-plugin](https://github.com/lkishalmi/gradle-gatling-plugin)

## Usage

Run all simulations in scenarios: ./gradlew gatlingRun 

Run a specific simulation: ./gradlew gatlingRun-scenario.AccountService (replace with name of Simulation)

## Reports
Reports are generated in build/reports/gatling