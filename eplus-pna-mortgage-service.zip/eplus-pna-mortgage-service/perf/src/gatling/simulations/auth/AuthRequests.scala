package auth

//import constants.CustomerConstants

import helpers.FeederHelpers
import io.gatling.core.Predef._
import io.gatling.http.Predef._


object InvokeTree {
  val invokeTree = exec(
    http("GET AuthID")
      .post("/v1/identityauth/authenticate").disableFollowRedirect
      .queryParam("service", "AuthTree")
      .queryParam("authIndexType", "service")
      .queryParam("authIndexValue", "AuthTree")
      .headers(FeederHelpers.forgerockHeaderMap)
      .header("x-lbg-customer-id", "${CustomerId}")
      .header("x-lbg-txn-customer-id" ,"${correlationId}")
      .check(status.is(200))
      .check(jsonPath("$.authId").saveAs("auth_Id"))
    //.check(jsonPath("$.ChallengeCode").saveAs("code"))
  )
}
object Validate{
  val validate =exec(
    http("UserID/Pwd Validate")
      .post("/v1/identityauth/authenticate").disableFollowRedirect
      .queryParam("service", "AuthTree")
      .queryParam("authIndexType", "service")
      .queryParam("authIndexValue", "AuthTree")
      .headers(FeederHelpers.forgerockHeaderMap)
      .header("x-lbg-customer-id", "${CustomerId}")
      .header("x-lbg-txn-customer-id" ,"${correlationId}")
      .body(StringBody(session => session("pwdValidatorReqBody").as[String].replaceAll("\\{ABCD}", session("auth_Id").as[String]).replaceAll("\\{user_id}", session("user_id").as[String]).replaceAll("\\{pwd}", session("pwd").as[String]))).asJson
      //.body(StringBody(("""{ "ABCD": "${auth_Id}" }"""))).asJson
      .check(status.is(200))
      .check(jsonPath("$.authId").saveAs("auth_Id"))
      .check(jsonPath("$.callbacks").saveAs("callbacks"))
      .check( regex( """pos\\\\\\\"\:(\d+)""").findAll.saveAs("task2"))
  )
}

object MiValidate{
  val miValidate =exec(
    http("MI Validate")
      .post("/v1/identityauth/authenticate").disableFollowRedirect
      .queryParam("service", "AuthTree")
      .queryParam("authIndexType", "service")
      .queryParam("authIndexValue", "AuthTree")
      .headers(FeederHelpers.forgerockHeaderMap)
      .header("x-lbg-customer-id", "${CustomerId}")
      .header("x-lbg-txn-customer-id" ,"${correlationId}")
      .body(StringBody(session => session("miChallengeReqBody").as[String]
        .replaceAll("\\{ABCD}", session("auth_Id").as[String])
        .replaceAll("\\{pos1}",session("task2").as[List[Int]].apply(0).toString)
        .replaceAll("\\{pos2}",session("task2").as[List[Int]].apply(1).toString)
        .replaceAll("\\{pos3}",session("task2").as[List[Int]].apply(2).toString)
        .replaceAll("\\{val1}",session("miphrase").as[String].split("").apply(session("task2").as[List[Int]].apply(0).toString.toInt-1))
        .replaceAll("\\{val2}",session("miphrase").as[String].split("").apply(session("task2").as[List[Int]].apply(1).toString.toInt-1))
        .replaceAll("\\{val3}",session("miphrase").as[String].split("").apply(session("task2").as[List[Int]].apply(2).toString.toInt-1)))).asJson
      //.body(StringBody(("""{ "ABCD": "${auth_Id}" }"""))).asJson
      .check(status.is(200))
      .check(jsonPath("$.tokenId").saveAs("TokenId"))
    //.check(jsonPath("$.ChallengeCode").saveAs("code"))
  )
}
object AuthCallByChannel {
  def authCallByChannel() = {
    http("Auth Call By Channel")
      .get("/v1/identityauth/authorize").disableFollowRedirect
      .queryParamMap("${AuthParams}")
      .check(status.is(302))
      .check(header("Location").saveAs("tempCode"))
  }
}
object ActualAuthCall {
  def actualAuthCall() = {
    http( "Actual Auth Call")
      .post("/v1/identityauth/authorize").disableFollowRedirect
      .queryParam("state",session=>{session("tempCode").as[String].split("goto=").apply(1).split("&").apply(0)})  //https://if-app.ew2.bld-02.ep.gcp.oncp.cloud/auth?goto=uid__rrt-8576450578696764594-b-geu2-3195-14436270-1
      .header("Content-Type","application/x-www-form-urlencoded")
      .header("Cookie", "amlbcookie=01")
      .header("x-lbg-txn-customer-id" ,"${correlationId}")
      .formParam("csrf","${TokenId}").asFormUrlEncoded
      .check(status.is(302))
      .check(header("Location").saveAs("tempCode2"))
  }
}
object AccessTokenCall {
  def accessTokenCall() = {
    http("Access Token Call")
      .post("/v1/identityauth/oauth2/access_token").disableFollowRedirect
      .header("Content-Type", "application/x-www-form-urlencoded")
      .header("iPlanetDirectoryPro",session=>{session("tempCode").as[String].split("goto=").apply(1)})
      .header("Cookie", "amlbcookie=01")
      .formParamMap("${AccessForm}")
      .formParam("code",session=>{session("tempCode2").as[String].split("[=&]").apply(1)}).asFormUrlEncoded
      .check(jsonPath("$.access_token").saveAs("AccessToken"))
      .check(jsonPath("$.token_type").saveAs("TokenType"))
  }
}