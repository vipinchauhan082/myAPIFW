package pna

import constants.OutboundConstants
import helpers.UrlHelpers
import io.gatling.core.Predef._
import io.gatling.http.Predef._

object MortgageUpdateOffsetting {
  def updateOffsetting() = {
    val directory = "fixtures/pna/" + scala.util.Properties.propOrElse("environment", "bld") +"/"
    http("Update Offsetting")
      .put(UrlHelpers.updateOffsettingOption)
      .headers(OutboundConstants.HEADERS)
      .header("Authorization","${TokenType} ${AccessToken}")
      .header("x-lbg-txn-correlation-id","${correlationId}")
      .body(RawFileBody(directory + "/request/updateOffsettingOption.json")).asJson
      .check(status.is(200))
  }
}
