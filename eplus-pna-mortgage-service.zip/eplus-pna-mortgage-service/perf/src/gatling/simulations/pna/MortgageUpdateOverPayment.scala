package pna

import constants.OutboundConstants
import helpers.UrlHelpers
import io.gatling.core.Predef._
import io.gatling.http.Predef._
import java.text.SimpleDateFormat
import java.util.Date

object MortgageUpdateOverPayment {
  def updateOverPayment() = {
    http("Update OverPayment")
      .put(UrlHelpers.updateOverPayment)
      .headers(OutboundConstants.HEADERS)
      .header("Authorization","${TokenType} ${AccessToken}")
      .header("x-lbg-txn-correlation-id","${correlationId}")
      .body(StringBody(session => session("updateOverpaymentBody").as[String].replaceAll("\\{Today}",new SimpleDateFormat("yyyy-MM-dd").format(new Date())))).asJson
      .check(status.is(200))
  }
}
