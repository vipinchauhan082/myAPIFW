package pna

import constants.OutboundConstants
import helpers.UrlHelpers
import io.gatling.core.Predef._
import io.gatling.http.Predef._

object MortgageUpdateRepayment {
  def updateRepayment() = {
    val directory = "fixtures/pna/" + scala.util.Properties.propOrElse("environment", "bld") +"/"
    http("Update Repayment Schedule")
      .put(UrlHelpers.repaymentSchedule)
      .headers(OutboundConstants.HEADERS)
      .header("Authorization","${TokenType} ${AccessToken}")
      .header("x-lbg-txn-correlation-id","${correlationId}")
      .body(RawFileBody(directory + "/request/repaymentSchedule.json")).asJson
      .check(status.is(200))
  }
}
