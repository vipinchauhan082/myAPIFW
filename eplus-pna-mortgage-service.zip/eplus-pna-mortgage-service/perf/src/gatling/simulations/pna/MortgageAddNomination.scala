package pna

import constants.OutboundConstants
import helpers.UrlHelpers
import io.gatling.core.Predef._
import io.gatling.http.Predef._

object MortgageAddNomination {
  def addNomination() = {
    http("add Nomination Sub Account")
      .put(UrlHelpers.addOverPayment)
      .headers(OutboundConstants.HEADERS)
      .header("Authorization","${TokenType} ${AccessToken}")
      .header("x-lbg-txn-correlation-id","${correlationId}")
      .body(StringBody(session => session("addNominationBody").as[String].replace("\\{subAccount}", session("MortgageDetail.SubAccountId").as[String]))).asJson
      .check(status.is(200))
  }
}
