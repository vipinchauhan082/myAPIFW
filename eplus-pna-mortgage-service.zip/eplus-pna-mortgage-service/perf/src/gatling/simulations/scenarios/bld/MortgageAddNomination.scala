package scenarios.bld

import auth._
import helpers.{FeederHelpers, ProfileHelpers, UrlHelpers}
import io.gatling.core.Predef._
import pna._

class MortgageAddNomination extends Simulation {
  val httpProtocol = UrlHelpers.gatewayHttpProtocol()

  val scn = scenario("Mortgage Service")
    .feed(FeederHelpers.mortgageFeeder)
    .feed(FeederHelpers.UniqueCorrelationId)
    .feed(FeederHelpers.addOverPaymentFeeder)
    .feed(FeederHelpers.updateOverPaymentFeeder)
    .feed(FeederHelpers.addNominationFeeder)
    .feed(FeederHelpers.staticTokenFeeder)
    .feed(FeederHelpers.pwdFeeder)
    .feed(FeederHelpers.miChallengeFeeder)
    .feed(FeederHelpers.authFeeder)
    .foreach("${MortgageDetails}","MortgageDetail") {
      exec(MortgageAddNomination.addNomination())
    }
  setUp(
    scn.inject(ProfileHelpers.closedProfile)
  ).protocols(httpProtocol)
}
