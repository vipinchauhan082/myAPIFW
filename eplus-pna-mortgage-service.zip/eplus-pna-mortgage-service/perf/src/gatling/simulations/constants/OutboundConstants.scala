package constants


object OutboundConstants {

  val HEADERS = Map(
    "Content-Type" -> "application/json",
    "x-lbg-txn-correlation-id" -> "1234567890123",
    "x-lbg-brand" -> "IF",
    //"x-lbg-channel" -> "Web",
    //"Authorization" -> "Bearer VALID_STATIC_TOKEN"
  )
  val istioHEADERS = Map(
    "Content-Type" -> "application/json",
    "x-lbg-txn-correlation-id" -> "1234567890123",
    "x-lbg-brand" -> "IF",
    "proxy" -> "proxy.mgmt-bld.oncp.dev:3128"
    //"x-lbg-channel" -> "Web",
    //"x-lbg-internal-system-id" -> "ALL"
  )
  val VAULTHEADERS = Map(
    "Content-Type" -> "application/json",
    "X-Auth-Token" -> scala.util.Properties.propOrElse("vaultToken","invalid"),
    "Cache-Control" -> "no-cache"
  )
}
