package helpers

import com.typesafe.config.ConfigFactory
import io.gatling.core.Predef._

import scala.concurrent.duration._

object ProfileHelpers {

  val conf = ConfigFactory.load()
  val injectionProfile = constantUsersPerSec(scala.util.Properties.propOrElse("users", conf.getString("usersPerSecond")).toInt) during (scala.util.Properties.propOrElse("duration", conf.getString("durationInMinutes")).toInt minutes)
  val testProfile = constantUsersPerSec(scala.util.Properties.propOrElse("users", conf.getString("usersPerSecond")).toInt) during (1 seconds)
  val closedProfile = constantConcurrentUsers(scala.util.Properties.propOrElse("users", conf.getString("usersPerSecond")).toInt) during (scala.util.Properties.propOrElse("duration", conf.getString("durationInMinutes")).toInt minutes)
  val workflowsProfile = constantConcurrentUsers(scala.util.Properties.propOrElse("wusers","2").toInt) during (scala.util.Properties.propOrElse("duration", conf.getString("durationInMinutes")).toInt minutes)
  val VaultUpdateProfile = constantUsersPerSec(scala.util.Properties.propOrElse("users", conf.getString("usersPerSecond")).toInt) during (scala.util.Properties.propOrElse("duration", conf.getString("durationInMinutes")).toInt minutes)
  val VaultCreateProfile = constantUsersPerSec(scala.util.Properties.propOrElse("wusers", "2").toInt) during (scala.util.Properties.propOrElse("duration", conf.getString("durationInMinutes")).toInt minutes)

  val responseTime = Map(
    "simpleRead" -> 1000,
    "complexRead" -> 3000,
    "simpleWrite" -> 2000,
    "mediumWrite" -> 2000,
    "complexWrite" -> 4000
  )
  val errorRate = 5
  //To be implemented formally later
  /*
  def getInjectionStep(stepType:String, stepArgs:JSONArray) : InjectionStep = {
    stepType match {
      case "rampUsers" => rampUsers(stepArgs.getInt(0)) over(stepArgs.getInt(1))
      case "heavisideUsers" => heavisideUsers(stepArgs.getInt(0)) over(stepArgs.getInt(1))
      case "atOnceUsers" => atOnceUsers(stepArgs.getInt(0))
      case "constantUsersPerSec" => constantUsersPerSec(stepArgs.getInt(0)) during(stepArgs.getInt(1))
      case "rampUsersPerSec" => rampUsersPerSec(stepArgs.getInt(0)) to(stepArgs.getInt(1)) during(stepArgs.getInt(2))
      case "nothingFor" => nothingFor(stepArgs.getInt(0))
    }
  }

  def scnList() : Seq[PopulatedScenarioBuilder] = {
    var testList = new JSONArray(rawTestList)
    var scnList = new ArraySeq[PopulatedScenarioBuilder](testList.length())
    for(i <- 0 until testList.length()) {
      //For each scenario
      var testCase = testList.getJSONObject(i)
      val injectionSteps = testCase.getJSONArray("inject")
      var injectStepList = new ArraySeq[InjectionStep](injectionSteps.length())
      for(j <- 0 until injectionSteps.length()) {
        //For each injection step
        var step = injectionSteps.getJSONObject(j)
        var stepType = step.getString("type")
        var stepArgs = step.getJSONArray("args")
        injectStepList(j) = getInjectionStep(stepType, stepArgs)
      }
      scnList(i) = scenarioNames(testCase.getString("case")).inject(injectStepList:_*)
    }
    scnList
  }*/
}
