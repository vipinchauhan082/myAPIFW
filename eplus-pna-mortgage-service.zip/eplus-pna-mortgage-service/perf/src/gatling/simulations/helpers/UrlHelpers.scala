package helpers

import constants.OutboundConstants
import io.gatling.core.Predef._
import io.gatling.http.Predef._
import io.gatling.http.protocol.HttpProtocolBuilder
import com.typesafe.config._

object UrlHelpers {
    val conf = ConfigFactory.load()

    def gatewayHttpProtocol(): HttpProtocolBuilder = {
        http
            .baseUrl(conf.getString("gatewayHost-"+scala.util.Properties.propOrElse("environment", "bld"))).disableCaching.strict302Handling
            .proxy(Proxy(conf.getString("proxyHost-"+scala.util.Properties.propOrElse("environment", "bld")), conf.getInt("proxyPort")).httpsPort(conf.getInt("proxyPort")))
            //.headers(OutboundConstants.HEADERS)
    }

    val repaymentSchedule = "/mortgages/v1.0/mortgages/${MortgageDetail.SubAccountId}/repayment-schedule"
    val addOverPayment = "/mortgages/v1.0/mortgages/${MortgageDetail.SubAccountId}/overpayment"
    val updateOverPayment = "/mortgages/v1.0/mortgages/${MortgageDetail.SubAccountId}/overpayment"
    val addNomination = "/mortgages/v1.0/mortgages/${MortgageDetail.RepayAccountId}/nomination"
    val updateOffsettingOption = "/mortgages/v1.0/mortgages/${MortgageDetail.RepayAccountId}/offsetting"

}
