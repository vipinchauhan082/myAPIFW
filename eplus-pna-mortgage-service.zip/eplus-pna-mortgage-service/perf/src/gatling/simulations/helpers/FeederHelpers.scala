package helpers

import java.net.URI
import java.util.UUID.randomUUID

import io.gatling.core.Predef._

import scala.io.Source
import scala.util.Random
object FeederHelpers {
  val directory = "fixtures/pna/" + scala.util.Properties.propOrElse("environment", "bld") +"/"

  val mortgageFeeder = jsonFile(directory +"data/mortgageDetails.json").circular
  val authFeeder = jsonFile(directory +"data/authParams.json").circular


  val staticTokenFeeder = Iterator.continually(Map("TokenType" -> "Bearer","AccessToken" -> "VALID_STATIC_TOKEN"))
  val UniqueIdFeeder = Iterator.continually(Map("x-idempotency-key" -> randomUUID().toString))
  val UniqueCorrelationId = Iterator.continually(Map("correlationId"->Random.alphanumeric.filter(_.isDigit).take(11).mkString))

  def timestampreqbody(filename: String):Iterator[Map[String, String]] = {
    val res: URI = getClass().getResource("/" + directory+ filename).toURI
    return Iterator.continually(Map("request-body" -> Source.fromFile(res).mkString.replaceAll("\\{RandomName}",Random.alphanumeric.take(10).mkString).replaceAll("\\{UUID}",randomUUID().toString)))
  }
  def timestampreqbody2(filename: String):Iterator[Map[String, String]] = {
    val res: URI = getClass().getResource("/" + directory +filename).toURI
    return Iterator.continually(Map("request-body2" -> Source.fromFile(res).mkString.replaceAll("\\{RandomName}",Random.alphanumeric.take(10).mkString).replaceAll("\\{UUID}",randomUUID().toString)))
  }
  def timestampreqbody3(filename: String):Iterator[Map[String, String]] = {
    val res: URI = getClass().getResource( "/" +directory +filename).toURI
    return Iterator.continually(Map("request-body3" -> Source.fromFile(res).mkString.replaceAll("\\{RandomName}",Random.alphanumeric.take(10).mkString).replaceAll("\\{UUID}",randomUUID().toString)))
  }
  val pwdFeeder = Iterator.continually(Map("pwdValidatorReqBody" -> Source.fromFile(getClass().getResource("/" +directory + "request/username_pwd_validator.json").toURI).mkString))
  val miChallengeFeeder = Iterator.continually(Map("miChallengeReqBody" -> Source.fromFile(getClass().getResource("/" +directory + "request/mi_validator.json").toURI).mkString))
  val accountApplicationFeeder = Iterator.continually(Map("accountApplicationReqBody" -> Source.fromFile(getClass().getResource("/" +directory + "request/accountApplication.json").toURI).mkString))
  val addOverPaymentFeeder = Iterator.continually(Map("addOverpaymentBody" -> Source.fromFile(getClass().getResource("/" +directory + "request/addOverPayment.json").toURI).mkString))
  val updateOverPaymentFeeder = Iterator.continually(Map("updateOverpaymentBody" -> Source.fromFile(getClass().getResource("/" +directory + "request/updateOverPayment.json").toURI).mkString))
  val addNominationFeeder = Iterator.continually(Map("addNominationBody" -> Source.fromFile(getClass().getResource("/" +directory + "request/addNomination.json").toURI).mkString))

  val forgerockHeaderMap = Map("Content-Type"->"application/json",
    "Accept-API-Version"->"protocol=1.0,resource=2.1",
    "x-lbg-txn-session-id"->"sdc3r34rcvxdv",
    "x-lbg-brand"->"IF",
    "x-lbg-channel"->"DIGITAL",
    "x-lbg-sub-channel"->"WEB",
    "x-lbg-tenant-id"->"lloyds",
    "x-lbg-event-type"->"PRIMARY_LOGIN",
    "x-lbg-org"->"LBG",
    "x-lbg-reset-credentials-flow"->"true");
}
