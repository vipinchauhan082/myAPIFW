# Changelog

All notable changes to this project will be documented in this file. See [standard-version](https://github.com/conventional-changelog/standard-version) for commit guidelines.

## [0.356.0](https://github.com/lbg-gcp-foundation/eplus-pna-mortgage-service/compare/v0.353.0...v0.356.0) (2021-02-10)

## [0.291.0](https://github.com/lbg-gcp-foundation/eplus-pna-mortgage-service/compare/v0.288.0...v0.291.0) (2021-02-01)


### Features

* SCW-22450 capture valuation report (#136) ([7100250](https://github.com/lbg-gcp-foundation/eplus-pna-mortgage-service/commit/71002505fd028f53ce2f53194d5b1f310b50825f))

## [0.288.0](https://github.com/lbg-gcp-foundation/eplus-pna-mortgage-service/compare/v0.287.0...v0.288.0) (2021-01-29)


### Release

* SCW-22739 mpo update at sub-accounts ([1a9c273](https://github.com/lbg-gcp-foundation/eplus-pna-mortgage-service/commit/1a9c273c082b377225a397d8c430a94fe8582d91))
* SCW-22739 mpo update at sub-accounts ([3ca5d75](https://github.com/lbg-gcp-foundation/eplus-pna-mortgage-service/commit/3ca5d756d3845b69ebcf2bb3abdc5eb521f353bc))
* SCW-22739 mpo update at sub-accounts ([811ba01](https://github.com/lbg-gcp-foundation/eplus-pna-mortgage-service/commit/811ba01fc05da686ebbf76eb440243c9524a86ac))

## [0.286.0](https://github.com/lbg-gcp-foundation/eplus-pna-mortgage-service/compare/v0.285.0...v0.286.0) (2021-01-28)


### Features

* update mpo at all sub-account level ([bd49de0](https://github.com/lbg-gcp-foundation/eplus-pna-mortgage-service/commit/bd49de01032ac6daefaddfa5e49d085861fefeeb))
* update mpo at all sub-account level ([42cd91f](https://github.com/lbg-gcp-foundation/eplus-pna-mortgage-service/commit/42cd91fec18c434ea6ce8402d39963ef13d070ce))
* update mpo at sub-account level ([4155017](https://github.com/lbg-gcp-foundation/eplus-pna-mortgage-service/commit/41550175a52882e78cf8421e29ad87a3b96cac3b))

## [0.285.0](https://github.com/lbg-gcp-foundation/eplus-pna-mortgage-service/compare/v0.284.0...v0.285.0) (2021-01-28)


### Bug Fixes

* fixed undefined errors in bdd ([cdfcc2b](https://github.com/lbg-gcp-foundation/eplus-pna-mortgage-service/commit/cdfcc2b2802329cd76a69a1e8c84497101144e94))

## [0.284.0](https://github.com/lbg-gcp-foundation/eplus-pna-mortgage-service/compare/v0.283.0...v0.284.0) (2021-01-28)


### Bug Fixes

* fixed undefined error in bdd ([080aa53](https://github.com/lbg-gcp-foundation/eplus-pna-mortgage-service/commit/080aa53e8765a487b3c75d9592a06a6610a65458))

## [0.283.0](https://github.com/lbg-gcp-foundation/eplus-pna-mortgage-service/compare/v0.282.0...v0.283.0) (2021-01-28)

## [0.282.0](https://github.com/lbg-gcp-foundation/eplus-pna-mortgage-service/compare/v0.281.0...v0.282.0) (2021-01-27)


### Bug Fixes

* fixed bdd issues ([70a1768](https://github.com/lbg-gcp-foundation/eplus-pna-mortgage-service/commit/70a176816807eaf362aae10e8d65bb58d6e440c9))

## [0.281.0](https://github.com/lbg-gcp-foundation/eplus-pna-mortgage-service/compare/v0.280.0...v0.281.0) (2021-01-27)


### Features

* added bdd for mpo update at sub account level ([8b0959c](https://github.com/lbg-gcp-foundation/eplus-pna-mortgage-service/commit/8b0959c80040ce35d06c1cd37a4474e9f1dd562d))


### Bug Fixes

* changes in bdd for update offsetting ([5647fd2](https://github.com/lbg-gcp-foundation/eplus-pna-mortgage-service/commit/5647fd290fbff215e379653d72230fb1530e55a1))

## [0.280.0](https://github.com/lbg-gcp-foundation/eplus-pna-mortgage-service/compare/v0.279.0...v0.280.0) (2021-01-27)


### Features

* bdd scenarios for update offsetting option ([842de2a](https://github.com/lbg-gcp-foundation/eplus-pna-mortgage-service/commit/842de2a60fec1c07a0d894d898e944cf6d68e91c))
* updated mpo at sub-account level ([b1bad00](https://github.com/lbg-gcp-foundation/eplus-pna-mortgage-service/commit/b1bad000da965bece23a7b97d21165ddaea67c74))
* updated mpo based on offsetting option selected ([4669df8](https://github.com/lbg-gcp-foundation/eplus-pna-mortgage-service/commit/4669df838e5f434de3141cbdd0e18af05de890bb))


### Bug Fixes

* dummy commit ([cee28e1](https://github.com/lbg-gcp-foundation/eplus-pna-mortgage-service/commit/cee28e109ce06082e18c17060ff0b7c3167cd120))
* resolved sonar issues ([536533c](https://github.com/lbg-gcp-foundation/eplus-pna-mortgage-service/commit/536533c39186f63fbd188b933f51521073a25519))
* resolved sonar issues ([d319b4e](https://github.com/lbg-gcp-foundation/eplus-pna-mortgage-service/commit/d319b4e27137fa39a1c04bde303210a230a1b5c9))
* resolved sonar issues ([8e1eba4](https://github.com/lbg-gcp-foundation/eplus-pna-mortgage-service/commit/8e1eba48a3ffaad988c33b6250078c5aeae6859c))
* resolving merge conflicts ([146b9db](https://github.com/lbg-gcp-foundation/eplus-pna-mortgage-service/commit/146b9dba07d5e90a46373a13fcd3a696fd610bed))

## [0.286.0](https://github.com/lbg-gcp-foundation/eplus-pna-mortgage-service/compare/v0.285.0...v0.286.0) (2021-01-28)


### Features

* update mpo at all sub-account level ([bd49de0](https://github.com/lbg-gcp-foundation/eplus-pna-mortgage-service/commit/bd49de01032ac6daefaddfa5e49d085861fefeeb))
* update mpo at all sub-account level ([42cd91f](https://github.com/lbg-gcp-foundation/eplus-pna-mortgage-service/commit/42cd91fec18c434ea6ce8402d39963ef13d070ce))
* update mpo at sub-account level ([4155017](https://github.com/lbg-gcp-foundation/eplus-pna-mortgage-service/commit/41550175a52882e78cf8421e29ad87a3b96cac3b))


### Release

* SCW-22455 application mortgage details info (#132) ([2898402](https://github.com/lbg-gcp-foundation/eplus-pna-mortgage-service/commit/2898402cd1eae095ccf60a302252b81f88e873b3))

## [0.285.0](https://github.com/lbg-gcp-foundation/eplus-pna-mortgage-service/compare/v0.284.0...v0.285.0) (2021-01-28)


### Bug Fixes

* fixed undefined errors in bdd ([cdfcc2b](https://github.com/lbg-gcp-foundation/eplus-pna-mortgage-service/commit/cdfcc2b2802329cd76a69a1e8c84497101144e94))

## [0.279.0](https://github.com/lbg-gcp-foundation/eplus-pna-mortgage-service/compare/v0.278.0...v0.279.0) (2021-01-27)


### Release

* SCW-22426 release commit (#130) ([56f706e](https://github.com/lbg-gcp-foundation/eplus-pna-mortgage-service/commit/56f706ec73d71e70f494b001c905a64967d86895))

### [0.182.1](https://github.com/lbg-gcp-foundation/eplus-pna-mortgage-service/compare/v0.182.0...v0.182.1) (2020-12-23)

### [0.182.1](https://github.com/lbg-gcp-foundation/eplus-pna-mortgage-service/compare/v0.182.0...v0.182.1) (2020-12-23)

## [0.179.0](https://github.com/lbg-gcp-foundation/eplus-pna-mortgage-service/compare/v0.179.0-feat-beta...v0.179.0) (2020-12-22)

## [0.179.0](https://github.com/lbg-gcp-foundation/eplus-pna-mortgage-service/compare/v0.179.0-feat-beta...v0.179.0) (2020-12-22)


### [0.182.1](https://github.com/lbg-gcp-foundation/eplus-pna-mortgage-service/compare/v0.182.0...v0.182.1) (2020-12-23)

### [0.182.1](https://github.com/lbg-gcp-foundation/eplus-pna-mortgage-service/compare/v0.182.0...v0.182.1) (2020-12-23)
## [0.179.0](https://github.com/lbg-gcp-foundation/eplus-pna-mortgage-service/compare/v0.179.0-feat-beta...v0.179.0) (2020-12-22)

## [0.179.0](https://github.com/lbg-gcp-foundation/eplus-pna-mortgage-service/compare/v0.179.0-feat-beta...v0.179.0) (2020-12-22)


### [0.67.1](https://github.com/lbg-gcp-foundation/eplus-pna-mortgage-service/compare/v0.67.0...v0.67.1) (2020-09-29)


### Features

* SCW-6478 Bdd xray change ([982670d](https://github.com/lbg-gcp-foundation/eplus-pna-mortgage-service/commit/982670dfe457c30c3ee6df778b3cfd5e0385244a))
 
