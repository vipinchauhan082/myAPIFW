# Spring Boot Scaffolding Template

This repo holds Spring Boot scaffolding template code for generating cloud native Spring Boot MciroServices leveraging Service Mesh, Containers , Kubernetes Orchestration, Automation and automated CI/CD pipeline. 

# Capabilities
Below capabilities are available:
1. Actuator
2. JWT authorization
3. OpenAPIv3 Model creation
4. Image Creation using jib
5. Compressed JSON responses
6. JUnit 5
7. Skaffold
8. Flogger + log4j2 + LoggingFilter (X-Correlation-ID)
9. OpenCensus 
10. Spring Cloud Config
11. Spring cloud GCP Support  
12. Sphinx (Generate HTML documentations from the README.md file)


## Configuration

### Actuator
Actuator endpoints of /health and /build are exposed. 

Below configuration is used to expose the endpoints.

**build.gradle**
```
plugins {
        id "com.gorylenko.gradle-git-properties" version "1.5.1"
}

dependencies{
        compile "org.springframework.boot:spring-boot-starter-actuator:${spring_boot_version}"
}

springBoot {
        buildInfo()
}

```

Expose the health and info endpoints by setting below properties. 

**application.properties**
```
management.endpoints.web.exposure.include=health,info
```

### JWT Authorization
JWT Authorisation is integrated with Spring Security. The code is present in following classes.

##### __CLASS__AppSecurity.java 
This specifies the reqyest patterns to allow and adds JWTAuthorizationFilter in filter chain.
##### JWTAuthorizationFilter.java
This class has the implementaion for decoding the token and verifying it can be decoded correcltly. Further checks can be added as per requirement.

For any secured API use below header for testing purpose:

```
Authorization:Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIxMjM0NTY3ODkwIiwibmFtZSI6IkpvaG4gRG9lIiwiaWF0IjoxNTE2MjM5MDIyfQ.XbPfbIHMI6arZ3Y922BhjWgQzWXcXNrz0ogtVhfEd2o
```


### Open API v3 Tools
Open API v3 tools allow creation of models from API specification. This template has sample yaml for Swagger Petstore API and required configuration to generate the model classes. 

##### specs/petstore.yaml
This is the sample API specification. Replace this file with the API specaification file for the API you want to generate.

##### build.gradle
```
openApiGenerate {
    generatorName = "java"
    inputSpec = "$rootDir/specs/petstore.yaml".toString() // specify the API specs
    outputDir = "$buildDir/generated".toString()
    modelPackage = "__PACKAGE_PREFIX__.request"
    systemProperties = [
            models: "Error,Pet"
    ]
}
```

Use below command to generate the API models
```
gradle openApiGenerate
```

### Jib
Jib allows docker image creation without docker deamon. Refer [jib documentation](https://github.com/GoogleContainerTools/jib/blob/master/README.md) Jib plugin (version '1.7.0') is present in build.gradle.
```
id "com.google.cloud.tools.jib" version "${jib_version}"
```

It is configured to push docker image to local docker registry. This can be finetuned using following properties. The current settings use [distroless-java11](https://github.com/GoogleContainerTools/distroless/blob/master/README.md) .
```
jib {
    // specify the name of docker image to be built
    to.image = "localhost:5000/app_name"
    // not required if using secured registry
    allowInsecureRegistries = true
    // specify the exact base image to be used.
    from.image = "gcr.io/distroless/java@sha256:f9fe0de7f8ded68f757d99e9d165b96e89e00d4cef80d204aa76bc0b8ffc4576"
}
```
#### Using jib to create an image
Use below command to create a docker image and push it to specified registry. 
```
gradle jibDockerBuild
```
Refer [jib-gradle-plugin documentation](https://github.com/GoogleContainerTools/jib/tree/master/jib-gradle-plugin) for more details.

### Compressed JSON responses
Below properties are set in the template to enbable compressed JSON responses. 
**application.properties**
```
# Enable response compression
server.compression.enabled=true
# The comma-separated list of mime types that should be compressed
server.compression.mime-types=application/json,text/html,text/xml,text/plain,text/css,text/javascript,application/javascript
# Compress the response only if the response size is at least 1KB
server.compression.min-response-size=1024
```


### JUnit 5
The template includes [JUnit 5](https://junit.org/junit5/).

### Skaffold
Skaffold is a command line tool that facilitates continuous development for Kubernetes-native applications. Refer [this link](https://skaffold.dev/docs/) for further details on features.

Execute below command from console to build code, create image using jib configuration, deploy it automatically using the manifests specified. 
```
skaffold dev
```
Other files:
##### skaffold.yaml 
This file holds the skaffold configuaration.
##### ./kubernetes/deployment.yaml
This file contains a sample deployment configuration for deploying a single service. 

The template has it integrated to deploy the application on the local kubernates cluster. 

for further configuration options refer [this documentation](https://skaffold.dev/docs/references/yaml/)


### Setting up the Client (Microservice) to use Config Server

After setting up the Config Server <TODO - Link to Config Server README>, you need to tell your  microservice application where to contact the Config Server. The ```bootstrap.yml``` file reads the application properties before any other configuration information used.
In general, the ```bootstrap.yml``` file contains the **application name** for the service, the **application profile**, and the **URI to connect to a Spring Cloud Config server**. Any other configuration information that you want to keep local
to the service (and not stored in Spring Cloud Config) can be set locally in the services in the ```application.yml``` file. Usually, the information you store in the ```application.properties``` file is configuration data that you might want to have available to a service even 
if the Spring Cloud Config service is unavailable. Both the ```bootstrap.yml``` and ```application.properties``` files are stored in a projects ```src/main/resources``` directory.

**bootstrap.yml**

        spring:
         application:
          name: mServiceA
         profiles:
          active: dev
         cloud:
          config:
           uri: http://<server>:<port>

In order to reflect properties change dynamically without restarting the client use ```@RefreshScope``` on your configuration classes. Following changes are required:

**pom.xml**
        
        <dependency>
        	<groupId>org.springframework.boot</groupId>
        	<artifactId>spring-boot-starter-actuator</artifactId>
        	<version>${spring_boot_version}</version>
        </dependency>

**build.gradle**
        
          compile "org.springframework.boot:spring-boot-starter-actuator:${spring_boot_version}"

**application.properties**
    
        management.endpoints.web.exposure.include=refresh
        management.endpoint.refresh.enable=true
       
After updating the properties, use below command to refresh:
    
        curl -X POST http://<server>:<port>/refresh -d {} -H "Content-Type: application/json"
        
### Flogger + log4j2 + LoggingFilter ##

Apache Log4j2 is the latest logging framework and provides support for SLF4J, automatically reloads your logging configuration, and supports advanced filtering options. 
In addition to these features, it also allows lazy evaluation of log statements based on lambda expressions, offers asynchronous loggers for low-latency systems, and provides
a garbage-free mode to avoid any latency caused by garbage collector operations.

Configuration can be found in ```log4j2.xml``` which is located in ```src/main/resources``` directory.

Also, ```filter/LoggingFilter.java``` supports following functionality:
* Changing the log level per request. To update log level on the fly for a specific request,
add a header named ```X-Log-Level``` and set its value to one of the log levels such as ```DEBUG```, ```INFO```, ```TRACES```, ```WARN``` and ```ERROR```.
* Adding ```correlation-id``` to ```ThreadContext``` for logging purpose. ```log4j2.xml``` is also updated to add ```x-lbg-txn-correlation-id``` in log pattern. ```x-lbg-brand``` header if present will also be logged. 
```
    <Property name="LOG_PATTERN">
            %d{ISO8601} %5p ${hostName} --- [%15.15t] [cid=%X{Correlation-ID}]%-40.40c{1.} : %m%n%ex
    </Property>
```


These features can be tested by using various combinations in below request:

``` 
         curl -X GET http://localhost:9080/__APP_NAME__/api/v1/customers  -H 'X-Log-Level: DEBUG' \
             -H 'x-lbg-txn-correlation-id: 12121001213' -H  'x-lbg-brand: LLOYDS'
```

### Opencensus ##

OpenCensus is an open-source project started by Google that can emit metrics and traces when it integrates within application code to give you a better 
understanding of what happens when the application is running.

#### How to use it? ####

1. Get Tracer

        private static final Tracer tracer = Tracing.getTracer();
        
2. Build a Scoped Span so that for a request you can identify the trace using a single traceId. Util class has a method
that helps you to build a span.

        public static SpanBuilder buildSpan(Tracer tracer, String name) {
                return tracer.spanBuilder(name)
                        .setRecordEvents(true)
                        .setSampler(Samplers.alwaysSample());
            }

3. A sample code will look like :
        
        try (Scope ss = __CLASS__Util.buildSpan(tracer, "__CLASS__Controller getAll").startScopedSpan()) {
                    customers = getAllCustomers();
                }
        
        private List<CustomerDTO> getAllCustomers(){
                tracer.getCurrentSpan().addAnnotation("Invoking getAllCustomers()");
                // do some work
            }
            
4. Register Exporter. We should be using ```StackDriver``` . Stackdriver Trace is a distributed tracing system that collects latency data
from your applications and displays it in the Google Cloud Platform Console. You can track how requests propagate through your application and receive
detailed near real-time performance insights.

 Please refer https://github.com/census-instrumentation/opencensus-java/tree/master/exporters/trace/stackdriver#quickstart for configuring the exporter.


### Pipeline
TBD

### Service-Mesh
TBD

### Spring Cloud GCP Support
Dependencies are already included for Spring Cloud GCP support. Read [this link](https://spring.io/projects/spring-cloud-gcp) to learn more. It is disabled as it needs credentials for google cloud.
Follow below steps to enable. 

**build.gradle**: Uncomment below lines.
```    
       compile "org.springframework.cloud:spring-cloud-gcp-starter:${gcp_support_version}"
       compile "org.springframework.cloud:spring-cloud-gcp-starter-pubsub:${gcp_support_version}"
       compile "org.springframework.cloud:spring-cloud-gcp-starter-storage:${gcp_support_version}"
```

**application.properties**: Update path to the GCP credentials and uncomment below line.  
```
        spring.cloud.gcp.credentials.location=file:///application_default_credentials.json
```

To find default credentials use below command (gcloud SDK required) and login using the browser:
```shell script
$ gcloud auth application-default login
Your browser has been opened to visit:

    https://accounts.google.com/o/oauth2/auth?code_challenge=*********



Credentials saved to file: [/Users/application_default_credentials.json]

```

### Sphinx (Generate HTML documentations from the README.md file)

The HTML documentations are generated using [Sphinx](http://www.sphinx-doc.org/en/master/) and the Gradle [Sphinx plugin](https://trustin.github.io/sphinx-gradle-plugin/configuration.html). To install Sphinx on the Mac use the following command `brew install sphinx-doc`.
The HTML documentations can be generated by executing the following command `./gradlew site`.
The generated HTML files can be found in the `build/site` directory.