var express = require("express");
var bodyParser = require("body-parser")
var app = express();

var port = process.env.PORT || 3000;

var urlencodedParser = bodyParser.urlencoded({ extended: false })
var jsonParser = bodyParser.json()

app.use('/assets', express.static(__dirname + '/public'));
app.set('view engine', 'ejs');

app.get('/', function(req, res){
    res.render('index');
})

app.use('/person/:id', function (req, res, next) {
    console.log('Request URL:', req.originalUrl)
    next()
  }, function (req, res, next) {
    console.log('Request Type:', req.method)
    next()
  })

app.get('/person/:id', function(req, res){
    res.render('person', {ID: req.params.id, QSTR: req.query.qury})
})

app.post('/person', urlencodedParser, function(req, res){
  res.send("Thank you vipin");
  console.log(req.body.firstname);
  console.log(req.body.lastname);
})

app.post('/personJson', jsonParser, function(req, res){
  res.send("Thank you for jsondata");
  console.log(req.body.firstname);
  console.log(req.body.lastname);
})

app.get('/api', function(req,res){
    res.json({firstname: "Vipin", lastname: "Chauhan"})
})

app.listen(port);

