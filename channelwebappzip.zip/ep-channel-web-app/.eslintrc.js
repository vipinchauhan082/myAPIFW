const confusingBrowserGlobals = require('confusing-browser-globals');

module.exports = {
  root: true,
  env: {
    browser: true,
    node: true,
    jest: true,
    es6: true,
  },
  extends: [
    'eslint:recommended',
    'prettier/@typescript-eslint',
    'prettier/react',
    'airbnb',
    'plugin:react/recommended',
    'plugin:import/recommended',
    'plugin:prettier/recommended',
    'plugin:@typescript-eslint/recommended',
    'plugin:sonarjs/recommended',
  ],
  parser: '@typescript-eslint/parser',
  parserOptions: {
    project: './tsconfig.json',
  },
  plugins: [
    'react',
    '@typescript-eslint',
    'prettier',
    'sonarjs',
    'better-styled-components',
  ],
  rules: {
    'consistent-this': ['error', 'self'],
    'linebreak-style': 'off', // Doesn't play nicely with Windows
    'no-alert': 'error',
    'no-console': ['error', { allow: ['warn', 'error'] }],
    'no-constant-condition': 'error',
    'no-param-reassign': 'error',
    'no-prototype-builtins': 'off',
    'no-useless-escape': "off", // allow slash and backslash as allowed char in regex
    'no-restricted-globals': ['error'].concat(confusingBrowserGlobals),
    'no-unused-vars': [
      'error',
      { vars: 'all', args: 'after-used', ignoreRestSiblings: true },
    ],
    '@typescript-eslint/no-unused-vars': [
      'error',
      { ignoreRestSiblings: true },
    ],
    '@typescript-eslint/ban-ts-ignore': 'off',
    'prettier/prettier': ['error', { singleQuote: true }],
    'no-underscore-dangle': ['error', { allow: ['__typename'] }],
    'prefer-arrow-callback': ['error', { allowNamedFunctions: true }],
    'jsx-a11y/label-has-associated-control': 'error',
    'jsx-a11y/label-has-for': 'off', // deprecated
    'jsx-a11y/no-autofocus': 'off',
    'react/jsx-curly-newline': 'off',
    'react/jsx-filename-extension': ['error', { extensions: ['.tsx'] }],
    'react/no-danger': 'error',
    'react/no-array-index-key': 'off',
    'react/no-danger': 'error',
    'import/prefer-default-export': 'off',
    // Strict, airbnb is using off
    'react/no-direct-mutation-state': 'error',
    'react/no-find-dom-node': 'off',
    'react/no-multi-comp': 'off',
    'react/require-default-props': 'off',
    'react/jsx-props-no-spreading': 'off',
    'react/sort-prop-types': 'error',
    'sonarjs/cognitive-complexity': 'error',
    'sonarjs/no-identical-expressions': 'error',
    'sonarjs/no-duplicate-string': 'off',
    'sonarjs/no-identical-functions': 'off',
    'sonarjs/prefer-immediate-return': 'off',
    'import/no-extraneous-dependencies': 'error', // It would be better to enable this rule.
    'import/namespace': ['error', { allowComputed: true }],
    'better-styled-components/sort-declarations-alphabetically': ['error'],
    '@typescript-eslint/explicit-function-return-type': 'off',
    '@typescript-eslint/no-explicit-any': ['off', { 'ignoreRestArgs': true, 'fixToUnknown': false }],
    'import/order': [
      'error',
      {
        groups: [
          ['index', 'sibling', 'parent', 'internal', 'external', 'builtin'],
        ],
        'newlines-between': 'never',
      },
    ],
    'import/extensions': [
      'error',
      'ignorePackages',
      {
        ts: 'never',
        tsx: 'never',
        js: 'never',
      },
    ],
    'import/no-extraneous-dependencies':[
      'error',
      {
        devDependencies: true,
      },
    ],
  },

  settings: {
    react: {
      pragma: 'React',
      version: 'detect',
    },
    'import/extensions': ['.js', '.jsx', '.ts', '.tsx'],
    'import/parsers': {
      '@typescript-eslint/parser': ['.ts', '.tsx'],
    },
    'import/resolver': {
      node: {
        extensions: ['.js', '.jsx', '.ts', '.tsx'],
      },
    },
  },
};
