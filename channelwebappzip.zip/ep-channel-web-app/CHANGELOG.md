# Changelog

All notable changes to this project will be documented in this file. See [standard-version](https://github.com/conventional-changelog/standard-version) for commit guidelines.

## [1.1792.0](https://github.com/lbg-gcp-foundation/ep-channel-web-app/compare/v1.1790.0...v1.1792.0) (2021-03-04)


### Release

* SCA-1111 int rlease (#3250) ([82b48e2](https://github.com/lbg-gcp-foundation/ep-channel-web-app/commit/82b48e2701e37693873e62c8853356975a79cb29))

## [1.1791.0](https://github.com/lbg-gcp-foundation/ep-channel-web-app/compare/v1.1790.0...v1.1791.0) (2021-03-04)

## [1.1788.0](https://github.com/lbg-gcp-foundation/ep-channel-web-app/compare/v1.1787.0...v1.1788.0) (2021-03-03)


### Release

* BB-0000 Back merge from master to develop ([1cf08af](https://github.com/lbg-gcp-foundation/ep-channel-web-app/commit/1cf08af2c0b70280ace9e85a53b074e29266c3d6))

## [1.1785.0](https://github.com/lbg-gcp-foundation/ep-channel-web-app/compare/v1.1784.4...v1.1785.0) (2021-03-03)


### Release

* BB-0000 Release commit for INT deployment ([6b317d1](https://github.com/lbg-gcp-foundation/ep-channel-web-app/commit/6b317d1fe66d9632e253aaecd02d72117ed3b3fe))

## [1.1785.0](https://github.com/lbg-gcp-foundation/ep-channel-web-app/compare/v1.1784.3...v1.1785.0) (2021-03-03)


### Release

* BB-0000 Release commit for INT deployment ([6b317d1](https://github.com/lbg-gcp-foundation/ep-channel-web-app/commit/6b317d1fe66d9632e253aaecd02d72117ed3b3fe))

## [1.1783.0](https://github.com/lbg-gcp-foundation/ep-channel-web-app/compare/v1.1780.7...v1.1783.0) (2021-03-02)


### Bug Fixes

* BB-58146 Added Client id for Beta Domains (#3198) ([a6ba298](https://github.com/lbg-gcp-foundation/ep-channel-web-app/commit/a6ba2987d83bcd7f65e79944ba6c9caf3125ee1b))


### Release

* BB-0000 Release commit for INT deployment ([6111c8e](https://github.com/lbg-gcp-foundation/ep-channel-web-app/commit/6111c8e0de6dc5817e890a31d5c4e8ab89694885))

### [1.1777.4](https://github.com/lbg-gcp-foundation/ep-channel-web-app/compare/v1.1777.3...v1.1777.4) (2021-03-02)


### Bug Fixes

* BB-0000 updated flag to run UT and code analysis ([2e04503](https://github.com/lbg-gcp-foundation/ep-channel-web-app/commit/2e0450377e1b625a6787609ffe6001b2cc2453ca))

### [1.1773.1](https://github.com/lbg-gcp-foundation/ep-channel-web-app/compare/v1.1773.0...v1.1773.1) (2021-03-01)


### Bug Fixes

* BB-0000 updated flag to run UT and code analysis ([8913eeb](https://github.com/lbg-gcp-foundation/ep-channel-web-app/commit/8913eebb3ca352880caf437bda7b58d85cf4460d))

### [1.1763.3](https://github.com/lbg-gcp-foundation/ep-channel-web-app/compare/v1.1763.2...v1.1763.3) (2021-02-26)


### Bug Fixes

* SCW-17959 API intergration for interest rates (#3158) ([5fb715e](https://github.com/lbg-gcp-foundation/ep-channel-web-app/commit/5fb715ebbf31dafc9f0d829213685633f851ed5f))

## [1.1731.0](https://github.com/lbg-gcp-foundation/ep-channel-web-app/compare/v1.1730.0...v1.1731.0) (2021-02-24)


### Bug Fixes

* BB-2394 Minor fixes (#3119) ([617d7c6](https://github.com/lbg-gcp-foundation/ep-channel-web-app/commit/617d7c634915a1432e3ce85a69720f150573870f))

## [1.1706.0](https://github.com/lbg-gcp-foundation/ep-channel-web-app/compare/v1.1705.0...v1.1706.0) (2021-02-23)


### Features

* BB-54809 IAT- Design updates (#3052) ([ffb79df](https://github.com/lbg-gcp-foundation/ep-channel-web-app/commit/ffb79dfef58392ba4145644f2ef18e7ab3125133))
* BB-55833 WIP feature flag check added on brand config (#3079) ([ba31ab5](https://github.com/lbg-gcp-foundation/ep-channel-web-app/commit/ba31ab58089cad1b4151a1bb721eeefe65912f13))
* SCA-1411 Msg when DRE responds with a refer & no authenticator … (#3081) ([64f288a](https://github.com/lbg-gcp-foundation/ep-channel-web-app/commit/64f288a3f29ca52746b58f9847f44491e1eebc9e))


### Bug Fixes

* BB-1111 Update pipeline for installing dependencies (#3080) ([e2f5704](https://github.com/lbg-gcp-foundation/ep-channel-web-app/commit/e2f5704ae739f27a5178710e595f14461e3c48b6))
* SCW-21021 journey-mortgage-overpayments sonar fixes (#3083) ([4b161b6](https://github.com/lbg-gcp-foundation/ep-channel-web-app/commit/4b161b6f011439d72941ad17e43fa08d6d4ac368))

## [1.1390.0](https://github.com/lbg-gcp-foundation/ep-channel-web-app/compare/v1.1367.0...v1.1390.0) (2021-02-16)


### Release

* BB-54876 cop settings and cards fixes (#2988) ([3a433a8](https://github.com/lbg-gcp-foundation/ep-channel-web-app/commit/3a433a8ec4094d5f6b63df7f60aef07d26ccadc4))

## [1.1367.0](https://github.com/lbg-gcp-foundation/ep-channel-web-app/compare/v1.1353.0...v1.1367.0) (2021-02-12)


### Release

* BB-53851 Standing Order fixes (#2945) ([45818d9](https://github.com/lbg-gcp-foundation/ep-channel-web-app/commit/45818d9649b1fa784a428c5fd633a413066f1de4))

## [1.1353.0](https://github.com/lbg-gcp-foundation/ep-channel-web-app/compare/v1.1352.0...v1.1353.0) (2021-02-11)


### Features

* BB-43479 Adding remove tax residencies - PD flow (#2888) ([b88037c](https://github.com/lbg-gcp-foundation/ep-channel-web-app/commit/b88037c3d7388972239aebfeea83fc207a417cf4))


### Release

* BB-0000 Release commit ([97a7c10](https://github.com/lbg-gcp-foundation/ep-channel-web-app/commit/97a7c10f38624c6aaedb8d5db80586cadfc4933e))

## [1.1347.0](https://github.com/lbg-gcp-foundation/ep-channel-web-app/compare/v1.1348.0...v1.1347.0) (2021-02-11)

## [1.1347.0](https://github.com/lbg-gcp-foundation/ep-channel-web-app/compare/v1.1346.1...v1.1347.0) (2021-02-11)


### Bug Fixes

* BB-52327 Bug fix (#2904) ([65a7174](https://github.com/lbg-gcp-foundation/ep-channel-web-app/commit/65a7174b115eba404aba0d3c8bbcfd0596ea237f))
* BB-7229-8 BDD fx (#2905) ([9e8214d](https://github.com/lbg-gcp-foundation/ep-channel-web-app/commit/9e8214dfe434f34983a997bee0e20bf515261212))


### Release

* BB-0000 Release branch fro 4.3 ([e82844d](https://github.com/lbg-gcp-foundation/ep-channel-web-app/commit/e82844d4a6549c6929f2d8c8032f2976fb238009))
* BB-54810 fix for config for payment journey (#2903) ([f4a548c](https://github.com/lbg-gcp-foundation/ep-channel-web-app/commit/f4a548cd9d8dfd8102ad4fb432910bd76a9b0f05))

## [1.1303.0](https://github.com/lbg-gcp-foundation/ep-channel-web-app/compare/v1.1304.0...v1.1303.0) (2021-02-07)

## [1.1303.0](https://github.com/lbg-gcp-foundation/ep-channel-web-app/compare/v1.1302.0...v1.1303.0) (2021-02-07)


### Features

* BB-0000 Back merge from master ([2770aa9](https://github.com/lbg-gcp-foundation/ep-channel-web-app/commit/2770aa9e74d5b3964515b4eb598bb4d16360935a))

## [1.1290.0](https://github.com/lbg-gcp-foundation/ep-channel-web-app/compare/v1.1289.0...v1.1290.0) (2021-02-04)


### Release

* BB-0002 Fixing incorrect helm format for pre  (#2811) ([d94f642](https://github.com/lbg-gcp-foundation/ep-channel-web-app/commit/d94f6423aa468af738199325ed39ddf98e2f18b4))

## [1.1285.0](https://github.com/lbg-gcp-foundation/ep-channel-web-app/compare/v0.311.0...v1.1285.0) (2021-02-03)

## [1.1290.0](https://github.com/lbg-gcp-foundation/ep-channel-web-app/compare/v1.1285.0...v1.1290.0) (2021-02-04)


### Release

* BB-0002 Fixing incorrect helm format for pre  (#2811) ([d94f642](https://github.com/lbg-gcp-foundation/ep-channel-web-app/commit/d94f6423aa468af738199325ed39ddf98e2f18b4))

## [1.1285.0](https://github.com/lbg-gcp-foundation/ep-channel-web-app/compare/v1.1284.0...v1.1285.0) (2021-02-03)


### Release

* BB-53986 Fixed mobile issue in Payment journey with account selection ([deab5c8](https://github.com/lbg-gcp-foundation/ep-channel-web-app/commit/deab5c84bad753f3500dcb86073f847ec1a393b6))

## [1.1284.0](https://github.com/lbg-gcp-foundation/ep-channel-web-app/compare/v1.1283.0...v1.1284.0) (2021-02-03)


### Release

* BB-23479 BDD issue fix in PR (#2782) ([9ca3bad](https://github.com/lbg-gcp-foundation/ep-channel-web-app/commit/9ca3bada19fa134280ef45bc8146c3b3b17f67d1))

## [1.1283.0](https://github.com/lbg-gcp-foundation/ep-channel-web-app/compare/v1.1282.0...v1.1283.0) (2021-02-03)


### Release

* BB-23479 CPR fix  (#2775) ([d2a21dd](https://github.com/lbg-gcp-foundation/ep-channel-web-app/commit/d2a21dd797f58534390ed5850dc725912032a9cf))

## [1.1282.0](https://github.com/lbg-gcp-foundation/ep-channel-web-app/compare/v1.1281.0...v1.1282.0) (2021-02-03)


### Bug Fixes

* BB-23479_1 hotfix for data issue (#2765) ([a0b163e](https://github.com/lbg-gcp-foundation/ep-channel-web-app/commit/a0b163ebb5c16c53e071cea6df09890579df3000))


### Release

* BB-0000 releasing data fix to INT ([b7c5798](https://github.com/lbg-gcp-foundation/ep-channel-web-app/commit/b7c57988f375485c3f2505ec3d92585804255aca))

## [1.1281.0](https://github.com/lbg-gcp-foundation/ep-channel-web-app/compare/v1.1280.1...v1.1281.0) (2021-02-03)


### Bug Fixes

* BB-2221 Bug fixes for title only change and address on confirmation page (#2758) ([ac7617b](https://github.com/lbg-gcp-foundation/ep-channel-web-app/commit/ac7617bf0d821931c824c1413c4ee121cd5b40d5))


### Release

* BB-0000 release to INT ([bb2766f](https://github.com/lbg-gcp-foundation/ep-channel-web-app/commit/bb2766f18680274b5ca84f68042ad147c19269d0))

### [1.1280.1](https://github.com/lbg-gcp-foundation/ep-channel-web-app/compare/v1.1280.0...v1.1280.1) (2021-02-02)


### Bug Fixes

* BB-0000 fixed duplicate items in data YML ([7f06330](https://github.com/lbg-gcp-foundation/ep-channel-web-app/commit/7f06330875234e1ac6954330396dfdb1a1b76e4a))

## [1.1280.0](https://github.com/lbg-gcp-foundation/ep-channel-web-app/compare/v1.1279.0...v1.1280.0) (2021-02-02)


### Bug Fixes

* BB-2112 | Personal details bug fixes (#2745) ([55b47e0](https://github.com/lbg-gcp-foundation/ep-channel-web-app/commit/55b47e011ca0945373e7676fdbb97757e531a1ac))


### Release

* BB-0005 release to int (#2750) ([e3d8e36](https://github.com/lbg-gcp-foundation/ep-channel-web-app/commit/e3d8e3668880168339f4d3109f09b6e0e635b700))
* SCA-1111 fix for double api call (#2744) ([9d2f2e6](https://github.com/lbg-gcp-foundation/ep-channel-web-app/commit/9d2f2e642ec82bba71cbc3655335e5537a9db9c4))

## [1.1279.0](https://github.com/lbg-gcp-foundation/ep-channel-web-app/compare/v0.291.0...v1.1279.0) (2021-02-01)


### Release

* BB-0000 removed emailnotify ([91239a0](https://github.com/lbg-gcp-foundation/ep-channel-web-app/commit/91239a0c1899f9deb3ba4d1a74be2eaeb5c42f8f))

### [1.1278.1](https://github.com/lbg-gcp-foundation/ep-channel-web-app/compare/v1.1278.0...v1.1278.1) (2021-02-01)


### Bug Fixes

* BB-0000 added a check if there are no BDD execution ([6b96ebe](https://github.com/lbg-gcp-foundation/ep-channel-web-app/commit/6b96ebe0d08a81f0cc3f98a9a635195ccdb5ea32))
* BB-0000 added a check if there are no BDD execution ([f23f0a3](https://github.com/lbg-gcp-foundation/ep-channel-web-app/commit/f23f0a372f6a19050759cf968c4a9f5444bb0d8e))

## [1.1278.0](https://github.com/lbg-gcp-foundation/ep-channel-web-app/compare/v1.1277.0...v1.1278.0) (2021-01-31)


### Release

* BB-0000 testing new sharedlob changes ([50ee7c8](https://github.com/lbg-gcp-foundation/ep-channel-web-app/commit/50ee7c8d4713d58a047fefee88974ffc34edd72e))

## [1.1277.0](https://github.com/lbg-gcp-foundation/ep-channel-web-app/compare/v1.1276.0...v1.1277.0) (2021-01-30)


### Release

* BB-0000 changed release sharedlib branch ([1f391e6](https://github.com/lbg-gcp-foundation/ep-channel-web-app/commit/1f391e6b932f808c6c8bd1166bd3252de56da181))
* BB-0000 Merge branch 'master' of github.com:lbg-gcp-foundation/ep-channel-web-app ([1ca3a66](https://github.com/lbg-gcp-foundation/ep-channel-web-app/commit/1ca3a663a8682739ab1c4b4d4c3ba12a6c8c0ce8))

## [1.1276.0](https://github.com/lbg-gcp-foundation/ep-channel-web-app/compare/v0.276.0...v1.1276.0) (2021-01-30)


### Release

* BB-0000 creation new release ([f7a3797](https://github.com/lbg-gcp-foundation/ep-channel-web-app/commit/f7a37977f8829439beb75b6e50a1d763fbb6150a))

## [1.1275.0](https://github.com/lbg-gcp-foundation/ep-channel-web-app/compare/v0.276.0...v1.1275.0) (2021-01-30)

### [1.67.1](https://github.com/lbg-gcp-foundation/ep-channel-web-app/compare/v1.1252.0...v1.67.1) (2021-01-27)


### Bug Fixes

* SCA-1111 fix for notification (#2612) ([3deb811](https://github.com/lbg-gcp-foundation/ep-channel-web-app/commit/3deb811497fb63616af50da0eac4ab7591921801))


### Release

* BB-0000 release to INT ([94cdb9a](https://github.com/lbg-gcp-foundation/ep-channel-web-app/commit/94cdb9ab45a35ec69845d6f40ed1107516df9944))
* BB-51363 corrected typo in permissions (#2627) ([6a437d1](https://github.com/lbg-gcp-foundation/ep-channel-web-app/commit/6a437d1fa08fb526f09e44082ec02b7abb743a3b))

## [1.67.0](https://github.com/lbg-gcp-foundation/ep-channel-web-app/compare/v1.1251.0...v1.67.0) (2021-01-27)


### Features

* BB-29927 Jest file update (#2623) ([1402713](https://github.com/lbg-gcp-foundation/ep-channel-web-app/commit/14027138371f4484529ac3b057e59a52b1f46ec3))


### Release

* BB-0003 release to int (#2625) ([e503127](https://github.com/lbg-gcp-foundation/ep-channel-web-app/commit/e5031273bdf9112221d0f74e7b395eb8aa69f893))
* BB-51323 Changes for customer search, product search and TIN for US Canada (#2624) ([a9b1513](https://github.com/lbg-gcp-foundation/ep-channel-web-app/commit/a9b15134b923a2c56d33bfce504581309172b843))

## [1.1244.0](https://github.com/lbg-gcp-foundation/ep-channel-web-app/compare/v1.1243.0...v1.1244.0) (2021-01-25)

### [1.66.4](https://github.com/lbg-gcp-foundation/ep-channel-web-app/compare/v1.1243.0...v1.66.4) (2021-01-25)


### Release

* BB-0000 Git push changes ([6825a08](https://github.com/lbg-gcp-foundation/ep-channel-web-app/commit/6825a08f017a128cddd06c34e3fbe2c8d6e8b331))

### [1.66.3](https://github.com/lbg-gcp-foundation/ep-channel-web-app/compare/v1.1230.0...v1.66.3) (2021-01-22)


### Release

* BB-0000 release commit - typo fix ([c8756b6](https://github.com/lbg-gcp-foundation/ep-channel-web-app/commit/c8756b6070b1091d03f94864bc6474d978c33fdb))

### [1.66.2](https://github.com/lbg-gcp-foundation/ep-channel-web-app/compare/v1.1228.0...v1.66.2) (2021-01-22)


### Bug Fixes

* BB-10780 Regression fix changes made (#2396) ([061b29e](https://github.com/lbg-gcp-foundation/ep-channel-web-app/commit/061b29eccb3b6a75cd758c4c2e3829f6b04a64d7))
* BB-50184 update col int url and e2e cust emp occ (#2568) ([26f0dd2](https://github.com/lbg-gcp-foundation/ep-channel-web-app/commit/26f0dd27eb2a66800887b8fccd6740a5d8f1ea1f))


### Release

* BB-0000 Release branch from develop ([d90a9ae](https://github.com/lbg-gcp-foundation/ep-channel-web-app/commit/d90a9ae52d3c75dc95c40bd0e115df72e29f447e))
* BB-49820 config tidy up, set correct default value for lbg-roles on BLD (#2572) ([afdc34c](https://github.com/lbg-gcp-foundation/ep-channel-web-app/commit/afdc34c0473cde3156d0bec8eee7c4ce224fd4c1))

## [1.1220.0](https://github.com/lbg-gcp-foundation/ep-channel-web-app/compare/v1.1219.0...v1.1220.0) (2021-01-21)


### Release

* BB-5013 Merge branch 'develop' ([276fe92](https://github.com/lbg-gcp-foundation/ep-channel-web-app/commit/276fe92f50790ad3c1f20e1e9049e73d879136c0))

## [1.1219.0](https://github.com/lbg-gcp-foundation/ep-channel-web-app/compare/v1.1218.0...v1.1219.0) (2021-01-21)


### Release

* BB-5013 Merge branch 'develop' ([d8613e7](https://github.com/lbg-gcp-foundation/ep-channel-web-app/commit/d8613e7b51081199f41925733b645f3702948b4a))

## [1.1216.0](https://github.com/lbg-gcp-foundation/ep-channel-web-app/compare/v1.1215.0...v1.1216.0) (2021-01-20)


### Release

* BB-5013 Merge branch 'develop' ([3fa24b8](https://github.com/lbg-gcp-foundation/ep-channel-web-app/commit/3fa24b89d17d88ed9a162861b6f01ed9266f77cb))

## [1.1215.0](https://github.com/lbg-gcp-foundation/ep-channel-web-app/compare/v1.1214.0...v1.1215.0) (2021-01-20)

### [1.66.1](https://github.com/lbg-gcp-foundation/ep-channel-web-app/compare/v1.1219.0...v1.66.1) (2021-01-21)


### Release

* BB-5013 fixed sharedlib branch ([804e468](https://github.com/lbg-gcp-foundation/ep-channel-web-app/commit/804e468e9da86fc3089c995acd0e0b935c279b53))
* BB-5013 Merge branch 'develop' ([276fe92](https://github.com/lbg-gcp-foundation/ep-channel-web-app/commit/276fe92f50790ad3c1f20e1e9049e73d879136c0))

## [1.66.0](https://github.com/lbg-gcp-foundation/ep-channel-web-app/compare/v1.1218.0...v1.66.0) (2021-01-21)


### Features

* BB-49791 ensure ffc session end on logout (#2542) ([1a1b3a4](https://github.com/lbg-gcp-foundation/ep-channel-web-app/commit/1a1b3a4ce6ae7db8774e4c5c2f3a970afcaf33e3))


### Release

* BB-5013 Merge branch 'develop' ([d8613e7](https://github.com/lbg-gcp-foundation/ep-channel-web-app/commit/d8613e7b51081199f41925733b645f3702948b4a))
* BB-5013 new release ([5aa200a](https://github.com/lbg-gcp-foundation/ep-channel-web-app/commit/5aa200aae866888be4219a6f31f15e828efa9d5a))

## [1.1216.0](https://github.com/lbg-gcp-foundation/ep-channel-web-app/compare/v1.1215.0...v1.1216.0) (2021-01-20)


### Release

* BB-5013 Merge branch 'develop' ([3fa24b8](https://github.com/lbg-gcp-foundation/ep-channel-web-app/commit/3fa24b89d17d88ed9a162861b6f01ed9266f77cb))

## [1.1215.0](https://github.com/lbg-gcp-foundation/ep-channel-web-app/compare/v1.1214.0...v1.1215.0) (2021-01-20)

### [1.65.6](https://github.com/lbg-gcp-foundation/ep-channel-web-app/compare/v1.1215.0...v1.65.6) (2021-01-20)


### Release

* BB-5013 Merge branch 'develop' ([3fa24b8](https://github.com/lbg-gcp-foundation/ep-channel-web-app/commit/3fa24b89d17d88ed9a162861b6f01ed9266f77cb))
* BB-5013 test ([a8407b5](https://github.com/lbg-gcp-foundation/ep-channel-web-app/commit/a8407b5a019f57b23d115f85d1fc36e70837d7fe))

### [1.65.5](https://github.com/lbg-gcp-foundation/ep-channel-web-app/compare/v1.1214.0...v1.65.5) (2021-01-20)


### Release

* BB-5013 added infra-tool container proxy ([e74bdcd](https://github.com/lbg-gcp-foundation/ep-channel-web-app/commit/e74bdcddf07d2d51c7a0194a70c272d49cf042d0))

### [1.65.4](https://github.com/lbg-gcp-foundation/ep-channel-web-app/compare/v1.1194.0...v1.65.4) (2021-01-19)


### Release

* BB-46352 add customer id flag to oauth calls on INT (#2509) ([767fb51](https://github.com/lbg-gcp-foundation/ep-channel-web-app/commit/767fb51ff364ccee2056343109052eb3e0f5e075))

### [1.65.3](https://github.com/lbg-gcp-foundation/ep-channel-web-app/compare/v1.1170.0...v1.65.3) (2021-01-18)


### Release

* BB-3288 Colleague Update (#2473) ([601c38b](https://github.com/lbg-gcp-foundation/ep-channel-web-app/commit/601c38b3a1e7dd24ca7145c5f19906492c5f0a71))
* BB-48605 de-parallelised stages in master build run because of resource issues (#2457) ([3aa5a9a](https://github.com/lbg-gcp-foundation/ep-channel-web-app/commit/3aa5a9a8bbac0209c04a942992aa393274444a64))
* BB-48605 pass querystring params across when redirecting from base route (#2452) ([693d59d](https://github.com/lbg-gcp-foundation/ep-channel-web-app/commit/693d59de933b3961c5da21a42a2cf12e6c585be8))

### [1.65.2](https://github.com/lbg-gcp-foundation/ep-channel-web-app/compare/v1.1168.0...v1.65.2) (2021-01-13)

### [1.65.1](https://github.com/lbg-gcp-foundation/ep-channel-web-app/compare/v1.1160.0...v1.65.1) (2021-01-12)


### Release

* BB-46358 Merge branch 'develop' ([af5e234](https://github.com/lbg-gcp-foundation/ep-channel-web-app/commit/af5e23401e4bdd4b698189535f23db15c4064be4))

## [1.1158.0](https://github.com/lbg-gcp-foundation/ep-channel-web-app/compare/v1.1159.0...v1.1158.0) (2021-01-11)

## [1.65.0](https://github.com/lbg-gcp-foundation/ep-channel-web-app/compare/v1.1156.0...v1.65.0) (2021-01-11)


### Features

* BB-1001 Colleague Fix (#2409) ([b2c2e7b](https://github.com/lbg-gcp-foundation/ep-channel-web-app/commit/b2c2e7b4d736b42be899d1a9e6110b3d6fd51a47))


### Release

* BB-46358 creating new release ([4afe7a2](https://github.com/lbg-gcp-foundation/ep-channel-web-app/commit/4afe7a2aa0f8f3720bba04fd370440377c2424cf))
* BB-46358 creating new release for sharedlib fix ([72b01bc](https://github.com/lbg-gcp-foundation/ep-channel-web-app/commit/72b01bcbe7a732eb15d33ab78b7f70aa7d72a60c))
* BB-46358 creating new release with proper image tag ([64c1fc1](https://github.com/lbg-gcp-foundation/ep-channel-web-app/commit/64c1fc190b54e819c3c2af7cefb04c2432b2f1fc))
* BB-46358 Merge branch 'develop' of github.com:lbg-gcp-foundation/ep-channel-web-app into develop ([f7305ec](https://github.com/lbg-gcp-foundation/ep-channel-web-app/commit/f7305ecfd5c536cc1352470dc97ecb929deb4871))

## [1.1157.0](https://github.com/lbg-gcp-foundation/ep-channel-web-app/compare/v1.1154.0...v1.1157.0) (2021-01-11)


### Release

* BB-46358 creating release ([e9f4537](https://github.com/lbg-gcp-foundation/ep-channel-web-app/commit/e9f453792755f3694428035aa6abf09e258b3d8a))

### [1.64.1](https://github.com/lbg-gcp-foundation/ep-channel-web-app/compare/v1.1154.0...v1.64.1) (2021-01-11)


### Release

* BB-46358 creating new release for sharedlib fix ([e9b4cc9](https://github.com/lbg-gcp-foundation/ep-channel-web-app/commit/e9b4cc9bd771e532794f5e4d2a4663b936d102fd))

## [1.64.0](https://github.com/lbg-gcp-foundation/ep-channel-web-app/compare/v1.1153.0...v1.64.0) (2021-01-11)


### Features

* BB-1001 Wrap Session (#2404) ([1ab6131](https://github.com/lbg-gcp-foundation/ep-channel-web-app/commit/1ab61317b92d9a7ec2853113f84fedb159593a23))


### Bug Fixes

* BB-46733 Removing unwanted links from colleague finder (#2374) ([87ad942](https://github.com/lbg-gcp-foundation/ep-channel-web-app/commit/87ad9427e9f50a3ee3c32c9e7afea83d79cac493))


### Release

* BB-46358 fixed sharedlib ([007bb32](https://github.com/lbg-gcp-foundation/ep-channel-web-app/commit/007bb32e65d69a1ff4ccf97abcdff66a30f9758e))

## [1.63.0](https://github.com/lbg-gcp-foundation/ep-channel-web-app/compare/v1.1153.0...v1.63.0) (2021-01-11)


### Features

* BB-1001 Wrap Session (#2404) ([1ab6131](https://github.com/lbg-gcp-foundation/ep-channel-web-app/commit/1ab61317b92d9a7ec2853113f84fedb159593a23))
* BB-46358 fixed sharedlib ([007bb32](https://github.com/lbg-gcp-foundation/ep-channel-web-app/commit/007bb32e65d69a1ff4ccf97abcdff66a30f9758e))


### Bug Fixes

* BB-46733 Removing unwanted links from colleague finder (#2374) ([87ad942](https://github.com/lbg-gcp-foundation/ep-channel-web-app/commit/87ad9427e9f50a3ee3c32c9e7afea83d79cac493))

### [1.62.1](https://github.com/lbg-gcp-foundation/ep-channel-web-app/compare/v1.875.0...v1.62.1) (2020-11-03)


### Bug Fixes

* BB-0000 added resolution to sauce tests ([07ff38f](https://github.com/lbg-gcp-foundation/ep-channel-web-app/commit/07ff38f222d367446e9eaa7896f002bbb54beb84))

## [1.62.0](https://github.com/lbg-gcp-foundation/ep-channel-web-app/compare/v1.693.1...v1.62.0) (2020-10-05)


### Features

* BB-8919 Edit nationality - CPR (#1533) ([4071192](https://github.com/lbg-gcp-foundation/ep-channel-web-app/commit/4071192a6fc400673d0b8ee3c0e9e2aec7cef2d7))

## [1.61.0](https://github.com/lbg-gcp-foundation/ep-channel-web-app/compare/v1.693.1...v1.61.0) (2020-10-05)


### Features

* BB-8919 Edit nationality - CPR (#1533) ([4071192](https://github.com/lbg-gcp-foundation/ep-channel-web-app/commit/4071192a6fc400673d0b8ee3c0e9e2aec7cef2d7))

### [1.60.2](https://github.com/lbg-gcp-foundation/ep-channel-web-app/compare/v1.60.1...v1.60.2) (2020-10-05)

### [1.60.1](https://github.com/lbg-gcp-foundation/ep-channel-web-app/compare/v1.692.0...v1.60.1) (2020-10-05)


### Bug Fixes

* BB-1048 Added account overview route for colleague redirect (#1547) ([126a3ec](https://github.com/lbg-gcp-foundation/ep-channel-web-app/commit/126a3ec7bd6b131213ca75ed81399419e346d589))

## [1.60.0](https://github.com/lbg-gcp-foundation/ep-channel-web-app/compare/v1.680.0...v1.60.0) (2020-10-01)


### Features

* BB-0000 codeql analysis ([1dc95f3](https://github.com/lbg-gcp-foundation/ep-channel-web-app/commit/1dc95f36b526eec0ea37ea93a7c4084a442f1ccf))

## [1.59.0](https://github.com/lbg-gcp-foundation/ep-channel-web-app/compare/v1.680.0...v1.59.0) (2020-10-01)


### Features

* BB-0000 codeql analysis ([1dc95f3](https://github.com/lbg-gcp-foundation/ep-channel-web-app/commit/1dc95f36b526eec0ea37ea93a7c4084a442f1ccf))

## [1.58.0](https://github.com/lbg-gcp-foundation/ep-channel-web-app/compare/v1.676.0...v1.58.0) (2020-10-01)


### Features

* BB-11144 added indicator bar for collleague (#1501) ([8594fe3](https://github.com/lbg-gcp-foundation/ep-channel-web-app/commit/8594fe3b35fb917d9ab37fe25d760cb6b9de3fc9))

## [1.57.0](https://github.com/lbg-gcp-foundation/ep-channel-web-app/compare/v1.676.0...v1.57.0) (2020-10-01)


### Features

* BB-11144 added indicator bar for collleague (#1501) ([8594fe3](https://github.com/lbg-gcp-foundation/ep-channel-web-app/commit/8594fe3b35fb917d9ab37fe25d760cb6b9de3fc9))

## [1.56.0](https://github.com/lbg-gcp-foundation/ep-channel-web-app/compare/v1.672.0...v1.56.0) (2020-09-30)


### Features

* SCA-2271 (#1511) ([8d8380f](https://github.com/lbg-gcp-foundation/ep-channel-web-app/commit/8d8380f7d56d91eac66a3565a604b3f11ca13eb8))

## [1.55.0](https://github.com/lbg-gcp-foundation/ep-channel-web-app/compare/v1.672.0...v1.55.0) (2020-09-30)


### Features

* SCA-2271 (#1511) ([8d8380f](https://github.com/lbg-gcp-foundation/ep-channel-web-app/commit/8d8380f7d56d91eac66a3565a604b3f11ca13eb8))

## [1.54.0](https://github.com/lbg-gcp-foundation/ep-channel-web-app/compare/v1.670.1...v1.54.0) (2020-09-30)


### Features

* BB-759 Modulus check API integration (#1496) ([17cfa17](https://github.com/lbg-gcp-foundation/ep-channel-web-app/commit/17cfa179300b5b66eab2aae58ea6b2e0c23195c4))

## [1.53.0](https://github.com/lbg-gcp-foundation/ep-channel-web-app/compare/v1.670.1...v1.53.0) (2020-09-30)


### Features

* BB-759 Modulus check API integration (#1496) ([17cfa17](https://github.com/lbg-gcp-foundation/ep-channel-web-app/commit/17cfa179300b5b66eab2aae58ea6b2e0c23195c4))

## [1.52.0](https://github.com/lbg-gcp-foundation/ep-channel-web-app/compare/v1.667.0...v1.52.0) (2020-09-29)


### Features

* BB-7154 International Payments (#1483) ([b0bd636](https://github.com/lbg-gcp-foundation/ep-channel-web-app/commit/b0bd636adfcd73f0457299bc9735a1a6eaa773b5))


### Bug Fixes

* BB-6243 BDD changes for perf script (#1439) ([9149ed4](https://github.com/lbg-gcp-foundation/ep-channel-web-app/commit/9149ed4d6fb6a8a422dcf2ef5a41ee9f2feb46c8))

## [1.51.0](https://github.com/lbg-gcp-foundation/ep-channel-web-app/compare/v1.667.0...v1.51.0) (2020-09-29)


### Features

* BB-7154 International Payments (#1483) ([b0bd636](https://github.com/lbg-gcp-foundation/ep-channel-web-app/commit/b0bd636adfcd73f0457299bc9735a1a6eaa773b5))


### Bug Fixes

* BB-6243 BDD changes for perf script (#1439) ([9149ed4](https://github.com/lbg-gcp-foundation/ep-channel-web-app/commit/9149ed4d6fb6a8a422dcf2ef5a41ee9f2feb46c8))

## [1.50.0](https://github.com/lbg-gcp-foundation/ep-channel-web-app/compare/v1.643.0...v1.50.0) (2020-09-22)


### Features

* BB-10501 | Functionality for CPR check after login (#1438) ([20fe978](https://github.com/lbg-gcp-foundation/ep-channel-web-app/commit/20fe97868a897dc803389735b784f48d422d38d2))

## [1.49.0](https://github.com/lbg-gcp-foundation/ep-channel-web-app/compare/v1.643.0...v1.49.0) (2020-09-22)


### Features

* BB-10501 | Functionality for CPR check after login (#1438) ([20fe978](https://github.com/lbg-gcp-foundation/ep-channel-web-app/commit/20fe97868a897dc803389735b784f48d422d38d2))

## [1.48.0](https://github.com/lbg-gcp-foundation/ep-channel-web-app/compare/v1.618.1...v1.48.0) (2020-09-17)


### Features

* BB-7987 | Atomic Structure Table Varients  (#1368) ([492aef5](https://github.com/lbg-gcp-foundation/ep-channel-web-app/commit/492aef5e519f54a5ecbdff79ed44ff219dd62572))


### Bug Fixes

* BB-8201 Payment fixes (#1410) ([e4d934d](https://github.com/lbg-gcp-foundation/ep-channel-web-app/commit/e4d934df8d5f07d02234deb1271b6994e12b979a))

## [1.47.0](https://github.com/lbg-gcp-foundation/ep-channel-web-app/compare/v1.618.1...v1.47.0) (2020-09-17)


### Features

* BB-7987 | Atomic Structure Table Varients  (#1368) ([492aef5](https://github.com/lbg-gcp-foundation/ep-channel-web-app/commit/492aef5e519f54a5ecbdff79ed44ff219dd62572))


### Bug Fixes

* BB-8201 Payment fixes (#1410) ([e4d934d](https://github.com/lbg-gcp-foundation/ep-channel-web-app/commit/e4d934df8d5f07d02234deb1271b6994e12b979a))

### [1.46.1](https://github.com/lbg-gcp-foundation/ep-channel-web-app/compare/v1.613.0...v1.46.1) (2020-09-16)


### Bug Fixes

* BB-6098 Changing sequence for account type (#1406) ([04177af](https://github.com/lbg-gcp-foundation/ep-channel-web-app/commit/04177af18961922deb500004e232d6317a1aa9ab))

## [1.46.0](https://github.com/lbg-gcp-foundation/ep-channel-web-app/compare/v1.611.1...v1.46.0) (2020-09-15)


### Features

* SCA-4418 Added BDD for change credentials (#1398) ([178c823](https://github.com/lbg-gcp-foundation/ep-channel-web-app/commit/178c8231e1b286aec910391dfa92d18987bac03a))

### [1.45.1](https://github.com/lbg-gcp-foundation/ep-channel-web-app/compare/v1.611.0...v1.45.1) (2020-09-15)


### Bug Fixes

* BB-384 transaction api filter (#1400) ([bf06473](https://github.com/lbg-gcp-foundation/ep-channel-web-app/commit/bf06473351a043bbf15db19e26a02e5c00d7766e))

## [1.45.0](https://github.com/lbg-gcp-foundation/ep-channel-web-app/compare/v1.607.0...v1.45.0) (2020-09-15)


### Features

* BB-7621 updated feature flag and added firebase feature flag (#1393) ([246f16e](https://github.com/lbg-gcp-foundation/ep-channel-web-app/commit/246f16e8e80e260a2e0afa5ca01c217b855ac395))
* SCA-2610 Tele Auth  | Integration with CWA screens. (#1380) ([747dad3](https://github.com/lbg-gcp-foundation/ep-channel-web-app/commit/747dad3b7266d17c7fc348070923f5c0c1d9e8cb))

## [1.44.0](https://github.com/lbg-gcp-foundation/ep-channel-web-app/compare/v1.606.3...v1.44.0) (2020-09-15)


### Features

* BB-584 Delete Payment Payee - Colleague (#1383) ([bc5e5c9](https://github.com/lbg-gcp-foundation/ep-channel-web-app/commit/bc5e5c9d213c9679d6dabfe7c0e5deee4a0754c1))
* BB-7293 Login customer (#1390) ([3b0f5ab](https://github.com/lbg-gcp-foundation/ep-channel-web-app/commit/3b0f5ab0e6def8519051b83a47ce52a06b863ff4))

### [1.43.3](https://github.com/lbg-gcp-foundation/ep-channel-web-app/compare/v1.603.2...v1.43.3) (2020-09-15)


### Bug Fixes

* BB-10481 updated keyname as provided by json api (#1388) ([86e9e2e](https://github.com/lbg-gcp-foundation/ep-channel-web-app/commit/86e9e2edd9df4693d207ce346b84d810a56f937d))
* BB-7405 Updated copy and error validations for national insurance (#1392) ([f09eed1](https://github.com/lbg-gcp-foundation/ep-channel-web-app/commit/f09eed1b0b3d7c984b6bf247e13b46fa3958b582))

### [1.43.2](https://github.com/lbg-gcp-foundation/ep-channel-web-app/compare/v1.602.1...v1.43.2) (2020-09-15)


### Bug Fixes

* SCA-4019 updated Auth BDD after regression test on BLD env (#1382) ([c0da988](https://github.com/lbg-gcp-foundation/ep-channel-web-app/commit/c0da98831b32ccb77dd3707835e20c8d05704f16))

### [1.43.1](https://github.com/lbg-gcp-foundation/ep-channel-web-app/compare/v1.601.0...v1.43.1) (2020-09-15)


### Bug Fixes

* BB-7225 Unit test fix ([8faffdb](https://github.com/lbg-gcp-foundation/ep-channel-web-app/commit/8faffdb1cd3ebe960df579bec6f7046cd0d5f87a))

## [1.43.0](https://github.com/lbg-gcp-foundation/ep-channel-web-app/compare/v1.596.0...v1.43.0) (2020-09-13)


### Features

* BB-7981 Update (#1361) ([3671e2b](https://github.com/lbg-gcp-foundation/ep-channel-web-app/commit/3671e2badc0eb96fca6ded371677b258dc5bce01))

## [1.42.0](https://github.com/lbg-gcp-foundation/ep-channel-web-app/compare/v1.588.0...v1.42.0) (2020-09-11)


### Features

* BB-8768 | Feature flag implementation (#1358) ([45a897a](https://github.com/lbg-gcp-foundation/ep-channel-web-app/commit/45a897a2274156a870ea24e820a788fb1561ae19))

## [1.41.0](https://github.com/lbg-gcp-foundation/ep-channel-web-app/compare/v1.586.1...v1.41.0) (2020-09-11)


### Features

* BB-7981 update  (#1359) ([78cb9f6](https://github.com/lbg-gcp-foundation/ep-channel-web-app/commit/78cb9f6ecfef18e879af1059be49ce4187f6fda1))

## [1.40.0](https://github.com/lbg-gcp-foundation/ep-channel-web-app/compare/v1.586.0...v1.40.0) (2020-09-11)


### Features

* BB-7981 Update (#1357) ([42b0791](https://github.com/lbg-gcp-foundation/ep-channel-web-app/commit/42b0791bd1ae3c4b4d430c1b6832b4ccbbf72b8e))


### Bug Fixes

* BB-7431 | Hi-Fi design updates for customer communication preferences (#1350) ([157c153](https://github.com/lbg-gcp-foundation/ep-channel-web-app/commit/157c1534bebce7066e92ef250e85cf59b5ca5f54))

## [1.39.0](https://github.com/lbg-gcp-foundation/ep-channel-web-app/compare/v1.584.2...v1.39.0) (2020-09-11)


### Features

* BB-4957 Update to account APIs (#1277) ([98b6958](https://github.com/lbg-gcp-foundation/ep-channel-web-app/commit/98b69585360ec7888901d827a004b16a6f44fd1a))

## [1.38.0](https://github.com/lbg-gcp-foundation/ep-channel-web-app/compare/v1.583.1...v1.38.0) (2020-09-10)


### Features

* BB-9328 Readme update for payment journey (#1338) ([65ac303](https://github.com/lbg-gcp-foundation/ep-channel-web-app/commit/65ac3038245fbd2e077c84be6303b3f674a341bf))


### Bug Fixes

* BB-2094 Styling fixes payment history (#1340) ([a3c90a8](https://github.com/lbg-gcp-foundation/ep-channel-web-app/commit/a3c90a89ecea6a27ca4beceead0ef8cf0986d5c8))
* BB-8206 Account tile design updated to match design (#1316) ([cea5496](https://github.com/lbg-gcp-foundation/ep-channel-web-app/commit/cea54962e577ff8a3c30eb995096b255513953f2))
* BB-8811 Bug fixes for JAR details page. (#1335) ([123b641](https://github.com/lbg-gcp-foundation/ep-channel-web-app/commit/123b641539d322328a0fcd0f467b3e2f94ea3566))
* SCA-4252 updated BDD for final VDs (#1328) ([6076b02](https://github.com/lbg-gcp-foundation/ep-channel-web-app/commit/6076b021f8d670b72be26d7cc88c8f715ccb129a))

### [1.37.1](https://github.com/lbg-gcp-foundation/ep-channel-web-app/compare/v1.583.0...v1.37.1) (2020-09-09)


### Bug Fixes

* BB-1048 Updating customer search endpoint (#1327) ([378e69c](https://github.com/lbg-gcp-foundation/ep-channel-web-app/commit/378e69c37d6d84a32b53902ce9b8d16c047acff2))

## [1.37.0](https://github.com/lbg-gcp-foundation/ep-channel-web-app/compare/v1.580.0...v1.37.0) (2020-09-09)


### Features

* BB-6126 Atomic Structure | Loader & Action Button (#1308) ([969946f](https://github.com/lbg-gcp-foundation/ep-channel-web-app/commit/969946f2f9029005fbdcbc8471f38ae8ec8502ad))

## [1.36.0](https://github.com/lbg-gcp-foundation/ep-channel-web-app/compare/v1.577.0...v1.36.0) (2020-09-08)


### Features

* BB-7949 Edit phone numbers hifi design (#1323) ([496f558](https://github.com/lbg-gcp-foundation/ep-channel-web-app/commit/496f558b8934acea8222d8c34d7c65d21d7a462b))

## [1.35.0](https://github.com/lbg-gcp-foundation/ep-channel-web-app/compare/v1.572.3...v1.35.0) (2020-09-08)


### Features

* BB-1620 Personal details added to colleague app (#1321) ([9669199](https://github.com/lbg-gcp-foundation/ep-channel-web-app/commit/96691991412e118e9b7c3374e5cb3fc0e02c8ca0))

### [1.34.1](https://github.com/lbg-gcp-foundation/ep-channel-web-app/compare/v1.571.2...v1.34.1) (2020-09-07)


### Bug Fixes

* BB-2750 CoP fixes (#1309) ([4b1a800](https://github.com/lbg-gcp-foundation/ep-channel-web-app/commit/4b1a8006136aa3d347c69daa8d4ac7df5321b64e))

## [1.34.0](https://github.com/lbg-gcp-foundation/ep-channel-web-app/compare/v1.570.1...v1.34.0) (2020-09-07)


### Features

* BB-2751 | view payment payee (#1311) ([ab9d163](https://github.com/lbg-gcp-foundation/ep-channel-web-app/commit/ab9d163d454605607286881831b9db5ca3c0d8a6))


### Bug Fixes

* BB-5885 BDD data changes (#1312) ([b5dd1ae](https://github.com/lbg-gcp-foundation/ep-channel-web-app/commit/b5dd1ae4e23c66ffd4850b67a00b2db98e2b6fcb))

### [1.33.1](https://github.com/lbg-gcp-foundation/ep-channel-web-app/compare/v1.570.0...v1.33.1) (2020-09-07)


### Bug Fixes

* BB-4807 update to content security policy for firebase (#1315) ([5143b2f](https://github.com/lbg-gcp-foundation/ep-channel-web-app/commit/5143b2fd5af0ccfc9bf54934529000db5c7ce509))

## [1.33.0](https://github.com/lbg-gcp-foundation/ep-channel-web-app/compare/v1.559.0...v1.33.0) (2020-09-02)


### Features

* BB-6123 Bifurcation of input box molecule to atoms (#1262) ([1a7823d](https://github.com/lbg-gcp-foundation/ep-channel-web-app/commit/1a7823df51c934e7566ef02f417d38b248941783))

## [1.32.0](https://github.com/lbg-gcp-foundation/ep-channel-web-app/compare/v1.541.0...v1.32.0) (2020-08-24)


### Features

* BB-6134 Tiles molecule extension with teaser and subheader (#1241) ([73bfeff](https://github.com/lbg-gcp-foundation/ep-channel-web-app/commit/73bfeff3888016da696c3acf093479f87ad2614a))

## [1.31.0](https://github.com/lbg-gcp-foundation/ep-channel-web-app/compare/v1.539.3...v1.31.0) (2020-08-24)


### Features

* BB-3476 Changed the flag logic for JAR name change feature (#1232) ([0dc74d7](https://github.com/lbg-gcp-foundation/ep-channel-web-app/commit/0dc74d745c560202c0d6dd5a351e04e5704d8899))
* BB-6132 Atomic Structure | Modal (#1227) ([dd3c302](https://github.com/lbg-gcp-foundation/ep-channel-web-app/commit/dd3c3026f7977ae408564c6ae8997473c46b5a53))

### [1.30.3](https://github.com/lbg-gcp-foundation/ep-channel-web-app/compare/v1.532.2...v1.30.3) (2020-08-21)

### [1.30.2](https://github.com/lbg-gcp-foundation/ep-channel-web-app/compare/v1.532.1...v1.30.2) (2020-08-21)


### Bug Fixes

* BB-6622 Updated local Docker setup, to be in sync with latest micro FE changes. (#1221) ([b5dd5ac](https://github.com/lbg-gcp-foundation/ep-channel-web-app/commit/b5dd5ac6f93739ec0c0ded513d714b779b0ce3f7))

### [1.30.1](https://github.com/lbg-gcp-foundation/ep-channel-web-app/compare/v1.532.0...v1.30.1) (2020-08-21)


### Bug Fixes

* BB-5530 updated the test data and locator (#1222) ([1fbbe2e](https://github.com/lbg-gcp-foundation/ep-channel-web-app/commit/1fbbe2e20e23b0c1a4cb82db21678ae1b0a799f6))

## [1.30.0](https://github.com/lbg-gcp-foundation/ep-channel-web-app/compare/v1.528.0...v1.30.0) (2020-08-20)


### Features

* BB-5432-1 Local Theme Fix ViewAccOverview (#1220) ([a5e5f3a](https://github.com/lbg-gcp-foundation/ep-channel-web-app/commit/a5e5f3a9a6e942a2e5831b04228bfa83073e64a8))

## [1.29.0](https://github.com/lbg-gcp-foundation/ep-channel-web-app/compare/v1.527.1...v1.29.0) (2020-08-20)


### Features

* BB-3254 Update to ordering of savings accounts (#1214) ([cbbe3fa](https://github.com/lbg-gcp-foundation/ep-channel-web-app/commit/cbbe3fa03a416ecc38eb472f00cd0c62daf985be))

### [1.28.1](https://github.com/lbg-gcp-foundation/ep-channel-web-app/compare/v1.527.0...v1.28.1) (2020-08-20)


### Bug Fixes

* BB-5400 Making create customer atomic structure (#1215) ([d6091dc](https://github.com/lbg-gcp-foundation/ep-channel-web-app/commit/d6091dce17198911c4506e2f3c11c115d9c22aae))

## [1.28.0](https://github.com/lbg-gcp-foundation/ep-channel-web-app/compare/v1.520.0...v1.28.0) (2020-08-19)


### Features

* SCA-2841 Auth | Tele Auth | CWA | Display 1st authenticator validation screen as returned in the list of authenticator as 1st screen when validation is initiated by colleague (#1204) ([59e1e5d](https://github.com/lbg-gcp-foundation/ep-channel-web-app/commit/59e1e5d5e6e0729ae495bbe95f3e89dc107d8c7e))

## [1.27.0](https://github.com/lbg-gcp-foundation/ep-channel-web-app/compare/v1.518.0...v1.27.0) (2020-08-19)


### Features

* BB-3588 Set Up Standing Order- Customer (#1201) ([eb039ba](https://github.com/lbg-gcp-foundation/ep-channel-web-app/commit/eb039ba8aeebabd5833be183108cdf8efe109f3e))

## [1.26.0](https://github.com/lbg-gcp-foundation/ep-channel-web-app/compare/v1.513.5...v1.26.0) (2020-08-18)


### Features

* BB-3845 View a Payment Payee  (#1163) ([0d99aa8](https://github.com/lbg-gcp-foundation/ep-channel-web-app/commit/0d99aa8c3546ba02d8acdd27b2d2dcc87f404df0))

### [1.25.3](https://github.com/lbg-gcp-foundation/ep-channel-web-app/compare/v1.478.4...v1.25.3) (2020-08-11)


### Bug Fixes

* BB-5217 URLs updated to readme file (#1165) ([edb4f4b](https://github.com/lbg-gcp-foundation/ep-channel-web-app/commit/edb4f4b856ab53fe9befd7ab2d831ba435df3051))

### [1.25.2](https://github.com/lbg-gcp-foundation/ep-channel-web-app/compare/v1.477.3...v1.25.2) (2020-08-11)


### Bug Fixes

* BB-2404 Payments journey test coverage improved (#1166) ([4ca6789](https://github.com/lbg-gcp-foundation/ep-channel-web-app/commit/4ca67893d09757c1e864ade0265d783557c0a968))

### [1.25.1](https://github.com/lbg-gcp-foundation/ep-channel-web-app/compare/v1.25.0...v1.25.1) (2020-08-05)


### Bug Fixes

* BB-4882 To update test data for e2e test data and selectors (#1140) ([3c67a1c](https://github.com/lbg-gcp-foundation/ep-channel-web-app/commit/3c67a1c236f6f0fe3fe575eff02868b1435158b6))

## [1.25.0](https://github.com/lbg-gcp-foundation/ep-channel-web-app/compare/v1.24.6...v1.25.0) (2020-08-05)


### Features

* SCA-1978 Credential reset journey (#1112) ([a2d6c27](https://github.com/lbg-gcp-foundation/ep-channel-web-app/commit/a2d6c278270ec76eec2b328de9e684f982e8878a))

### [1.24.7](https://github.com/lbg-gcp-foundation/ep-channel-web-app/compare/v1.24.6...v1.24.7) (2020-08-05)

### [1.24.6](https://github.com/lbg-gcp-foundation/ep-channel-web-app/compare/v1.24.4...v1.24.6) (2020-08-05)


### Bug Fixes

* BB-2698 Decouple helm deploy (#1138) ([e98c3a7](https://github.com/lbg-gcp-foundation/ep-channel-web-app/commit/e98c3a722b5d2db2a2f94080f8ffe3e72380d241))
* BB-4786 updated istio virtual service api host (#1139) ([772a8d3](https://github.com/lbg-gcp-foundation/ep-channel-web-app/commit/772a8d3411d34fb98e63af79d474ddc5619a0fe8))

### [1.24.5](https://github.com/lbg-gcp-foundation/ep-channel-web-app/compare/v1.24.4...v1.24.5) (2020-08-04)

### [1.24.4](https://github.com/lbg-gcp-foundation/ep-channel-web-app/compare/v1.458.2...v1.24.4) (2020-08-04)


### Bug Fixes

* BB-4616 Merge from develop to master (#1116) ([8e5fe9c](https://github.com/lbg-gcp-foundation/ep-channel-web-app/commit/8e5fe9c4256ad175457a5b8196adcfe47cf6d4f7))

### [1.24.3](https://github.com/lbg-gcp-foundation/ep-channel-web-app/compare/v1.439.1...v1.24.3) (2020-07-31)

### [1.24.2](https://github.com/lbg-gcp-foundation/ep-channel-web-app/compare/v1.409.0...v1.24.2) (2020-07-16)


### Bug Fixes

* BB-1408 Removed current date test from transaction unit testing (#969) ([fd0091f](https://github.com/lbg-gcp-foundation/ep-channel-web-app/commit/fd0091f5437e5ae213a08c995e4e08791218d2e4))

### [1.24.1](https://github.com/lbg-gcp-foundation/ep-channel-web-app/compare/v1.403.0...v1.24.1) (2020-07-14)

## [1.24.0](https://github.com/lbg-gcp-foundation/ep-channel-web-app/compare/v1.399.2...v1.24.0) (2020-07-14)


### Features

* SCA-2332 (#939) ([0647412](https://github.com/lbg-gcp-foundation/ep-channel-web-app/commit/06474121a141e8c44eafa8776809e461ebdb8ba1))

### [1.23.4](https://github.com/lbg-gcp-foundation/ep-channel-web-app/compare/v1.399.1...v1.23.4) (2020-07-14)


### Bug Fixes

* BB-2705 Added new user for int and ignore search feature file (#943) ([9397429](https://github.com/lbg-gcp-foundation/ep-channel-web-app/commit/939742981a490f7030a7ea0b1205be9a76a07c22))

### [1.23.3](https://github.com/lbg-gcp-foundation/ep-channel-web-app/compare/v1.398.0...v1.23.3) (2020-07-14)


### Bug Fixes

* BB-3367 R4 Payments BDDs and updated test data (#941) ([c61b4c2](https://github.com/lbg-gcp-foundation/ep-channel-web-app/commit/c61b4c2f17857bea8ba28ea93ae3a6307aafd92d))

### [1.23.2](https://github.com/lbg-gcp-foundation/ep-channel-web-app/compare/v1.392.0...v1.23.2) (2020-07-13)


### Bug Fixes

* BB-3505 BDD script fixes ([e7cb36f](https://github.com/lbg-gcp-foundation/ep-channel-web-app/commit/e7cb36fb15419dc1a5f78e16e9dcab49af8418ac))


### Release

* BB-2769 Back merge the analytics tagging from master (#937) ([7cf6459](https://github.com/lbg-gcp-foundation/ep-channel-web-app/commit/7cf64590b459e1de868cfa72c6e38450d5b46746))

### [1.23.1](https://github.com/lbg-gcp-foundation/ep-channel-web-app/compare/v1.391.0...v1.23.1) (2020-07-13)


### Bug Fixes

* BB-3473 removed CSS that was expanding icons unnecessarily in IE11 (#928) ([5e9cc23](https://github.com/lbg-gcp-foundation/ep-channel-web-app/commit/5e9cc230b1df3edf4f702f7259359b45a70b8d58))


### Release

* BB-3494 add DigiCert update (#933) ([d45e9c9](https://github.com/lbg-gcp-foundation/ep-channel-web-app/commit/d45e9c919c7e15861e69260091738c70b2ddf7ac))

## [1.23.0](https://github.com/lbg-gcp-foundation/ep-channel-web-app/compare/v1.388.2...v1.23.0) (2020-07-13)


### Features

* BB-3487 Fix cancel payment store bug (#925) ([308fa2e](https://github.com/lbg-gcp-foundation/ep-channel-web-app/commit/308fa2ed0691b7eda68d579050ac74841ade5675))

### [1.22.3](https://github.com/lbg-gcp-foundation/ep-channel-web-app/compare/v1.385.2...v1.22.3) (2020-07-12)

### [1.22.2](https://github.com/lbg-gcp-foundation/ep-channel-web-app/compare/v1.384.1...v1.22.2) (2020-07-10)


### Bug Fixes

* BB-3467 Updated feature file steps ,locators and user (#915) ([cbf989d](https://github.com/lbg-gcp-foundation/ep-channel-web-app/commit/cbf989db8807f9410c82ddf5a46f7303c27cd056))

### [1.22.1](https://github.com/lbg-gcp-foundation/ep-channel-web-app/compare/v1.383.0...v1.22.1) (2020-07-10)


### Bug Fixes

* BB-2359 BDD for Search Transactions stories (#844) ([d5db122](https://github.com/lbg-gcp-foundation/ep-channel-web-app/commit/d5db122eb0fb352eea4dab2c96c500c47ba9f593))

## [1.22.0](https://github.com/lbg-gcp-foundation/ep-channel-web-app/compare/v1.381.0...v1.22.0) (2020-07-10)


### Features

* BB-3293 Design and copy changes calendar FDP (#907) ([4454275](https://github.com/lbg-gcp-foundation/ep-channel-web-app/commit/4454275be18edab33e2caed8fc7e626f37485816))

## [1.21.0](https://github.com/lbg-gcp-foundation/ep-channel-web-app/compare/v1.380.0...v1.21.0) (2020-07-10)


### Features

* BB-2614 Prevent transaction page refresh from transaction details (#887) ([8cefac0](https://github.com/lbg-gcp-foundation/ep-channel-web-app/commit/8cefac029a4d3e4d4a7d260a5e9e71b5ebdbcef3))

### [1.20.5](https://github.com/lbg-gcp-foundation/ep-channel-web-app/compare/v1.373.1...v1.20.5) (2020-07-09)


### Bug Fixes

* BB-3040 Import test cases for Xray and tagging (#872) ([1ba7e4b](https://github.com/lbg-gcp-foundation/ep-channel-web-app/commit/1ba7e4bad18ee21b5e611584a0115f798cdde49b))

### [1.20.4](https://github.com/lbg-gcp-foundation/ep-channel-web-app/compare/v1.372.0...v1.20.4) (2020-07-08)


### Bug Fixes

* BB-2021 Removed special character validation from add jar name feature file (#888) ([d66c6dd](https://github.com/lbg-gcp-foundation/ep-channel-web-app/commit/d66c6ddc2ce23512efedf47245587189afae657e))

### [1.20.3](https://github.com/lbg-gcp-foundation/ep-channel-web-app/compare/v1.369.1...v1.20.3) (2020-07-08)


### Bug Fixes

* BB-3342 back merge from hotfix (#885) ([e990c50](https://github.com/lbg-gcp-foundation/ep-channel-web-app/commit/e990c50730e1cbfd5e5679cab78aa94baa7698e3))

### [1.20.2](https://github.com/lbg-gcp-foundation/ep-channel-web-app/compare/v1.364.0...v1.20.2) (2020-07-08)


### Bug Fixes

* BB-2989 CoP and add payee fixes (#863) ([1c191f6](https://github.com/lbg-gcp-foundation/ep-channel-web-app/commit/1c191f63bfe70e00a3de4c2c5b3a40f7f1eec29b))

### [1.20.1](https://github.com/lbg-gcp-foundation/ep-channel-web-app/compare/v1.362.0...v1.20.1) (2020-07-08)

## [1.20.0](https://github.com/lbg-gcp-foundation/ep-channel-web-app/compare/v1.356.0...v1.20.0) (2020-07-07)


### Features

* SCA-1021 AUTH | CWA Screen post selecting 'Resend' (#869) ([ead27cb](https://github.com/lbg-gcp-foundation/ep-channel-web-app/commit/ead27cb855315a04b599fef7e6489b6ac141d457))


### Bug Fixes

* BB-2596 removed Text Hardcoding within components (#840) ([ff66414](https://github.com/lbg-gcp-foundation/ep-channel-web-app/commit/ff66414c519936a90dee684d14bb5bbac12c9679))

## [1.19.0](https://github.com/lbg-gcp-foundation/ep-channel-web-app/compare/v1.347.0...v1.19.0) (2020-07-06)


### Features

* BB-2489 Assets folder (#851) ([079074c](https://github.com/lbg-gcp-foundation/ep-channel-web-app/commit/079074cff310e8952ccd3e63022cf0e3722f4e22))

## [1.18.0](https://github.com/lbg-gcp-foundation/ep-channel-web-app/compare/v1.345.0...v1.18.0) (2020-07-06)


### Features

* BB-2489 Themes folder structure (#847) ([19d57e3](https://github.com/lbg-gcp-foundation/ep-channel-web-app/commit/19d57e32a7de9af49209b4752f3bdc2093ef0ebf))

## [1.17.0](https://github.com/lbg-gcp-foundation/ep-channel-web-app/compare/v1.344.1...v1.17.0) (2020-07-06)


### Features

* BB-1381 CoP copy changes + minor fixes (#835) ([f4d8015](https://github.com/lbg-gcp-foundation/ep-channel-web-app/commit/f4d8015fb7dbd521ebad6f36c927a690efeea2a1))

### [1.16.1](https://github.com/lbg-gcp-foundation/ep-channel-web-app/compare/v1.344.0...v1.16.1) (2020-07-06)


### Bug Fixes

* BB-3051 fixing the continue button callback in timer modals (#849) ([83f1a29](https://github.com/lbg-gcp-foundation/ep-channel-web-app/commit/83f1a297a099c133221cb8627c24a3ecfcc970f4))

## [1.16.0](https://github.com/lbg-gcp-foundation/ep-channel-web-app/compare/v1.343.2...v1.16.0) (2020-07-06)


### Features

* BB-2193 Url Param (#848) ([6eccf74](https://github.com/lbg-gcp-foundation/ep-channel-web-app/commit/6eccf74bea0ca0bb7f95cb0f0de79da9fe0f203d))

### [1.15.5](https://github.com/lbg-gcp-foundation/ep-channel-web-app/compare/v1.335.1...v1.15.5) (2020-07-03)


### Bug Fixes

* BB-2956 Update copy for Change Jar Name (#829) ([006b3f0](https://github.com/lbg-gcp-foundation/ep-channel-web-app/commit/006b3f0d2c334ffc75098b3da1eabdd033366593))

### [1.15.4](https://github.com/lbg-gcp-foundation/ep-channel-web-app/compare/v1.330.1...v1.15.4) (2020-07-02)

### [1.15.3](https://github.com/lbg-gcp-foundation/ep-channel-web-app/compare/v1.329.1...v1.15.3) (2020-07-02)

### [1.15.2](https://github.com/lbg-gcp-foundation/ep-channel-web-app/compare/v1.325.0...v1.15.2) (2020-07-01)


### Bug Fixes

* BB-1381 CoP API endpoint fix (#809) ([df87923](https://github.com/lbg-gcp-foundation/ep-channel-web-app/commit/df87923298f8ded522032a6e9a10170fa01901c8))

### [1.15.1](https://github.com/lbg-gcp-foundation/ep-channel-web-app/compare/v1.320.0...v1.15.1) (2020-06-30)


### Bug Fixes

* BB-1048 Improvements to micro front end loading (#726) ([cdf057c](https://github.com/lbg-gcp-foundation/ep-channel-web-app/commit/cdf057c62dfc15d1bc57791a05994c75b427957b))

## [1.15.0](https://github.com/lbg-gcp-foundation/ep-channel-web-app/compare/v1.319.0...v1.15.0) (2020-06-30)


### Features

* BB-2001 added jenkinsfile for page perf and functional auto trigger job (#796) ([b8be4dd](https://github.com/lbg-gcp-foundation/ep-channel-web-app/commit/b8be4dd678bf12c925ee5be6fa54ba88d3658746))

### [1.14.1](https://github.com/lbg-gcp-foundation/ep-channel-web-app/compare/v1.312.0...v1.14.1) (2020-06-26)

## [1.14.0](https://github.com/lbg-gcp-foundation/ep-channel-web-app/compare/v1.310.1...v1.14.0) (2020-06-26)


### Features

* BB-1417 View a Payment payee (#723) ([49b43a8](https://github.com/lbg-gcp-foundation/ep-channel-web-app/commit/49b43a80154def504185e7101fe24a022a99cd86))

### [1.13.7](https://github.com/lbg-gcp-foundation/ep-channel-web-app/compare/v1.309.0...v1.13.7) (2020-06-25)


### Bug Fixes

* SCA-1551 Changes with resp to error messages for CWA (#756) ([e27e33b](https://github.com/lbg-gcp-foundation/ep-channel-web-app/commit/e27e33b6f7bc053a887bd7bfbd6941314fa7091c))

### [1.13.6](https://github.com/lbg-gcp-foundation/ep-channel-web-app/compare/v1.307.0...v1.13.6) (2020-06-25)

### [1.13.5](https://github.com/lbg-gcp-foundation/ep-channel-web-app/compare/v1.306.0...v1.13.5) (2020-06-25)
### [1.13.14](https://github.com/lbg-gcp-foundation/ep-channel-web-app/compare/v1.371.0...v1.13.14) (2020-07-09)


### Hotfix

* BB-2424 BB-2424 updated error pages and helm (#894) ([c23f92c](https://github.com/lbg-gcp-foundation/ep-channel-web-app/commit/c23f92cf615dd076b595baef71a63ba8b7c871aa))

### [1.13.13](https://github.com/lbg-gcp-foundation/ep-channel-web-app/compare/v1.370.0...v1.13.13) (2020-07-08)


### Hotfix

* BB-3241 Loader fixes for journey (#891) ([eca107b](https://github.com/lbg-gcp-foundation/ep-channel-web-app/commit/eca107b74f6517684a003bcfb0a891ffffb75518))

### [1.13.12](https://github.com/lbg-gcp-foundation/ep-channel-web-app/compare/v1.361.0...v1.13.12) (2020-07-08)


### Hotfix

* BB-3342 Parse the input field in payment, time restriction disabled (#883) ([4234647](https://github.com/lbg-gcp-foundation/ep-channel-web-app/commit/423464703c4486ff874fb26047bc7be0b8ff4206))
* BB-3342 Reduce the timeout (#889) ([7c78eff](https://github.com/lbg-gcp-foundation/ep-channel-web-app/commit/7c78effb1047ed919349baaa2d327cca0994ca98))

### [1.13.11](https://github.com/lbg-gcp-foundation/ep-channel-web-app/compare/v1.359.0...v1.13.11) (2020-07-07)


### Hotfix

* BB-3241 Reduced timeout for balance API. (#876) ([fc6cb0d](https://github.com/lbg-gcp-foundation/ep-channel-web-app/commit/fc6cb0d7b8b0e24c8b21e5472e3035dacf1a3a9a))

### [1.13.10](https://github.com/lbg-gcp-foundation/ep-channel-web-app/compare/v1.322.0...v1.13.10) (2020-07-07)


### Hotfix

* BB-3241 Updated Docker base images (#874) ([bfeeb1c](https://github.com/lbg-gcp-foundation/ep-channel-web-app/commit/bfeeb1cdf4ef95ed3707a946c63932fdc0416fd1))
* BB-3241 Updated success screen, removed timeouts (#873) ([66c75aa](https://github.com/lbg-gcp-foundation/ep-channel-web-app/commit/66c75aa9ef4da4b0d08c61233d4b9055ea496bee))

### [1.13.9](https://github.com/lbg-gcp-foundation/ep-channel-web-app/compare/v1.321.0...v1.13.9) (2020-06-30)


### Hotfix

* BB-2791 address field mapping changed and lables updated (#804) ([fcda876](https://github.com/lbg-gcp-foundation/ep-channel-web-app/commit/fcda876da0807cce3a1c4b2cd4c468190f44f22b))
* BB-2791 updated error msg and name pattern (#805) ([32506ea](https://github.com/lbg-gcp-foundation/ep-channel-web-app/commit/32506ea8e6ca12fd9d2f617b71c24f42ee5185dd))

### [1.13.8](https://github.com/lbg-gcp-foundation/ep-channel-web-app/compare/v1.317.0...v1.13.8) (2020-06-30)


### Hotfix

* BB-2790 Added name special character on on change regex (#799) ([a0fa81b](https://github.com/lbg-gcp-foundation/ep-channel-web-app/commit/a0fa81bb21560fb70409bc9c5ad20350fc809333))
* BB-2792 Updating the regex for address fields - House number, first line, street address  (#798) ([ecb6667](https://github.com/lbg-gcp-foundation/ep-channel-web-app/commit/ecb66679dd2ea935c117f3054e957cb93c2b12f9))
* BB-2795 Changes for error page (#800) ([df03788](https://github.com/lbg-gcp-foundation/ep-channel-web-app/commit/df037881bd6f36c0731da188b8087da355b7eb72))
* BB-2873 fix for saving password (#803) ([e7754fb](https://github.com/lbg-gcp-foundation/ep-channel-web-app/commit/e7754fbb8ef27e87ec045930691ba2ef4b6b9e01))

### [1.13.7](https://github.com/lbg-gcp-foundation/ep-channel-web-app/compare/v1.315.0...v1.13.7) (2020-06-30)


### Hotfix

* BB-2768 Added analytics data tagging after user loges in successfully (#786) ([d4c79f3](https://github.com/lbg-gcp-foundation/ep-channel-web-app/commit/d4c79f363bf96cf745f046c49ee883378f4fff16))

### [1.13.6](https://github.com/lbg-gcp-foundation/ep-channel-web-app/compare/v1.313.0...v1.13.6) (2020-06-27)


### Hotfix

* BB-2755 Hotfix fopr release R1 copy changes and cosmetic changes (#785) ([fffbde5](https://github.com/lbg-gcp-foundation/ep-channel-web-app/commit/fffbde53b0a232d78b28b47c32cefd696f520669))

### [1.13.5](https://github.com/lbg-gcp-foundation/ep-channel-web-app/compare/v1.305.0...v1.13.5) (2020-06-26)


### Hotfix

* BB-1234 hotfix test for prod (#782) ([9c618b4](https://github.com/lbg-gcp-foundation/ep-channel-web-app/commit/9c618b4a4d0038c3f22b864f5843defe35498961))

### [1.13.4](https://github.com/lbg-gcp-foundation/ep-channel-web-app/compare/v1.304.3...v1.13.4) (2020-06-24)


### Release

* BB-2506 Releae branch with amount validation and error scenarios for 404 and 500 ([2d5856a](https://github.com/lbg-gcp-foundation/ep-channel-web-app/commit/2d5856aef34f87f3b0f072e6258b4cab9e912df6))

### [1.13.3](https://github.com/lbg-gcp-foundation/ep-channel-web-app/compare/v1.304.2...v1.13.3) (2020-06-24)


### Bug Fixes

* BB-2611 decimal aamount fix (#774) ([b347c8a](https://github.com/lbg-gcp-foundation/ep-channel-web-app/commit/b347c8ae8e397e60cb08ffdd22d5960e5e373134))

### [1.13.2](https://github.com/lbg-gcp-foundation/ep-channel-web-app/compare/v1.294.1...v1.13.2) (2020-06-23)


### Bug Fixes

* BB-2439 Added updated images for home page (#754) ([5a53be6](https://github.com/lbg-gcp-foundation/ep-channel-web-app/commit/5a53be659ed471b750cdfab67f8f9b54ae2429ca))

### [1.13.1](https://github.com/lbg-gcp-foundation/ep-channel-web-app/compare/v1.293.0...v1.13.1) (2020-06-23)


### Bug Fixes

* BB-2487 Payments R1 Fixes (#737) ([b677435](https://github.com/lbg-gcp-foundation/ep-channel-web-app/commit/b677435d73554c2b7d232a9aad68ef8d207d05cc))

## [1.13.0](https://github.com/lbg-gcp-foundation/ep-channel-web-app/compare/v1.286.0...v1.13.0) (2020-06-22)


### Features

* BB-2502 Updated timeout modal  (#741) ([656f01b](https://github.com/lbg-gcp-foundation/ep-channel-web-app/commit/656f01b786ba114f8375f672bed7f568c30fc27c))

## [1.12.0](https://github.com/lbg-gcp-foundation/ep-channel-web-app/compare/v1.283.2...v1.12.0) (2020-06-22)


### Features

* BB-2568 Add mandatory headers (#732) ([8b74617](https://github.com/lbg-gcp-foundation/ep-channel-web-app/commit/8b746170041c71f74c705f3f2a519f834a2a72a2))

### [1.11.2](https://github.com/lbg-gcp-foundation/ep-channel-web-app/compare/v1.281.2...v1.11.2) (2020-06-22)

### [1.11.1](https://github.com/lbg-gcp-foundation/ep-channel-web-app/compare/v1.279.1...v1.11.1) (2020-06-22)


### Bug Fixes

* BB-2504 fixed padding on table header (#729) ([583604e](https://github.com/lbg-gcp-foundation/ep-channel-web-app/commit/583604eb1d73ba8227ecadb9570356446ad2314f))

## [1.11.0](https://github.com/lbg-gcp-foundation/ep-channel-web-app/compare/v1.279.0...v1.11.0) (2020-06-22)


### Features

* BB-2501 PO feedback changes on pre application pages (#730) ([7dbacc7](https://github.com/lbg-gcp-foundation/ep-channel-web-app/commit/7dbacc747de5e1fd2fe9700fa01100d1825b37b2))


### Bug Fixes

* BB-2150 modified post build failure notification changes for mas… (#651) ([fe37fd8](https://github.com/lbg-gcp-foundation/ep-channel-web-app/commit/fe37fd8b8b90ce48358ea1034ee296a1de88450d))

## [1.10.0](https://github.com/lbg-gcp-foundation/ep-channel-web-app/compare/v1.276.4...v1.10.0) (2020-06-22)


### Features

* BB-2326 Patch Beneficiary API Implementation Reference CR R1 (#705) ([1c8ed2c](https://github.com/lbg-gcp-foundation/ep-channel-web-app/commit/1c8ed2c63c3d616502c388da480bab55692c08b6))

### [1.9.4](https://github.com/lbg-gcp-foundation/ep-channel-web-app/compare/v1.273.4...v1.9.4) (2020-06-21)

### [1.9.3](https://github.com/lbg-gcp-foundation/ep-channel-web-app/compare/v1.268.3...v1.9.3) (2020-06-19)


### Bug Fixes

* BB-2374 R1 changes - Adding new images for tablet (#714) ([5142741](https://github.com/lbg-gcp-foundation/ep-channel-web-app/commit/51427411f8542f3f3740d322598e9d964414f147))

### [1.9.2](https://github.com/lbg-gcp-foundation/ep-channel-web-app/compare/v1.267.2...v1.9.2) (2020-06-19)


### Bug Fixes

* BB-2370 Beneficiary table design change, copy changes across payment (#713) ([7eec481](https://github.com/lbg-gcp-foundation/ep-channel-web-app/commit/7eec4811e43d85a16cec97afdfb25270074f36ba))

### [1.9.1](https://github.com/lbg-gcp-foundation/ep-channel-web-app/compare/v1.263.1...v1.9.1) (2020-06-18)


### Bug Fixes

* BB-2279 support keyboard nav of transactions list (#701) ([8d48c0b](https://github.com/lbg-gcp-foundation/ep-channel-web-app/commit/8d48c0bfaaf9ce8896afa5d8e4fc59459abf8c27))

## [1.9.0](https://github.com/lbg-gcp-foundation/ep-channel-web-app/compare/v1.263.0...v1.9.0) (2020-06-18)


### Features

* BB-2423 feedback changes on application page (#702) ([5322f4e](https://github.com/lbg-gcp-foundation/ep-channel-web-app/commit/5322f4e4897e14379402607bd00a925a8eea8b47))


### Bug Fixes

* BB-2441 Fixed blank page bug if no transactions present (#707) ([7fc8cbf](https://github.com/lbg-gcp-foundation/ep-channel-web-app/commit/7fc8cbfe75bab59748d30e660f6818c404f00df6))

## [1.8.0](https://github.com/lbg-gcp-foundation/ep-channel-web-app/compare/v1.252.8...v1.8.0) (2020-06-17)


### Features

* BB-2407 Adding application down feature after 5Pm (#693) ([558a726](https://github.com/lbg-gcp-foundation/ep-channel-web-app/commit/558a726513713024db5385a59770fb597a1fc7e6))

### [1.7.12](https://github.com/lbg-gcp-foundation/ep-channel-web-app/compare/v1.250.8...v1.7.12) (2020-06-17)

### [1.7.11](https://github.com/lbg-gcp-foundation/ep-channel-web-app/compare/v1.245.7...v1.7.11) (2020-06-16)


### Bug Fixes

* BB-2317 UAT demo copy changes and Balance API on view transaction (#678) ([c8e41e7](https://github.com/lbg-gcp-foundation/ep-channel-web-app/commit/c8e41e79414181131bf7fe8e394e6c3b94f43663))

### [1.7.10](https://github.com/lbg-gcp-foundation/ep-channel-web-app/compare/v1.225.6...v1.7.10) (2020-06-12)


### Bug Fixes

* BB-2096 updated test case (#644) ([972df31](https://github.com/lbg-gcp-foundation/ep-channel-web-app/commit/972df31a1c17ffc3959265f7e734581351d85b4b))

### [1.7.9](https://github.com/lbg-gcp-foundation/ep-channel-web-app/compare/v1.223.5...v1.7.9) (2020-06-12)


### Bug Fixes

* BB-2195 Message box and header global changes - R1 changes (#649) ([ba751af](https://github.com/lbg-gcp-foundation/ep-channel-web-app/commit/ba751af176d3f6f6927e61eb8402d318676de750))

### [1.7.8](https://github.com/lbg-gcp-foundation/ep-channel-web-app/compare/v1.222.5...v1.7.8) (2020-06-12)

### [1.7.7](https://github.com/lbg-gcp-foundation/ep-channel-web-app/compare/v1.213.4...v1.7.7) (2020-06-11)


### Bug Fixes

* BB-2125 Update tealium tag (#635) ([a15670e](https://github.com/lbg-gcp-foundation/ep-channel-web-app/commit/a15670e5a0dfa64a0739cd30414bca67daf926c5))

### [1.7.6](https://github.com/lbg-gcp-foundation/ep-channel-web-app/compare/v1.212.4...v1.7.6) (2020-06-11)

### [1.7.5](https://github.com/lbg-gcp-foundation/ep-channel-web-app/compare/v1.212.3...v1.7.5) (2020-06-11)


### Bug Fixes

* BB-1994 Fix Non-Root Security Issue and Refactored Build Image (#618) ([15094b7](https://github.com/lbg-gcp-foundation/ep-channel-web-app/commit/15094b75a7f0b05bde1553b793d9db0535ad37a9))

### [1.7.4](https://github.com/lbg-gcp-foundation/ep-channel-web-app/compare/v1.209.2...v1.7.4) (2020-06-10)


### Bug Fixes

* BB-2132 Make Payment R1 fixes (#631) ([fc30b39](https://github.com/lbg-gcp-foundation/ep-channel-web-app/commit/fc30b3999ef1d05a921394f557ec279d8cdfd87a))
* BB-2177 Update product name, transaction description for R1 (#629) ([58d772c](https://github.com/lbg-gcp-foundation/ep-channel-web-app/commit/58d772c1720873dcbd7c0b928ba526d5b69e823d))

### [1.7.3](https://github.com/lbg-gcp-foundation/ep-channel-web-app/compare/v1.195.2...v1.7.3) (2020-06-09)


### Bug Fixes

* BB-2099 QA on-demand and nightly job Jenkins file created (#614) ([b786e92](https://github.com/lbg-gcp-foundation/ep-channel-web-app/commit/b786e922a7e4bfbc39adcb1c83b5f771bd7e5125))

### [1.7.2](https://github.com/lbg-gcp-foundation/ep-channel-web-app/compare/v1.194.1...v1.7.2) (2020-06-09)


### Bug Fixes

* BB-2099 QA ondemand and nightly job jenkinsfile created (#609) ([e60e27b](https://github.com/lbg-gcp-foundation/ep-channel-web-app/commit/e60e27bed65fc7eb784538826abc7456dfc06d88))

### [1.7.1](https://github.com/lbg-gcp-foundation/ep-channel-web-app/compare/v1.178.0...v1.7.1) (2020-06-05)


### Bug Fixes

* Bb 2086 Lint fixes reverted for future dated payment (#585) ([51374cf](https://github.com/lbg-gcp-foundation/ep-channel-web-app/commit/51374cf4ffd75454090717e3fb40537e8f8ea22c))
* BB-1985 fixed the feature file path (#584) ([1be91b4](https://github.com/lbg-gcp-foundation/ep-channel-web-app/commit/1be91b4ef035ee4f73a7976c9098974c5eac1271))

## [1.7.0](https://github.com/lbg-gcp-foundation/ep-channel-web-app/compare/v1.175.0...v1.7.0) (2020-06-05)


### Features

* BB-1677 Zap Proxy implementation and perf baselining along with compatibility (#575) ([52d80eb](https://github.com/lbg-gcp-foundation/ep-channel-web-app/commit/52d80eb07a143c84b02c68a0e1fe8751f7caafcb))


### Bug Fixes

* BB-20174 Added all feature file (#558) ([e1973d9](https://github.com/lbg-gcp-foundation/ep-channel-web-app/commit/e1973d936f77abfeab8e0427291f13fa6e09e14b))

## [1.6.0](https://github.com/lbg-gcp-foundation/ep-channel-web-app/compare/v1.166.0...v1.6.0) (2020-06-04)


### Features

* BB-2082 Login Button Functionality Fix (#557) ([d1cd675](https://github.com/lbg-gcp-foundation/ep-channel-web-app/commit/d1cd675b79eb095b9610950e35d0f8dfc8dece6a))

## [1.5.0](https://github.com/lbg-gcp-foundation/ep-channel-web-app/compare/v1.164.0...v1.5.0) (2020-06-04)


### Features

* BB-1981 Copy changes for account overview and transactions journey (#527) ([1d241fe](https://github.com/lbg-gcp-foundation/ep-channel-web-app/commit/1d241fe8505250c84e9840350d49ccb3697a163d))

## [1.4.0](https://github.com/lbg-gcp-foundation/ep-channel-web-app/compare/v1.163.2...v1.4.0) (2020-06-04)


### Features

* BB-2072 Adding provision for all links in Richtext component to behave as react router dom Link component (#543) ([f6ac8f9](https://github.com/lbg-gcp-foundation/ep-channel-web-app/commit/f6ac8f9f45eb906fb61e801fdc584a4c3551797d))


### Bug Fixes

* BB-1464 Removed test for Feedback button (#533) ([0f0de13](https://github.com/lbg-gcp-foundation/ep-channel-web-app/commit/0f0de13688edf4601def81ce881ed2733cdfc67c))
* BB-1827 Updated the copy and renamed few keys in Payment Journey (#525) ([9e8391c](https://github.com/lbg-gcp-foundation/ep-channel-web-app/commit/9e8391c6de56a60542a067b47c6df599304664cc))

### [1.3.2](https://github.com/lbg-gcp-foundation/ep-channel-web-app/compare/v1.161.1...v1.3.2) (2020-06-03)


### Bug Fixes

* BB-1995 remove outline when hover and focus on login button. (#540) ([6191fc9](https://github.com/lbg-gcp-foundation/ep-channel-web-app/commit/6191fc93544a71db905f7d0c26cb4a5a83bfc639))

### [1.3.1](https://github.com/lbg-gcp-foundation/ep-channel-web-app/compare/v1.158.0...v1.3.1) (2020-06-03)


### Bug Fixes

* BB-2062 - Updating copy for application success screen (#542) ([ea1c953](https://github.com/lbg-gcp-foundation/ep-channel-web-app/commit/ea1c9531452afdcf5444b937cdebc2398dd82f86))
* SCA-1268 VD and copy update (#547) ([8acd954](https://github.com/lbg-gcp-foundation/ep-channel-web-app/commit/8acd954924a6a32bf131f7ef62e1121dc267f4c1))

## [1.3.0](https://github.com/lbg-gcp-foundation/ep-channel-web-app/compare/v1.157.1...v1.3.0) (2020-06-03)


### Features

* BB-1581 cross browser updates for box shadow (#541) ([935be24](https://github.com/lbg-gcp-foundation/ep-channel-web-app/commit/935be240d359a2526630c0e89a668c9e965b64fe))


### Bug Fixes

* BB-1688 Refresh Add Payee Page, Make Payment form reset fixes  (#544) ([9eacb9e](https://github.com/lbg-gcp-foundation/ep-channel-web-app/commit/9eacb9ef39de54fc5f5a97c96b4c7f7a741ab716))

### [1.2.2](https://github.com/lbg-gcp-foundation/ep-channel-web-app/compare/v1.155.0...v1.2.2) (2020-06-03)


### Bug Fixes

* BB-1895 Issue with ipad resolution for error (#538) ([867a384](https://github.com/lbg-gcp-foundation/ep-channel-web-app/commit/867a38493531723c6b826eafac563319ee3185cd))

# Changelog

## Release 1 - 2020-05-27

### Journey Make a Payment - IAT
