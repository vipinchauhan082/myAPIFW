/* eslint-disable @typescript-eslint/no-var-requires */
const fs = require('fs');

const newFileData = fs.readFileSync(
  'tests/reportTemp/htmlTextFile.txt',
  'utf8',
);
const readTempFile = fs.readFileSync(
  'tests/reportTemp/reportTemp.html',
  'utf8',
);
const readTempFileNew = readTempFile.replace('#Replace#', newFileData);
fs.writeFileSync(
  'tests/reportTemp/PagePerformanceReport.html',
  readTempFileNew,
);
