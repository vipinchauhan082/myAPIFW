/* eslint-disable no-undef */
/* eslint-disable @typescript-eslint/no-var-requires */
export {};
const { When } = require('cucumber');
const actions = require('../support/common-actions');
const Selectors = require('../support/loadDataAndLocators');

When(
  /^User navigates to account overviw page after login as customer using username as "(.*)" & password as "(.*)" or search as colleague using "(.*)" and customer id "(.*)"$/,
  (username, password, customerRef, customerId) => {
    if (process.env.MOCK === 'true' && process.env.AUTH === 'false') {
      const custId = Selectors.getData(customerId);
      browser.execute(`sessionStorage.setItem('_cid', '${custId}')`);
      browser.execute("sessionStorage.setItem('_at', 'VALID_STATIC_TOKEN')");
      browser.execute("sessionStorage.setItem('runtime-brand', 'IF')");
      browser.pause(2000);
      browser.refresh();
    } else {
      if (process.env.USERTYPE === 'customer') {
        actions.click('loginLink');
        actions.enter(username, 'usernameField');
        actions.enter(password, 'passwordField');
        actions.click('loginButton');
        actions.selectMI();
        actions.click('continueButton');
      }
      if (process.env.USERTYPE === 'colleague') {
        actions.click('searchByCustomerPlanNoPage');
        actions.enter(customerRef, 'Customer Ref textbox');
        actions.click('Find Customer button');
        if (process.env.ENV === 'bld') {
          actions.click('accessTypeContinueButton');
        }
        browser.pause(5000);
        actions.enterMI();
        actions.click('continueButton');
      }
    }
  },
);

When(/^User logout from the application$/, () => {
  if (process.env.USERTYPE === 'customer') {
    actions.click('logoff_button');
  }
  if (process.env.USERTYPE === 'colleague') {
    actions.click('wrapTab');
  }
});

When(
  /^User navigates to account overviw page after search as colleague using "(.*)"$/,
  customerRef => {
    actions.click('searchByCustomerPlanNoPage');
    actions.enter(customerRef, 'Customer Ref textbox');
    actions.click('Find Customer button');
    if (process.env.ENV === 'bld') {
      actions.click('accessTypeContinueButton');
    }
    actions.enterMI();
    actions.click('continueButton');
  },
);
