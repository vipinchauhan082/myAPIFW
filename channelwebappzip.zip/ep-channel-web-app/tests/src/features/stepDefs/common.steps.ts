/* eslint-disable no-undef */
/* eslint-disable no-await-in-loop */
/* eslint-disable @typescript-eslint/no-var-requires */

const { Given, When, Then } = require('cucumber');
const { assert, expect } = require('chai');
const Selectors = require('../support/loadDataAndLocators');
const actions = require('../support/common-actions');
const randGenerator = require('../support/getRandomData');
const { format, subDays, subMonths, subYears } = require('date-fns');
const date = require('../support/getDate');
const fs = require('fs');
const path = require('path');
const getTransactions = require('../../../../packages/journey-view-transaction/tests/builders/getTransactions');
const getGeneralAccountInfo = require('../../../../packages/journey-view-transaction/tests/builders/getGeneralAccountInfo');
const wait = require('../../../../packages/journey-view-transaction/tests/utils/wait');
const setRemittenceAccount = require('../support/setRemittenceAccount');
const setSweepBalanceRule = require('../support/setUpBalanceSweep');
const { config } = require('../../../conf/shared/wdio.shared');
const envConfig = require('../../../conf/shared/env.conf');

const tokenUrl = envConfig.getConfig(process.env.ENV).ENV_COLLEAGUE_TOKEN_URL;

let genderCurrentValue = '';
let changedGenderValue = '';
const savedValueList = new Map();
const currentDate = new Date();
let chequeNumber = '';

Given(/^User is on application homepage url "(.*)"$/, url => {
  if (process.env.USERTYPE === 'colleague') {
    browser.url('');
  } else {
    browser.url(url);
  }

  if (process.env.FLAG === 'BETA') {
    browser.execute("sessionStorage.setItem('BETA', 'true')");
  } else if (process.env.FLAG === 'WIP') {
    browser.execute("sessionStorage.setItem('WIP', 'true')");
  }

  if (process.env.ENV === 'local') {
    // actions.click("agentbtn");
    actions.click('coll_agent');
    browser.execute("sessionStorage.setItem('_cid', 'amit')");
    browser.execute("sessionStorage.setItem('_at', 'amit')");
    browser.execute("sessionStorage.setItem('runtime-brand', 'IF')");
    browser.execute("sessionStorage.setItem('WIP', 'true')");
    browser.pause(2000);
    browser.refresh();
    actions.click('okButton');
  }
  if (process.env.MOCK === 'true') {
    browser.execute("sessionStorage.setItem('MOCK', 'true')");
  }

  if (
    process.env.LOADTEST === 'true' &&
    typeof process.env.LOADTEST !== 'undefined'
  ) {
    browser.execute("sessionStorage.setItem('delay', 'true')");
    const delayTime = envConfig.pagePerf(process.env.SLADELAY);
    browser.execute(`sessionStorage.setItem('delayduration', ${delayTime})`);
  }
});

Then(/^User navigate to following url "(.*)"$/, url => {
  browser.url(url);
});

Then(
  /^User is verifying the "(.*)" text contains "(.*)"$/,
  (element, expectedText) => {
    let expectedvalue = expectedText;
    expectedvalue = Selectors.getData(expectedText);
    const locatorString = Selectors.getSelector(element);
    const selector = $(locatorString);
    const actualText = selector.getText().trim();
    assert.include(actualText, expectedvalue);
  },
);

Then(
  /^User is verifying the "(.*)" text as "(.*)"$/,
  (element, expectedText) => {
    let expectedvalue = expectedText;
    expectedvalue = Selectors.getData(expectedText);
    const locatorString = Selectors.getSelector(element);
    const selector = $(locatorString);
    const actualText = selector.getText().trim();
    // browser.waitUntil(() => {
    //   return actualText === expectedvalue;
    // }, config.cucumberOpts.timeout);
    assert.equal(actualText, expectedvalue);
  },
);

Then(
  /^User is verifying the property value of "(.*)" text as "(.*)"$/,
  (element, expectedText) => {
    let expectedvalue = expectedText;
    expectedvalue = Selectors.getData(expectedText);
    const locatorString = Selectors.getSelector(element);
    const selector = $(locatorString);
    const actualText = selector.getCSSProperty('value');
    assert.equal(actualText, expectedvalue);
  },
);

Then(
  /^User is verifying the accessibility value "(.*)" text as "(.*)"$/,
  (element, accessibilityValue) => {
    const expectedvalue = savedValueList.get(accessibilityValue);
    const locatorString = Selectors.getSelector(element);
    const selector = $(locatorString);
    const actualText = selector.getText().trim();
    browser.waitUntil(() => {
      return actualText === expectedvalue;
    }, config.cucumberOpts.timeout);
    assert.equal(actualText, expectedvalue);
  },
);

When(/^note API returns an Error "(.*)"$/, element => {
  const locatorString = Selectors.getSelector(element);
  const selector = $(locatorString);
  if (selector.isDisplayed()) {
    actions.click('cancelButton');
  }
});

Then(
  /^User is verifying the amount "(.*)" text as "(.*)"$/,
  (element, expectedText) => {
    const locatorString = Selectors.getSelector(element);
    const selector = $(locatorString);
    const actualText = selector.getText();
    assert.equal(actualText, expectedText);
  },
);

Then(
  /^User validate "(.*)" element text as "(.*)"$/,
  (element, expectedText) => {
    let expectedvalue = expectedText;
    expectedvalue = Selectors.getData(expectedText);
    const locatorString = Selectors.getSelector(element);
    const selector = $(locatorString);
    const actualText = selector.getText();
    assert.equal(actualText, expectedvalue);
  },
);

When(
  /^User switched to the tab or window having page title as "(.*)"$/,
  pageTitle => {
    browser.switchWindow(pageTitle);
  },
);

Then(/^User clicks on amend transaction of the page$/, () => {
  const selector = $(`//p[text()='${global.expectedValue}']`);
  selector.click();
});

When(/^User clicks on "(.*)" of page$/, element => {
  actions.click(element);
});

When(
  /User clicks on compliant flag "(.*)" of page if not disabled$/,
  element => {
    const locatorString = Selectors.getSelector(element);
    const selector = $(locatorString);
    if (selector.getAttribute('aria-disabled') !== 'true') {
      selector.click();
    }
  },
);

When(
  /^User select the "(.*)" "(.*)" "(.*)" "(.*)" "(.*)" and save in "(.*)"$/,
  (
    element,
    elementOne,
    accessibleStatementOption,
    accessibleStatementOptionOne,
    accountNum1,
    savedAccessOptionValue,
  ) => {
    const locatorString = Selectors.getSelector(element);
    const selector = $(locatorString);
    const locatorStringTwo = Selectors.getSelector(accessibleStatementOption);
    const selectorTwo = $(locatorStringTwo);
    const getTextSupportOption = selectorTwo.getText();
    const getCurrentText = savedValueList.get(accountNum1);
    if (getCurrentText !== 'Standard format') {
      const locatorStringOne = Selectors.getSelector(elementOne);
      const selectorOne = $(locatorStringOne);
      const locatorStringThree = Selectors.getSelector(
        accessibleStatementOptionOne,
      );
      const selectorThree = $(locatorStringThree);
      const getTextSupportOptionA = selectorThree.getText();
      selectorOne.click();
      savedValueList.set(savedAccessOptionValue, getTextSupportOptionA);
    } else {
      selector.click();
      const elem = $('#consentSelected');
      elem.selectByIndex(1);
      savedValueList.set(savedAccessOptionValue, getTextSupportOption);
    }
  },
);

Then(
  /^User is verifying the displayed support tooltip partial text on "(.*)" text as "(.*)" is displayed$/,
  (element, savedAccessOptionValue) => {
    const accessibilityStatementValue = savedValueList.get(
      savedAccessOptionValue,
    );
    const locatorString = Selectors.getSelector(element);
    const locator = $(locatorString);
    const actualtext = locator.getText();
    assert.isTrue(
      actualtext.includes(accessibilityStatementValue),
      `${accessibilityStatementValue} not present in actual text, actual text is: ${actualtext}`,
    );
  },
);

Then(
  /^User is verifying the support tooltip partial text on "(.*)" text as "(.*)" is not displayed$/,
  (element, accessibleStatementOption) => {
    const accessibilityStatementValue = savedValueList.get(
      accessibleStatementOption,
    );
    const locatorString = Selectors.getSelector(element);
    const locator = $(locatorString);
    const actualtext = locator.getText();
    assert.isNotTrue(
      actualtext.includes(accessibilityStatementValue),
      `${accessibilityStatementValue} not present in actual text, actual text is: ${actualtext}`,
    );
  },
);

When(/^User turns on support option "(.*)" of page$/, element => {
  const locatorString = Selectors.getSelector(element);
  const selector = $(locatorString);
  if (selector.getAttribute('checked') !== 'true') {
    selector.click();
  } else {
    selector.click();
    actions.click('goneawayYes');
    browser.pause(3000);
  }
});

Then(
  /^User is verifying the support tooltip partial text on "(.*)" text as "(.*)"$/,
  (element, accessibleStatementOption) => {
    const accessibilityStatementValue = savedValueList.get(
      'accessibleStatementOption',
    );
    const locatorString = Selectors.getSelector(element);
    const locator = $(locatorString);
    const actualtext = locator.getText();
    if (accessibleStatementOption !== 'Standard format') {
      assert.isTrue(
        actualtext.includes(accessibilityStatementValue),
        `${accessibilityStatementValue} not present in actual text, actual text is: ${actualtext}`,
      );
    } else {
      assert.isNotTrue(
        actualtext.includes(accessibilityStatementValue),
        `${accessibilityStatementValue} not present in actual text, actual text is: ${actualtext}`,
      );
    }
  },
);

When(/^User clicks on close account "(.*)" of page$/, element => {
  let locatorString = Selectors.getSelector(element);

  locatorString = locatorString.replace(
    'closeAccountNo',
    global.CloseAccountId,
  );
  const selector = $(locatorString);
  selector.click();
  // clickOnElement(element);
});

When(
  /^User provide the updated jarname "(.*)" on "(.*)" on the page$/,
  (jarName, element) => {
    const jarNameValue = Selectors.getData(jarName);
    const locatorString = Selectors.getSelector(element);
    const selector = $(locatorString);
    selector.setValue(jarNameValue);
  },
);

When(/^User clicks on the current year "(.*)" on the page$/, element => {
  let locatorString = Selectors.getSelector(element);
  locatorString = locatorString.replace(
    '##currentYear##',
    currentDate.getFullYear(),
  );
  const selector = $(locatorString);
  selector.click();
});

Then(
  /^User clicks on previousDate "(.*)" days back "(.*)" on the "(.*)" of page$/,
  (numofDays, previousMonth, element) => {
    let previousDate1;
    if (currentDate.getDate() < 4) {
      actions.click(previousMonth);
      previousDate1 = currentDate.getDate() + 20;
    } else {
      previousDate1 = currentDate.getDate() - numofDays;
    }
    let locatorString = Selectors.getSelector(element);
    locatorString = locatorString.replace('##previousDate##', previousDate1);
    const selector = $(locatorString);
    selector.click();
  },
);

Then(/^User clicks on todayDate on the "(.*)" of page$/, element => {
  let locatorString = Selectors.getSelector(element);
  locatorString = locatorString.replace(
    '##previousDate##',
    currentDate.getDate(),
  );
  const selector = $(locatorString);
  selector.click();
});

When(
  /^User clicks on the previous year "(.*)" on the page and saved in "(.*)"$/,
  (element, previousOneYear) => {
    let locatorString = Selectors.getSelector(element);
    locatorString = locatorString.replace(
      '##currentYear##',
      currentDate.getFullYear() - 1,
    );
    const selector = $(locatorString);
    const actualText = selector.getText();
    selector.click();
    savedValueList.set(previousOneYear, actualText);
  },
);

Then(
  /^User is verifying month year value "(.*)" text of page is prepopulated with CurrentMonthYear$/,
  element => {
    const locatorString = Selectors.getSelector(element);
    const selector = $(locatorString);
    let actualText = selector.getValue();
    if (actualText == null) {
      actualText = selector.getText();
    }
    const expectedText = format(currentDate, 'MMMM YYYY');
    assert.equal(actualText, expectedText);
  },
);

When(/^User scroll to "(.*)" of page$/, element => {
  const locatorString = Selectors.getSelector(element);
  const selector = $(locatorString);
  selector.scrollIntoView();
  browser.pause(2000);
});

Then(/^User is verifying the stored text as "(.*)"$/, element => {
  const locatorString = Selectors.getSelector(element);
  const selector = $(locatorString);
  const actualText = selector.getText().trim();
  assert.equal(actualText, global.expectedValue);
});

When(/^User clicks on "(.*)" of page and captures customerId$/, element => {
  actions.click(element);
  browser.setupInterceptor(); // capture ajax calls
  browser.pause(30000); // maybe wait a bit until request is finished
  const request = browser.getRequest(0);
  global.customerID = request.response.body.CustomerId;
});

When(
  /^User clicks on "(.*)" of page and captures contactDetailId$/,
  element => {
    browser.setupInterceptor(); // capture ajax calls
    actions.click(element);
    browser.pause(5000); // maybe wait a bit until request is finished
    const request = browser.getRequest(2);
    const { value } = request.response.body.callbacks[0].output[0];
    const output = JSON.parse(value);
    const nextStateValue = JSON.parse(output.nextStateValue);
    const { phoneNumber } = nextStateValue;
    global.contactDetailId = phoneNumber.contactDetailId;
  },
);

When(/^User captures accessToken and save with key "(.*)"$/, element => {
  let result = browser.execute(() => {
    return sessionStorage.getItem('_at');
  });
  result = `Bearer ${result}`;
  global.authtoken = result;
  savedValueList.set(element, result);
});

When(
  /^User sets up sweeping balance rule for account id "(.*)" and nominated account id "(.*)"$/,
  async (account, nominatedAccountId) => {
    const accessToken = savedValueList.get('authToken');
    const accountId = Selectors.getData(account);
    const nominatedAccount = Selectors.getData(nominatedAccountId);
    const response = await setSweepBalanceRule(
      accountId,
      nominatedAccount,
      accessToken,
    );
    assert.equal(response.statusCode, 200);
  },
);

When(
  /^User captures colleague accessToken and save with key "(.*)"$/,
  element => {
    if (process.env.USERTYPE === 'colleague') {
      const result = browser.execute(() => {
        return sessionStorage.getItem('_colleague_at');
      });
      savedValueList.set(element, result);
    }
  },
);

When(/^User clicks on "(.*)" of page using wdio click$/, element => {
  const locatorString = Selectors.getSelector(element);
  const selector = $(locatorString);
  selector.click();
});

When(/^User clicks on "(.*)" element in case of devices$/, element => {
  const locatorString = Selectors.getSelector(element);
  const selector = $(locatorString);
  if (browser.capabilities.deviceName) {
    selector.scrollIntoView();
    selector.click();
  }
});

When(/^User clicks on account "(.*)" for making payment$/, element => {
  if (element.includes('fromAccount1')) {
    const selector = $(
      `//*[contains(text(),'${global.accountAccount1}')]//parent::td//parent::tr/td[1]`,
    );
    if (browser.capabilities.browserName === 'safari') {
      browser.execute('arguments[0].click();', selector);
    }
    if (browser.capabilities.deviceName) {
      selector.scrollIntoView();
      browser.execute('arguments[0].click();', selector);
    } else {
      selector.click();
    }
  } else {
    const selector = $(
      `//*[contains(text(),'${global.accountAccount2}')]//parent::td//parent::tr/td[1]/button`,
    );
    if (browser.capabilities.browserName === 'safari') {
      selector.waitForDisplayed(10000);
      browser.execute('arguments[0].click();', selector);
    }
    if (browser.capabilities.deviceName) {
      selector.scrollIntoView();
      browser.execute('arguments[0].click();', selector);
    } else {
      selector.click();
    }
  }
});

When(
  /^User selects the payee "(.*)" from "(.*)" of page$/,
  (expectedText, element) => {
    let flag = false;
    let actualText: string;
    let expectedvalue = expectedText;
    const locatorString = Selectors.getSelector(element);
    const parentselector = $$(locatorString);
    expectedvalue = Selectors.getData(expectedText);
    for (let index = 0; index < parentselector.length; index += 1) {
      actualText = parentselector[index].getText();
      if (expectedvalue.toString() === actualText) {
        parentselector[index].click();
        flag = true;
        break;
      }
    }
    if (flag === false) assert.fail();
  },
);

Then(/^User is verifying the element is displayed on the page$/, () => {
  const selector = $(`//p[text()='${global.expectedValue}']`);
  selector.waitForDisplayed();
  const isVisible = selector.isDisplayed();
  assert.equal(isVisible, true);
});

Then(/^User is verifying the saved value is displayed on the page$/, () => {
  const val = savedValueList.get(accountNum1);
  const selector = $(`//p[text()='${val}']`);
  selector.waitForDisplayed();
  const isVisible = selector.isDisplayed();
  assert.equal(isVisible, true);
  selector.click();
});

Then(
  /^User is verifying "(.*)" month year value "(.*)" text of page is prepopulated with CurrentMonthYear$/,
  (element, value) => {
    const locatorString = Selectors.getSelector(element);
    const selector = $(locatorString);
    let actualText = selector.getValue();
    if (actualText == null) {
      actualText = selector.getText();
    }
    let currentYear = currentDate.getFullYear();
    let currentMonth;
    if (value === 'decrease') {
      currentMonth = currentDate.getMonth() - 1;
    } else {
      currentMonth = currentDate.getMonth() + 1;
    }
    if (currentMonth === -1) {
      currentYear -= 1;
    } else if (currentMonth === 12) {
      currentYear += 1;
    }
    let monthText;
    switch (currentMonth) {
      case 0:
        monthText = 'January';
        break;
      case 1:
        monthText = 'February';
        break;
      case 2:
        monthText = 'March';
        break;
      case 3:
        monthText = 'April';
        break;
      case 4:
        monthText = 'May';
        break;
      case 5:
        monthText = 'June';
        break;
      case 6:
        monthText = 'July';
        break;
      case 7:
        monthText = 'August';
        break;
      case 8:
        monthText = 'September';
        break;
      case 9:
        monthText = 'October';
        break;
      case 10:
        monthText = 'November';
        break;
      default:
        monthText = 'December';
        break;
    }
    const expectedText = `${monthText} ${currentYear}`;
    assert.equal(actualText, expectedText);
  },
);

Then(
  /^User is verifying year value "(.*)" text of page is prepopulated with CurrentYear and saved in "(.*)"$/,
  (element, currentYearValue) => {
    const locatorString = Selectors.getSelector(element);
    const selector = $(locatorString);
    let actualText = selector.getValue();
    if (actualText == null) {
      actualText = selector.getText();
    }
    const expectedText = currentDate.getFullYear();
    assert.equal(actualText, expectedText);
    savedValueList.set(currentYearValue, actualText);
  },
);

Then(
  /^User is verifying the current year "(.*)" of page is displayed in dropdown$/,
  element => {
    let locatorString = Selectors.getSelector(element);
    locatorString = locatorString.replace(
      '##currentYear##',
      currentDate.getFullYear(),
    );
    const selector = $(locatorString);
    let actualText = selector.getValue();
    if (actualText == null) {
      actualText = selector.getText();
    }
    const expectedText = currentDate.getFullYear();
    assert.equal(actualText, expectedText);
  },
);

Then(
  /^User is verifying the new current year "(.*)" of page is not displayed in dropdown$/,
  element => {
    let locatorString = Selectors.getSelector(element);
    locatorString = locatorString.replace(
      '##currentYear##',
      currentDate.getFullYear(),
    );
    const selector = $(locatorString);
    let actualText = selector.getValue();
    if (actualText == null) {
      actualText = selector.getText();
    }
    const expectedText = currentDate.getFullYear();
    assert.notEqual(actualText, expectedText);
  },
);

Then(
  /^User verifies the previous year value of "(.*)" contains text as "(.*)"$/,
  (element, previousYearValue) => {
    const locatorString = Selectors.getSelector(element);
    const selector = $(locatorString);
    let actualText = selector.getValue();
    if (actualText == null) {
      actualText = selector.getText();
    }
    const expectedText = currentDate.getFullYear() - 1;
    assert.equal(actualText, expectedText);
    savedValueList.set(previousYearValue, actualText);
  },
);

Then(/^User should be navigated to "(.*)" of page$/, element => {
  const locatorString = Selectors.getSelector(element);
  const selector = $(locatorString);
  selector.waitForDisplayed();
  const isVisible = selector.isDisplayed();
  assert.equal(isVisible, true);
});

Then(/^User is verifying the "(.*)" of page is displayed$/, element => {
  const locatorString = Selectors.getSelector(element);
  const selector = $(locatorString);
  selector.scrollIntoView();
  selector.waitForDisplayed();
  const isVisible = selector.isDisplayed();
  assert.equal(isVisible, true);
});

Then(/^User is verifying the value "(.*)" is displayed$/, element => {
  const locatorString = Selectors.getSelector(element);
  const selectorValue = $$(locatorString);
  // eslint-disable-next-line no-plusplus
  for (let index = 0; index < selectorValue.length; index++) {
    const elementISA = selectorValue[index].getText();
    if (elementISA === '') {
      break;
    }
  }
});

Then(/^User is verifying the "(.*)" of page is clickable$/, element => {
  const locatorString = Selectors.getSelector(element);
  const selector = $(locatorString);
  selector.waitForClickable();
  const isVisible = selector.isClickable();
  assert.equal(isVisible, true);
});

Then(/^User is verifying the "(.*)" is grater than zero$/, element => {
  const locatorString = Selectors.getSelector(element);
  const selector = $(locatorString);
  selector.waitForDisplayed();
  const actualText = selector.getText().substr(0, 3);
  assert.notEqual(actualText, 0);
});

Then(/^User is verifying the "(.*)" value is not blank$/, element => {
  const locatorString = Selectors.getSelector(element);
  const selector = $(locatorString);
  selector.waitForDisplayed();
  const isVisible = selector.getText();
  assert.equal(isVisible.length > 0, true);
});

Then(/^User is verifying the "(.*)" of page is not displayed$/, element => {
  const locatorString = Selectors.getSelector(element);
  const selector = $(locatorString);
  assert.isNotTrue(selector.isDisplayed());
});

Then(
  /^User matching the "(.*)" data of page with "(.*)" for "(.*)"$/,
  (tableLocator, testDataFile, dataTobeChecked) => {
    const locatorString = Selectors.getSelector(tableLocator);
    const testDataObject = testData.getData(testDataFile);
    const selector = $$(locatorString);
    let tableData = '';
    for (let i = 0; i < selector.length; i += 1) {
      tableData += `${selector[i].getText()} `;
    }
    // eslint-disable-next-line no-restricted-syntax
    for (const actualData of testDataObject[dataTobeChecked]) {
      expect(tableData).to.include(actualData);
    }
  },
);

Then(/^User is verifying the "(.*)" text of page is empty$/, element => {
  const locatorString = Selectors.getSelector(element);
  const selector = $(locatorString);
  const actualText = selector.getText();
  assert.equal(actualText, '');
});

Then(
  /^User is verifying the "(.*)" text of page is prepopulated with CurrentDate$/,
  element => {
    const locatorString = Selectors.getSelector(element);
    const selector = $(locatorString);
    let actualText = selector.getValue();
    if (actualText == null) {
      actualText = selector.getText();
    }
    const expectedText = format(currentDate, 'dd/MM/yyyy');
    assert.equal(actualText, expectedText);
  },
);

Then(/^User maximize windows$/, () => {
  browser.maximizeWindow();
});

Then(/^User is verifying the "(.*)" as today date$/, element => {
  const locatorString = Selectors.getSelector(element);
  const selector = $(locatorString);
  const actualText = selector.getText();
  const expectedText = date.getTodayDateInFormat();
  assert.equal(actualText, expectedText);
});

Then(
  /^User is verifying the "(.*)" as today date in printable format$/,
  element => {
    const locatorString = Selectors.getSelector(element);
    const selector = $(locatorString);
    const actualText = selector.getText();
    assert.equal(actualText, format(currentDate, 'DD/MM/YY'));
  },
);

When(/^User enters "(.*)" in "(.*)" of page$/, (setValue, element) => {
  const locatorString = Selectors.getSelector(element);
  const selector = $(locatorString);
  let inputValue = setValue;
  inputValue = Selectors.getData(setValue);
  browser.setTimeout({ implicit: 5000 });
  selector.setValue(inputValue.trim());
  browser.pause(2000);
});

When(
  /^User enters random "(.*)" in "(.*)" of page$/,
  (accountNum1, element) => {
    const locatorString = Selectors.getSelector(element);
    const selector = $(locatorString);
    const setAccountRef =
      accountNum1 + Math.floor(Math.random() * (30 - 2 + 1)) + 2;
    const accountNum2 = Selectors.getData(setAccountRef);
    selector.setValue(accountNum2);
    browser.setTimeout({ implicit: 5000 });
    selector.setValue(accountNum2.trim());
    browser.pause(2000);
  },
);

When(/^User verifying that "(.*)" is selected$/, element => {
  const locatorString = Selectors.getSelector(element);
  const selector = $(locatorString);
  assert.equal(selector.isSelected(), true);
});

When(/^User checking that the tab "(.*)" is selected$/, element => {
  const locatorString = Selectors.getSelector(element);
  const selector = $(locatorString);
  assert.equal(selector.getAttribute('aria-selected'), 'true');
});

When(
  /^User enters password in "(.*)" and "(.*)" of page$/,
  (element1, element2) => {
    const locatorString1 = Selectors.getSelector(element1);
    const selector1 = $(locatorString1);
    const locatorString2 = Selectors.getSelector(element2);
    const selector2 = $(locatorString2);
    const setValue = `Reset${randGenerator.randomNumeric(6)}`;
    const inputValue = Selectors.getData(setValue);
    selector1.setValue(inputValue.trim());
    selector2.setValue(inputValue.trim());
    browser.pause(2000);
  },
);

When(
  /^User enters generated "(.*)" in "(.*)" of page$/,
  (setValue, element) => {
    const locatorString = Selectors.getSelector(element);
    const selector = $(locatorString);
    let inputValue;
    if (setValue === 'username') {
      inputValue = global.username;
    } else if (setValue === 'password') {
      inputValue = global.password;
    } else if (setValue === 'otp') {
      inputValue = global.otp;
    }
    selector.click();
    for (let index = 0; index < 18; index += 1) {
      browser.keys('\uE003');
    }
    for (let index = 0; index < 18; index += 1) {
      browser.keys('\uE017');
    }
    selector.setValue(inputValue.trim());
    browser.pause(2000);
  },
);

When(
  /^User clears and enters "(.*)" in "(.*)" of page$/,
  (setValue, element) => {
    const locatorString = Selectors.getSelector(element);
    const selector = $(locatorString);

    let inputValue = setValue;
    inputValue = Selectors.getData(setValue);
    let elementtextval: string;
    if (inputValue.includes('[Random')) {
      const randValue = inputValue.includes('[RandomString')
        ? randGenerator.randomString(5)
        : randGenerator.randomNumeric(5);
      elementtextval = inputValue.replace(/\[Random(.*?)\]/i, randValue);
    } else {
      elementtextval = inputValue;
    }

    selector.click();
    for (let index = 0; index < 18; index += 1) {
      browser.keys('\uE003');
    }
    for (let index = 0; index < 18; index += 1) {
      browser.keys('\uE017');
    }
    browser.pause(1000);
    selector.setValue(elementtextval.trim());
  },
);

When(/^User enters amount "(.*)" in "(.*)" of page$/, (setValue, element) => {
  const locatorString = Selectors.getSelector(element);
  const selector = $(locatorString);
  selector.addValue(setValue.trim());
});

Then(
  /^User is verifying the "(.*)" text of page is prepopulated as "(.*)"$/,
  (element, expectedText) => {
    const expectedvalue = Selectors.getData(expectedText);
    const locatorString = Selectors.getSelector(element);
    const selector = $(locatorString);
    const actualText = selector.getValue();
    assert.equal(actualText, expectedvalue);
  },
);

Then(
  /^User is verifying amount "(.*)" text of page is prepopulated as "(.*)"$/,
  (element, expectedText) => {
    const locatorString = Selectors.getSelector(element);
    const selector = $(locatorString);
    const actualText = selector.getValue();
    assert.equal(actualText, expectedText);
  },
);

Then(/^User waits for 10 secs$/, () => {
  browser.pause(10000);
});

Then(/^User waits for "(.*)" secs$/, seconds => {
  browser.pause(seconds * 1000);
});

When(
  /^User takes the count of "(.*)" as "(.*)"$/,
  (element, lengthBankAccount) => {
    const locatorString = Selectors.getSelector(element);
    const selector = $$(locatorString);
    const { length } = selector;
    savedValueList.set(lengthBankAccount, length);
  },
);

When(
  /^User takes the text of the "(.*)" and saves as "(.*)"$/,
  (element, accountNum1) => {
    const locatorString = Selectors.getSelector(element);
    const selector = $(locatorString);
    const accountNumText = selector.getText();
    savedValueList.set(accountNum1, accountNumText);
  },
);

When(
  /^User verifies the count of "(.*)" as "(.*)"$/,
  (element, lengthBankAccount) => {
    const locatorString = Selectors.getSelector(element);
    const selector = $$(locatorString);
    const { length } = selector;
    const value = savedValueList.get(lengthBankAccount);
    assert.equal(length, value);
  },
);

When(
  /^User verifies the value of "(.*)" contains text as "(.*)"$/,
  (element, accountNum1) => {
    const locatorString = Selectors.getSelector(element);
    const selector = $(locatorString);
    const AccountNumtext = selector.getText();
    const value = savedValueList.get(accountNum1);
    assert.include(AccountNumtext, value);
  },
);

When(
  /^User verifies the accessible statement value of "(.*)" contains text as "(.*)"$/,
  (element, savedAccessOptionValue) => {
    const locatorString = Selectors.getSelector(element);
    const selector = $(locatorString);
    const AccountNumtext = selector.getText();
    const value = savedValueList.get(savedAccessOptionValue);
    assert.include(AccountNumtext, value);
  },
);

Then(
  /^User verifies the custom value of "(.*)" contains text as "(.*)"$/,
  (element, customText) => {
    const locatorString = Selectors.getSelector(element);
    const selector = $(locatorString);
    const customValueText = selector.getText();
    const value = Selectors.getData(customText);
    assert.include(customValueText, value);
  },
);

// Then(
//   /^User verifies the display custom value of "(.*)" not contains text as "(.*)"$/,
//   (element, customText) => {
//     const locatorString = Selectors.getSelector(element);
//     const selector = $(locatorString);
//     const customValueText = selector.getText();
//     const value = Selectors.getData(customText);
//     assert.(customValueText, value);
//   },
// );

When(
  /^User verifies the custom date value of "(.*)" contains text as "(.*)"$/,
  (element, accountNum1) => {
    const locatorString = Selectors.getSelector(element);
    const selector = $(locatorString);
    const customValueText = selector.getText();
    const value = savedValueList.get(accountNum1);
    assert.include(customValueText, value);
  },
);

When(
  /^User is verifying the custom "(.*)" text as "(.*)"$/,
  (element, accountNum1) => {
    const locatorString = Selectors.getSelector(element);
    const selector = $(locatorString);
    const customValueText = selector.getText();
    const value = savedValueList.get(accountNum1);
    assert.equal(customValueText, value);
  },
);

When(
  /^User click on calender "(.*)" and "(.*)" new date and click on "(.*)" of page$/,
  (element, selectDate, Okbtn) => {
    const locatorString = Selectors.getSelector(element);
    const selector = $(locatorString);
    const locatorStringelementtwo = Selectors.getSelector(selectDate);
    const locatorStringOkbtn = Selectors.getSelector(Okbtn);
    const Okbutton = $(locatorStringOkbtn);
    const Expecteddate = date.getDate(35);
    const isdateEnable = locatorStringelementtwo.replace('date', Expecteddate);
    const selectfuturedate = $(isdateEnable);
    for (let i = 0; i < 3; i += 1) {
      if (i === 1) {
        selectfuturedate.click();
        Okbutton.click();
      } else {
        selector.click();
        browser.pause(1000);
      }
    }
  },
);

Then(/^User enter "(.*)"$/, element => {
  const locatorString = Selectors.getSelector(element);
  const selector = $(locatorString);
  selector.setValue(5000);
});

When(
  /^User is on screen resolution width "([^"]*)" and height "([^"]*)"$/,
  (width, height) => {
    const screenWidth = Number(width);
    const screenHeight = Number(height);
    browser.setWindowSize(screenWidth, screenHeight);
    browser.pause(2000);
  },
);

Then(/^User should be able to see the option "(.*)" of page$/, element => {
  const locatorString = Selectors.getSelector(element);
  const selector = $(locatorString);
  assert.equal(selector.isDisplayed(), true);
  assert.equal(selector.isEnabled(), true);
});

Then(
  /^User is verifying the "(.*)" format as "(.*)"$/,
  (element, expectedText) => {
    const locatorString = Selectors.getSelector(element);
    const regexstr = Selectors.getData(expectedText);
    const regexp = new RegExp(regexstr);
    const selector = $(locatorString);
    const actualText = selector.getText();
    assert.equal(
      true,
      regexp.test(actualText),
      `text found : ${actualText}Expected regext${regexstr}`,
    );
  },
);

Then(/^"(.*)" should match the baseline image$/, pageName => {
  assert.equal(
    browser.checkScreen(pageName, { disableCSSAnimation: true }),
    0,
    `${pageName} does not match`,
  );
});

When(/^User provide "(.*)" on "(.*)" on the page$/, (elementtext, element) => {
  const value: string = Selectors.getData(elementtext);
  let elementtextval: string;
  if (value.includes('[Random')) {
    const randValue = value.includes('[RandomString')
      ? randGenerator.randomString(5)
      : randGenerator.randomNumeric(5);
    elementtextval = value.replace(/\[Random(.*?)\]/i, randValue);
  } else {
    elementtextval = value;
  }
  const locatorString = Selectors.getSelector(element);
  const selector = $(locatorString);
  selector.scrollIntoView();
  selector.addValue(elementtextval);
});

When(
  /^User provide "(.*)" character on "(.*)" on the page$/,
  (elementtext, element) => {
    let elementtextval: string;
    if (elementtext.includes('space')) {
      elementtextval = '\ue00D';
    }
    const locatorString = Selectors.getSelector(element);
    const selector = $(locatorString);
    selector.addValue(elementtextval);
  },
);

Then(
  /^User is verifying the future date "(.*)" date as "(.*)" days from current date$/,
  (element, numOfDays) => {
    const locatorString = Selectors.getSelector(element);
    const selector = $(locatorString);
    let actualDate = selector.getValue();
    if (actualDate == null) {
      actualDate = selector.getText();
    }
    const expectedDate = date.getFutureFullDate(numOfDays);
    assert.equal(actualDate, format(expectedDate, 'DD/MM/YYYY'));
  },
);

Then(
  /^User is verifying the previous days "(.*)" date as "(.*)" days from current date$/,
  (element, daysvalue) => {
    const locatorString = Selectors.getSelector(element);
    const selector = $(locatorString);
    let actualDate = selector.getValue();
    let actualMonth;
    if (actualDate == null) {
      actualDate = selector.getText();
    }
    if (currentDate.getMonth() + 1 < 9) {
      actualMonth = `0${currentDate.getMonth() + 1}`;
    }
    let expectedDate;
    if (currentDate.getDate() < 4) {
      expectedDate = currentDate.getDate() + 20;
      actualMonth = `0${actualMonth - 1}`;
    } else {
      expectedDate = currentDate.getDate() - daysvalue;
    }
    assert.equal(
      actualDate,
      `${expectedDate}/${actualMonth}/${currentDate.getFullYear()}`,
    );
  },
);

Then(
  /^User is verifying the current date "(.*)" date as todays Date$/,
  element => {
    const locatorString = Selectors.getSelector(element);
    const selector = $(locatorString);
    let actualDate = selector.getValue();
    if (actualDate == null) {
      actualDate = selector.getText();
    }
    assert.equal(actualDate, format(currentDate, 'DD/MM/YYYY'));
  },
);

When(
  /^User is clicking on the previous date calender "(.*)""(.*)""(.*)" and selects "(.*)" as "(.*)" days back from current date$/,
  (
    prevMonthButton,
    nextMonthButton,
    currentMonth,
    dateToBeSelected,
    numOfDays,
  ) => {
    const nextMonthButtonlocatorString = Selectors.getSelector(nextMonthButton);
    const nextMonthButtonselector = $(nextMonthButtonlocatorString);

    const prevMonthButtonlocatorString = Selectors.getSelector(prevMonthButton);
    const prevMonthButtonselector = $(prevMonthButtonlocatorString);

    const currentMonthlocatorString = Selectors.getSelector(currentMonth);
    const currentMonthselector = $(currentMonthlocatorString);
    const currentMonthText = currentMonthselector.getText();
    const expectedDate = date.getPreviousFullDate(numOfDays);

    let numMonths = date.getMonthDifferenceBetweenDates(
      currentMonthText,
      expectedDate,
    );
    if (numMonths > 0) {
      for (let i = 0; i < numMonths; i += 1) {
        nextMonthButtonselector.click();
      }
    } else if (numMonths < 0) {
      numMonths = Math.abs(numMonths);
      for (let i = 0; i < numMonths; i += 1) {
        prevMonthButtonselector.click();
      }
    }
    browser.pause(2000);
    const dateToBeSelectedlocatorString = Selectors.getSelector(
      dateToBeSelected,
    );
    const previousDate = date.getpreviousDate(numOfDays);
    const isdateEnable = dateToBeSelectedlocatorString.replace(
      'replaceActualDate',
      previousDate,
    );
    const selectorPreviousdate = $(isdateEnable);
    selectorPreviousdate.click();
  },
);

When(
  /^User selects first record from "(.*)" of autocomplete list$/,
  element => {
    const locatorString = `${Selectors.getSelector(element)}`;
    const selector = $(locatorString);
    selector.waitForDisplayed(10000);
    selector.click();
  },
);

When(/^User selects first record from "(.*)" of select list$/, element => {
  const locatorString = `${Selectors.getSelector(element)}`;
  const selector = $(locatorString);
  selector.waitForDisplayed(10000);
  selector.selectByVisibleText('United Kingdom');
});

When(
  /^User provide invalid values on "(.*)" and see "(.*)" on the "(.*)" as message$/,
  (element, expectedData, expectedElement, dataTable) => {
    const arrayname = dataTable.raw();
    const data: string = Selectors.getData(arrayname[0][1])
      .toString()
      .split(',');

    const locatorString = Selectors.getSelector(element);

    const locatorString1 = Selectors.getSelector(expectedElement);

    for (let i = 0; i < data.length; i += 1) {
      let sendvalue = data[i];
      const selector = $(locatorString);
      if (sendvalue.localeCompare('EMPTY') === 0) {
        sendvalue = '';
      } else if (sendvalue.localeCompare('WHITESPACE') === 0) {
        sendvalue = ' ';
      }
      selector.setValue(sendvalue);
      browser.keys('\ue004');
      const expectedselector = $(locatorString1);
      const actualText = expectedselector.getText();
      const expectedDatatest = Selectors.getData(expectedData);
      assert.equal(actualText, expectedDatatest);
      browser.refresh();
    }
  },
);

// this step is used for verification of downloaded file and validate if size is greater than given size
Then(
  /^Verify file downloaded is of extension "(.*)" and name "(.*)" size greater than "(.*)" KB$/,
  (extension, filenameexpected, size) => {
    fs.readdir(downloadDir, (_err, files) => {
      const fileFound = true;
      files.forEach(file => {
        const filePath = path.join(downloadDir, file);
        const stats = fs.statSync(filePath);
        const createdTime = stats.birthtime;
        // const currentTime = new Date();
        const seconds = (currentDate.getTime() - createdTime.getTime()) / 1000;

        if (seconds < 3000) {
          assert.isAbove(
            stats.size * 1,
            size * 1,
            `FileSize should be greater than${stats.size}${size}`,
          );
          assert.equal(
            path.extname(filePath),
            extension,
            `Expected extension of file${extension}Actaul extension ${filePath.extname}`,
          );
          assert.equal(
            path.basename(filePath).startsWith(filenameexpected),
            true,
            `Expected file name of file${filenameexpected}Actaul File name ${path.basename(
              filePath,
            )}`,
          );

          fs.unlink(filePath, () => {
            // Do nothing
          });
        }
      });
      assert.equal(true, fileFound, 'Downloaded File found');
    });
  },
);

Then(/^User verify state of "(.*)" as "(.*)"$/, (element, elementState) => {
  const locatorString = Selectors.getSelector(element).toString();
  const selector = $(locatorString);
  const state = selector.isSelected();
  assert.equal(
    elementState,
    state.toString(),
    `Checkbox state is ${state} Actual State is ${elementState}`,
  );
});

// this step calculate page response time amd compare it against max time
When(/^Page response time was less than "(.*)" seconds$/, maxtime => {
  const start = browser.execute(
    'return window.performance.timing.navigationStart',
  );
  const domComplete = browser.execute(
    'return window.performance.timing.domComplete',
  );
  const frontendPerformanceCalc = (domComplete - start) / 1000;
  assert.isAbove(maxtime, frontendPerformanceCalc);
});

When(
  /^User added cookies name as "(.*)" and value as "(.*)"$/,
  (cookieName, cookieValue) => {
    browser.setCookies({ name: cookieName, value: cookieValue });
    browser.refresh();
  },
);

When(/^User switched on the beta flag if needed$/, () => {
  if (process.env.FLAG === 'beta') {
    browser.url('/view-account-overview?beta=true');
  }
});

Then(
  /^User is verifying the "(.*)" button as "(.*)"$/,
  (element, expectedText) => {
    const locatorString = Selectors.getSelector(element);
    const selector = $(locatorString);
    selector.waitForClickable(10000);
    const actualText = selector.isClickable();
    const actualTextToString = actualText.toString();
    assert.equal(actualTextToString, expectedText);
  },
);

Then(
  /^User is checking on calender "(.*)" and verifying "(.*)" days from current date of "(.*)" is "(.*)"$/,
  (nextMonthButton, numOfDays, dateToBeChecked) => {
    const nextMonthButtonlocatorString = Selectors.getSelector(nextMonthButton);
    const nextMonthButtonselector = $(nextMonthButtonlocatorString);
    const dateToBeCheckedlocatorString = Selectors.getSelector(dateToBeChecked);
    const futureDate = date.getFutureDate(numOfDays);
    const isdateEnable = dateToBeCheckedlocatorString.replace(
      'replaceActualDate',
      futureDate,
    );
    const selectorFuturedate = $(isdateEnable);
    const numMonths = date.getMonthDifference(numOfDays);
    if (numMonths > 0) {
      for (let i = 0; i < numMonths; i += 1) {
        nextMonthButtonselector.click();
        browser.pause(1000);
      }
    }
    assert.equal(true, selectorFuturedate.isDisplayed());
  },
);

When(
  /^User is checking on calender "(.*)" and selects "(.*)" as "(.*)" days from current date of "(.*)"$/,
  (nextMonthButton, dateToBeSelected, numOfDays) => {
    const nextMonthButtonlocatorString = Selectors.getSelector(nextMonthButton);
    const nextMonthButtonselector = $(nextMonthButtonlocatorString);
    const dateToBeSelectedlocatorString = Selectors.getSelector(
      dateToBeSelected,
    );
    const futureDate = date.getFutureDate(numOfDays);
    const isdateEnable = dateToBeSelectedlocatorString.replace(
      'replaceActualDate',
      futureDate,
    );
    const selectorFuturedate = $(isdateEnable);
    const numMonths = date.getMonthDifference(numOfDays);
    if (numMonths > 0) {
      for (let i = 0; i < numMonths; i += 1) {
        nextMonthButtonselector.click();
        browser.pause(1000);
      }
    }
    selectorFuturedate.click();
  },
);

Then(
  /^User is verifying the "(.*)" date as "(.*)" days from current date$/,
  (element, numOfDays) => {
    const locatorString = Selectors.getSelector(element);
    const selector = $(locatorString);
    let actualDate = selector.getValue();
    if (actualDate == null) {
      actualDate = selector.getText();
    }
    const expectedDate = date.getFutureFullDate(numOfDays);
    assert.equal(actualDate, format(expectedDate, 'DD MMMM YYYY'));
  },
);

Then(
  /^User is verifying the "(.*)" date as "(.*)" months from current date$/,
  (element, numOfDays) => {
    const locatorString = Selectors.getSelector(element);
    const selector = $(locatorString);
    let actualDate = selector.getValue();
    if (actualDate == null) {
      actualDate = selector.getText();
    }
    const expectedDate = date.getFutureMonthDate(numOfDays);
    assert.equal(actualDate, format(expectedDate, 'DD MMMM YYYY'));
  },
);

Then(
  /^User is verifying all "(.*)" "(.*)" is displayed as "(.*)" in row "(.*)"$/,
  (tableLocator, childElement, expectedText, rowNum) => {
    const locatorString = Selectors.getSelector(tableLocator);
    const selector = $$(locatorString);
    const childNode = childElement.split(',');
    const rowText = selector[rowNum - 1].getText();
    let expectedValue: string;
    for (let i = 0; i < childNode.length; i += 1) {
      expectedValue = Selectors.getData(`${expectedText}.${childNode[i]}`);
      assert.equal(true, rowText.includes(expectedValue));
    }
  },
);

Then(
  /^User is verifying all columns "(.*)" of "(.*)" is displayed as "(.*)" in row "(.*)"$/,
  (tableColumns, expectedText, rowNum) => {
    let expectedValues = expectedText;
    if (expectedText.includes('>>'))
      expectedValues = Selectors.getData(expectedText);

    const expectedValue = expectedValues.toString().split(',');

    const columnlocators = tableColumns.split(',');
    let selector: any;
    let actualText: any;
    let locatorString: any;
    for (let i = 0; i < columnlocators.length; i += 1) {
      locatorString = locators
        .getLocator(elementType, columnlocators[i])
        .toString();
      locatorString = locatorString.replace('rowNum', rowNum);
      selector = $(locatorString);
      actualText = selector.getText();
      assert.equal(actualText, expectedValue[i]);
    }
  },
);

Then(
  /^User is verifying the "(.*)" of "(.*)" is displayed in row "(.*)"$/,
  (element, rowNum) => {
    let locatorString = locators.getLocator(elementType, element).toString();
    locatorString = locatorString.replace('rowNum', rowNum);
    const selector = $(locatorString);
    const isVisible = selector.isDisplayed();
    assert.equal(isVisible, true);
  },
);

When(/^User clicks "(.*)" of "(.*)" in row "(.*)"$/, (element, rowNum) => {
  let locatorString = locators.getLocator(elementType, element).toString();
  locatorString = locatorString.replace('rowNum', rowNum);
  const selector = $(locatorString);
  selector.click();
});

Then(
  /^User is verifying the "(.*)" records as "(.*)"$/,
  (element, rowcount) => {
    const locatorString = Selectors.getSelector(element);
    const selector = $$(locatorString);
    browser.pause(2000);
    const tablesize = selector.length;
    const rowcount1 = Selectors.getData(rowcount);
    if (rowcount1.includes('moreThan')) {
      assert.isTrue(
        tablesize > parseInt(rowcount1, 10),
        `table size is greater than: ${parseFloat(rowcount1)}`,
      );
    } else if (rowcount1.includes('lessThan')) {
      assert.isTrue(
        tablesize < parseInt(rowcount1, 10),
        `table size is less than: ${parseFloat(rowcount1)}`,
      );
    } else if (tablesize === parseInt(rowcount1, 10)) {
      assert.equal(tablesize, rowcount1);
    } else {
      assert.fail(
        `table size is less or greater than: ${parseInt(rowcount1, 10)}`,
      );
    }
  },
);

Then(
  /^User is verifying the records sorted according to "(.*)" most recent$/,
  element => {
    const locatorString = Selectors.getSelector(element);
    const actualselector = $$(locatorString);
    const actualselectorvalue = actualselector.map(n => `${n.getText()}`);
    const sortedvalue = actualselectorvalue;
    sortedvalue.sort((a, b) => {
      return new Date(b) - new Date(a);
    });
    if (JSON.stringify(actualselectorvalue) === JSON.stringify(sortedvalue)) {
      assert.isTrue(true, 'Values are displayed in sorted order.');
    }
  },
);

Then(
  /^user verify the (.*) present in "(.*)" or "(.*)" of search result$/,
  (searchText, inelement, outelement) => {
    const text = Selectors.getData(searchText);
    const inelementLocator = Selectors.getSelector(inelement);
    const outelementLocator = Selectors.getSelector(outelement);
    const inWebelement = $$(inelementLocator);
    const outWebelement = $$(outelementLocator);
    const inText = inWebelement.map(n => `${n.getText()}`);
    const outText = outWebelement.map(n => `${n.getText()}`);

    inText.forEach((n, index) => {
      const out = outText[index];
      const inResult = parseFloat(text) === parseFloat(n.split(' ')[1]);
      const outResult = parseFloat(text) === parseFloat(out);
      assert.isTrue(
        inResult || outResult,
        `${text} is not present in row ${index + 1}`,
      );
    });
  },
);

Then(
  /^User is checking on date calender "(.*)""(.*)""(.*)" and verifying "(.*)" days from current date is "(.*)"$/,
  (
    prevMonthButton,
    nextMonthButton,
    currentMonth,
    numOfDays,
    dateToBeChecked,
  ) => {
    const nextMonthButtonlocatorString = Selectors.getSelector(nextMonthButton);
    const nextMonthButtonselector = $(nextMonthButtonlocatorString);

    const prevMonthButtonlocatorString = Selectors.getSelector(prevMonthButton);
    const prevMonthButtonselector = $(prevMonthButtonlocatorString);

    const currentMonthlocatorString = Selectors.getSelector(currentMonth);
    const currentMonthselector = $(currentMonthlocatorString);
    const currentMonthText = currentMonthselector.getText();
    const expectedDate = date.getFutureFullDate(numOfDays);

    let numMonths = date.getMonthDifferenceBetweenDates(
      currentMonthText,
      expectedDate,
    );

    if (numMonths > 0) {
      for (let i = 0; i < numMonths; i += 1) {
        nextMonthButtonselector.click();
      }
    } else if (numMonths < 0) {
      numMonths = Math.abs(numMonths);
      for (let i = 0; i < numMonths; i += 1) {
        prevMonthButtonselector.click();
      }
    }
    const dateToBeCheckedlocatorString = Selectors.getSelector(dateToBeChecked);
    const futureDate = date.getFutureDate(numOfDays);
    const isdateEnable = dateToBeCheckedlocatorString.replace(
      'replaceActualDate',
      futureDate,
    );
    const selectorFuturedate = $(isdateEnable);

    assert.equal(true, selectorFuturedate.isDisplayed());
  },
);

When(
  /^User is checking on date calender "(.*)""(.*)""(.*)" and selects "(.*)" as "(.*)" days from current date$/,
  (
    prevMonthButton,
    nextMonthButton,
    currentMonth,
    dateToBeSelected,
    numOfDays,
  ) => {
    const nextMonthButtonlocatorString = Selectors.getSelector(nextMonthButton);
    const nextMonthButtonselector = $(nextMonthButtonlocatorString);

    const prevMonthButtonlocatorString = Selectors.getSelector(prevMonthButton);
    const prevMonthButtonselector = $(prevMonthButtonlocatorString);

    const currentMonthlocatorString = Selectors.getSelector(currentMonth);
    const currentMonthselector = $(currentMonthlocatorString);
    const currentMonthText = currentMonthselector.getText();
    const expectedDate = date.getFutureFullDate(numOfDays);

    let numMonths = date.getMonthDifferenceBetweenDates(
      currentMonthText,
      expectedDate,
    );
    if (numMonths > 0) {
      for (let i = 0; i < numMonths; i += 1) {
        nextMonthButtonselector.click();
      }
    } else if (numMonths < 0) {
      numMonths = Math.abs(numMonths);
      for (let i = 0; i < numMonths; i += 1) {
        prevMonthButtonselector.click();
      }
    }
    browser.pause(2000);
    const dateToBeSelectedlocatorString = Selectors.getSelector(
      dateToBeSelected,
    );
    const futureDate = date.getFutureDate(numOfDays);
    const isdateEnable = dateToBeSelectedlocatorString.replace(
      'replaceActualDate',
      futureDate,
    );
    const selectorFuturedate = $(isdateEnable);
    selectorFuturedate.click();
  },
);

When(
  /^User selects the "(.*)" for "(.*)" from the dropdown of page$/,
  (miData, childelement) => {
    const midropdown = childelement.split('>>');
    const locatorString1 = Selectors.getSelector(midropdown[0].toString());
    const mi1 = $(locatorString1);
    const mi1position = parseInt(mi1.getText().replace(/[^0-9]/g, ''), 10);

    let mi = miData;
    if (mi.includes('>>')) mi = Selectors.getData(mi);

    const mi1Dropdown = $(Selectors.getSelector(midropdown[1].toString()));
    mi1Dropdown.selectByAttribute(
      'value',
      mi.substring(mi1position - 1, mi1position).toString(),
    );
  },
);

When(/^User selects the "(.*)" from the dropdowns of page$/, setValue => {
  browser.pause(2000);
  let mi;
  if (setValue.includes('.otp')) {
    mi = global.otp;
  } else {
    mi = Selectors.getData(setValue);
  }
  const mi1 = $(Selectors.getSelector('mi1lable').toString());
  const mi1position = parseInt(mi1.getText().replace(/[^0-9]/g, ''), 10);
  const mi1Dropdown = $(Selectors.getSelector('mi1Dropdown').toString());
  mi1Dropdown.selectByAttribute(
    'value',
    mi.substring(mi1position - 1, mi1position).toString(),
  );

  const mi2 = $(Selectors.getSelector('mi2lable').toString());
  const mi2position = parseInt(mi2.getText().replace(/[^0-9]/g, ''), 10);
  const mi2Dropdown = $(Selectors.getSelector('mi2Dropdown').toString());
  mi2Dropdown.selectByAttribute(
    'value',
    mi.substring(mi2position - 1, mi2position).toString(),
  );

  const mi3 = $(Selectors.getSelector('mi3lable').toString());
  const visible = mi3.isDisplayed();
  if (visible) {
    const mi3position = parseInt(mi3.getText().replace(/[^0-9]/g, ''), 10);
    const mi3Dropdown = $(Selectors.getSelector('mi3Dropdown').toString());
    mi3Dropdown.selectByAttribute(
      'value',
      mi.substring(mi3position - 1, mi3position).toString(),
    );
  }
});

When(/^User enters the "(.*)" in the mi textbox of page$/, setValue => {
  browser.pause(2000);
  let mi;
  if (setValue.includes('.otp')) {
    mi = global.otp;
  } else {
    mi = Selectors.getData(setValue);
  }
  const mi1 = $(Selectors.getSelector('mi1lable_Text').toString());
  const mi1position = parseInt(mi1.getText().replace(/[^0-9]/g, ''), 10);
  const mi1TextBox = $(Selectors.getSelector('mi1TextBox').toString());
  mi1TextBox.click();
  mi1TextBox.setValue(mi.substring(mi1position - 1, mi1position).toString());

  const mi2 = $(Selectors.getSelector('mi2lable_Text').toString());
  const mi2position = parseInt(mi2.getText().replace(/[^0-9]/g, ''), 10);
  const mi2TextBox = $(Selectors.getSelector('mi2TextBox').toString());
  mi2TextBox.click();
  mi2TextBox.setValue(mi.substring(mi2position - 1, mi2position).toString());

  const mi3 = $(Selectors.getSelector('mi3lable_Text').toString());
  const visible = mi3.isDisplayed();
  if (visible) {
    const mi3position = parseInt(mi3.getText().replace(/[^0-9]/g, ''), 10);
    const mi3TextBox = $(Selectors.getSelector('mi3TextBox').toString());
    mi3TextBox.click();
    mi3TextBox.setValue(mi.substring(mi3position - 1, mi3position).toString());
  }
});

When(/^User enters the "(.*)" in textbox of the page$/, setValue => {
  browser.pause(2000);
  let mi;
  if (setValue.includes('.otp')) {
    mi = global.otp;
  } else {
    mi = Selectors.getData(setValue);
  }
  const mi1 = $(Selectors.getSelector('textbox1lable').toString());
  const mi1position = parseInt(mi1.getText().replace(/[^0-9]/g, ''), 10);
  const mi1textbox = $(Selectors.getSelector('textbox1').toString());
  mi1textbox.click();
  for (let index = 0; index < 18; index += 1) {
    browser.keys('\uE003');
  }
  for (let index = 0; index < 18; index += 1) {
    browser.keys('\uE017');
  }
  mi1textbox.setValue(mi.substring(mi1position - 1, mi1position).toString());

  const mi2 = $(Selectors.getSelector('textbox2lable').toString());
  const mi2position = parseInt(mi2.getText().replace(/[^0-9]/g, ''), 10);
  const mi2textbox = $(Selectors.getSelector('textbox2').toString());
  mi2textbox.click();
  for (let index = 0; index < 18; index += 1) {
    browser.keys('\uE003');
  }
  for (let index = 0; index < 18; index += 1) {
    browser.keys('\uE017');
  }
  mi2textbox.setValue(mi.substring(mi2position - 1, mi2position).toString());

  const mi3 = $(Selectors.getSelector('textbox3lable').toString());
  const visible = mi3.isDisplayed();
  if (visible) {
    const mi3position = parseInt(mi3.getText().replace(/[^0-9]/g, ''), 10);
    const mi3textbox = $(Selectors.getSelector('textbox3').toString());
    mi3textbox.click();
    for (let index = 0; index < 18; index += 1) {
      browser.keys('\uE003');
    }
    for (let index = 0; index < 18; index += 1) {
      browser.keys('\uE017');
    }
    mi3textbox.setValue(mi.substring(mi3position - 1, mi3position).toString());
  }
});

Given(
  /^User logins to the application "(.*)" with "(.*)" and navigated to AOV page if not logged in$/,
  (url, custData) => {
    let username = `${custData}${'.username'}`;
    let password = `${custData} ${'.password'}`;
    let mi = `${custData} ${'.mi'}`;
    browser.url(url);
    // code is to collect test data
    const data = custData;
    if (data.includes('>>')) {
      username = Selectors.getData(username);
      password = Selectors.getData(password);
      mi = Selectors.getData(mi);
    }
    const logOffLink = $(
      locators.getLocator('cwaPages', 'logoffLink').toString(),
    );
    const login = logOffLink.isDisplayed();
    if (!login) {
      const loginLink = $(
        locators.getLocator('cwaPages', 'loginLink').toString(),
      );

      const loginButton = $(
        locators.getLocator('cwaPages', 'loginButton').toString(),
      );

      browser.url(url);
      loginLink.click();

      const name = locators.getLocator('cwaPages', 'usernameField').toString();
      const usernameField = $(name);
      const pass = locators.getLocator('cwaPages', 'passwordField').toString();
      const passwordField = $(pass);
      const cont = locators.getLocator('cwaPages', 'continueButton').toString();
      const continueButton = $(cont);
      usernameField.setValue(username);
      passwordField.setValue(password);
      loginButton.click();
      browser.pause(1000);

      // code is to collect mi positions
      const mi1 = $(locators.getLocator('cwaPages', 'mi1lable').toString());
      const mi1position = parseInt(mi1.getText().replace(/[^0-9]/g, ''), 10);
      const mi2 = $(locators.getLocator('cwaPages', 'mi2lable').toString());
      const mi2position = parseInt(mi2.getText().replace(/[^0-9]/g, ''), 10);
      const mi3 = $(locators.getLocator('cwaPages', 'mi3lable').toString());
      const mi3position = parseInt(mi3.getText().replace(/[^0-9]/g, ''), 10);
      const mi1Dropdown = $(
        locators.getLocator('cwaPages', 'mi1Dropdown').toString(),
      );
      mi1Dropdown.selectByAttribute(
        'value',
        mi.substring(mi1position - 1, mi1position).toString(),
      );

      const mi2Dropdown = $(
        locators.getLocator('cwaPages', 'mi2Dropdown').toString(),
      );
      mi2Dropdown.selectByAttribute(
        'value',
        mi.substring(mi2position - 1, mi2position).toString(),
      );

      const mi3Dropdown = $(
        locators.getLocator('cwaPages', 'mi3Dropdown').toString(),
      );
      mi3Dropdown.selectByAttribute(
        'value',
        mi.substring(mi3position - 1, mi3position).toString(),
      );
      continueButton.click();
      browser.pause(2000);
    }
  },
);

Then(
  /^User is verifying the Future Dated Payment "(.*)" text as "(.*)""(.*)""(.*)" days from current date$/,
  (element, expectedText, payeeName, numOfDays) => {
    let payeeNameValue = payeeName;
    if (payeeNameValue.includes('.'))
      payeeNameValue = Selectors.getData(payeeName);

    const expectedDate = date.getFutureFullDate(numOfDays);
    let expectedvalue = expectedText;
    expectedvalue = expectedvalue.replace('<PayeeName>', payeeNameValue);
    expectedvalue = expectedvalue.replace(
      '<Date>',
      format(expectedDate, 'DD MMMM YYYY'),
    );

    const locatorString = Selectors.getSelector(element);
    const selector = $(locatorString);
    let actualText = selector.getText();
    actualText = actualText.replace(/\n/g, '');

    assert.equal(actualText, expectedvalue);
  },
);

Then(/^User is able to fetch the account 1 "(.*)" details$/, element => {
  const locatorString = Selectors.getSelector(element);
  const selector = $(locatorString);
  global.accountAccount1 = selector.getText();
  const selector1 = $(
    `//*[contains(text(), '${global.accountAccount1}')]//parent::div//parent::div//*[@data-selector='txt_jarDetailsAvailableBalance']`,
  );
  global.accountAmount1 = selector1.getText().substring(1);
});

Then(/^User is able to fetch the account 2 "(.*)" details$/, element => {
  const locatorString = Selectors.getSelector(element);
  const selector = $(locatorString);
  global.accountAccount2 = selector.getText();
  const selector1 = $(
    `//*[contains(text(),'${global.accountAccount2}')]//parent::div//parent::div//*[@data-selector='txt_jarDetailsAvailableBalance']`,
  );
  global.accountAmount2 = selector1.getText().substring(1);
});

Then(/^User is verifying the balance of account 1$/, () => {
  const selector = $(
    `//*[contains(text(),'${global.accountAccount1}')]//parent::div//parent::div//*[@data-selector='txt_jarDetailsAvailableBalance']`,
  );
  const actualText = selector.getText();
  const actualAmount = actualText.substring(1);
  assert.equal(actualAmount, global.accountAmount1);
});

Then(/^User is verifying the balance of account 2$/, () => {
  const selector = $(
    `//*[contains(text(),'${global.accountAccount2}')]//parent::div//parent::div//*[@data-selector='txt_jarDetailsAvailableBalance']`,
  );
  const actualText = selector.getText();
  const actualAmount = actualText.substring(1);
  assert.equal(actualAmount, global.accountAmount2);
});

Then(/^User clicks on account2 viewTransaction of page$/, () => {
  const selector = $(
    `//*[contains(text(),'${global.accountAccount2}')]//parent::div/parent::div/following::div[@data-selector="btn_jarDetailsViewTransactions"][1]`,
  );
  selector.click();
});

When(/^User select (.*)from (.*) dropdown$/, (expectedText, element) => {
  let flag = false;
  let actualText: string;
  const locatorString = Selectors.getSelector(element);
  const parentselector = $$(locatorString);
  for (let index = 0; index < parentselector.length; index += 1) {
    actualText = parentselector[index].getText();
    if (expectedText.toString() === actualText) {
      parentselector[index].click();
      flag = true;
      break;
    }
  }
  if (flag === false) assert.fail();
});

Then(
  /^User is verifying that "(.*)" option is present in dropdown$/,
  expectedText => {
    const list = [];
    const listElements = $$('ul.MuiList-root li');
    listElements.forEach(element => {
      const text = element.getText();
      list.push(text);
    });
    assert.isTrue(
      list.includes(expectedText),
      `${expectedText} not present in dropdown, found these options ${list}`,
    );
    browser.refresh();
  },
);

Then(
  /^User verify that all transaction records should display from account has created with the bank to current date$/,
  async () => {
    const accountId = Selectors.getData('validAccountId');
    const accounts = await getGeneralAccountInfo(accountId);
    const accountOpeningDate =
      accounts.Data.Account[0].Details.AccountDetails.OpeningDate;
    const currDate = format(new Date().toLocaleString(), 'YYYY-MM-DDTHH:mm:ss');
    const accountOpeningDateTime = format(
      `${accountOpeningDate}`,
      'YYYY-MM-DDT00:00:00',
    );
    const transactions = await getTransactions(
      accountId,
      accountOpeningDateTime,
      currDate,
    );
    const transactionCount = transactions.Data.Total;
    const loadLocator = Selectors.getSelector('loadMore_button');
    const recordListLocator = Selectors.getSelector('transaction_row_list');
    const noMoreTransactionLocator = Selectors.getSelector(
      'no_more_transaction',
    );
    let loadMoreElement = await $(loadLocator);
    while (await loadMoreElement.isDisplayed()) {
      loadMoreElement = await $(loadLocator);
      await loadMoreElement.click();
      await wait(5000);
      const noMoreElement = await $(noMoreTransactionLocator);
      if (await noMoreElement.isDisplayed()) {
        break;
      }
      loadMoreElement = await $(loadLocator);
    }

    const recordListElements = await $$(recordListLocator);
    const recordCount = recordListElements.length;
    assert.isTrue(
      recordCount === transactionCount,
      `Transaction records not matching, expected ${transactionCount} records but got ${recordCount} records`,
    );
  },
);

Then(
  /^User is verifying transaction record should display from the last 7 days to current date$/,
  async () => {
    const accountId = Selectors.getData('validAccountId');
    const currDate = format(new Date().toLocaleString(), 'YYYY-MM-DDTHH:mm:ss');
    const fromBookingDateTime = format(
      subDays(new Date(), 7),
      'YYYY-MM-DDT00:00:00',
    );
    const transactions = await getTransactions(
      accountId,
      fromBookingDateTime,
      currDate,
    );
    const transactionCount = transactions.Data.Total;
    const loadLocator = Selectors.getSelector('loadMore_button');
    const recordListLocator = Selectors.getSelector('transaction_row_list');
    const noMoreTransactionLocator = Selectors.getSelector(
      'no_more_transaction',
    );
    let loadMoreElement = await $(loadLocator);
    while (await loadMoreElement.isDisplayed()) {
      loadMoreElement = await $(loadLocator);
      await loadMoreElement.click();
      await wait(5000);
      const noMoreElement = await $(noMoreTransactionLocator);
      if (await noMoreElement.isDisplayed()) {
        break;
      }
      loadMoreElement = await $(loadLocator);
    }
    const recordListElements = await $$(recordListLocator);
    const recordCount = recordListElements.length;
    assert.isTrue(
      recordCount === transactionCount,
      `Transaction records not matching, expected ${transactionCount} records but got ${recordCount} records`,
    );
  },
);

Then(
  /^User is verifying transaction record should display from Last month to current date/,
  async () => {
    const accountId = Selectors.getData('validAccountId');
    const currDate = format(new Date().toLocaleString(), 'YYYY-MM-DDTHH:mm:ss');

    const fromBookingDateTime = format(
      subMonths(new Date(), 1),
      'YYYY-MM-DDT00:00:00',
    );
    const transactions = await getTransactions(
      accountId,
      fromBookingDateTime,
      currDate,
    );
    const transactionCount = transactions.Data.Total;
    const loadLocator = Selectors.getSelector('loadMore_button');
    const recordListLocator = Selectors.getSelector('transaction_row_list');
    const noMoreTransactionLocator = Selectors.getSelector(
      'no_more_transaction',
    );
    let loadMoreElement = await $(loadLocator);
    while (await loadMoreElement.isDisplayed()) {
      loadMoreElement = await $(loadLocator);
      await loadMoreElement.click();
      await wait(5000);
      const noMoreElement = await $(noMoreTransactionLocator);
      if (await noMoreElement.isDisplayed()) {
        break;
      }
      loadMoreElement = await $(loadLocator);
    }
    const recordListElements = await $$(recordListLocator);
    const recordCount = recordListElements.length;
    assert.isTrue(
      recordCount === transactionCount,
      `Transaction records not matching, expected ${transactionCount} records but got ${recordCount} records`,
    );
  },
);
Then(
  /^User is verifying transaction record should display from last year to current date/,
  async () => {
    const accountId = Selectors.getData('validAccountId');
    const currDate = format(new Date().toLocaleString(), 'YYYY-MM-DDTHH:mm:ss');

    const fromBookingDateTime = format(
      subYears(new Date(), 1),
      'YYYY-MM-DDT00:00:00',
    );
    const transactions = await getTransactions(
      accountId,
      fromBookingDateTime,
      currDate,
    );
    const transactionCount = transactions.Data.Total;
    const loadLocator = Selectors.getSelector('loadMore_button');
    const recordListLocator = Selectors.getSelector('transaction_row_list');
    const noMoreTransactionLocator = Selectors.getSelector(
      'no_more_transaction',
    );
    let loadMoreElement = await $(loadLocator);
    while (await loadMoreElement.isDisplayed()) {
      loadMoreElement = await $(loadLocator);
      await loadMoreElement.click();
      await wait(5000);
      const noMoreElement = await $(noMoreTransactionLocator);
      if (await noMoreElement.isDisplayed()) {
        break;
      }
      loadMoreElement = await $(loadLocator);
    }
    const recordListElements = await $$(recordListLocator);
    const recordCount = recordListElements.length;
    assert.isTrue(
      recordCount === transactionCount,
      `Transaction records not matching, expected ${transactionCount} records but got ${recordCount} records`,
    );
  },
);

Then(
  /^User is verifying the transaction record should display from selected "(.*)" till the current date$/,
  async startDate => {
    const accountId = Selectors.getData('validAccountId');
    const currDate = format(new Date(), 'YYYY-MM-DDTHH:mm:ss');
    const fromBookingDateTime = format(
      date.converter(startDate),
      'YYYY-MM-DDTHH:mm:ss',
    );

    const transactions = await getTransactions(
      accountId,
      fromBookingDateTime,
      currDate,
    );
    const transactionCount = transactions.Data.Total;
    const loadLocator = Selectors.getSelector('loadMore_button');
    const recordListLocator = Selectors.getSelector('transaction_row_list');
    const noMoreTransactionLocator = Selectors.getSelector(
      'no_more_transaction',
    );
    let loadMoreElement = await $(loadLocator);
    while (await loadMoreElement.isDisplayed()) {
      loadMoreElement = await $(loadLocator);
      await loadMoreElement.click();
      await wait(5000);
      const noMoreElement = await $(noMoreTransactionLocator);
      if (await noMoreElement.isDisplayed()) {
        break;
      }
      loadMoreElement = await $(loadLocator);
    }
    const recordListElements = await $$(recordListLocator);
    const recordCount = recordListElements.length;
    assert.isTrue(
      recordCount === transactionCount,
      `Transaction records not matching, expected ${transactionCount} records but got ${recordCount} records`,
    );
  },
);

Then(
  /^User is verifying the transaction record should display from account creation with the bank till the selected "(.*)"$/,
  async endDate => {
    browser.pause(3000);
    const accountId = Selectors.getData('validAccountId');
    const accounts = await getGeneralAccountInfo(accountId);

    const accountOpeningDate =
      accounts.Data.Account[0].Details.AccountDetails.OpeningDate;
    const toBookingDate = format(
      date.converter(endDate),
      'YYYY-MM-DDT23:59:59',
    );
    const accountOpeningDateTime = `${accountOpeningDate}T00:00:00`;
    const transactions = await getTransactions(
      accountId,
      accountOpeningDateTime,
      toBookingDate,
    );
    const transactionCount = transactions.Data.Total;
    const loadLocator = Selectors.getSelector('loadMore_button');
    const recordListLocator = Selectors.getSelector('transaction_row_list');
    const noMoreTransactionLocator = Selectors.getSelector(
      'no_more_transaction',
    );
    let loadMoreElement = await $(loadLocator);
    while (await loadMoreElement.isDisplayed()) {
      loadMoreElement = await $(loadLocator);
      await loadMoreElement.click();
      await wait(5000);
      const noMoreElement = await $(noMoreTransactionLocator);
      if (await noMoreElement.isDisplayed()) {
        break;
      }
      loadMoreElement = await $(loadLocator);
    }
    const recordListElements = await $$(recordListLocator);
    const recordCount = recordListElements.length;
    assert.isTrue(
      recordCount === transactionCount,
      `Transaction records not matching, expected ${transactionCount} records but got ${recordCount} records`,
    );
  },
);

Then(
  /^User is verifying the transaction record should display from selected "(.*)" till the selected "(.*)"$/,
  async (startDate, endDate) => {
    browser.pause(3000);
    const accountId = Selectors.getData('validAccountId');
    const fromBookingDateTime = format(
      date.converter(startDate),
      'YYYY-MM-DDTHH:mm:ss',
    );
    const toBookingDate = format(
      date.converter(endDate),
      'YYYY-MM-DDT23:59:59',
    );

    const transactions = await getTransactions(
      accountId,
      fromBookingDateTime,
      toBookingDate,
    );
    const transactionCount = transactions.Data.Total;
    const loadLocator = Selectors.getSelector('loadMore_button');
    const recordListLocator = Selectors.getSelector('transaction_row_list');
    const noMoreTransactionLocator = Selectors.getSelector(
      'no_more_transaction',
    );
    let loadMoreElement = await $(loadLocator);
    while (await loadMoreElement.isDisplayed()) {
      loadMoreElement = await $(loadLocator);
      await loadMoreElement.click();
      await wait(5000);
      const noMoreElement = await $(noMoreTransactionLocator);
      if (await noMoreElement.isDisplayed()) {
        break;
      }
      loadMoreElement = await $(loadLocator);
    }
    const recordListElements = await $$(recordListLocator);
    const recordCount = recordListElements.length;
    assert.isTrue(
      recordCount === transactionCount,
      `Transaction records not matching, expected ${transactionCount} records but got ${recordCount} records`,
    );
  },
);

Then(
  /^User verified the transaction description "(.*)" is (.*)-(.*)$/,
  (element, payeeName, reference) => {
    const locatorString = Selectors.getSelector(element);
    const descriptionElemnet = $(locatorString);
    const descriptionText = descriptionElemnet.getText();
    const expectedPayeeName = Selectors.getData(payeeName);
    const expectedreference = Selectors.getData(reference);
    const actualpayeeName = descriptionText.split(' - ')[0].toString();
    const actualrefrence = descriptionText.split(' - ')[1].toString();
    assert.isTrue(
      actualpayeeName === expectedPayeeName &&
        actualrefrence === expectedreference,
      `payeename or refrence is  not matching, expected ${expectedPayeeName} payee but got ${actualpayeeName} and
		expected ${expectedreference} refrence but got ${actualrefrence} `,
    );
  },
);

Then(
  /^User select "(.*)" option in "(.*)" dropdown$/,
  (expectedText, element) => {
    let flag = false;
    const dropdownLocator = Selectors.getSelector(element);
    const dropdownElement = $(dropdownLocator);
    dropdownElement.click();
    const listElements = $$(`ul[class^='MuiList-root'] li`);
    for (let index = 0; index < listElements.length; index += 1) {
      const text = listElements[index].getText();
      if (text === expectedText) {
        listElements[index].click();
        flag = true;
        break;
      }
      browser.pause(3000);
    }
    assert.isTrue(
      flag,
      `Dropdown option ${expectedText} not found in dropdown list`,
    );
  },
);

Then(/^user set the session storage$/, () => {
  if (process.env.ENV === 'local') {
    browser.execute("sessionStorage.setItem('_cid', 'amit')");
    browser.execute("sessionStorage.setItem('_at', 'amit')");
    browser.execute("sessionStorage.setItem('runtime-brand', 'IF')");
    browser.execute("sessionStorage.setItem('WIP', 'true')");
    browser.pause(2000);
    browser.refresh();
    browser.pause(2000);
    browser.refresh();
  }
});

Then(/^User set the CPR handled session storage$/, () => {
  browser.execute("sessionStorage.setItem('_handledCPR', 'true')");
  browser.pause(2000);
  browser.refresh();
});

When(/^User is setting the flag value if required$/, () => {
  browser.pause(10000);
  if (process.env.FLAG === 'beta') {
    // browser.setSessionStorage('beta', 'true');
    browser.url('/view-account-overview?beta=true');
  } else if (process.env.FLAG === 'wip') {
    browser.url('/view-account-overview?wip=true');
  }
});

Then(
  /^User is verifying the table record for "(.*)" as "(.*)"$/,
  (element, expectedText) => {
    const locatorString = Selectors.getSelector(element);
    const selector = $(locatorString);
    const actualText = selector.getText();
    const expectedText1 = Selectors.getData(expectedText);
    // if (expectedText.includes('>>'))
    const expecteddata = expectedText1.split(',');
    for (let i = 0; i < expecteddata.length; i += 1) {
      if (actualText.includes(expecteddata[i])) {
        assert.isTrue(
          true,
          `${actualText} record is having expected values: ${expecteddata[i]}`,
        );
      } else {
        assert.fail(
          `${actualText} record is not having expected values: ${expecteddata[i]}`,
        );
      }
    }
  },
);

Then(
  /^User is validate the table record for "(.*)" as "(.*)" with seperator "(.*)"$/,
  (element, expectedText, seperator) => {
    const locatorString = Selectors.getSelector(element);
    const selector = $(locatorString);
    const actualText = selector.getText();
    const expectedText1 = Selectors.getData(expectedText);
    // if (expectedText.includes('>>'))
    const expecteddata = expectedText1.split(seperator);
    for (let i = 0; i < expecteddata.length; i += 1) {
      if (actualText.includes(expecteddata[i])) {
        assert.isTrue(
          true,
          `${actualText} record is having expected values: ${expecteddata[i]}`,
        );
      } else {
        assert.fail(
          `${actualText} record is not having expected values: ${expecteddata[i]}`,
        );
      }
    }
  },
);

When(/^User refresh the page$/, () => {
  browser.refresh();
});

Then(/^Amount will be reduced from debtor account$/, () => {
  global.accountAmount1 = (
    parseFloat(global.accountAmount1.replace(',', '')) - 0.01
  ).toFixed(2);
});

Then(/^Amount will be credited to creditor account$/, () => {
  global.accountAmount2 = (parseFloat(global.accountAmount2) + 0.01).toFixed(2);
});

When(/^User selects record of list$/, () => {
  browser.keys('\ue015');
  browser.keys('\ue007');
  browser.pause(2000);
});

Then(/^User is verifying the jarname "(.*)" text$/, element => {
  const expectedvalue = global.changeJarName;
  const locatorString = Selectors.getSelector(element);
  const selector = $(locatorString);

  const actualText = selector.getText();
  assert.equal(actualText, expectedvalue);
});

Then(
  /^User is verifying the "(.*)" name as (.*)$/,
  (element, txtCustomerName) => {
    const locatorString = Selectors.getSelector(element);
    const CustomerElemnet = $(locatorString);
    const CustomerElemnetText = CustomerElemnet.getText();
    const expectedCustomerName = Selectors.getData(txtCustomerName);
    const actualCustomerName = CustomerElemnetText.split(' ')[1];
    assert.isTrue(
      actualCustomerName === expectedCustomerName,
      `CustomerName is not matching, expected ${expectedCustomerName} customerName but got ${actualCustomerName}`,
    );
  },
);

//

When(
  /^User provide updated jarname "(.*)" for "(.*)" on "(.*)" on the page$/,
  (elementtext, key, element) => {
    const value: string = Selectors.getData(elementtext);
    let elementtextval: string;
    if (value.includes('[Random')) {
      const randValue = value.includes('[RandomString')
        ? randGenerator.randomString(6)
        : randGenerator.randomNumber(5);
      elementtextval = value.replace(/\[Random(.*?)\]/i, randValue);
    } else {
      elementtextval = value;
    }
    savedValueList.set(key, elementtextval);
    const locatorString = Selectors.getSelector(element);
    const selector = $(locatorString);
    //
    selector.addValue(elementtextval);
  },
);

Then(/^User is verifying the balance on "(.*)"$/, element => {
  const expectedText = global.accountAmount1;
  const locatorString = Selectors.getSelector(element);
  const selector = $(locatorString);

  const actualText = selector.getText();
  assert.equal(actualText, expectedText);
});

Then(
  /^User validates the "(.*)" of "(.*)" contains "(.*)"$/,
  (attribute, element, expectedText) => {
    let expectedvalue = expectedText;
    expectedvalue = Selectors.getData(expectedText);
    const locatorString = Selectors.getSelector(element);
    const selector = $(locatorString);
    const actualText = selector.getAttribute(attribute);
    assert.equal(
      true,
      actualText.includes(expectedvalue),
      `Error message not include expected message${expectedvalue}`,
    );
  },
);

Then(
  /^User selects the "(.*)" option from "(.*)" dropdown$/,
  (elementText, element) => {
    const locatorString = Selectors.getSelector(element);
    const selector = $(locatorString);
    const toBeSelectedValue = Selectors.getData(elementText);
    selector.selectByAttribute('value', toBeSelectedValue);
  },
);

Then(
  /^User selects value "(.*)" option from "(.*)" dropdown$/,
  (elementText, element) => {
    const locatorString = Selectors.getSelector(element);
    const selector = $(locatorString);
    const toBeSelectedValue = Selectors.getData(elementText);
    selector.selectByAttribute('value', toBeSelectedValue);
  },
);

Then(
  /^User selects the "(.*)" value from "(.*)" dropdown$/,
  (elementText, element) => {
    const locatorString = Selectors.getSelector(element);
    const selector = $(locatorString);
    selector.click();
    selector.selectByAttribute('value', elementText);
  },
);

Given(/^User reload the browser session$/, () => {
  browser.reloadSession();
});

Then(/^User is verifying that "(.*)" option is not displayed$/, element => {
  const locatorString = Selectors.getSelector(element);
  const selector = $(locatorString);
  assert.isNotTrue(
    selector.isDisplayed(),
    'Move to another Jar option is present',
  );
});
Then(
  /^User select "(.*)" option in "(.*)" dropdown with wait$/,
  (index, element) => {
    const dropdownLocator = Selectors.getSelector(element);
    const dropdownElement = $(dropdownLocator);
    dropdownElement.click();
    browser.pause(3000);
    dropdownElement.selectByIndex(index);
  },
);

When(/^User read current Gender value$/, () => {
  const locatorString = Selectors.getSelector('crpGenderValue');
  const selector = $(locatorString);
  genderCurrentValue = selector.getText();
});

When(
  /^User set the interest remittence destination account for "(.*)" with remitting interest account "(.*)"$/,
  async (acctID, remittingAcc) => {
    const accessToken = savedValueList.get('authToken');
    const accountID = Selectors.getData(acctID);
    const remittingAccount = Selectors.getData(remittingAcc);
    await setRemittenceAccount(accountID, accessToken, remittingAccount);
  },
);

function clickOnElement(locatorString) {
  const selector = $(locatorString);
  if (browser.capabilities.browserName === 'safari') {
    browser.execute('arguments[0].click();', selector);
  } else {
    selector.waitForDisplayed();
    browser.execute('arguments[0].click();', selector);
    browser.pause(2000);
  }
}

When(/^User select another gender value$/, () => {
  switch (genderCurrentValue) {
    case 'Male':
      changedGenderValue = 'Female';
      break;
    case 'Female':
      changedGenderValue = 'Non-binary';
      break;
    case 'Non-binary':
      changedGenderValue = 'Male';
      break;
    default:
      changedGenderValue = 'Male';
  }

  const locatorString = `//span[text()='${changedGenderValue}']`;
  const selector = $(locatorString);
  selector.click();
});

When(/^User see updated gender value in success message$/, () => {
  const locatorString = Selectors.getSelector('crpSuccessMSGGenderValue');
  const selector = $(locatorString);
  const successMessageCurrentValue = selector.getText();
  assert.isTrue(
    changedGenderValue === successMessageCurrentValue,
    'Updated gender value and success message gender value is not same',
  );
});

Then(/^User selects the stored value from "(.*)" dropdown$/, element => {
  const locatorString = Selectors.getSelector(element);
  const selector = $(locatorString);
  selector.selectByAttribute('value', global.expectedValue);
});

When(
  /^User provide the updated name "(.*)" on "(.*)" on the page$/,
  (elementtext, element) => {
    const value: string = Selectors.getData(elementtext);
    let elementtextval: string;
    if (value.includes('[Random')) {
      const randValue = value.includes('[RandomString')
        ? randGenerator.randomString(6)
        : randGenerator.randomString(5);
      elementtextval = value.replace(/\[Random(.*?)\]/i, randValue);
    } else {
      elementtextval = value;
    }
    global.changeJarName = elementtextval;
    const locatorString = Selectors.getSelector(element);
    const selector = $(locatorString);
    //
    selector.addValue(elementtextval);
  },
);

When(
  /^User provide the updated date "(.*)" on "(.*)" on the page$/,
  (enterVale, element) => {
    const locatorString = Selectors.getSelector(element);
    const selector = $(locatorString);
    let inputValue = enterVale;
    inputValue = Math.floor(Math.random() * (30 - 2 + 1)) + 2;
    selector.setValue(inputValue);
  },
);

When(
  /^User provide the updated month "(.*)" on "(.*)" on the page$/,
  (monthValue, element) => {
    const locatorString = Selectors.getSelector(element);
    const selector = $(locatorString);
    let inputValue = monthValue;
    inputValue = Math.floor(Math.random() * (12 - 2 + 1)) + 1;
    selector.setValue(inputValue);
  },
);

When(
  /^User provide the updated number "(.*)" on "(.*)" on the page$/,
  (elementtext, element) => {
    const locatorString = Selectors.getSelector(element);
    const selector = $(locatorString);
    let Mobilenumber = elementtext;
    Mobilenumber = Math.floor(1000 + Math.random() * 9000);
    selector.setValue(`778788${Mobilenumber}`);
  },
);

When(/^I change "(.*)" selection for "(.*)"$/, (element, elementText) => {
  let locatorString = Selectors.getSelector(element);
  locatorString = locatorString.replace('##replace##', elementText);
  const selector = $(locatorString);
  browser.execute('arguments[0].click();', selector);
});

When(/^User (?:uncheck|check) all "(.*)" checkboxes$/, element => {
  const locatorString = Selectors.getSelector(element);
  const selector = $$(locatorString);
  selector.forEach(testelement => {
    browser.execute('arguments[0].click();', testelement);
  });
  browser.pause(1000);
});

When(/^User is verifying "(.*)" is checked$/, element => {
  const locatorString = Selectors.getSelector(element);
  const selector = $(locatorString);
  assert.equal('true', selector.getAttribute('checked'));
});

When(/^User is verifying the element "(.*)" available on page$/, element => {
  const locatorString = Selectors.getSelector(element);
  const selector = $(locatorString);
  const isVisible = selector.isDisplayed();
  assert.equal(isVisible, true);
});

Then(/^User fetches the expected value from "(.*)"$/, element => {
  const locatorString = Selectors.getSelector(element);
  const selector = $(locatorString);
  global.expectedValue = selector.getValue();
});

Then(/^User fetches the expected text from "(.*)"$/, element => {
  const locatorString = Selectors.getSelector(element);
  const selector = $(locatorString);
  global.expectedValue = selector.getText();
});

Then(/^User fetches the expected interest rate from "(.*)"$/, element => {
  const locatorString = Selectors.getSelector(element);
  const selector = $(locatorString);
  const IntrestInfo = selector.getText().split('%');
  const InterestRate = IntrestInfo[0];
  global.expectedValue = InterestRate;
});

Then(
  /^User is verifying the expected value is same as actual value of "(.*)"$/,
  element => {
    const locatorString = Selectors.getSelector(element);
    const selector = $(locatorString);

    const actualValue = selector.getValue();
    assert.equal(actualValue, global.expectedValue);
  },
);

Then(
  /^User is verifying the expected text is same as actual text of "(.*)"$/,
  element => {
    const locatorString = Selectors.getSelector(element);
    const selector = $(locatorString);

    const actualValue = selector.getText();
    assert.equal(actualValue, global.expectedValue);
  },
);

Then(
  /^User is verifying the expected text "(.*)" is same as actual text of "(.*)"$/,
  (expectedText, element) => {
    const locatorString = Selectors.getSelector(element);
    const selector = $(locatorString);
    const actualValue = selector.getText();
    assert.equal(actualValue, expectedText);
  },
);

Then(/^User is verifying the updated jar name$/, () => {
  const updatedJar = savedValueList.get('updatedDasaLiteJarName');
  const locatorString = `//p[text()="${updatedJar}"]`;
  const locator = locatorString;
  const selector = $(locator);
  selector.waitForDisplayed();
  const isVisible = selector.isDisplayed();
  assert.equal(isVisible, true);
});

Then(/^User is updating new value of "(.*)"$/, element => {
  const newValue: any = actions.updatedValue(element);
  savedValueList.set('updatedValue', newValue);
});

Then(/^User is verifying the updated plan key date$/, () => {
  // let date = new Date();
  const month = [
    'Jan',
    'Feb',
    'Mar',
    'Apr',
    'May',
    'Jun',
    'Jul',
    'Aug',
    'Sep',
    'Oct',
    'Nov',
    'Dec',
  ];
  const newMonth = month[currentDate.getMonth() + 1];
  const year = currentDate.getFullYear();
  const expectedKeyDate = `1 ${newMonth} ${year}`;
  actions.saveDataForE2E('Details.DasaLite.KeyDate', expectedKeyDate);
  const locatorString = `//p[text()="${expectedKeyDate}"]`;
  const selector = $(locatorString);
  selector.waitForDisplayed();
  const isVisible = selector.isDisplayed();
  assert.equal(isVisible, true);
});

When(/^Colleague search customer by "(.*)" details$/, dataSetName => {
  let selector = Selectors.getSelector('Customer doesnt know button');
  actions.click(selector);
  const elmentfirstnamelocatorString = Selectors.getSelector(
    'First Name textbox',
  );
  const elmentfirstnameselector = $(elmentfirstnamelocatorString);
  const inputfirstNameValue = Selectors.getData(`${dataSetName}.FirstName`);
  elmentfirstnameselector.setValue(inputfirstNameValue.trim());

  const elmentlastnamelocatorString = Selectors.getSelector(
    'Last Name textbox',
  );
  const elmentlastnamelocatorStringselector = $(elmentlastnamelocatorString);
  const inputelmentlastnameValue = Selectors.getData(`${dataSetName}.LastName`);
  elmentlastnamelocatorStringselector.setValue(inputelmentlastnameValue.trim());

  const elmentfirstdatelocatorString = Selectors.getSelector('DOB Day');
  const elmentfirstdateselector = $(elmentfirstdatelocatorString);
  const inputelmentdateValue = Selectors.getData(`${dataSetName}.DOBDay`);
  elmentfirstdateselector.setValue(inputelmentdateValue.trim());

  const locatorelementmonthString = Selectors.getSelector('DOB Month');
  const locatorelementmonthStringselector = $(locatorelementmonthString);
  const inputmonthofyearValue = Selectors.getData(`${dataSetName}.DOBMonth`);
  locatorelementmonthStringselector.setValue(inputmonthofyearValue.trim());
  const elementyearlocatorString = Selectors.getSelector('DOB Year');
  const elementyearlocatorStringselector = $(elementyearlocatorString);
  const inputValue = Selectors.getData(`${dataSetName}.DOBYear`);
  elementyearlocatorStringselector.setValue(inputValue.trim());

  selector = Selectors.getSelector('Find Customer button');
  clickOnElement(selector);

  if (process.env.ENV !== 'local') {
    selector = Selectors.getSelector('FirstName Result Item');
    clickOnElement(selector);
  }
});

When(
  /^Colleague search customer by "(.*)" using "(.*)" customer details$/,
  (searchType, dataSetName) => {
    let locatorString = '';
    let elmentfirstnamelocatorString = '';

    switch (searchType) {
      case 'Plan Number':
      case 'PlanNumber':
        locatorString = Selectors.getSelector('Plan Number textbox');
        elmentfirstnamelocatorString = Selectors.getData(
          `${dataSetName}.PlanNumber`,
        );
        break;
      case 'Customer Ref':
      case 'CustomerRef':
      case 'Customer ID':
      case 'CustomerID':
        locatorString = Selectors.getSelector('Customer Ref textbox');
        elmentfirstnamelocatorString = Selectors.getData(
          `${dataSetName}.PlanNumber`,
        );
        break;
      default:
        break;
    }

    const elmentfirstnameselector = $(locatorString);
    elmentfirstnameselector.setValue(elmentfirstnamelocatorString.trim());

    const selector2 = Selectors.getSelector('Find Customer button');
    actions.click(selector2);

    if (process.env.ENV !== 'local') {
      const selector3 = Selectors.getSelector('FirstName Result Item');
      actions.click(selector3);
    }
  },
);

When(/^User press TAB key$/, () => {
  browser.keys('\ue004');
});

Then(/^User fetches the account information for "(.*)"$/, element => {
  const locatorString = Selectors.getSelector(element);
  const selector = $(locatorString);
  global.expectedValue = selector.getText().substring(1);
});

Then(
  /^User is verifying the amount is debited from the account "(.*)"$/,
  element => {
    const locatorString = Selectors.getSelector(element);
    const selector = $(locatorString);
    const actualValue = selector.getText().substring(1);
    assert.equal(
      parseFloat(actualValue),
      (parseFloat(global.expectedValue) - 0.01).toFixed(2),
    );
  },
);

When(/^User enter MI details of "(.*)" customer$/, setValue => {
  if (process.env.ENV !== 'local') {
    browser.pause(2000);
    const mi = Selectors.getData(setValue);
    const mi1 = $(Selectors.getSelector('mi1lable').toString());
    const mi1position = parseInt(mi1.getText().replace(/[^0-9]/g, ''), 10);
    const mi1Dropdown = $(Selectors.getSelector('mi1Dropdown').toString());
    mi1Dropdown.selectByAttribute(
      'value',
      mi.substring(mi1position - 1, mi1position).toString(),
    );

    const mi2 = $(Selectors.getSelector('mi2lable').toString());
    const mi2position = parseInt(mi2.getText().replace(/[^0-9]/g, ''), 10);
    const mi2Dropdown = $(Selectors.getSelector('mi2Dropdown').toString());
    mi2Dropdown.selectByAttribute(
      'value',
      mi.substring(mi2position - 1, mi2position).toString(),
    );

    const mi3 = $(Selectors.getSelector('mi3lable').toString());
    const visible = mi3.isDisplayed();
    if (visible) {
      const mi3position = parseInt(mi3.getText().replace(/[^0-9]/g, ''), 10);
      const mi3Dropdown = $(Selectors.getSelector('mi3Dropdown').toString());
      mi3Dropdown.selectByAttribute(
        'value',
        mi.substring(mi3position - 1, mi3position).toString(),
      );
    }

    const selector = Selectors.getSelector('continueButton');
    clickOnElement(selector);
  }
});

Then(/^User fetch the text from "(.*)"$/, element => {
  const locatorString = Selectors.getSelector(element);
  const selector = $(locatorString);
  global.expectedValue = selector.getText();
});

Then(
  /^User is verifying the amount is credited to the account "(.*)"$/,
  element => {
    const locatorString = Selectors.getSelector(element);
    const selector = $(locatorString);
    const actualValue = selector.getText();
    assert.equal(
      parseFloat(actualValue),
      (parseFloat(global.expectedValue) + 0.01).toFixed(2),
    );
  },
);

Then(
  /^User validate that "(.*)" element "(.*)" is "(.*)"$/,
  (element, attributeType, expectedText) => {
    const locatorString = Selectors.getSelector(element);
    const selector = $(locatorString);
    const actualText = selector.getAttribute(attributeType);
    assert.equal(
      true,
      actualText === expectedText,
      `Captures value ${actualText} is not equal to ${expectedText}`,
    );
  },
);

Then(/^User choose Bank to proceed$/, () => {
  let locatorString = '';
  if (process.env.BRAND === 'SJPB') {
    locatorString = Selectors.getSelector('SJPB Radio');
  } else {
    locatorString = Selectors.getSelector('Intelligent Finance Radio');
  }
  clickOnElement(locatorString);
});

Then(/^User switch Bank to proceed$/, () => {
  let locatorString = '';
  if (process.env.BRAND === 'IF') {
    locatorString = Selectors.getSelector('SJPB Radio');
  } else if (process.env.BRAND === 'SJPB') {
    locatorString = Selectors.getSelector('Intelligent Finance Radio');
  }
  clickOnElement(locatorString);
});

Then(/^User fetch the value from "(.*)"$/, element => {
  const locatorString = Selectors.getSelector(element);
  const selector = $(locatorString);
  global.expectedValue = selector.getValue();
});

Then(
  /^User able to view tooltip on "(.*)" and "(.*)" value as "(.*)"$/,
  (element, elementnew, expectedText) => {
    let expectedvalue = expectedText;
    expectedvalue = Selectors.getData(expectedText);
    const locatorString = Selectors.getSelector(element);
    const selector = $(locatorString);
    selector.moveTo();
    browser.pause(4000);
    const locatorStringt = Selectors.getSelector(elementnew);
    const selectort = $(locatorStringt);
    const actualText = selectort.getAttribute('innerText');
    assert.equal(actualText, expectedvalue);
  },
);

Then(
  /^When User saw priority flag popup on "(.*)" then user clicks on "(.*)" Ok button$/,
  (element, element1) => {
    const dropdownLocator = Selectors.getSelector(element);
    const dropdownElement = $(dropdownLocator);
    const dropdownLocator1 = Selectors.getSelector(element1);
    const dropdownElement1 = $(dropdownLocator1);

    if (dropdownElement.isDisplayed()) {
      dropdownElement1.click();
    }
  },
);

Then(
  /^User is CSS Property of the "(.*)" value as "(.*)"$/,
  (element, expectedText) => {
    let expectedvalue = expectedText;
    expectedvalue = Selectors.getData(expectedText);
    const locatorString = Selectors.getSelector(element);
    const selector = $(locatorString);
    const actualText = selector.getCSSProperty('background-color').value;
    assert.equal(actualText, expectedvalue);
  },
);

When(
  /^User select value "(.*)" from dropdown "(.*)"$/,
  (elementtext, element) => {
    const value = Selectors.getData(elementtext);
    const locatorString = Selectors.getSelector(element);
    const selectBox = $(locatorString);
    selectBox.selectByVisibleText(value);
    browser.pause(2000);
  },
);

When(/^User clicks on manage indicator"(.*)" and wait load page$/, element => {
  browser.pause(7000);
  actions.click(element);
  browser.pause(20000);
});

When(/^User clicks on "(.*)" and wait load page$/, element => {
  browser.pause(1000);
  actions.click(element);
  browser.pause(5000);
});

Then(/^User selects "(.*)" from the list of country of page$/, element => {
  const index = Math.floor(Math.random() * Math.floor(100));
  const locatorString = Selectors.getSelector(element);
  const selector = $(locatorString);
  selector.selectByIndex(index);
});

When(/^logoff the user if already logged in$/, () => {
  const locatorString = Selectors.getSelector('logoffLink');
  const selector = $(locatorString);
  const isVisible = selector.isDisplayed();
  if (isVisible) {
    actions.click('logoffLink');
    browser.pause(5000);
  }
});

When(/^User clears the browser "(.*) cookie$/, element => {
  browser.deleteCookie(element);
});

When(
  /^User provide current employee status "(.*)" on "(.*)","(.*)","(.*)","(.*)","(.*)","(.*)","(.*)","(.*)" and saves on "(.*)" on the page$/,
  (
    occupation,
    elementone,
    elementtwo,
    elementthree,
    radioelementone,
    radioelementtwo,
    radioelementthree,
    elementOccupation,
    elesubmit,
    keyname,
  ) => {
    const locatorString = Selectors.getSelector(elementone);
    const selector = $(locatorString);

    const locatorOccupation = Selectors.getSelector(elementOccupation);
    const occupationLocator = $(locatorOccupation);

    const submit = Selectors.getSelector(elesubmit);
    const selectorcomfirm = $(submit);

    const locatorString2 = Selectors.getSelector(elementtwo);
    const selector2 = $(locatorString2);

    const locatorString3 = Selectors.getSelector(elementthree);
    const selector3 = $(locatorString3);

    const locatorString4 = Selectors.getSelector(radioelementone);
    const selector4 = $(locatorString4);

    const locatorString5 = Selectors.getSelector(radioelementtwo);
    const selector5 = $(locatorString5);

    const locatorString6 = Selectors.getSelector(radioelementthree);
    const selector6 = $(locatorString6);
    if (selector.isSelected().toString() === 'true') {
      selector5.click();
      savedValueList.set(keyname, 'Employed part-time');
    } else if (selector2.isSelected().toString() === 'true') {
      selector6.click();
      savedValueList.set(keyname, 'Self-employed');
    } else if (selector3.isSelected().toString() === 'true') {
      selector4.click();
      savedValueList.set(keyname, 'Employed full-time');
    }
    const inputValue = Selectors.getData(occupation);
    browser.setTimeout({ implicit: 5000 });
    occupationLocator.setValue(inputValue.trim());
    browser.pause(2000);
    browser.keys('\ue015');
    browser.keys('\ue007');
    browser.pause(3000);
    selectorcomfirm.click();
  },
);

When(/^User should see "(.*)" are more then "(.*)"$/, (element, number) => {
  const locatorString = Selectors.getSelector(element);
  const elements = $$(locatorString).length;
  assert.isTrue(
    elements > number,
    'Number of result items are less then expected',
  );
});

When(/^User click on "(.*)" indexed "(.*)"$/, (number, element) => {
  const locatorString = Selectors.getSelector(element);
  const selector = $$(locatorString)[number - 1];
  selector.waitForDisplayed();
  browser.pause(2000);
  selector.click();
});

Then(/^User able to view tooltip on "(.*)" on hover$/, element => {
  const locatorString = Selectors.getSelector(element);
  const selector = $(locatorString);
  selector.moveTo();
  browser.pause(4000);
});

Then(
  /^User selects United state "(.*)" from the list of country of page$/,
  element => {
    const locatorString = Selectors.getSelector(element);
    const selector = $(locatorString);
    selector.selectByVisibleText('United States');
  },
);

Then(/^User saves the text on "(.*)" as "(.*)"$/, (element, valueKey) => {
  const locatorString = Selectors.getSelector(element);
  const locator = $(locatorString);

  const actualtext = locator.getText();
  savedValueList.set(valueKey, actualtext);
});

When(
  /^User provide random year on "(.*)" on the page and saves on "(.*)"$/,
  (element, valueKey) => {
    const min = Math.ceil(1901);
    const max = Math.floor(2000);
    const elementtext1 = Math.floor(Math.random() * (max - min + 1)) + min;

    const locatorString = Selectors.getSelector(element);
    const selector = $(locatorString);
    selector.scrollIntoView();
    selector.addValue(elementtext1);
    savedValueList.set(valueKey, elementtext1);
  },
);

Then(
  /^User verify button state of "(.*)" as "(.*)"$/,
  (element, elementState) => {
    const locatorString = Selectors.getSelector(element).toString();
    const selector = $(locatorString);
    const state = selector.isEnabled();
    assert.equal(
      elementState,
      state.toString(),
      `Checkbox state is ${state} Actual State is ${elementState}`,
    );
  },
);

Then(/^User transfer accounts balance to make balance as 0$/, () => {
  browser.execute("localStorage.setItem('balance', '0')");
});

Then(
  /^User is verifying all list "(.*)" is displayed as "(.*)"$/,
  (element, expectedText) => {
    const locatorString = Selectors.getSelector(element);
    const value = Selectors.getData(expectedText);
    const selector = $$(locatorString);
    let actualValue = '';
    for (let i = 0; i < selector.length; i += 1) {
      actualValue += `${selector[i].getText()} `;
    }
    actualValue = actualValue.replace(/\n/g, ' ');
    assert.equal(actualValue, value);
  },
);

Then(/^User clear the input "(.*)" field of page$/, element => {
  const locatorString = Selectors.getSelector(element);
  const selector = $(locatorString);
  selector.clearValue();
});

When(/^User TAB out and clicks on "(.*)" of page$/, element => {
  browser.keys('\ue004');
  const locatorString = Selectors.getSelector(element);
  const selector = $(locatorString);
  selector.click();
});

When(/^User provide random value of year on "(.*)" on the page$/, element => {
  const min = Math.ceil(1901);
  const max = Math.floor(2000);
  const elementtext1 = Math.floor(Math.random() * (max - min + 1)) + min;

  const locatorString = Selectors.getSelector(element);
  const selector = $(locatorString);
  selector.scrollIntoView();
  selector.setValue(elementtext1);
});

Then(
  /^Update Test Data json file with key "(.*)" and value "(.*)"$/,
  (key, expectedvalue) => {
    let expectedVarValue = savedValueList.get(expectedvalue);

    if (!expectedVarValue) {
      expectedVarValue = Selectors.getData(expectedvalue);
    }
    actions.saveDataForE2E(key, expectedVarValue);
  },
);

Then(
  /^User clicks on "(.*)" of page and captures "(.*)" from path "(.*)" from "(.*)" api$/,
  (element, keyName, jsonXPATH, urlPath) => {
    actions.click(element);
    browser.setupInterceptor(); // capture ajax calls
    browser.pause(50000); // maybe wait a bit until request is finished
    const request = browser.getRequest;
    for (let index = 0; index < request.length; index += 1) {
      if (request[index].url.includes(urlPath)) {
        const expctedvalue = request[index].response.body + jsonXPATH;
        savedValueList.set(keyName, expctedvalue);
      }
    }
  },
);

Then(
  /^User clicks on "(.*)" of page and captures "(.*)" from path "(.*)" from uri$/,
  (element, keyName, jsonXPATH) => {
    browser.setupInterceptor();
    actions.click(element);
    browser.pause(10000);
    const request = browser.getRequest(0);
    const requrl = request.url;
    const re = new RegExp(jsonXPATH);
    const resultval = requrl.match(re);
    savedValueList.set(keyName, resultval[0]);
    savedValueList.get(keyName);
  },
);

Then(
  /^User is updating value as per param "(.*)" and "(.*)"$/,
  (value1, value2) => {
    const expectedvalue = Selectors.getData(value1);
    const randomValue = savedValueList.get(value2);
    const newvalue = expectedvalue + randomValue;
    savedValueList.set(value2, newvalue);
  },
);
When(/^User clicks on "(.*)" of page and captures paymentid$/, element => {
  browser.setupInterceptor(); // capture ajax calls
  actions.click(element);
  browser.pause(30000); // maybe wait a bit until request is finished
  const request = browser.getRequest(0);
  savedValueList.set('paymentid', request.response.body.Data.DomesticPaymentId);
});

Given(/^User captures colleague access token$/, () => {
  browser.url(tokenUrl);
  browser.pause(5000);
  const result = browser.execute(() => {
    return sessionStorage.getItem('_colleague_at');
  });
  global.colleagueToken = result;
});

When(/^User clears long values "(.*)" of page$/, element => {
  const locatorString = Selectors.getSelector(element);
  const selector = $(locatorString);
  selector.click();
  for (let index = 0; index < 30; index += 1) {
    browser.keys('\uE003');
  }
  for (let index = 0; index < 30; index += 1) {
    browser.keys('\uE017');
  }
});

When(/^User clears long values "(.*)" of page$/, element => {
  const locatorString = Selectors.getSelector(element);
  const selector = $(locatorString);
  selector.click();
  for (let index = 0; index < 30; index += 1) {
    browser.keys('\uE003');
  }
  for (let index = 0; index < 30; index += 1) {
    browser.keys('\uE017');
  }
});

Then(
  /^User clicks on "(.*)" of page and captures BrandPreferenceValue$/,
  element => {
    browser.setupInterceptor(); // capture ajax calls
    actions.click(element);
    browser.pause(20000); // maybe wait a bit until request is finished
    const request = browser.getRequests();
    for (let index = 0; index < request.length; index += 1) {
      if (request[index].url.includes('/preferences/')) {
        const expctedvalue =
          request[index].response.body.Data.BrandPreference.PreferenceValue;
        savedValueList.set('brandPreferenceValue', expctedvalue);
      }
    }
  },
);

Then(
  /^User is verifying the element value is displayed on the page as "(.*)"$/,
  element => {
    const selector = $(`//p[text()='${global.expectedValue}']`);
    selector.waitForDisplayed();
    const isVisible = selector.isDisplayed();
    assert.equal(isVisible, true);
    const expectedvalue = selector.getText();
    const locatorString = Selectors.getSelector(element);
    const Selector = $(locatorString);
    const actualText = Selector.getText().trim();
    assert.equal(actualText, expectedvalue);
  },
);

Then(/^User is verifying the element is not displayed on the page$/, () => {
  const selector = $(`//p[text()='${global.expectedValue}']`);
  selector.waitForDisplayed();
  assert.isNotTrue(selector.isDisplayed());
});

Then(
  /^User is able to see close accounts text "(.*)" and date "(.*)" on the AOV page$/,
  (expectedText, element1) => {
    const locatorString1 = Selectors.getSelector(element1);
    const ExpectedString1 = Selectors.getData(expectedText);

    const selector = $$(locatorString1);

    if (selector.length > 1) {
      for (let index = 1; index < selector.length; index += 1) {
        const actualtext = selector[index].getText();
        assert.isTrue(
          actualtext.includes(ExpectedString1),
          `${ExpectedString1} not present in actual text, actual text is: ${actualtext}`,
        );
      }
    }
  },
);

Then(
  /^Verify User is able to Delete "(.*)" by click on "(.*)" button on page$/,
  (element1, element2) => {
    const locatorString1 = Selectors.getSelector(element1);
    const selector1 = $(locatorString1);
    const locatorString2 = Selectors.getSelector(element2);
    const selector2 = $(locatorString2);
    browser.pause(10000);
    if (selector1.isDisplayed()) {
      selector1.click();
      browser.pause(2000);
      selector2.click();
      browser.pause(2000);
    }
  },
);

Then(
  /^User get the field "(.*)" attribute "(.*)" is "(.*)"$/,
  (element, attributeType, expectedText) => {
    let expectedvalue = expectedText;
    expectedvalue = Selectors.getData(expectedText);
    const locatorString = Selectors.getSelector(element);
    const selector = $(locatorString);
    const actualText = selector.getAttribute(attributeType);
    assert.equal(
      true,
      actualText === expectedvalue,
      `Captures value ${actualText} is not equal to ${expectedvalue}`,
    );
  },
);

When(
  /^User checks a checkbox from all available "(.*)" unchecked checkboxes$/,
  element => {
    const locatorString = Selectors.getSelector(element);
    const selector = $$(locatorString);
    for (let index = 0; index < selector.length; index += 1) {
      if (!selector[index].getAttribute('checked')) {
        selector[index].click();
        break;
      }
    }
    browser.pause(1000);
  },
);

Then(/^User clear the session session$/, () => {
  browser.execute("sessionStorage.removeItem('_handledCPR')");
  browser.pause(2000);
  browser.refresh();
});

When(
  /^User clicks on "(.*)" of page and captures Domestic Scheduled PaymentID as "(.*)"$/,
  (element, ScheduledPaymentId) => {
    browser.setupInterceptor(); // capture ajax calls
    actions.click(element);
    browser.pause(50000); // maybe wait a bit until request is finished
    const request = browser.getRequest(0);
    savedValueList.set(
      ScheduledPaymentId,
      request.response.body.Data.DomesticScheduledPaymentId,
    );
    savedValueList.get(ScheduledPaymentId);
  },
);

When(
  /^User unchecks a checkbox from all available "(.*)" checkboxes$/,
  element => {
    const locatorString = Selectors.getSelector(element);
    const selector = $$(locatorString);
    for (let index = 0; index < selector.length; index += 1) {
      if (selector[index].getAttribute('checked')) {
        selector[index].click();
        break;
      }
    }
    browser.pause(1000);
  },
);

When(
  /^User saves and capture the value of "(.*)" as "(.*)"$/,
  (element, keyName) => {
    const locatorString = Selectors.getSelector(element);
    const selector = $(locatorString);
    const selectorText = selector.getText();
    savedValueList.set(keyName, selectorText);
    savedValueList.get(keyName);
  },
);

Then(
  /^User is comparing the list "(.*)" is with number of elements present "(.*)" and values "(.*)"$/,
  (element, expectedLength, expectedValue) => {
    const value = Selectors.getData(expectedValue);
    const locatorString = Selectors.getSelector(element);
    const selector = $$(locatorString);
    const actualLength = selector.length;
    assert.equal(actualLength, expectedLength);

    let actualValue = '';
    for (let i = 0; i < selector.length; i += 1) {
      actualValue += `${selector[i].getText()} `;
    }
    assert.equal(
      true,
      actualValue === value,
      `Captures value ${actualValue} is not equal to ${value}`,
    );
  },
);

When(/^User is verifying "(.*)" is not checked$/, element => {
  const locatorString = Selectors.getSelector(element);
  const selector = $(locatorString);
  assert.equal(null, selector.getAttribute('checked'));
});

When(/^User clicks on button "(.*)" if it is displayed$/, element => {
  const locatorString = Selectors.getSelector(element);
  const selector = $(locatorString);
  if (selector.isDisplayed()) {
    actions.click(element);
  }
});

When(
  /^User verify the capture value of "(.*)" as "(.*)"$/,
  (element, keyName) => {
    const locatorString = Selectors.getSelector(element);
    const selector = $(locatorString);
    const selectorText = selector.getText();
    assert.equal(selectorText, savedValueList.get(keyName));
  },
);

When(/^Unchecks all checkboxes "(.*)" if checked$/, element => {
  const locatorString = Selectors.getSelector(element);
  const selector = $$(locatorString);
  for (let index = 0; index < selector.length; index += 1) {
    if (selector[index].getAttribute('checked')) {
      selector[index].click();
      actions.click('goneawayYes');
    }
  }
  browser.pause(1000);
});

When(
  /User checks if element "(.*)" of page state as "(.*)"$/,
  (element, elementText) => {
    const locatorString = Selectors.getSelector(element);
    const selector = $(locatorString);
    browser.pause(3000);
    const selectorState = selector.getAttribute('aria-disabled');
    switch (selectorState) {
      case 'true':
        assert.equal(elementText.toString() === selectorState.toString());
        break;
      case 'false':
        assert.equal(elementText.toString() === selectorState.toString());
        break;
      default:
        break;
    }
  },
);

Then(
  /^User is verifying that values "(.*)" present in dropdown "(.*)"$/,
  (expectedText, element) => {
    const expectedValue = Selectors.getData(expectedText);
    const locatorString = Selectors.getSelector(element);
    const selector = $(locatorString);
    const actualText = selector.getText();
    assert.isTrue(
      actualText.includes(expectedValue),
      `${expectedValue} not present in dropdown, found these options ${actualText}`,
    );
  },
);

Then(
  /^User is verifying that values "(.*)" not present in dropdown "(.*)"$/,
  (expectedText, element) => {
    const expectedValue = Selectors.getData(expectedText);
    const locatorString = Selectors.getSelector(element);
    const selector = $(locatorString);
    const actualText = selector.getText();
    assert.isNotTrue(
      actualText.includes(expectedValue),
      `${expectedValue} not present in dropdown, found these options ${actualText}`,
    );
  },
);
Then(
  /^User fetches the "(.*)" cheque of chequebook "(.*)"$/,
  (chequeNo, chequeBook) => {
    const locatorString = Selectors.getSelector(chequeBook);
    const selector = $(locatorString);
    const chequeText = selector.getText().split('-');
    chequeNumber = (
      parseInt(chequeText[1].trim(), 10) + parseInt(chequeNo, 10)
    ).toString();
  },
);

When(/^User enters chequeNumber in "(.*)" of page$/, element => {
  const locatorString = Selectors.getSelector(element);
  const selector = $(locatorString);
  selector.setValue(chequeNumber.trim());
  browser.pause(2000);
});

Then(
  /^User verifies current option "(.*)" and select "(.*)" if not available and save in (.*)"$/,
  (element, elementOne, accessibilityValue) => {
    const locatorString = Selectors.getSelector(element);
    const selector = $(locatorString);
    const locatorStringOne = Selectors.getSelector(elementOne);
    const selectorOne = $(locatorStringOne);
    const elementText = selector.getText().trim();
    let elem;
    let isDisplayed;
    if (
      locatorStringOne.includes('check_correspondenceNeeds_1002') &&
      elementText !== 'Braille'
    ) {
      selectorOne.click();
    } else if (
      locatorStringOne.includes('check_correspondenceNeeds_0') &&
      elementText !== 'Standard format'
    ) {
      selectorOne.click();
      elem = $('#consentSelected');
      isDisplayed = elem.isDisplayed();
      assert.equal(isDisplayed, false);
    } else if (
      locatorStringOne.includes('check_correspondenceNeeds_1003') &&
      elementText !== 'Large Print'
    ) {
      selectorOne.click();
      elem = $('//*[text()="What we do with this information"]');
      isDisplayed = elem.isDisplayed();
      assert.equal(isDisplayed, true);
    }
    elem = accessibilityValue;
    // const updatedAccessibileValue = selectorOne.getText().trim();
    // assert.equal(accessibilityValue, updatedAccessibileValue);
  },
);

Then(
  /^User verifies "(.*)" option and select "(.*)" if not available and confirm by click on "(.*)" and "(.*)"$/,
  (element, elementOne, element1, element2) => {
    const locatorString = Selectors.getSelector(element);
    const selector = $(locatorString);

    const locatorStringOne = Selectors.getSelector(elementOne);
    const selectorOne = $(locatorStringOne);

    const locatorString1 = Selectors.getSelector(element1);
    const selector1 = $$(locatorString1);
    const locatorString2 = Selectors.getSelector(element2);
    const selector2 = $(locatorString2);

    const elementText = selector.getText().trim();
    if (elementText !== 'Braille') {
      selectorOne.click();
      if (process.env.USERTYPE === 'customer') {
        selector1.forEach(testelement => {
          testelement.click();
          // browser.execute('arguments[0].click();', testelement);
        });
      } else if (process.env.USERTYPE === 'colleague') {
        const selector3 = $(locatorString1);
        // const dropdownElement = $(selector1);
        selector3.click();
        browser.pause(3000);
        selector3.selectByIndex(1);
      }
      browser.pause(1000);
      selector2.scrollIntoView();
      selector2.click();
    }
  },
);

Then(
  /^User is verifying the "(.*)" text does not contains "(.*)"$/,
  (element, expectedText) => {
    const expectedvalue = Selectors.getData(expectedText);
    const locatorString = Selectors.getSelector(element);
    const selector = $(locatorString);
    const actualText = selector.getText().trim();
    assert.isNotTrue(
      actualText.includes(expectedvalue),
      `${expectedvalue} not present, found these options ${actualText}`,
    );
  },
);

Then(/^User validate the navigated url "(.*)"$/, url => {
  const actualUrl = browser.getUrl();
  assert.isTrue(
    actualUrl.includes(url),
    `${url} not present in actual url, actual url is: ${actualUrl}`,
  );
});

Then(
  /^User select "(.*)" text for autosuggestive element "(.*)" on the page$/,
  (elementtext, element) => {
    const elementtextVal = Selectors.getData(elementtext);
    const locatorString = Selectors.getSelector(element);
    const selector = $(locatorString);
    selector.click();
    browser.pause(2000);
    selector.setValue(elementtextVal.trim());
    browser.pause(2000);
    browser.keys('\uE015');
    browser.pause(2000);
    browser.keys('\uE007');
    browser.pause(2000);
  },
);
