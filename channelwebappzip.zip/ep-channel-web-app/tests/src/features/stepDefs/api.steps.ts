/* eslint-disable @typescript-eslint/no-var-requires */
const { Given } = require('cucumber');
const randGenerator = require('../support/getRandomData');
const request = require('request-promise');
const envConfig = require('../../../conf/shared/env.conf');
const Selectors = require('../support/loadDataAndLocators');

const apiUrl = envConfig.getConfig(process.env.ENV).ENV_API;
const onboardUrl = envConfig.getConfig(process.env.ENV).ENV_ONBOARD;
const auth = envConfig.getConfig(process.env.ENV).ENV_AUTH;
const proxyUrl = envConfig.getConfig(process.env.ENV).ENV_PROXY;
const otpUrl = envConfig.getConfig(process.env.ENV).ENV_OTP;

Given(/^User onboards the new customer$/, async () => {
  const firstName = randGenerator.randomString(8);
  const baseuri = onboardUrl;
  const body = {
    Title: 5,
    FirstName: firstName,
    MiddleName: 'na',
    LastName: 'aa',
    Suffix: 'PHd',
    PreviousSurname: 'James',
    DateOfBirth: '1967-06-23',
    Gender: 1,
    ContactDetails: [
      {
        ContactType: 1,
        ContactReference: 'testuser23sdsd@gmail.com',
        Status: 1,
      },
      {
        ContactType: 2,
        PhoneNumber: 7439223453,
        DialingCode: '+44',
        CountryCode: 'GBR',
        Status: 1,
      },
    ],
    Addresses: [
      {
        AddressType: 1,
        HouseNumber: '123',
        FirstLine: 'FirstLine',
        SecondLine: 'Northolt Test',
        ThirdLine: 'thirdline',
        FourthLine: 'fourthline',
        FifthLine: '5thline',
        City: 'London',
        StateOrProvince: 'Greater London',
        PostOfficeBox: null,
        PostalCode: 'EC3R5FR',
        StartDate: '2019-03-23',
        EndDate: null,
        SharedAddress: true,
        CountryCode: 'GBR',
      },
      {
        AddressType: 1,
        HouseNumber: '123',
        FirstLine: 'FirstLine1',
        SecondLine: 'Northolt Test1',
        ThirdLine: 'thirdline',
        FourthLine: 'fourthline',
        FifthLine: '5thlinee',
        City: 'London',
        StateOrProvince: 'Greater London',
        PostOfficeBox: null,
        PostalCode: 'EC3R5DR',
        StartDate: '2014-03-23',
        EndDate: '2019-03-23',
        SharedAddress: true,
        CountryCode: 'GBR',
      },
    ],
    CountryAssociations: [
      {
        CountryCode: 'GBR',
        SubCountryCode: 'EW',
        AssociationTypeCode: 5,
        StartDate: '2016-01-01',
        EndDate: null,
      },
      {
        CountryCode: 'GBR',
        SubCountryCode: null,
        AssociationTypeCode: 2,
        StartDate: '2016-01-01',
        EndDate: null,
      },
    ],
    Identifiers: [
      {
        IdentifierCode: 'NINO',
        CountryCode: 'GBR',
        IdentifierReference: 'SX123456A',
      },
    ],
    EmploymentDetails: {
      EmploymentStatus: 2,
      OccupationCode: 35,
      CountryOfWork: 'GBR',
      EmployerName: 'LBG',
      JobTitle: 'Associate',
      IncomeAmount: 50000,
      IncomeFrequencyCode: 1,
      IncomeCurrencyCode: 8,
      EmploymentPensionIndicator: true,
      GrossNetIndicator: 'G',
      AdditionalIncomeTypeId: 1,
      AdditionalIncomeFrequencyCode: 1,
      AdditionalIncomeAmount: 800,
      AdditionalIncomeGrossNetIndicator: 'G',
    },
  };

  const headers = {
    'x-lbg-org': 'LBG',
    'x-lbg-brand': 'IF',
    'x-lbg-txn-correlation-id': 'asd2234234asasasasasasdsasdasd',
    'Content-Type': 'application/json',
    Authorization: 'Bearer VALID_STATIC_TOKEN',
  };

  const defaultOpts = {
    method: 'POST',
    uri: baseuri,
    json: true,
    timeout: 10000,
    resolveWithFullResponse: true,
  };

  const opts = Object.assign(defaultOpts, {
    headers,
    body,
    proxy: proxyUrl,
    strictSSL: false,
  });

  await request(opts)
    .then(res => {
      global.firstName = res.body.FirstName;
      global.customerID = res.body.CustomerId;
      // console.log('Onboarded customer Information*****', `CustID: ${global.customerID} firstname: ${global.firstName}`);
      return res;
    })
    .catch(() => {
      return false;
    });
});

Given(/^User generates the sort code and account number$/, async () => {
  const baseuri = `${apiUrl}/accounts/v1.0/accounts/application`;

  const body = {
    ProductId: 'lbg_dasa_lite',
    CustomerId: global.customerID,
    Declaration: true,
    TCAccepted: true,
    AccountOptions: {
      InterestPaymentSchedule: 'ANNUALLY',
      RemittingInterestAccount: 11912053109475,
    },
  };

  const headers = {
    'x-lbg-org': 'LBG',
    'x-lbg-brand': 'IF',
    'x-lbg-txn-correlation-id': '1111111111',
    'Content-Type': 'application/json',
  };

  const defaultOpts = {
    method: 'POST',
    uri: baseuri,
    json: true,
    timeout: 10000,
    resolveWithFullResponse: true,
  };

  const opts = Object.assign(defaultOpts, {
    headers,
    body,
    proxy: proxyUrl,
    strictSSL: false,
  });

  await request(opts)
    .then(res => {
      global.accountNumber = res.body.AccountNumber;
      global.sortcode = res.body.SortCode;
      // console.log('Onboarded customer Information*****', `CustID: ${global.customerID} firstname: ${global.firstName} sortcode: ${global.sortcode} accountnumber: ${global.accountNumber}`);
      return res;
    })
    .catch(() => {
      return false;
    });
});

Given(/^User creats the user and login credentials$/, async () => {
  const userName = randGenerator.randomString(8);
  const baseuri = `${apiUrl}/v1/user/create/${userName}`;
  const body = {
    userpassword: 'Mango12345',
    customerId: global.customerID,
    memorableInfo: 'A23456789',
  };

  const headers = {
    Realm: 'IF',
    'Content-Type': 'application/json',
    'If-None-Match': '*',
    Authorization: auth,
  };

  const defaultOpts = {
    method: 'PUT',
    uri: baseuri,
    json: true,
    timeout: 10000,
    resolveWithFullResponse: true,
  };

  const opts = Object.assign(defaultOpts, {
    headers,
    body,
    proxy: proxyUrl,
    strictSSL: false,
  });

  await request(opts)
    .then(res => {
      global.username = res.body.username;
      // console.log('Onboarded customer Information*****', `CustID: ${global.customerID} firstname: ${global.firstName} sortcode: ${global.sortcode} accountnumber: ${global.accountNumber} username: ${global.username}`);
      return res;
    })
    .catch(() => {
      return false;
    });
});

Given(
  /^User capturs the "(.*)" for customer "(.*)"$/,
  async (otpType, cusID) => {
    let baseuri = otpUrl;
    if (otpType === 'POSTALOTP') {
      baseuri = baseuri.replace('/otp', '/postalotp');
    }
    let cus = cusID;
    cus = Selectors.getData(cusID);
    const headers = {
      'x-lbg-customer-id': cus,
      'x-lbg-txn-correlation-id': cus,
    };

    const defaultOpts = {
      method: 'GET',
      uri: baseuri,
      timeout: 10000,
    };

    const opts = Object.assign(defaultOpts, {
      headers,
      strictSSL: false,
    });

    await request(opts)
      .then(res => {
        global.otp = JSON.parse(res).otp;
        return res;
      })
      .catch(() => {
        return false;
      });
  },
);

Given(
  /^Admin set the counter "(.*)" for digital, "(.*)" for telphoney, "(.*)" for miTelphoney, "(.*)" for pscTelephoney, "(.*)" for digital and "(.*)" for telephoney "(.*)"$/,
  async (
    authCount,
    telCount,
    miTelCount,
    pscTelCount,
    digitalStatus,
    telStatus,
    user,
  ) => {
    const userName = Selectors.getData(user);
    const password = 'Mango12345';
    const mi = 'A23456789';
    const baseuri = `${apiUrl}/v1/user/create/${userName}`;

    const body = {
      userpassword: password,
      memorableInfo: mi,
      authCounter: authCount,
      telFailedAttemptCounter: telCount,
      miFailedAttempt: miTelCount,
      pscFailedAttempt: pscTelCount,
      inetUserStatus: digitalStatus,
      telUserStatus: telStatus,
    };

    const headers = {
      Realm: 'IF',
      'Content-Type': 'application/json',
      'If-Match': '_rev',
      Authorization: auth,
    };

    const defaultOpts = {
      method: 'PUT',
      uri: baseuri,
      json: true,
      timeout: 10000,
      resolveWithFullResponse: true,
    };

    const opts = Object.assign(defaultOpts, {
      headers,
      body,
      proxy: proxyUrl,
      strictSSL: false,
    });

    await request(opts)
      .then(res => {
        return res;
      })
      .catch(() => {
        return false;
      });
  },
);

Given(
  /^Admin set the "(.*)" for the customer "(.*)"$/,
  async (setValue, user) => {
    const userName = Selectors.getData(user);
    const value = Selectors.getData(setValue);

    const baseuri = `${apiUrl}/v1/user/create/${userName}`;

    const body = {
      telCounterTimeStamp: value,
    };

    const headers = {
      Realm: 'IF',
      'Content-Type': 'application/json',
      'If-Match': '_rev',
      Authorization: auth,
    };

    const defaultOpts = {
      method: 'PUT',
      uri: baseuri,
      json: true,
      timeout: 10000,
      resolveWithFullResponse: true,
    };

    const opts = Object.assign(defaultOpts, {
      headers,
      body,
      proxy: proxyUrl,
      strictSSL: false,
    });

    await request(opts)
      .then(res => {
        return res;
      })
      .catch(() => {
        return false;
      });
  },
);

Given(
  /^User add joint the "(.*)" for the customer "(.*)"$/,
  async (accountId, customerid) => {
    const num = randGenerator.randomNumeric(6);

    // const userName = Selectors.getData(user);
    // const value = Selectors.getData(setValue);
    // const baseuri = 'https://api.ew2.bld-02.ep.gcp.oncp.cloud/account-service/v2.0/beta/accounts/bade7ba1-1d07-eeb3-4de0-0e7568c724cc/parties/application';
    // url: `${ENV_API}/open-banking/v3.1/aisp/accounts/${accountID}/beneficiaries`,
    // https://api.ew2.bld-02.ep.gcp.oncp.cloud/account-service/v2.0/accounts/e2063f12-dd2a-d11f-9a19-4887b3d3d240/parties/application
    const baseuri = `${apiUrl}/account-service/v2.0/accounts/${accountId}/parties/application`;

    const body = {
      // CustomerId: '0ff3f374-ff7b-4033-9d07-48a4c9139464',
      CustomerId: customerid,
      TCAccepted: true,
    };

    const headers = {
      'x-lbg-brand': 'IF',
      'x-lbg-customer-id': '0ff3f374-ff7b-4033-9d07-48a4c9139464',
      'x-lbg-org': 'LBG',
      // 'x-lbg-txn-correlation-id':'d71167c3-fdae-4dd7-9f77-34eefd57e4f4',
      // 'x-lbg-txn-correlation-id':'d71167c3-fdae-4dd7-9f77-34eefd${num}',
      'x-lbg-txn-correlation-id': `d71167c3-fdae-4dd7-9f77-34eefd${num}`,

      'Content-Type': 'application/json',
      Authorization: 'Bearer VALID_STATIC_TOKEN',
    };

    const defaultOpts = {
      method: 'POST',
      uri: baseuri,
      json: true,
      timeout: 10000,
      resolveWithFullResponse: true,
    };

    const opts = Object.assign(defaultOpts, {
      headers,
      body,
      proxy: proxyUrl,
      strictSSL: false,
    });

    await request(opts)
      .then(res => {
        //  console.log('respons',opts.body);

        return res;
      })
      .catch(() => {
        return false;
      });

    // console.log('response.body', response.body);
  },
);
