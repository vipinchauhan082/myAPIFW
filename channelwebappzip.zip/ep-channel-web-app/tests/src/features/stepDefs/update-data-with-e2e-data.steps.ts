/* eslint-disable @typescript-eslint/no-var-requires */
export {};
const { When } = require('cucumber');
const updateBBData = require('../support/updateDataFromE2EOutCome');

When(
  /^User updates journey data "(.*)" from e2e data "(.*)"$/,
  (bbDataKey, e2eDataKey) => {
    updateBBData.updateData(bbDataKey, e2eDataKey);
  },
);
