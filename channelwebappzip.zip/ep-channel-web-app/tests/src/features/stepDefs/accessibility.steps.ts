/* eslint-disable no-undef */
/* eslint-disable @typescript-eslint/no-var-requires */
export {};
const { Then } = require('cucumber');
const axeSource = require('axe-core').source;

let errDescAxe;

Then(/^User runs accessibility standards using AXE$/, () => {
  browser.execute(axeSource);
  const results = browser.executeAsync(done => {
    axe.run(
      {
        runOnly: {
          type: 'tag',
          values: ['wcag2a', 'wcag2aa'],
        },
      },
      (err, res) => {
        if (err) done(err);
        done(res);
      },
    );
  });

  const errorsAxe = results.violations.length;

  const axeReport = results.violations;
  for (let i = 0; i < errorsAxe; i += 1) {
    if (i === 0) {
      errDescAxe = `\t AXE Error: ${results.violations[i].description}`;
    } else {
      errDescAxe = `errDescAxe '\n\t AXE Error: ${results.violations[i].description}`;
    }
  }
  if (parseFloat(errorsAxe) !== 0) {
    return Promise.reject(
      new Error(
        `\n\n
          Accessibility Report Summary:
          \n
          ${errDescAxe}
          \n\n
          AXE REPORT:
          \n\n
          ${JSON.stringify(axeReport, null, '\t')}`,
      ),
    );
  }
  return Promise.resolve;
});
