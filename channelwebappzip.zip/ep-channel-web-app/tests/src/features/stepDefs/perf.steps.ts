/* eslint-disable no-undef */
/* eslint-disable @typescript-eslint/no-var-requires */
export {};
const { Then } = require('cucumber');
const baseLine = require('../support/performanceBaseLine.json');
const { assert } = require('chai');
const cucumberJson = require('wdio-cucumberjs-json-reporter').default;
const fs = require('fs');

let performance: any;
const htmltextFile = './tests/reportTemp/htmlTextFile.txt';
// fs.writeFileSync(htmltextFile, '');

Then(/^User runs page performance scan$/, () => {
  // browser.refresh();
  performance = browser.execute('sauce:log', {
    type: 'sauce:performance',
    metrics: [
      'timeToFirstByte',
      'speedIndex',
      'lastVisualChange',
      'First Meaningful Paint',
    ],
  });

  cucumberJson.attach(JSON.stringify(performance));
  if (process.env.LOADTEST === 'true') {
    let status;
    const url = browser.getUrl();
    if (performance.speedIndex > baseLine.speedIndex) {
      status = `<td class="danger">NOT OK</td>`;
    } else {
      status = `<td class="success">OK</td>`;
    }

    const htmlString = `<tr>
      <td>${url}</td>
      ${status}
      <td>${baseLine.speedIndex}</td>
      <td>${performance.timeToFirstByte}</td>
      <td>${performance.speedIndex}</td>
      <td>${performance.lastVisualChange}</td>
      <td>${performance.firstMeaningfulPaint}</td>
      </tr>`;
    fs.appendFileSync(htmltextFile, htmlString);
  } else {
    assert.ok(performance.timeToFirstByte < baseLine.timeToFirstByte);
    assert.ok(performance.firstMeaningfulPaint < baseLine.firstMeaningfulPaint);
    assert.ok(performance.lastVisualChange < baseLine.lastVisualChange);
  }
});

Then(/^User runs page performance scan for time to first byte$/, () => {
  // browser.refresh();
  performance = browser.execute('sauce:log', {
    type: 'sauce:performance',
    metrics: ['timeToFirstByte', 'speedIndex'],
  });
  cucumberJson.attach(JSON.stringify(performance));
  // assert.ok(performance.speedIndex < baseLine.speedIndex);
  // // assert.ok(performance.load < baseLine.load);
  assert.ok(performance.timeToFirstByte < baseLine.timeToFirstByte);
});
