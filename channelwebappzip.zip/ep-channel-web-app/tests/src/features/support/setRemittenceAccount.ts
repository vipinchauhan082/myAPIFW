/* eslint-disable @typescript-eslint/no-var-requires */
const request = require('request-promise');
const {
  ENV_API,
  ENV_PROXY,
} = require('../../../conf/shared/env.conf').getConfig(process.env.ENV);

module.exports = async (accountID, accessToken, remittingInterestAcc) => {
  const options = {
    method: 'PUT',
    url: `${ENV_API}/accounts/v2.0/accounts/${accountID}/account-options`,
    proxy: `${ENV_PROXY}`,
    gzip: true,
    headers: {
      'x-lbg-org': 'LBG',
      'x-lbg-txn-correlation-id': '15620598-5800-4fb7-b67d-edff80a95e17',
      'Content-Type': 'application/json',
      Accept: 'application/json, text/plain, */*',
      withCredentials: 'true',
      'x-lbg-brand': 'IF',
      'x-lbg-channel': 'DIGITAL',
      'x-lbg-sub-channel': 'WEB',
      Authorization: `${accessToken}`,
    },
    body: {
      RemittingInterestAccount: `${remittingInterestAcc}`,
    },
    resolveWithFullResponse: true,
    json: true,
  };
  const response = await request(options).catch(err => {
    throw new Error(err);
  });
  return response.body;
};
