/* eslint-disable no-undef */
/* eslint-disable @typescript-eslint/no-var-requires */
const Selectors = require('./loadDataAndLocators');
const fs = require('fs');

const devices = [
  'Samsung Galaxy S8 FHD GoogleAPI Emulator',
  'iPhone XS Max Simulator',
  'iPhone 11 Pro Simulator',
  'iPad Pro (9.7 inch) Simulator',
  'iPad Pro (12.9 inch) (2nd generation) Simulator',
  'Samsung Galaxy Tab S3 GoogleAPI Emulator',
];

module.exports = {
  click(element) {
    const locatorString = Selectors.getSelector(element);
    const selector = $(locatorString);
    if (browser.capabilities.browserName === 'safari') {
      browser.execute('arguments[0].click();', selector);
    }
    if (devices.includes(browser.capabilities.deviceName)) {
      selector.scrollIntoView();
      browser.execute('arguments[0].click();', selector);
    } else {
      selector.waitForDisplayed();
      selector.click();
    }
  },

  selectMI() {
    const mi = 'a23456789';
    const mi1 = $(Selectors.getSelector('mi1lable').toString());
    const mi1position = parseInt(mi1.getText().replace(/[^0-9]/g, ''), 10);
    const mi1Dropdown = $(Selectors.getSelector('mi1Dropdown').toString());
    mi1Dropdown.selectByAttribute(
      'value',
      mi.substring(mi1position - 1, mi1position).toString(),
    );

    const mi2 = $(Selectors.getSelector('mi2lable').toString());
    const mi2position = parseInt(mi2.getText().replace(/[^0-9]/g, ''), 10);
    const mi2Dropdown = $(Selectors.getSelector('mi2Dropdown').toString());
    mi2Dropdown.selectByAttribute(
      'value',
      mi.substring(mi2position - 1, mi2position).toString(),
    );

    const mi3 = $(Selectors.getSelector('mi3lable').toString());
    const visible = mi3.isDisplayed();
    if (visible) {
      const mi3position = parseInt(mi3.getText().replace(/[^0-9]/g, ''), 10);
      const mi3Dropdown = $(Selectors.getSelector('mi3Dropdown').toString());
      mi3Dropdown.selectByAttribute(
        'value',
        mi.substring(mi3position - 1, mi3position).toString(),
      );
    }
  },

  enterMI() {
    browser.pause(5000);
    const mi = 'a23456789';

    const mi1 = $(Selectors.getSelector('textbox1lable').toString());
    const mi1position = parseInt(mi1.getText().replace(/[^0-9]/g, ''), 10);
    const mi1textbox = $(Selectors.getSelector('textbox1').toString());
    mi1textbox.click();
    for (let index = 0; index < 18; index += 1) {
      browser.keys('\uE003');
    }
    for (let index = 0; index < 18; index += 1) {
      browser.keys('\uE017');
    }
    mi1textbox.setValue(mi.substring(mi1position - 1, mi1position).toString());

    const mi2 = $(Selectors.getSelector('textbox2lable').toString());
    const mi2position = parseInt(mi2.getText().replace(/[^0-9]/g, ''), 10);
    const mi2textbox = $(Selectors.getSelector('textbox2').toString());
    mi2textbox.click();
    for (let index = 0; index < 18; index += 1) {
      browser.keys('\uE003');
    }
    for (let index = 0; index < 18; index += 1) {
      browser.keys('\uE017');
    }
    mi2textbox.setValue(mi.substring(mi2position - 1, mi2position).toString());

    const mi3 = $(Selectors.getSelector('textbox3lable').toString());
    const visible = mi3.isDisplayed();
    if (visible) {
      const mi3position = parseInt(mi3.getText().replace(/[^0-9]/g, ''), 10);
      const mi3textbox = $(Selectors.getSelector('textbox3').toString());
      mi3textbox.click();
      for (let index = 0; index < 18; index += 1) {
        browser.keys('\uE003');
      }
      for (let index = 0; index < 18; index += 1) {
        browser.keys('\uE017');
      }
      mi3textbox.setValue(
        mi.substring(mi3position - 1, mi3position).toString(),
      );
    }
  },

  enter(setValue, element) {
    const locatorString = Selectors.getSelector(element);
    const selector = $(locatorString);
    let inputValue = setValue;
    inputValue = Selectors.getData(setValue);
    selector.setValue(inputValue.trim());
  },

  waitForPageLoad(timeout) {
    browser.waitUntil(
      () => {
        const state = browser.execute(() => {
          return document.readyState;
        });
        return state === 'complete';
      },
      {
        timeout,
        timeoutMsg: 'Oops! Check your internet connection',
      },
    );
  },

  saveDataForE2E(key, value) {
    let keyValue = value;
    if (
      key.includes('StatementFrequency') ||
      key.includes('InterestFrequency')
      // || key.includes('StatementMethod')
    ) {
      keyValue = value.toUpperCase();
    }
    let data = fs.readFileSync('testdata.json', 'utf8');
    data = JSON.parse(data);
    const keyVal = key.split('.');
    switch (keyVal.length) {
      case 1:
        data[keyVal[0]] = keyValue;
        break;
      case 2:
        data[keyVal[0]][keyVal[1]] = keyValue;
        break;
      case 3:
        data[keyVal[0]][keyVal[1]][keyVal[2]] = keyValue;
        break;
      case 4:
        data[keyVal[0]][keyVal[1]][keyVal[2]][keyVal[3]] = keyValue;
        break;
      default:
        break;
    }
    fs.writeFileSync('testdata.json', JSON.stringify(data));
  },
  updatedValue(element) {
    let newValue = '';
    if (element.includes('StatementFormat')) {
      newValue =
        global.expectedValue === 'Online only'
          ? 'By post and online'
          : 'Online only';
      return newValue;
    }
    newValue = global.expectedValue === 'Annually' ? 'Monthly' : 'Annually';
    return newValue;
  },
};
