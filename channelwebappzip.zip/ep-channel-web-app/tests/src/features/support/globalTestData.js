const GlobalTestData = () => {
  this.testData = {
    AccountID: '',
    CustomerId: '',
    CustomerID2: '',
    ExternalReference: '',
    StackholderID: '',
    PlanNumber: '',
    MortgageNo: '',
    RepaymentAccountID: '',
    SubAccountId: '',
    PrincipalAmount: '',
    BankId: '',
    BankIdCode: '',
    AccountNumber: '',
    ApplicationID: '',
    PortMortgageNo: '',
  };
  this.setField = (field, value) => {
    this.testData[field] = value;
  };

  this.getField = field => {
    return this.testData[field];
  };
};
module.exports = new GlobalTestData();
