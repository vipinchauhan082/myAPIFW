/* eslint-disable @typescript-eslint/no-var-requires */
const selectors = require('../../../locator.js'); // get all locators
const data = require('../../../data.js'); // get all locators

class GenerateLocators {
  constructor() {
    this.objYaml = selectors.config;
    this.objDataYaml = data.config;
  }

  getSelector(selector) {
    return this.objYaml[selector];
  }

  getData(testData) {
    if (testData.split('.').length > 1) {
      const dataNode = testData.split('.');
      return this.objDataYaml[dataNode[0]][dataNode[1]];
    }
    const returnData = this.objDataYaml[testData];
    return returnData || testData;
  }
}

module.exports = new GenerateLocators();
