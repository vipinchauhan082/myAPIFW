const obj = {
  mem: {},
  get context() {
    return this.mem;
  },
  set context(val) {
    this.mem = { ...this.mem, ...val };
  },
};
module.exports = obj;
