/* eslint-disable @typescript-eslint/no-var-requires */

const request = require('request-promise');
const {
  ENV_API,
  ENV_PROXY,
} = require('../../../conf/shared/env.conf').getConfig(process.env.ENV);

module.exports = async (accountID, nominatedAccountID, accessToken) => {
  const options = {
    method: 'PUT',
    url: `${ENV_API}/accounts/v2.0/accounts/${accountID}/account-options`,
    proxy: `${ENV_PROXY}`,
    gzip: true,
    headers: {
      'x-lbg-org': 'LBG',
      Accept: 'application/json, text/plain, */*',
      'x-lbg-brand': 'IF',
      'x-lbg-channel': 'DIGITAL',
      Authorization: `${accessToken}`,
    },
    body: {
      NominatedSavingsAccountForSweeping: `${nominatedAccountID}`,
      MinimumBalanceForSweeping: 200,
    },
    resolveWithFullResponse: true,
    json: true,
  };
  const response = await request(options).catch(err => {
    throw new Error(err);
  });
  // eslint-disable-next-line no-console
  console.log('-----Response------', response);
  return response;
};
