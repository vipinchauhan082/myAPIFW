/* eslint-disable @typescript-eslint/no-var-requires */
const { addDays, getMonth, getDate, addMonths, subDays } = require('date-fns');

function getFutureDate(days: number) {
  const newDate = addDays(new Date(), days);
  const futureDate = getDate(newDate);
  return futureDate;
}

function getpreviousDate(days: number) {
  const newDate = subDays(new Date(), days);
  const previousDate = getDate(newDate);
  return previousDate;
}

function getTodayDateInFormat() {
  const currentDate = new Date();
  const day = currentDate.getDay();
  const year = currentDate.getFullYear();
  const month = currentDate.getMonth();
  const date = currentDate.getDate();
  let actualday;
  const actualYear: string = year.toString().substring(2);
  let actualMonth;
  switch (day) {
    case 0:
      actualday = 'Sun';
      break;
    case 1:
      actualday = 'Mon';
      break;
    case 2:
      actualday = 'Tue';
      break;
    case 3:
      actualday = 'Wed';
      break;
    case 4:
      actualday = 'Thu';
      break;
    case 5:
      actualday = 'Fri';
      break;
    default:
      actualday = 'Sat';
      break;
  }
  switch (month) {
    case 0:
      actualMonth = 'Jan';
      break;
    case 1:
      actualMonth = 'Feb';
      break;
    case 2:
      actualMonth = 'Mar';
      break;
    case 3:
      actualMonth = 'Apr';
      break;
    case 4:
      actualMonth = 'May';
      break;
    case 5:
      actualMonth = 'June';
      break;
    case 6:
      actualMonth = 'July';
      break;
    case 7:
      actualMonth = 'Aug';
      break;
    case 8:
      actualMonth = 'Sep';
      break;
    case 9:
      actualMonth = 'Oct';
      break;
    case 10:
      actualMonth = 'Nov';
      break;
    default:
      actualMonth = 'Dec';
      break;
  }
  let updatedDate;
  if (date < 9) {
    updatedDate = `0${date}`;
  } else {
    updatedDate = date;
  }
  const dateFormat = `${actualday} ${updatedDate} ${actualMonth} ${actualYear}`;
  return dateFormat;
}

function getFutureMonthDate(months: number) {
  const newDate = addMonths(new Date(), months);
  const futureDate = getDate(newDate);
  return futureDate;
}

function getFutureFullDate(days: number) {
  const newDate = addDays(new Date(), days);
  return newDate;
}

function getPreviousFullDate(days: number) {
  const newPreviousDate = subDays(new Date(), days);
  return newPreviousDate;
}
function getMonthDifference(days: number) {
  const today = new Date();
  const newDate = addDays(new Date(), days);
  const diffMonths = getMonth(new Date(newDate)) - getMonth(new Date(today));
  return diffMonths;
}
function getMonthDifferenceBetweenDates(
  selectedDate: string,
  toBeSelectedDate: string,
) {
  const date1 = new Date(selectedDate);
  const date2 = new Date(toBeSelectedDate);
  const diffMonths = getMonth(new Date(date2)) - getMonth(new Date(date1));
  return diffMonths;
}

const converter = date => {
  const day = date.split('-')[0];
  const month = date.split('-')[1];
  const year = date.split('-')[2];
  return `${year}-${month}-${day}`;
};
exports.converter = converter;
exports.getFutureDate = getFutureDate;
exports.getFutureMonthDate = getFutureMonthDate;
exports.getMonthDifference = getMonthDifference;
exports.getFutureFullDate = getFutureFullDate;
exports.getMonthDifferenceBetweenDates = getMonthDifferenceBetweenDates;
exports.getTodayDateInFormat = getTodayDateInFormat;
exports.getpreviousDate = getpreviousDate;
exports.getPreviousFullDate = getPreviousFullDate;
