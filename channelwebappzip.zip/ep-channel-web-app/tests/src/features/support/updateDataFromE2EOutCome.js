/* eslint-disable @typescript-eslint/no-var-requires */
/* eslint-disable no-console */
const util = require('util');
const testData = require('../../../../testdata.json');
const data = require('../../../data.js');
const fs = require('fs');

const updateData = (param1, param2) => {
  const bbData = param1.split('.');
  const tData = param2.split('.');

  switch (true) {
    case bbData.length === 1 && tData.length === 1:
      data.config[bbData[0]] = testData[tData[0]];
      break;
    case bbData.length === 1 && tData.length === 2:
      data.config[bbData[0]] = testData[tData[0]][tData[1]];
      break;
    case bbData.length === 2 && tData.length === 1:
      data.config[bbData[0]][bbData[1]] = testData[tData[0]];
      break;
    case bbData.length === 2 && tData.length === 2:
      data.config[bbData[0]][bbData[1]] = testData[tData[0]][tData[1]];
      break;
    case bbData.length === 3 && tData.length === 3:
      data.config[bbData[0]][bbData[1]][bbData[2]] =
        testData[tData[0]][tData[1]][tData[2]];
      break;
    case bbData.length === 3 && tData.length === 2:
      data.config[bbData[0]][bbData[1]][bbData[2]] =
        testData[tData[0]][tData[1]];
      break;
    case bbData.length === 2 && tData.length === 3:
      data.config[bbData[0]][bbData[1]] =
        testData[tData[0]][tData[1]][tData[2]];
      break;
    case bbData.length === 3 && tData.length === 1:
      data.config[bbData[0]][bbData[1]][bbData[2]] = testData[tData[0]];
      break;
    case bbData.length === 1 && tData.length === 3:
      data.config[bbData[0]] = testData[tData[0]][tData[1]][tData[2]];
      break;
    default:
      break;
  }

  const filePath = '../../../data.js';
  const fileData = `exports.config =${util.inspect(data.config)}`;

  fs.writeFile(filePath, fileData, err => {
    if (err) {
      return console.log(err);
    }
    return true;
  });
};

exports.updateData = updateData;
// updateData('E2EOutcome.username', 'Details.Username');
