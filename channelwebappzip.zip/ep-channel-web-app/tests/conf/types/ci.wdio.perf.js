/* eslint-disable @typescript-eslint/no-var-requires */
const path = require('path');
const files = require('../../changedPackages.js');

const featureFiles = [];

// eslint-disable-next-line no-plusplus
for (let x = 0; x < files.config.length - 1; x++) {
  featureFiles.push(path.resolve(`${files.config[x]}/tests/**/*.perf.feature`));
}

exports.perf = {
  name: 'BB Journey Page Performance',
  specs: featureFiles,
};
