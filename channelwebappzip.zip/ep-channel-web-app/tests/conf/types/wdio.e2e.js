/* eslint-disable @typescript-eslint/no-var-requires */
const path = require('path');

// All E2E Journey Feature files
const featureFiles = path.resolve(
  __dirname,
  '../../../apps/if.com/tests/featuresFiles/Help_me_to_log_in_remotely.e2e.feature',
);

// Commented
// Feature files for Transfer Money Journey
// const featureFileTransferMoney = path.resolve(
//   __dirname,
//   '../../../apps/if.com/tests/featuresFiles/transferMoney/*.e2e.feature',
// );

exports.functional = {
  name: 'BB Journey functional E2E tests',
  specs: [featureFiles],
};
