/* eslint-disable @typescript-eslint/no-var-requires */
const path = require('path');

const featureFiles = path.resolve(
  __dirname,
  `../../../packages/${process.env.PACKAGE}/tests/**/*.${process.env.TESTINGTYPE}.feature`,
);

exports.perf = {
  name: 'BB Journey Page Performance',
  specs: [featureFiles],
};
