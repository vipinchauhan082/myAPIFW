/* eslint-disable @typescript-eslint/no-var-requires */
const path = require('path');

const featureFiles = path.resolve(
  __dirname,
  '../../../packages/**/tests/**/*.perf.feature',
);

exports.perf = {
  name: 'BB Journey Page Performance',
  specs: [featureFiles],
};
