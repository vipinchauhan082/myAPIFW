/* eslint-disable @typescript-eslint/no-var-requires */
const path = require('path');

const featureFiles = path.resolve(
  __dirname,
  '../../../packages/**/tests/**/*.functional.feature',
);

exports.functional = {
  name: 'BB Journey customer colleague tests',
  specs: [featureFiles],
};
