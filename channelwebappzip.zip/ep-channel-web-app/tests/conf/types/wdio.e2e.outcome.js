/* eslint-disable @typescript-eslint/no-var-requires */
const path = require('path');

const featureFiles = path.resolve(
  __dirname,
  '../../../apps/if.com/tests/featuresFiles/E2E-Outcome/**/*.e2e.functional.feature',
);

exports.functional = {
  name: 'BB Journey E2E Outcome Tests ',
  specs: [featureFiles],
};
