/* eslint-disable @typescript-eslint/no-var-requires */
const path = require('path');

const featureFiles = path.resolve(
  __dirname,
  '../../../packages/**/tests/**/*.accessibility.feature',
);

exports.accessibility = {
  name: 'BB Journey Accessibility tests',
  specs: [featureFiles],
};
