/* eslint-disable @typescript-eslint/no-var-requires */
const { config } = require('./shared/sauce.conf.js');
const { accessibility } = require('./types/ci.wdio.accessibility.js');

config.capabilities[0]['sauce:options'] = {
  ...config.capabilities[0]['sauce:options'],
  build: `BB Journey Accessibility Tests`,
  name: `BB Journey Accessibility Tests ${Math.ceil(Date.now() / 1000)}`,
};

exports.config = {
  ...config,
  ...accessibility,
  maxInstances: 5,
};
