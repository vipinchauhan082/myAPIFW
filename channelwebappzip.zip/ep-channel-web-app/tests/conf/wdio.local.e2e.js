/* eslint-disable @typescript-eslint/no-var-requires */
const { config } = require('./shared/local.conf.js');
const { functional } = require('./types/wdio.e2e.js');

global.expectedValue = '';
global.actualValue = '';

exports.config = {
  ...config,
  ...functional,
};
