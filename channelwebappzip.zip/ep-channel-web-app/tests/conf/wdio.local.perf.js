/* eslint-disable @typescript-eslint/no-var-requires */
const { config } = require('./shared/local.conf.js');
const { perf } = require('./types/wdio.perf.js');

exports.config = {
  ...config,
  ...perf,
};
