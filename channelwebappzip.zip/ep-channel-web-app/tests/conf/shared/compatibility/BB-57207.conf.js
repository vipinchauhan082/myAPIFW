// eslint-disable-next-line @typescript-eslint/no-var-requires
const { config } = require('../wdio.shared.js');

exports.config = {
  ...config,
  ...{
    user: 'MCP.Endeavor',
    key: 'b200bb9a-35a5-4df0-ade2-51014c8e2e32',
    region: 'eu',
    capabilities: [
      {
        deviceName: 'Samsung Galaxy Tab S3 GoogleAPI Emulator',
        platformName: 'Android',
        appiumVersion: '1.16.0',
        browserName: 'chrome',
        platformVersion: 'latest',
        deviceOrientation: 'portrait',
        build: 'BB Journey Functional BDDs',
        name: 'Eplus_Samsung_Galaxy_Tab_S3_GoogleAPI_Emulator',
        'sauce:options': {
          commandTimeout: 600,
          idleTimeout: 900,
          maxDuration: 10800,
          screenResolution: '1440x900',
        },
      },
    ],
  },
};
