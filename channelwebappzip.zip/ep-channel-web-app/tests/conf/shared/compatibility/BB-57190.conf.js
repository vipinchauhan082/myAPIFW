// eslint-disable-next-line @typescript-eslint/no-var-requires
const { config } = require('../wdio.shared.js');

exports.config = {
  ...config,
  ...{
    user: 'MCP.Endeavor',
    key: 'b200bb9a-35a5-4df0-ade2-51014c8e2e32',
    region: 'eu',
    capabilities: [
      {
        maxInstances: 10,
        browserName: 'MicrosoftEdge',
        version: '81.0',
        platform: 'Windows 10',
        build: 'BB Journey Functional BDDs Grade 1',
        name: 'Eplus_Edge_Windows10_18',
        'sauce:options': {
          commandTimeout: 600,
          idleTimeout: 900,
          maxDuration: 10800,
          screenResolution: '1440x900',
        },
      },
    ],
  },
};
