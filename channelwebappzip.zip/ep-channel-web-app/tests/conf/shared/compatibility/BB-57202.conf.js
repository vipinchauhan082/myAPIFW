// eslint-disable-next-line @typescript-eslint/no-var-requires
const { config } = require('../wdio.shared.js');

exports.config = {
  ...config,
  ...{
    user: 'MCP.Endeavor',
    key: 'b200bb9a-35a5-4df0-ade2-51014c8e2e32',
    region: 'eu',
    capabilities: [
      {
        deviceName: 'iPad Pro (9.7 inch) Simulator',
        platformName: 'iOS',
        appiumVersion: '1.17.1',
        browserName: 'Safari',
        platformVersion: '13.0',
        deviceOrientation: 'portrait',
        build: 'BB Journey Functional BDDs',
        name: 'Eplus_iPad_Pro_9.7_inch_Simulator',
        'sauce:options': {
          commandTimeout: 600,
          idleTimeout: 900,
          maxDuration: 10800,
          screenResolution: '1440x900',
        },
      },
    ],
  },
};
