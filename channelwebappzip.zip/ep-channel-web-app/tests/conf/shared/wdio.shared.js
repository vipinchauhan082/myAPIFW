/* eslint-disable global-require */
/* eslint-disable @typescript-eslint/no-var-requires */
// const { generate } = require('multiple-cucumber-html-reporter');
// const del = require('del');
const path = require('path');
const cucumberJson = require('wdio-cucumberjs-json-reporter').default;
const cucumber = require('cucumber');
const envConfig = require('./env.conf.js'); // load environment configuration
// const selectors = require('../../src/features/support/loadDataAndLocators.ts'); // get all locators

const stepDefs = path.resolve(
  __dirname,
  '../../src/features/stepDefs/*.steps.ts',
); // get  global/generic step definations

const stepDefJourney = path.resolve(
  __dirname,
  '../../../packages/**/tests/stepDefs/*.steps.ts',
); // get journey specific step definations
// Default timeout for BDD run
const defaultTimeoutInterval = process.env.DEBUG ? 60 * 60 * 500 : 60000;

// Identify whether the run is for customer journeys or colleague
let url = '';
if (process.env.BRAND === 'IF') {
  url = envConfig.getConfig(process.env.ENV).ENV_URL;
} else if (process.env.BRAND === 'SJPB') {
  url = envConfig.getConfig(process.env.ENV).ENV_SJPB_URL;
}
if (process.env.USERTYPE === 'colleague') {
  url = envConfig.getConfig(process.env.ENV).COLLEAUGE_ENV_URL;
}

// TAG Expressions
let tagExpressionc = '';
if (process.env.SCENARIO) {
  tagExpressionc = process.env.SCENARIO;
} else {
  tagExpressionc = envConfig.getTags(process.env.USERTYPE, process.env.FLAG);
}

// ToDo: cleaup
global.downloadDir = path.join(__dirname, '../../src/features/tempDownload');
global.expectedValue = '';
global.actualValue = '';
global.colleagueToken = '';
global.CloseAccountId = '';

exports.config = {
  runner: 'local',
  baseUrl: url,
  exclude: [
    // 'path/to/excluded/files'
  ],
  maxInstances: 10,
  logLevel: 'silent',
  bail: 0,
  waitforTimeout: 180000, // Default timeout for all waitFor* commands.
  connectionRetryTimeout: 90000, // Default timeout in milliseconds for request, if browser driver or grid doesn't send response
  connectionRetryCount: 1,
  framework: 'cucumber',
  reporters: [
    'spec',
    [
      'cucumberjs-json',
      {
        jsonFolder: 'tests/reports/json/',
      },
    ],
  ],
  cucumberOpts: {
    require: [stepDefs, stepDefJourney],
    tagExpression: tagExpressionc,
    backtrace: true,
    failAmbiguousDefinitions: true,
    dryRun: false,
    failFast: false,
    format: ['pretty'],
    colors: true,
    snippets: true,
    source: true,
    profile: [],
    strict: false,
    timeout: defaultTimeoutInterval,
    snippetSyntax: undefined,
    ignoreUndefinedDefinitions: false,
    requireModule: [
      'tsconfig-paths/register',
      () => {
        require('ts-node').register({ transpileOnly: true }, { files: true });
      },
    ],
  },
  skipSeleniumInstall: false,
  // onPrepare: async () => {
  //     // const json = path.resolve(__dirname, 'tests/reports/json/*.json');
  //     // const html = path.resolve(__dirname, 'tests/reports/html/**');
  //     await del(['tests/reports/json/*.json']);
  //   },

  //   onComplete: () => {
  //    generate({
  //      //     saveCollectedJSON: true,
  //      jsonDir: 'tests/reports/json/',
  //      reportPath: 'tests/reports/html/',
  //      openReportInBrowser: true,
  //      reportName: `Execution-Result-${new Date().toJSON().replace(/:/g, '-')}`,
  //    });
  //   },

  afterScenario(uri, feature, scenario, result) {
    if (result.status === cucumber.Status.FAILED) {
      // eslint-disable-next-line no-undef
      cucumberJson.attach(browser.takeScreenshot(), 'image/png');
    }
  },
};
