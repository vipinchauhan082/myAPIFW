module.exports = {
  getConfig(runningEnv) {
    switch (process.env.FLAG) {
      case 'BETA':
        switch (runningEnv) {
          case 'int01':
            return {
              ENV_URL: 'https://beta-app.int01.if.e.lloydsbanking.com',
              ENV_SJPB_URL:
                'https://beta-app.int01.sjpbank.e.lloydsbanking.com',
              ENV_PROXY: 'http://10.85.6.31:3128',
              ENV_API: 'https://api.int01.if.e.lloydsbanking.com',
              ENV_ONBOARD:
                'https://api.int01.if.e.lloydsbanking.com/customers/v1.0/customers/onboard',
              clientID: 'wx1ScYAxYXKtS0IqZ2HFliqeNoWiizuj',
              redirectUri:
                'https://app.int01.if.e.lloydsbanking.com/view-account-overview',
              COLLEAUGE_ENV_URL:
                'https://colleague-api.int01.if.e.lloydsbanking.com/v1/mock/colleague/identity/authorize?client_id=Fo0AHgkuHCiL51X7lDlMkRkvlhg5BD6p&redirect_uri=https://beta-colleague-app.int01.if.e.lloydsbanking.com/',
              ENV_AUTH:
                'Basic d3gxU2NZQXhZWEt0UzBJcVoySEZsaXFlTm9XaWl6dWo6VmM1NGxqUWZtcHdCa0hMMg==',
              ENV_OTP:
                'https://icp-ilbgw.eplus-int-01.oncp.group/ep-ath-otp-bdd-helper-service/v1.0/otp',
              ENV_COLLEAGUE_TOKEN_URL:
                ' https://colleague-api.int01.if.e.lloydsbanking.com/v1/mock/colleague/identity/authorize?client_id=Fo0AHgkuHCiL51X7lDlMkRkvlhg5BD6p&redirect_uri=https://beta-colleague-app.int01.if.e.lloydsbanking.com/',
            };

          case 'pre-01':
            return {
              ENV_URL: 'https://beta-app.pre01.if.e.lloydsbanking.com',
              ENV_SJPB_URL:
                'https://beta-app.pre01.sjpbank.e.lloydsbanking.com',
              ENV_PROXY: 'http://eplus-pre-proxy.mgmt-prd.oncp.io:3128',
              ENV_API: 'https://api.pre01.if.e.lloydsbanking.com',
              ENV_ONBOARD:
                'https://app.pre01.if.e.lloydsbanking.com/customers/v1.0/customers/onboard',
              COLLEAUGE_ENV_URL:
                'https://colleague-app.ew2.bld-02.ep.gcp.oncp.cloud',
              ENV_AUTH:
                'Basic WTlUdG0xdEF1Qk5vT0FBVkFDbUxHbE1sNDE1U3Y3dzQ6QmNEYzdDR1VXZUdBZmIzQg==',
              ENV_OTP:
                'https://icp-ilbgw.eplus-pre-01.oncp.dev/ep-ath-otp-bdd-helper-service/v1.0/otp',
            };
          default:
            return {
              ENV_URL: 'https://app.int01.if.e.lloydsbanking.com',
              ENV_SJPB_URL:
                'https://beta-app.pre01.sjpbank.e.lloydsbanking.com',
              ENV_PROXY: 'http://10.85.6.31:3128',
              ENV_API: 'https://api.int01.if.e.lloydsbanking.com',
              ENV_ONBOARD:
                'https://api.int01.if.e.lloydsbanking.com/customers/v1.0/customers/onboard',
              clientID: 'wx1ScYAxYXKtS0IqZ2HFliqeNoWiizuj',
              redirectUri:
                'https://app.int01.if.e.lloydsbanking.com/view-account-overview',
              COLLEAUGE_ENV_URL:
                'https://colleague-api.int01.if.e.lloydsbanking.com/v1/mock/colleague/identity/authorize?client_id=Fo0AHgkuHCiL51X7lDlMkRkvlhg5BD6p&redirect_uri=https://colleague-app.int01.if.e.lloydsbanking.com/',
              ENV_AUTH:
                'Basic d3gxU2NZQXhZWEt0UzBJcVoySEZsaXFlTm9XaWl6dWo6VmM1NGxqUWZtcHdCa0hMMg==',
              ENV_OTP:
                'https://icp-ilbgw.eplus-int-01.oncp.group/ep-ath-otp-bdd-helper-service/v1.0/otp',
              ENV_COLLEAGUE_TOKEN_URL:
                ' https://colleague-api.int01.if.e.lloydsbanking.com/v1/mock/colleague/identity/authorize?client_id=Fo0AHgkuHCiL51X7lDlMkRkvlhg5BD6p&redirect_uri=https://colleague-app.int01.if.e.lloydsbanking.com/',
            };
        }
      case 'Other':
        return {};
      default:
        switch (runningEnv) {
          case 'bld':
            return {
              ENV_URL: 'https://if-app.ew2.bld-02.ep.gcp.oncp.cloud/',
              ENV_SJPB_URL: 'https://sjpb-app.ew2.bld-02.ep.gcp.oncp.cloud/',
              ENV_PROXY: 'http://10.84.15.145:3128',
              ENV_URL_COLLEAGUE:
                'https://colleague-app.ew2.bld-02.ep.gcp.oncp.cloud',
              ENV_API: 'https://api.bld-02.ep.agw.oncp.cloud',
              ENV_API_ICP: 'https://api.ew2.bld-02.ep.gcp.oncp.cloud',
              ENV_API_PAY: 'https://payments-hub-api-01.eplus-bld-02.oncp.dev',
              ENV_API_CORE: 'https://core-api-01.eplus-bld-02.oncp.dev',
              ENV_AUTH_CORE: '',
              ENV_ONBOARD:
                'https://api.ew2.bld-02.ep.gcp.oncp.cloud/customer-service/v1.0/customers/onboard',
              clientID: 'Nw8YKMxJnaiPZFIFovdFoBo3wrhjrGRp',
              COLLEAUGE_ENV_URL:
                'https://colleague-api.bld-02.ep.agw.oncp.cloud/v1/mock/colleague/identity/authorize?client_id=FsjUBBUjHJh8BYwmgqsgts9limgviPsQ&redirect_uri=https://colleague-app.ew2.bld-02.ep.gcp.oncp.cloud/',
              redirectUri:
                'https://if-app.ew2.bld-02.ep.gcp.oncp.cloud/view-account-overview',
              ENV_AUTH:
                'Basic Tnc4WUtNeEpuYWlQWkZJRm92ZEZvQm8zd3JoanJHUnA6dWVHS2tFaTRtQW9ZeXo5cw==',
              ENV_OTP:
                'https://icp-ilbgw.eplus-bld-02.oncp.dev/ep-ath-otp-bdd-helper-service/v1.0/otp',
              ENV_COLLEAGUE_TOKEN_URL:
                'https://colleague-api.bld-02.ep.agw.oncp.cloud/v1/mock/colleague/identity/authorize?client_id=FsjUBBUjHJh8BYwmgqsgts9limgviPsQ&redirect_uri=https://colleague-app.ew2.bld-02.ep.gcp.oncp.cloud/',
            };
          case 'int':
            return {
              ENV_URL: 'https://app.int01.if.e.lloydsbanking.com',
              ENV_SJPB_URL:
                'https://sjpb-app.pre01.sjpbank.e.lloydsbanking.com',
              ENV_PROXY: 'http://10.85.6.31:3128',
              ENV_API: 'https://colleague-api.int01.if.e.lloydsbanking.com',
              ENV_ONBOARD:
                'https://api.int01.if.e.lloydsbanking.com/customers/v1.0/customers/onboard',
              clientID: 'wx1ScYAxYXKtS0IqZ2HFliqeNoWiizuj',
              redirectUri:
                'https://app.int01.if.e.lloydsbanking.com/view-account-overview',
              COLLEAUGE_ENV_URL:
                'https://colleague-api.int01.if.e.lloydsbanking.com/v1/mock/colleague/identity/authorize?client_id=Fo0AHgkuHCiL51X7lDlMkRkvlhg5BD6p&redirect_uri=https://colleague-app.int01.if.e.lloydsbanking.com/',
              ENV_AUTH:
                'Basic d3gxU2NZQXhZWEt0UzBJcVoySEZsaXFlTm9XaWl6dWo6VmM1NGxqUWZtcHdCa0hMMg==',
              ENV_OTP:
                'https://icp-ilbgw.eplus-int-01.oncp.group/ep-ath-otp-bdd-helper-service/v1.0/otp',
              ENV_COLLEAGUE_TOKEN_URL:
                ' https://colleague-api.int01.if.e.lloydsbanking.com/v1/mock/colleague/identity/authorize?client_id=Fo0AHgkuHCiL51X7lDlMkRkvlhg5BD6p&redirect_uri=https://colleague-app.int01.if.e.lloydsbanking.com/',
            };
          case 'pre-01':
            return {
              ENV_URL: 'https://app.pre01.if.e.lloydsbanking.com',
              ENV_SJPB_URL:
                'https://beta-app.pre01.sjpbank.e.lloydsbanking.com',
              ENV_PROXY: 'http://eplus-pre-proxy.mgmt-prd.oncp.io:3128',
              ENV_API: 'https://api.pre01.if.e.lloydsbanking.com',
              ENV_ONBOARD:
                'https://app.pre01.if.e.lloydsbanking.com/customers/v1.0/customers/onboard',
              COLLEAUGE_ENV_URL:
                'https://colleague-api.pre01.if.e.lloydsbanking.com/v1/mock/colleague/identity/authorize?client_id=Dw9JmCw8R6UKnARQcaykzYdgcJyxkpgK&redirect_uri=https://colleague-app.pre01.if.e.lloydsbanking.com/',
              ENV_AUTH:
                'Basic WTlUdG0xdEF1Qk5vT0FBVkFDbUxHbE1sNDE1U3Y3dzQ6QmNEYzdDR1VXZUdBZmIzQg==',
              ENV_OTP:
                'https://icp-ilbgw.eplus-pre-01.oncp.dev/ep-ath-otp-bdd-helper-service/v1.0/otp',
              ENV_COLLEAGUE_TOKEN_URL:
                'https://colleague-api.pre01.if.e.lloydsbanking.com/v1/mock/colleague/identity/authorize?client_id=Dw9JmCw8R6UKnARQcaykzYdgcJyxkpgK&redirect_uri=https://colleague-app.pre01.if.e.lloydsbanking.com/',
            };
          case 'local':
            return {
              ENV_URL: 'http://localhost:9000',
              ENV_PROXY: 'http://proxy.mgmt-bld.oncp.dev:3128',
              ENV_API: 'https://api.bld-02.ep.agw.oncp.cloud',
              clientID: 'Nw8YKMxJnaiPZFIFovdFoBo3wrhjrGRp',
              COLLEAUGE_ENV_URL: 'http://localhost:9002',
              redirectUri:
                'https://if-app.ew2.bld-02.ep.gcp.oncp.cloud/view-account-overview',
            };
          default:
            return {
              ENV_URL: 'https://if-app.ew2.bld-02.ep.gcp.oncp.cloud',
              ENV_PROXY: 'http://proxy.mgmt-bld.oncp.dev:3128',
              ENV_API: 'https://api.bld-02.ep.agw.oncp.cloud',
              ENV_ONBOARD:
                'https://api.ew2.bld-02.ep.gcp.oncp.cloud/customer-service/v1.0/customers/onboard',
              COLLEAUGE_ENV_URL:
                'https://colleague-app.ew2.bld-02.ep.gcp.oncp.cloud',
              ENV_AUTH:
                'Basic Tnc4WUtNeEpuYWlQWkZJRm92ZEZvQm8zd3JoanJHUnA6dWVHS2tFaTRtQW9ZeXo5cw==',
              ENV_OTP:
                'https://icp-ilbgw.eplus-bld-02.oncp.dev/ep-ath-otp-bdd-helper-service/v1.0/otp',
              ENV_COLLEAGUE_TOKEN_URL:
                'https://colleague-api.bld-02.ep.agw.oncp.cloud/v1/mock/colleague/identity/authorize?client_id=FsjUBBUjHJh8BYwmgqsgts9limgviPsQ&redirect_uri=https://colleague-app.ew2.bld-02.ep.gcp.oncp.cloud/',
            };
        }
    }
  },

  getTags(userType, flag) {
    let newTags = '';
    if (
      typeof process.env.RELEASETAGS !== 'undefined' &&
      process.env.RELEASETAGS !== ''
    ) {
      newTags = `${process.env.RELEASETAGS} and `;
    }

    switch (userType) {
      case 'customer':
        switch (flag) {
          case 'beta':
            return `${newTags}not @manual and not @mock and not @ignore and not @wip and not @R4OutOfScope and not @onlycolleague`;
          case 'wip':
            return `${newTags}not @manual and not @mock and not @ignore and not @R4OutOfScope and not @onlycolleague`;

          case 'live':
            return `${newTags}not @manual and not @mock and not @ignore and not @wip and not @R4OutOfScope and not @onlycolleague and not @beta`;
          default:
            return `${newTags}not @manual and not @mock and not @ignore and not @wip and not @R4OutOfScope and not @onlycolleague and not @beta`;
        }
      case 'colleague':
        switch (flag) {
          case 'beta':
            return `${newTags}not @manual and not @mock and not @ignore and not @wip and not @R4OutOfScope and not @onlycustomer`;
          case 'wip':
            return `${newTags}not @manual and not @mock and not @ignore and not @R4OutOfScope and not @onlycustomer`;
          case 'live':
            return `${newTags}not @manual and not @mock and not @ignore and not @wip and not @R4OutOfScope and not @onlycustomer and not @beta`;
          default:
            return `${newTags}not @manual and not @mock and not @ignore and not @wip and not @R4OutOfScope and not @onlycustomer and not @beta`;
        }
      default:
        return `${newTags}not @manual and not @mock and not @ignore and not @wip and not @R4OutOfScope and not @onlycolleague and not @beta`;
    }
  },

  pagePerf(loadType) {
    switch (loadType) {
      case '1x':
        return '250';
      case '2x':
        return '600';
      case '10x':
        return '1000';
      default:
        return '';
    }
  },
};
