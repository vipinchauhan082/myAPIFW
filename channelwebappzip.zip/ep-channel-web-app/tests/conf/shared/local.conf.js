// eslint-disable-next-line @typescript-eslint/no-var-requires
const { config } = require('./wdio.shared.js');

exports.config = {
  ...config,
  ...{
    runner: 'local',
    path: '/wd/hub',
    port: 4444,
    services: ['selenium-standalone', 'intercept'],

    capabilities: [
      {
        proxy: {
          proxyType: 'MANUAL',
          httpProxy: '10.84.15.145:3128',
          sslProxy: '10.84.15.145:3128',
          noProxy:
            '*.postcodeanywhere.co.uk, *.gstatic.com,*.tiqcdn.com, *.demdex.net,*.omtrdc.net,*.googleapis.com,*.we-stats.com, *.biocatch.com,*.online-metrix.net',
        },
        maxInstances: 5,
        browserName: 'chrome',
      },
    ],
  },
};
