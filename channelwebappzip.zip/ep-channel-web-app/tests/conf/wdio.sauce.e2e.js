/* eslint-disable @typescript-eslint/no-var-requires */
const del = require('del');
const { config } = require('./shared/sauce.conf.js');
const { functional } = require('./types/wdio.e2e.js');

global.accountAmount1 = '';
global.accountAmount2 = '';
global.accountAccount1 = '';
global.accountAccount2 = '';
global.changeJarName = '';

config.capabilities[0]['sauce:options'] = {
  ...config.capabilities[0]['sauce:options'],
  build: `BB Journey Functional E2E ${Math.ceil(Date.now() / 1000)}`,
  name: `BB Journey Functional E2E ${Math.ceil(Date.now() / 1000)}`,
};

exports.config = {
  ...config,
  ...functional,
  onPrepare: async () => {
    // const json = path.resolve(__dirname, 'tests/reports/json/*.json');
    // const html = path.resolve(__dirname, 'tests/reports/html/**');
    await del(['tests/reports/json/*.json', `$downloadDir/*.pdf`]);
  },
};
