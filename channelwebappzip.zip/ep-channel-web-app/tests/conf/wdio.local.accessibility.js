/* eslint-disable @typescript-eslint/no-var-requires */
const { config } = require('./shared/local.conf.js');
const { accessibility } = require('./types/wdio.accessibility.js');

exports.config = {
  ...config,
  ...accessibility,
};
