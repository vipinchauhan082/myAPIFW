/* eslint-disable @typescript-eslint/no-var-requires */
const whoami = require('../../scripts/whoami');
const { config } = require('./shared/sauce.conf.js');
const { accessibility } = require('./types/wdio.accessibility.js');

config.capabilities[0]['sauce:options'] = {
  ...config.capabilities[0]['sauce:options'],
  build: `BB Journey Accessibility BDDs ${whoami}`,
  name: `BB Journey Accessibility BDDs ${whoami} ${Math.ceil(
    Date.now() / 1000,
  )}`,
};

exports.config = {
  ...config,
  ...accessibility,
};
