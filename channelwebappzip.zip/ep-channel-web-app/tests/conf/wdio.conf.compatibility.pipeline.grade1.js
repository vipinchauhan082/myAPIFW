/* eslint-disable global-require */
/* eslint-disable @typescript-eslint/no-var-requires */
const path = require('path');
// /* eslint-disable import/no-unresolved */
//  const { generate } = require('multiple-cucumber-html-reporter');
// const del = require('del');
const cucumberJson = require('wdio-cucumberjs-json-reporter').default;
const envConfig = require('./shared/env.conf.js');
const selectors = require('../src/features/support/loadDataAndLocators.ts');

const featureFiles = path.resolve(
  __dirname,
  '../../packages/**/tests/featuresFiles/*.feature',
);
const stepDefs = path.resolve(__dirname, '../src/features/stepDefs/*.steps.ts');

const stepDefJourney = path.resolve(__dirname, '../../packages/**/*.steps.ts');

const url = envConfig.getConfig(process.env.ENV).ENV_URL;

global.downloadDir = path.join(__dirname, '../src/features/tempDownload');
global.accountAmount1 = '';
global.accountAmount2 = '';
global.accountAccount1 = '';
global.accountAccount2 = '';
global.changeJarName = '';

exports.config = {
  //
  // ====================
  // Runner Configuration
  // ====================
  //
  // WebdriverIO allows it to run your tests in arbitrary locations (e.g. locally or
  // on a remote machine).
  runner: 'local',
  //
  // host: 'chrome-standalone',
  // path: '/wd/hub',
  // port: 4444,
  user: 'MCP.Endeavor',
  key: 'b200bb9a-35a5-4df0-ade2-51014c8e2e32',
  region: 'eu',
  // ==================
  // Specify Test Files
  // ==================
  // Define which test specs should run. The pattern is relative to the directory
  // from which `wdio` was called. Notice that, if you are calling `wdio` from an
  // NPM script (see https://docs.npmjs.com/cli/run-script) then the current working
  // directory is where your package.json resides, so `wdio` will be called from there.
  //
  specs: [featureFiles],

  // Patterns to exclude.
  exclude: [
    // 'path/to/excluded/files'
  ],
  //
  // ============
  // Capabilities
  // ============
  // Define your capabilities here. WebdriverIO can run multiple capabilities at the same
  // time. Depending on the number of capabilities, WebdriverIO launches several test
  // sessions. Within your capabilities you can overwrite the spec and exclude options in
  // order to group specific specs to a specific capability.
  //
  // First, you can define how many instances should be started at the same time. Let's
  // say you have 3 different capabilities (Chrome, Firefox, and Safari) and you have
  // set maxInstances to 1; wdio will spawn 3 processes. Therefore, if you have 10 spec
  // files and you set maxInstances to 10, all spec files will get tested at the same time
  // and 30 processes will get spawned. The property handles how many capabilities
  // from the same test should run tests.
  //
  maxInstances: 10,
  //
  // If you have trouble getting all important capabilities together, check out the
  // Sauce Labs platform configurator - a great tool to configure your capabilities:
  // https://docs.saucelabs.com/reference/platforms-configurator
  //
  capabilities: [
    {
      // maxInstances can get overwritten per capability. So if you have an in-house Selenium
      // grid with only 5 firefox instances available you can make sure that not more than
      // 5 instances get started at a time.
      maxInstances: 1,
      //
      browserName: 'chrome',
      version: 'latest',
      platform: 'Windows 10',
      build: 'BB Journey Functional BDDs Grade 1',
      name: 'Eplus_Chrome_Windows10_Latest',
      maxDuration: 10800,
      idleTimeout: 900,
      commandTimeout: 600,
      // If outputDir is provided WebdriverIO can capture driver session logs
      // it is possible to configure which logTypes to include/exclude.
      excludeDriverLogs: ['*'], // pass '*' to exclude all driver session logs
    },
    {
      // maxInstances can get overwritten per capability. So if you have an in-house Selenium
      // grid with only 5 firefox instances available you can make sure that not more than
      // 5 instances get started at a time.
      maxInstances: 1,
      //
      browserName: 'chrome',
      version: '56',
      platform: 'Windows 10',
      build: 'BB Journey Functional BDDs Grade 1',
      name: 'Eplus_Chrome_Windows10_56',
      maxDuration: 10800,
      idleTimeout: 900,
      commandTimeout: 600,
      // If outputDir is provided WebdriverIO can capture driver session logs
      // it is possible to configure which logTypes to include/exclude.
      excludeDriverLogs: ['*'], // pass '*' to exclude all driver session logs
    },
    {
      // maxInstances can get overwritten per capability. So if you have an in-house Selenium
      // grid with only 5 firefox instances available you can make sure that not more than
      // 5 instances get started at a time.
      maxInstances: 1,
      //
      browserName: 'chrome',
      version: '79',
      platform: 'Windows 10',
      build: 'BB Journey Functional BDDs Grade 1',
      name: 'Eplus_Chrome_Windows10_79',
      maxDuration: 10800,
      idleTimeout: 900,
      commandTimeout: 600,
      // If outputDir is provided WebdriverIO can capture driver session logs
      // it is possible to configure which logTypes to include/exclude.
      excludeDriverLogs: ['*'], // pass '*' to exclude all driver session logs
    },
    {
      // maxInstances can get overwritten per capability. So if you have an in-house Selenium
      // grid with only 5 firefox instances available you can make sure that not more than
      // 5 instances get started at a time.
      maxInstances: 1,
      //
      browserName: 'chrome',
      version: 'latest',
      platform: 'Windows 7',
      build: 'BB Journey Functional BDDs Grade 1',
      name: 'Eplus_Chrome_Windows10_Latest',
      maxDuration: 10800,
      idleTimeout: 900,
      commandTimeout: 600,
      // If outputDir is provided WebdriverIO can capture driver session logs
      // it is possible to configure which logTypes to include/exclude.
      excludeDriverLogs: ['*'], // pass '*' to exclude all driver session logs
    },
    {
      // maxInstances can get overwritten per capability. So if you have an in-house Selenium
      // grid with only 5 firefox instances available you can make sure that not more than
      // 5 instances get started at a time.
      maxInstances: 1,
      //
      browserName: 'chrome',
      version: 'latest-1',
      platform: 'Windows 7',
      build: 'BB Journey Functional BDDs Grade 1',
      name: 'Eplus_Chrome_Windows10_Latest-1',
      maxDuration: 10800,
      idleTimeout: 900,
      commandTimeout: 600,
      // If outputDir is provided WebdriverIO can capture driver session logs
      // it is possible to configure which logTypes to include/exclude.
      excludeDriverLogs: ['*'], // pass '*' to exclude all driver session logs
    },
    {
      // maxInstances can get overwritten per capability. So if you have an in-house Selenium
      // grid with only 5 firefox instances available you can make sure that not more than
      // 5 instances get started at a time.
      maxInstances: 1,
      //
      browserName: 'chrome',
      version: '79',
      platform: 'Windows 7',
      build: 'BB Journey Functional BDDs Grade 1',
      name: 'Eplus_Chrome_Windows10_79',
      maxDuration: 10800,
      idleTimeout: 900,
      commandTimeout: 600,
      // If outputDir is provided WebdriverIO can capture driver session logs
      // it is possible to configure which logTypes to include/exclude.
      excludeDriverLogs: ['*'], // pass '*' to exclude all driver session logs
    },
    {
      // maxInstances can get overwritten per capability. So if you have an in-house Selenium
      // grid with only 5 firefox instances available you can make sure that not more than
      // 5 instances get started at a time.
      maxInstances: 1,
      //
      browserName: 'chrome',
      version: '56',
      platform: 'Windows 7',
      build: 'BB Journey Functional BDDs Grade 1',
      name: 'Eplus_Chrome_Windows10_56',
      maxDuration: 10800,
      idleTimeout: 900,
      commandTimeout: 600,
      // If outputDir is provided WebdriverIO can capture driver session logs
      // it is possible to configure which logTypes to include/exclude.
      excludeDriverLogs: ['*'], // pass '*' to exclude all driver session logs
    },
    {
      // maxInstances can get overwritten per capability. So if you have an in-house Selenium
      // grid with only 5 firefox instances available you can make sure that not more than
      // 5 instances get started at a time.
      maxInstances: 1,
      //
      browserName: 'chrome',
      version: 'latest',
      platform: 'Windows 8.1',
      build: 'BB Journey Functional BDDs Grade 1',
      name: 'Eplus_Chrome_Windows8_1_56',
      maxDuration: 10800,
      idleTimeout: 900,
      commandTimeout: 600,
      // If outputDir is provided WebdriverIO can capture driver session logs
      // it is possible to configure which logTypes to include/exclude.
      excludeDriverLogs: ['*'], // pass '*' to exclude all driver session logs
    },
    {
      // maxInstances can get overwritten per capability. So if you have an in-house Selenium
      // grid with only 5 firefox instances available you can make sure that not more than
      // 5 instances get started at a time.
      maxInstances: 1,
      //
      browserName: 'chrome',
      version: 'latest-1',
      platform: 'Windows 8.1',
      build: 'BB Journey Functional BDDs Grade 1',
      name: 'Eplus_Chrome_Windows_8_1_56',
      maxDuration: 10800,
      idleTimeout: 900,
      commandTimeout: 600,
      // If outputDir is provided WebdriverIO can capture driver session logs
      // it is possible to configure which logTypes to include/exclude.
      excludeDriverLogs: ['*'], // pass '*' to exclude all driver session logs
    },
    {
      // maxInstances can get overwritten per capability. So if you have an in-house Selenium
      // grid with only 5 firefox instances available you can make sure that not more than
      // 5 instances get started at a time.
      maxInstances: 1,
      //
      browserName: 'chrome',
      version: '56',
      platform: 'macOS 10.13',
      build: 'BB Journey Functional BDDs Grade 1',
      name: 'Eplus_Chrome_macOS_10_13_56',
      maxDuration: 10800,
      idleTimeout: 900,
      commandTimeout: 600,
      // If outputDir is provided WebdriverIO can capture driver session logs
      // it is possible to configure which logTypes to include/exclude.
      excludeDriverLogs: ['*'], // pass '*' to exclude all driver session logs
    },
    {
      // maxInstances can get overwritten per capability. So if you have an in-house Selenium
      // grid with only 5 firefox instances available you can make sure that not more than
      // 5 instances get started at a time.
      maxInstances: 1,
      //
      browserName: 'firefox',
      browserVersion: 'latest',
      platformName: 'Windows 10',
      'sauce:options': {
        build: 'BB Journey Functional BDDs Grade 1',
        name: 'Eplus_Firefox_Windows10_Latest',
        maxDuration: 10800,
        idleTimeout: 900,
        commandTimeout: 600,
      },
      // If outputDir is provided WebdriverIO can capture driver session logs
      // it is possible to configure which logTypes to include/exclude.
      excludeDriverLogs: ['*'], // pass '*' to exclude all driver session logs
      // excludeDriverLogs: ['bugreport', 'server'],
      // 'moz:firefoxOptions': {
      //   prefs: {
      //     'download.default_directory': global.downloadDir,
      //   },
      // },
    },
    {
      // maxInstances can get overwritten per capability. So if you have an in-house Selenium
      // grid with only 5 firefox instances available you can make sure that not more than
      // 5 instances get started at a time.
      maxInstances: 1,
      //
      browserName: 'firefox',
      browserVersion: 'latest',
      platformName: 'Windows 7',
      'sauce:options': {
        build: 'BB Journey Functional BDDs Grade 1',
        name: 'Eplus_Firefox_Windows7_Latest',
        maxDuration: 10800,
        idleTimeout: 900,
        commandTimeout: 600,
      },
      // If outputDir is provided WebdriverIO can capture driver session logs
      // it is possible to configure which logTypes to include/exclude.
      excludeDriverLogs: ['*'], // pass '*' to exclude all driver session logs
      // excludeDriverLogs: ['bugreport', 'server'],
      // 'moz:firefoxOptions': {
      //   prefs: {
      //     'download.default_directory': global.downloadDir,
      //   },
      // },
    },
    {
      // maxInstances can get overwritten per capability. So if you have an in-house Selenium
      // grid with only 5 firefox instances available you can make sure that not more than
      // 5 instances get started at a time.
      maxInstances: 1,
      //
      browserName: 'firefox',
      browserVersion: 'latest',
      platformName: 'Windows 8.1',
      'sauce:options': {
        build: 'BB Journey Functional BDDs Grade 1',
        name: 'Eplus_Firefox_Windows8_1_Latest',
        maxDuration: 10800,
        idleTimeout: 900,
        commandTimeout: 600,
      },
      // If outputDir is provided WebdriverIO can capture driver session logs
      // it is possible to configure which logTypes to include/exclude.
      excludeDriverLogs: ['*'], // pass '*' to exclude all driver session logs
      // excludeDriverLogs: ['bugreport', 'server'],
      // 'moz:firefoxOptions': {
      //   prefs: {
      //     'download.default_directory': global.downloadDir,
      //   },
      // },
    },
    {
      // maxInstances can get overwritten per capability. So if you have an in-house Selenium
      // grid with only 5 firefox instances available you can make sure that not more than
      // 5 instances get started at a time.
      maxInstances: 1,
      //
      browserName: 'MicrosoftEdge',
      browserVersion: '18.17763',
      platformName: 'Windows 10',
      'sauce:options': {
        build: 'BB Journey Functional BDDs Grade 1',
        name: 'Eplus_Edge_Windows10_18',
        maxDuration: 10800,
        idleTimeout: 900,
        commandTimeout: 600,
        noSslBumpDomains: ['all'],
      },
      // If outputDir is provided WebdriverIO can capture driver session logs
      // it is possible to configure which logTypes to include/exclude.
      excludeDriverLogs: ['*'], // pass '*' to exclude all driver session logs
      // excludeDriverLogs: ['bugreport', 'server'],
      // 'moz:firefoxOptions': {
      //   prefs: {
      //     'download.default_directory': global.downloadDir,
      //   },
      // },
    },
    {
      // maxInstances can get overwritten per capability. So if you have an in-house Selenium
      // grid with only 5 firefox instances available you can make sure that not more than
      // 5 instances get started at a time.
      maxInstances: 1,
      //
      browserName: 'MicrosoftEdge',
      version: '81.0',
      platform: 'Windows 10',
      build: 'BB Journey Functional BDDs Grade 1',
      name: 'Eplus_Edge_Windows10_18',
      maxDuration: 10800,
      idleTimeout: 900,
      commandTimeout: 600,
      // If outputDir is provided WebdriverIO can capture driver session logs
      // it is possible to configure which logTypes to include/exclude.
      excludeDriverLogs: ['*'], // pass '*' to exclude all driver session logs
      // excludeDriverLogs: ['bugreport', 'server'],
      // EdgeOptions: {
      //   prefs: {
      //     'download.default_directory': global.downloadDir,
      //   },
      // },
    },
    {
      // maxInstances can get overwritten per capability. So if you have an in-house Selenium
      // grid with only 5 firefox instances available you can make sure that not more than
      // 5 instances get started at a time.
      maxInstances: 1,
      //
      browserName: 'safari',
      browserVersion: '12.0',
      platformName: 'macOS 10.14',
      'sauce:options': {
        build: 'BB Journey Functional BDDs Grade 1',
        name: 'Eplus_Safari_OS_10.14_12',
        maxDuration: 10800,
        idleTimeout: 900,
        commandTimeout: 600,
      },
      // If outputDir is provided WebdriverIO can capture driver session logs
      // it is possible to configure which logTypes to include/exclude.
      excludeDriverLogs: ['*'], // pass '*' to exclude all driver session logs
      // excludeDriverLogs: ['bugreport', 'server'],
      // SafariOptions: {
      //   prefs: {
      //     'download.default_directory': global.downloadDir,
      //   },
      // },
    },
    {
      // maxInstances can get overwritten per capability. So if you have an in-house Selenium
      // grid with only 5 firefox instances available you can make sure that not more than
      // 5 instances get started at a time.
      maxInstances: 1,
      //
      browserName: 'safari',
      browserVersion: '13.0',
      platformName: 'macOS 10.13',
      'sauce:options': {
        build: 'BB Journey Functional BDDs Grade 1',
        name: 'Eplus_Safari_OS_10.13_13',
        maxDuration: 10800,
        idleTimeout: 900,
        commandTimeout: 600,
      },
      // If outputDir is provided WebdriverIO can capture driver session logs
      // it is possible to configure which logTypes to include/exclude.
      excludeDriverLogs: ['*'], // pass '*' to exclude all driver session logs
      // excludeDriverLogs: ['bugreport', 'server'],
      // SafariOptions: {
      //   prefs: {
      //     'download.default_directory': global.downloadDir,
      //   },
      // },
    },
  ],
  //
  // ===================
  // Test Configurations
  // ===================
  // Define all options that are relevant for the WebdriverIO instance here
  //
  // Level of logging verbosity: trace | debug | info | warn | error | silent
  logLevel: 'info',
  //
  // Set specific log levels per logger
  // loggers:
  // - webdriver, webdriverio
  // - @wdio/applitools-service, @wdio/browserstack-service, @wdio/devtools-service, @wdio/sauce-service
  // - @wdio/mocha-framework, @wdio/jasmine-framework
  // - @wdio/local-runner, @wdio/lambda-runner
  // - @wdio/sumologic-reporter
  // - @wdio/cli, @wdio/config, @wdio/sync, @wdio/utils
  // Level of logging verbosity: trace | debug | info | warn | error | silent
  // logLevels: {
  //     webdriver: 'info',
  //     '@wdio/applitools-service': 'info'
  // },
  //
  // If you only want to run your tests until a specific amount of tests have failed use
  // bail (default is 0 - don't bail, run all tests).
  bail: 0,
  //
  // Set a base URL in order to shorten url command calls. If your `url` parameter starts
  // with `/`, the base url gets prepended, not including the path portion of your baseUrl.
  // If your `url` parameter starts without a scheme or `/` (like `some/path`), the base url
  // gets prepended directly.
  baseUrl: url,
  //
  // Default timeout for all waitFor* commands.
  waitforTimeout: 180000,
  //
  // Default timeout in milliseconds for request
  // if browser driver or grid doesn't send response
  connectionRetryTimeout: 90000,
  //
  // Default request retries count
  connectionRetryCount: 1,
  //
  // Test runner services
  // Services take over a specific job you don't want to take care of. They enhance
  // your test setup with almost no effort. Unlike plugins, they don't add new
  // commands. Instead, they hook themselves up into the test process.
  // services: ['selenium-standalone'],
  //
  // Framework you want to run your specs with.
  // The following are supported: Mocha, Jasmine, and Cucumber
  // see also: https://webdriver.io/docs/frameworks.html
  //
  // Make sure you have the wdio adapter package for the specific framework installed
  // before running any tests.
  framework: 'cucumber',
  //
  // The number of times to retry the entire specfile when it fails as a whole
  // specFileRetries: 1,
  //
  // Whether or not retried specfiles should be retried immediately or deferred to the end of the queue
  // specFileRetriesDeferred: false,
  //
  // Test reporter for stdout.
  // The only one supported by default is 'dot'
  // see also: https://webdriver.io/docs/dot-reporter.html
  reporters: [
    'spec',
    [
      'cucumberjs-json',
      {
        jsonFolder: 'tests/reports/json/',
      },
    ],
  ],
  //
  // If you are using Cucumber you need to specify the location of your step definitions.
  cucumberOpts: {
    require: [stepDefs, stepDefJourney], // <string[]> (file/dir) require files before executing features
    backtrace: false, // <boolean> show full backtrace for errors
    dryRun: false, // <boolean> invoke formatters without executing steps
    failFast: false, // <boolean> abort the run on first failure
    format: ['pretty'], // <string[]> (type[:path]) specify the output format, optionally supply PATH to redirect formatter output (repeatable)
    colors: true, // <boolean> disable colors in formatter output
    snippets: true, // <boolean> hide step definition snippets for pending steps
    source: true, // <boolean> hide source uris
    profile: [], // <string[]> (name) specify the profile to use
    strict: false, // <boolean> fail if there are any undefined or pending steps
    tagExpression:
      'not @manual and not @mock and not @ignore and not @wip and not @R4OutOfScope and not @onlycustomer', // <string> (expression) only execute the features or scenarios with tags matching the expression
    timeout: 60000, // <number> timeout for step definitions
    ignoreUndefinedDefinitions: false, // <boolean> Enable this config to treat undefined definitions as warnings.
    requireModule: [
      'tsconfig-paths/register',
      () => {
        require('ts-node').register({ transpileOnly: true }, { files: true });
      },
    ],
  },

  //
  // =====
  // Hooks
  // =====
  // WebdriverIO provides several hooks you can use to interfere with the test process in order to enhance
  // it and to build services around it. You can either apply a single function or an array of
  // methods to it. If one of them returns with a promise, WebdriverIO will wait until that promise got
  // resolved to continue.
  /**
   * Gets executed once before all workers get launched.
   * @param {Object} config wdio configuration object
   * @param {Array.<Object>} capabilities list of capabilities details
   */
  // onPrepare: async () => {
  //   // const json = path.resolve(__dirname, 'tests/reports/json/*.json');
  //   // const html = path.resolve(__dirname, 'tests/reports/html/**');
  //   await del(['tests/reports/json/*.json']);
  // },
  /*
  onPrepare: function (config, capabilities) {
    // make sure download directory exists
    if (!fs.existsSync(downloadDir)){
        // if it doesn't exist, create it
        fs.mkdirSync(downloadDir);
    }
  },
  onComplete: function() {
    var list = fs.readdirSync(downloadDir);
    for(var i = 0; i < list.length; i++) {
      var filename = path.join(downloadDir, list[i]);
      var stat = fs.statSync(filename);

      if(filename == "." || filename == "..") {

      } else if(stat.isDirectory()) {
        rmdir(filename);
      } else {
        fs.unlinkSync(filename);
      }
    }
    fs.rmdirSync(downloadDir);
}
*/
  // onComplete: () => {
  //   // Generate the report when it all tests are done
  //   generate({
  //     // Required
  //     // This part needs to be the same path where you store the JSON files
  //     saveCollectedJSON: true,
  //     jsonDir: 'tests/reports/json/',
  //     reportPath: 'tests/reports/html/',
  //     openReportInBrowser: true,
  //     reportName: `Execution-Result-${new Date().toJSON().replace(/:/g, '-')}`,
  //     // for more options see https://github.com/wswebcreation/multiple-cucumber-html-reporter#options
  //   });
  // },
  /**
   * Gets executed before a worker process is spawned and can be used to initialise specific service
   * for that worker as well as modify runtime environments in an async fashion.
   * @param  {String} cid      capability id (e.g 0-0)
   * @param  {[type]} caps     object containing capabilities for session that will be spawn in the worker
   * @param  {[type]} specs    specs to be run in the worker process
   * @param  {[type]} args     object that will be merged with the main configuration once worker is initialised
   * @param  {[type]} execArgv list of string arguments passed to the worker process
   */
  // onWorkerStart: function (cid, caps, specs, args, execArgv) {
  // },
  /**
   * Gets executed just before initialising the webdriver session and test framework. It allows you
   * to manipulate configurations depending on the capability or spec.
   * @param {Object} config wdio configuration object
   * @param {Array.<Object>} capabilities list of capabilities details
   * @param {Array.<String>} specs List of spec file paths that are to be run
   */
  // beforeSession: function (config, capabilities, specs) {
  // },
  before: async () => {
    const Selectors = new Promise(reslove => {
      // eslint-disable-next-line no-unused-expressions
      selectors.objYaml ? reslove() : selectors.mergeLocatorsYamls(reslove);
    });
    const Data = await new Promise(reslove => {
      // eslint-disable-next-line no-unused-expressions
      selectors.objYaml ? reslove() : selectors.mergeDataYamls(reslove);
    });
    return { Selectors, Data };
  },
  /**
   * Gets executed before test execution begins. At this point you can access to all global
   * variables like `browser`. It is the perfect place to define custom commands.
   * @param {Array.<Object>} capabilities list of capabilities details
   * @param {Array.<String>} specs List of spec file paths that are to be run
   */
  // before: () => {
  //   browser.locators = locatorFilePath;
  // },
  /**
   * Runs before a WebdriverIO command gets executed.
   * @param {String} commandName hook command name
   * @param {Array} args arguments that command would receive
   */
  // beforeCommand: function (commandName, args) {
  // },
  /**
   * Runs before a Cucumber feature
   */
  // beforeFeature: function (uri, feature, scenarios) {
  // },
  /**
   * Runs before a Cucumber scenario
   */
  // beforeScenario: function (uri, feature, scenario, sourceLocation) {
  // },
  /**
   * Runs before a Cucumber step
   */
  // beforeStep: function ({ uri, feature, step }, context) {
  // },
  /**
   * Runs after a Cucumber step
   */
  /**
   * Runs after a Cucumber scenario
   */
  afterScenario(uri, feature, scenario, result) {
    const cucumber = require('cucumber');
    if (result.status === cucumber.Status.FAILED) {
      // eslint-disable-next-line no-undef
      cucumberJson.attach(browser.takeScreenshot(), 'image/png');
    }
  },
  /**
   * Runs after a Cucumber feature
   */
  // afterFeature: function (uri, feature, scenarios) {
  // },

  /**
   * Runs after a WebdriverIO command gets executed
   * @param {String} commandName hook command name
   * @param {Array} args arguments that command would receive
   * @param {Number} result 0 - command success, 1 - command error
   * @param {Object} error error object if any
   */
  // afterCommand: function (commandName, args, result, error) {
  // },
  /**
   * Gets executed after all tests are done. You still have access to all global variables from
   * the test.
   * @param {Number} result 0 - test pass, 1 - test fail
   * @param {Array.<Object>} capabilities list of capabilities details
   * @param {Array.<String>} specs List of spec file paths that ran
   */
  // after: function (result, capabilities, specs) {
  // },
  /**
   * Gets executed right after terminating the webdriver session.
   * @param {Object} config wdio configuration object
   * @param {Array.<Object>} capabilities list of capabilities details
   * @param {Array.<String>} specs List of spec file paths that ran
   */
  // afterSession: function (config, capabilities, specs) {
  // },
  /**
   * Gets executed after all workers got shut down and the process is about to exit. An error
   * thrown in the onComplete hook will result in the test run failing.
   * @param {Object} exitCode 0 - success, 1 - fail
   * @param {Object} config wdio configuration object
   * @param {Array.<Object>} capabilities list of capabilities details
   * @param {<Object>} results object containing test results
   */
  // onComplete: function(exitCode, config, capabilities, results) {
  // },
  /**
   * Gets executed when a refresh happens.
   * @param {String} oldSessionId session ID of the old session
   * @param {String} newSessionId session ID of the new session
   */
  // onReload: function(oldSessionId, newSessionId) {
  // }
};
