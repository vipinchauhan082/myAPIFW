/* eslint-disable @typescript-eslint/no-var-requires */
const { config } = require('./shared/sauce.conf.js');
const { functional } = require('./types/ci.wdio.functional.js');

global.expectedValue = '';
global.actualValue = '';

config.capabilities[0]['sauce:options'] = {
  ...config.capabilities[0]['sauce:options'],
  build: `BB Journey Functional Tests`,
  name: `BB Journey Functional Tests ${Math.ceil(Date.now() / 1000)}`,
};

exports.config = {
  ...config,
  ...functional,
};
