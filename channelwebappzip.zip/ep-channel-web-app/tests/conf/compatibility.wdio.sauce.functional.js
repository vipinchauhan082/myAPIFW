/* eslint-disable @typescript-eslint/no-var-requires */
/* eslint-disable import/order */
const whoami = require('../../scripts/whoami');

const {
  config,
} = require(`./shared/compatibility/${process.env.PLANNUMBER}.conf.js`); // eslint-disable-line import/no-dynamic-require
const { functional } = require('./types/cust.wdio.functional.js');

global.expectedValue = '';
global.actualValue = '';

config.capabilities[0]['sauce:options'] = {
  ...config.capabilities[0]['sauce:options'],
  build: `BB Journey Cust BDDs ${whoami}`,
  name: `BB Journey Cust BDDs ${whoami} ${Math.ceil(Date.now() / 1000)}`,
};

exports.config = {
  ...config,
  ...functional,
};
