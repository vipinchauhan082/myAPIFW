/* eslint-disable @typescript-eslint/no-var-requires */
const { config } = require('./shared/sauce.conf.js');
const { perf } = require('./types/ci.wdio.perf.js');

config.capabilities[0]['sauce:options'] = {
  ...config.capabilities[0]['sauce:options'],
  build: `BB Journey Web Performance Tests`,
  capturePerformance: true,
  extendedDebugging: true,
  name: `BB Journey Web Perf Tests ${Math.ceil(Date.now() / 1000)}`,
};

exports.config = {
  ...config,
  ...perf,
  maxInstances: 5,
};
