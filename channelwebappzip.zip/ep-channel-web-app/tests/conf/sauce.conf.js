exports.sauceConfig = {
  user: 'MCP.Endeavor',
  key: 'b200bb9a-35a5-4df0-ade2-51014c8e2e32',
  region: 'eu',
  services: ['intercept'],
  capabilities: [
    {
      maxInstances: 10,
      browserName: 'chrome',
      browserVersion: 'latest',
      platformName: 'Windows 10',
      'sauce:options': {
        commandTimeout: 600,
        idleTimeout: 900,
        maxDuration: 10800,
        screenResolution: '1440x900',
      },
    },
  ],
};
