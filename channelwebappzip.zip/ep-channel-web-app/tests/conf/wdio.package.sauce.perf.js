/* eslint-disable @typescript-eslint/no-var-requires */
const whoami = require('../../scripts/whoami');
const { config } = require('./shared/sauce.conf.js');
const { perf } = require('./types/wdio.package.perf.js');

config.capabilities[0]['sauce:options'] = {
  ...config.capabilities[0]['sauce:options'],
  build: `BB Journey Page Performance ${whoami}`,
  capturePerformance: true,
  extendedDebugging: true,
  name: `BB Journey Page Performance ${whoami} ${Math.ceil(Date.now() / 1000)}`,
};

exports.config = {
  ...config,
  ...perf,
};
