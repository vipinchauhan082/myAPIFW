/* eslint-disable global-require */
/* eslint-disable @typescript-eslint/no-var-requires */
const path = require('path');
// /* eslint-disable import/no-unresolved */
// const { generate } = require('multiple-cucumber-html-reporter');
const del = require('del');
const cucumberJson = require('wdio-cucumberjs-json-reporter').default;
const envConfig = require('./shared/env.conf.js');
const selectors = require('../src/features/support/loadDataAndLocators.ts');

const featureFiles = path.resolve(
  __dirname,
  '../../packages/journey-personal-details/tests/featuresFiles/reviewCPRColleague.functional.feature',
);
const common = path.resolve(
  __dirname,
  '../src/features/stepDefs/common.steps.ts',
);

const NIN = path.resolve(
  __dirname,
  '../../packages/journey-create-customer/tests/stepDefs/createAccount.steps.ts',
);

const commPref = path.resolve(
  __dirname,
  '../../packages/journey-create-customer/tests/stepDefs/viewCustomerDetails.steps.ts',
);

const amentAccount = path.resolve(
  __dirname,
  '../../packages/journey-amend-account-options/tests/stepDefs/amendAccountOptions.steps.ts',
);

const accessibility = path.resolve(
  __dirname,
  '../src/features/stepDefs/accessibility.steps.ts',
);

// const createAccount = path.resolve(
//   __dirname,
//   '../../packages/journey-create-customer/tests/stepDefs/createAccount.steps.ts',
// );

// const createCustomer = path.resolve(
//   __dirname,
//   '../../packages/journey-create-customer/tests/stepDefs/viewCustomerDetails.steps.ts',
// );

const api = path.resolve(__dirname, '../src/features/stepDefs/api.steps.ts');
const perf = path.resolve(__dirname, '../src/features/stepDefs/perf.steps.ts');
const stepDefJourney = path.resolve(
  __dirname,
  '../src/features/stepDefs/login-navigation.steps.ts',
);
const closeAccount = path.resolve(
  __dirname,
  '../../packages/journey-amend-account-options/tests/stepDefs/amendAccountOptions.steps.ts',
);

let url = envConfig.getConfig(process.env.ENV).ENV_URL;

let tagExpressionc = '';
if (process.env.USERTYPE === 'customer') {
  tagExpressionc =
    'not @manual and not @mock and not @ignore and not @R4OutOfScope and not @onlycolleague';
  url = envConfig.getConfig(process.env.ENV).ENV_URL;
} else {
  tagExpressionc =
    'not @manual and not @mock and not @ignore and not @R4OutOfScope and not @onlycustomer';
  url = envConfig.getConfig(process.env.ENV).COLLEAUGE_ENV_URL;
}

global.downloadDir = path.join(__dirname, '../src/features/tempDownload');

exports.config = {
  runner: 'local',
  user: 'MCP.Endeavor',
  key: 'b200bb9a-35a5-4df0-ade2-51014c8e2e32',
  region: 'eu',
  specs: [featureFiles],
  // Patterns to exclude.
  exclude: [
    // 'path/to/excluded/files'
  ],
  maxInstances: 10,

  capabilities: [
    {
      maxInstances: 5,
      browserName: 'chrome',
      version: 'latest',
      platform: 'Windows 10',
      build: 'BB Cust Journey Functional BDDs',
      name: 'Amit',
      maxDuration: 10800,
      idleTimeout: 900,
      commandTimeout: 600,
      excludeDriverLogs: ['*'],
    },
  ],
  logLevel: 'info',
  bail: 0,
  baseUrl: url,
  waitforTimeout: 180000,
  connectionRetryTimeout: 90000,
  connectionRetryCount: 0,
  framework: 'cucumber',
  reporters: [
    'spec',
    [
      'cucumberjs-json',
      {
        jsonFolder: 'tests/reports/json/',
      },
    ],
  ],
  cucumberOpts: {
    require: [
      common,
      accessibility,
      api,
      perf,
      stepDefJourney,
      NIN,
      commPref,
      amentAccount,
      closeAccount,
    ],
    backtrace: false,
    dryRun: false,
    failFast: false,
    format: ['pretty'],
    colors: true,
    snippets: true,
    source: true,
    profile: [],
    strict: false,
    tagExpression: tagExpressionc,
    timeout: 60000,
    ignoreUndefinedDefinitions: false,
    requireModule: [
      'tsconfig-paths/register',
      () => {
        require('ts-node').register(
          {
            transpileOnly: true,
          },
          { files: true },
        );
      },
    ],
  },
  onPrepare: async () => {
    await del(['tests/reports/json/*.json', `$downloadDir/*.pdf`]);
  },

  // onComplete: () => {
  // // Generate the report when it all tests are done
  // generate({
  //     saveCollectedJSON: true,
  //     jsonDir: 'tests/reports/json/',
  //     reportPath: 'tests/reports/html/',
  //     openReportInBrowser: true,
  //     reportName: `Execution-Result-${new Date().toJSON().replace(/:/g, '-')}`,
  // });
  // },

  before: async () => {
    const Selectors = new Promise(reslove => {
      // eslint-disable-next-line no-unused-expressions
      selectors.objYaml ? reslove() : selectors.mergeLocatorsYamls(reslove);
    });
    const Data = await new Promise(reslove => {
      // eslint-disable-next-line no-unused-expressions
      selectors.objYaml ? reslove() : selectors.mergeDataYamls(reslove);
    });
    return { Selectors, Data };
  },

  afterScenario(uri, feature, scenario, result) {
    const cucumber = require('cucumber');
    if (result.status === cucumber.Status.FAILED) {
      // eslint-disable-next-line no-undef
      cucumberJson.attach(browser.takeScreenshot(), 'image/png');
    }
  },
};
