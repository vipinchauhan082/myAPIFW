module.exports = {
  name: 'EP Channel Web App | Documentation',
  mode: 'file',
  out: './typedoc',
  inputFiles: ['./packages'],
  readme: './README.md',
  exclude: ['**/*.test.tsx', '**/*.test'],
  ignoreCompilerErrors: true,
};
