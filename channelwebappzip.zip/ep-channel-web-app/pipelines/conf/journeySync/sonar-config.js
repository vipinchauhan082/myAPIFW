const config = {
  'sonar.projectVersion': '1.1.0',
  'sonar.javascript.file.suffixes': '.js,.jsx',
  'sonar.typescript.file.suffixes': '.ts,.tsx',
  'sonar.exclusions':
    'src/App.tsx,**/style.ts,**/*.xml,**/node_modules/**,**/coverage/**,**/**/story.tsx,**/__mockdata__/**/*,**/__test__/**/*,**/setupTests.ts,**/preSetupTests.ts,**/config/**,**/config.ts,**/enum.ts',
};
const sonarServer = 'https://sonar.mgmt-bld.oncp.dev/';

module.exports = {
  config,
  sonarServer,
};
