/* eslint-disable */
const scanner = require('sonarqube-scanner');
const { config, sonarServer } = require('./sonar-config');

scanner(
  {
    serverUrl: sonarServer,
    options: {
      ...config,
      'sonar.projectKey': 'ep-journey-web-app',
      'sonar.sources': 'packages',
    },
  },

  () => {
    // callback is required
  },
);
