/* eslint-disable */
const scanner = require('sonarqube-scanner');
const { config, sonarServer } = require('./journeys/sonar-config');

scanner(
  {
    serverUrl: sonarServer,
    options: {
      ...config,
      'sonar.projectKey': 'ep-channel-web-app',
      'sonar.sources': 'packages',
    },
  },
  () => {
    scanner(
      {
        serverUrl: sonarServer,
        options: {
          ...config,
          'sonar.projectKey': 'ep-channel-web-app-shared',
          'sonar.sources': 'packages/channel-common/src',
          'sonar.typescript.lcov.reportPaths':
            'packages/channel-common/coverage/lcov.info',
          'sonar.exclusions':
            '**/*.xml,**/node_modules/**,**/coverage/**,**/**/story.tsx,**/__mockdata__/**/*,**/__test__/**/*,**/__tests__/**/*',
        },
      }
    );
  },
);
