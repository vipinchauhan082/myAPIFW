/* eslint-disable */
/**
 * This file will be replaced, once the assembler changes starts going in.
 * The relative path for this file is parent directory.
 */
const webpack = require('webpack');
const path = require('path');
const HtmlWebpackPlugin = require('html-webpack-plugin');
const { BundleAnalyzerPlugin } = require('webpack-bundle-analyzer');
const dotenv = require('dotenv');
const fs = require('fs');
const webpackCommon = require('./webpack/common');
const microAppConfig = require('./webpack/config/microapp');

const getConfig = (pagePath, buildPath, versionMapperOpts) => {
  const commonConfig = webpackCommon('journeys', 'development');

  return {
    stats: "errors-only",
    entry: commonConfig.entry,
    output: commonConfig.output(buildPath,process.env.npm_package_version),
    devServer: commonConfig.devServer(pagePath),
    module: commonConfig.module,
    resolve: {
      extensions: ['.js', '.jsx', '.tsx', '.ts', '.json'],
      alias: {
        'react-dom': '@hot-loader/react-dom',
        'styled-components': path.resolve(
          '../../node_modules/styled-components',
        ),
      },
    },
    plugins: [
      new HtmlWebpackPlugin({
        template: require('html-webpack-template'),
        inject: false,
        appMountId: 'app',
      }),
    ],
    optimization: commonConfig.optimization,
  };
};

module.exports = (env, argv, pathToBuild, barOpts = {}, versionMapperOpts = { type: 'default'}) => {
  const { pagePath, buildPath } = pathToBuild;
  let config = getConfig(pagePath, buildPath, versionMapperOpts);
  if (argv.hot) {
    // Cannot use 'contenthash' when hot reloading is enabled.
    config.output.filename = '[name].[hash].js';
  }
  // Temporarily using if.com config during microapp build.
  // Will later pass this config from within the journey
  const currentPath = path.join(buildPath);
  const basePath = `${currentPath}/.env`;
  const envPath = `${basePath}.${argv.mode}`;
  const finalPath = fs.existsSync(envPath) ? envPath : basePath;
  const fileEnv = dotenv.config({ path: finalPath }).parsed;
  if (argv.analyser === 'true') {
    config.plugins.push(
      new BundleAnalyzerPlugin({
        generateStatsFile: true,
      }),
    );
  }
  if (fs.existsSync(finalPath)) {
    const envKeys = Object.keys(fileEnv).reduce((prev, next) => {
      const prevEnv = prev;
      prevEnv[`process.env.${next}`] = JSON.stringify(fileEnv[next]);
      return prevEnv;
    }, {});

    config.plugins.push(new webpack.DefinePlugin(envKeys));
  }
  return microAppConfig(argv, buildPath, config, barOpts, versionMapperOpts);
};
