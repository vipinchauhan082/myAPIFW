#!/bin/sh
# script to fetch latest FFC module from nexus and override the local module
#
# wired up in top-level package.json as a postinstall task - run `npm run install` or `yarn install`
#  to do a lwrna bootstrap followed by update using this script
#
# TODO fetch https://nexus-eeg.eplus-bld-02.oncp.dev/repository/eplus-ffc-npm/@ffc/profiler and read /dist-tags/latest
# to automatically update to new versions
# manually update the target version on the line below if a newer version is released
FFC_VERSION=1.0.0
FFC_TMP_DIR=tmp-ffc
echo "updating FFC module v${FFC_VERSION} from nexus"

mkdir ${FFC_TMP_DIR}
cd ${FFC_TMP_DIR}
curl https://nexus-eeg.eplus-bld-02.oncp.dev/repository/eplus-ffc-npm/@ffc/profiler/-/profiler-${FFC_VERSION}.tgz > profiler.tgz
echo "  ...fetched"
tar xfz profiler.tgz
echo "  ...extracted"
cp -r package/* ../local-modules/ffc/profiler/
echo "  ...copied"
cd ..
rm -rf ${FFC_TMP_DIR}
echo "done (manual git commit required)"
