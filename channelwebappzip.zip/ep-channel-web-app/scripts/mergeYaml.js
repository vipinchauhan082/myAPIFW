/* eslint-disable no-console */
/* eslint-disable @typescript-eslint/no-var-requires */
const mergeYaml = require('merge-yaml');
const util = require('util');
const path = require('path');
const glob = require('glob');
const fs = require('fs');

const getPathForDataLocator = () => {
  let filePath = '';
  if (process.env.DATA === 'jrn') {
    filePath = `..//packages/**/tests/testData/${process.env.BRAND}/*.${process.env.ENV}.journey.data.yml`;
  } else {
    filePath = `../apps/if.com/**/tests/testData/${process.env.BRAND}/${process.env.ENV}.${process.env.DATA}.data.yml`;
  }
  return filePath;
};

const locatorsFiles = `../packages/**/tests/pageLocators/*.locators.yml`;
const dataFiles = getPathForDataLocator();

const generateFile = (filesToMerge, filename) => {
  const mergedData = mergeYaml(glob.sync(path.join(__dirname, filesToMerge)));
  const fileData = `exports.config =${util.inspect(mergedData)}`;

  fs.writeFile(filename, fileData, err => {
    if (err) {
      return console.log(err);
    }
    return true;
  });
};

generateFile(locatorsFiles, './tests/locator.js');
generateFile(dataFiles, './tests/data.js');
