#!/bin/bash
# $1 is the GCS bucket name, full string including gs://
# $2 is the journey name

BUILD_DIR="build"

# sync the current journey to GCS
#export https_proxy='http://10.84.65.177:8118'

# sleep to wait for workload identity
sleep 100

# Remove config
#rm build/journey-mapper.json

gsutil ls "${1}"
#echo "Removing old journey artifact"
#gsutil rm -r "${1}/${2}" || echo "Artifact ${2} not found"

echo "Syncing new journey artifact"
gsutil -m rsync -r build "${1}"
gsutil -m rsync -r build "${2}"
echo "Getting new bucket state"
gsutil ls "${1}"
gsutil ls "${2}"

# This is so that the istio sidecar is killed, allowing the job to terminate
#exec su-exec root pkill -f /usr/local/bin/pilot-agent

echo "Istio terminated"
