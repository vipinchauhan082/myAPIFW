/* eslint-disable global-require */
const whoami = () => {
  const username = require('child_process').execSync('whoami', {
    encoding: 'utf-8',
  });
  return String(username).trim();
};

module.exports = whoami();
