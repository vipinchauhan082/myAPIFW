#!/bin/bash
BUILD_DIR="build"

echo "Setting up Build Directories"
[ ! -d "$BUILD_DIR" ] && mkdir -p "$BUILD_DIR" || rm -rfv "$BUILD_DIR/*"

# Loop over and copy the files in place
for f in ./packages/$1/build; do
    PACKAGE_NAME=$(basename $(dirname $f))
    PACKAGE_NAME=`echo $PACKAGE_NAME | cut -d "-" -f2-`
    echo $PACKAGE_NAME
    cp -vR "$f" ./$BUILD_DIR/$PACKAGE_NAME/
done

rm -r /app/packages
