/* eslint-disable */
const { exec } = require('child_process');
const util = require('util');
const fs = require('fs');

exec('lerna ls -p --since', (error, stdout, stderr) => {
  if (error) {
    console.log(`error: ${error.message}`);
    return;
  }
  if (stderr) {
    console.log(`stderr: ${stderr}`);
    //return;
  }
  let output = stdout.split('\n');
  output = JSON.stringify(output);
  output = `exports.config =${output}`;

  fs.writeFile('./tests/changedPackages.js', output, err => {
    if (err) {
      return console.log(err);
    }
    return true;
  });
});
