
NGNIX_APP_CONFIG="/app/nginx/conf/application.conf"
JOURNEY_COTAINER_NAME="journey-build"
JOURNEY_COTAINER_PROXY="proxy_pass http://${JOURNEY_COTAINER_NAME}/journey-webapp;"

function escape_slashes {
  sed 's/\//\\\//g' 
}

function change_line {
  local OLD_LINE_PATTERN=$1; shift
  local NEW_LINE=$1; shift
  local FILE=$1

  local NEW=$(echo "${NEW_LINE}" | escape_slashes)
  sed -i '/'"${OLD_LINE_PATTERN}"'/s/.*/'"${NEW}"'/' "${FILE}"
}

#Reverse proxy to 2nd container running Journey for accessing journey JS bundles
change_line "alias \/etc\/nginx\/html\/;" "${JOURNEY_COTAINER_PROXY}" $NGNIX_APP_CONFIG
change_line "try_files \$uri \$uri\/ =404;" "" $NGNIX_APP_CONFIG
#Remove CROS, security for accessiling local mock server
change_line "add_header Content-Security-Policy" "" $NGNIX_APP_CONFIG
