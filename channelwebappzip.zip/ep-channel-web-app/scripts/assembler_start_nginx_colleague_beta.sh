#!/bin/sh
# in beta, we have two env vars per brand - base values used by stable, plus beta overrides

# tidy up env variables
IF_APP_CONFIG_JSON=${IF_APP_CONFIG_JSON:-\{\}}
# replace first and last double quote
IF_APP_CONFIG_JSON="${IF_APP_CONFIG_JSON%\"}"
IF_APP_CONFIG_JSON="${IF_APP_CONFIG_JSON#\"}"

IF_APP_CONFIG_JSON_BETA_OVERRIDES=${IF_APP_CONFIG_JSON_BETA_OVERRIDES:-\{\}}
# replace first and last double quote
IF_APP_CONFIG_JSON_BETA_OVERRIDES="${IF_APP_CONFIG_JSON_BETA_OVERRIDES%\"}"
IF_APP_CONFIG_JSON_BETA_OVERRIDES="${IF_APP_CONFIG_JSON_BETA_OVERRIDES#\"}"


SJPB_APP_CONFIG_JSON=${SJPB_APP_CONFIG_JSON:-\{\}}
# replace first and last double quote
SJPB_APP_CONFIG_JSON="${SJPB_APP_CONFIG_JSON%\"}"
SJPB_APP_CONFIG_JSON="${SJPB_APP_CONFIG_JSON#\"}"

SJPB_APP_CONFIG_JSON_BETA_OVERRIDES=${SJPB_APP_CONFIG_JSON_BETA_OVERRIDES:-\{\}}
# replace first and last double quote
SJPB_APP_CONFIG_JSON_BETA_OVERRIDES="${SJPB_APP_CONFIG_JSON_BETA_OVERRIDES%\"}"
SJPB_APP_CONFIG_JSON_BETA_OVERRIDES="${SJPB_APP_CONFIG_JSON_BETA_OVERRIDES#\"}"


COLLEAGUE_APP_CONFIG_JSON=${COLLEAGUE_APP_CONFIG_JSON:-\{\}}
# replace first and last double quote from  IF CONFIG
COLLEAGUE_APP_CONFIG_JSON="${COLLEAGUE_APP_CONFIG_JSON%\"}"
COLLEAGUE_APP_CONFIG_JSON="${COLLEAGUE_APP_CONFIG_JSON#\"}"

COLLEAGUE_APP_CONFIG_JSON_BETA_OVERRIDES=${COLLEAGUE_APP_CONFIG_JSON_BETA_OVERRIDES:-\{\}}
# replace first and last double quote
COLLEAGUE_APP_CONFIG_JSON_BETA_OVERRIDES="${COLLEAGUE_APP_CONFIG_JSON_BETA_OVERRIDES%\"}"
COLLEAGUE_APP_CONFIG_JSON_BETA_OVERRIDES="${COLLEAGUE_APP_CONFIG_JSON_BETA_OVERRIDES#\"}"


# pipe base and beta config into files in order to merge them with jq, 
# easier to read files than trying to feed env vars into jq
mkdir /tmp/json

echo $IF_APP_CONFIG_JSON > /tmp/json/if_base.json
echo $IF_APP_CONFIG_JSON_BETA_OVERRIDES > /tmp/json/if_beta.json
export IF_APP_CONFIG_JSON_MERGED=`jq -s '.[0] * .[1]' -c /tmp/json/if_base.json /tmp/json/if_beta.json`

echo $SJPB_APP_CONFIG_JSON > /tmp/json/sjpb_base.json
echo $SJPB_APP_CONFIG_JSON_BETA_OVERRIDES > /tmp/json/sjpb_beta.json
export SJPB_APP_CONFIG_JSON_MERGED=`jq -s '.[0] * .[1]' -c /tmp/json/sjpb_base.json /tmp/json/sjpb_beta.json`

echo $COLLEAGUE_APP_CONFIG_JSON > /tmp/json/colleague_base.json
echo $COLLEAGUE_APP_CONFIG_JSON_BETA_OVERRIDES > /tmp/json/colleague_beta.json
export COLLEAGUE_APP_CONFIG_JSON_MERGED=`jq -s '.[0] * .[1]' -c /tmp/json/colleague_base.json /tmp/json/colleague_beta.json`
rm -rf /tmp/json

# Inject config in brand_env.json by escaping / in URLs
sed -i "s/__APP_CONFIG_JSON__/${IF_APP_CONFIG_JSON_MERGED//\//\\/}/g" /usr/share/nginx/html/if.com/brand/brand-env.json
sed -i "s/__APP_CONFIG_JSON__/${SJPB_APP_CONFIG_JSON_MERGED//\//\\/}/g" /usr/share/nginx/html/sjpb/brand/brand-env.json
sed -i "s/__APP_CONFIG_JSON__/${COLLEAGUE_APP_CONFIG_JSON_MERGED//\//\\/}/g" /usr/share/nginx/html/colleague/brand/brand-env.json
nginx -g "daemon off;"

/bin/sh
