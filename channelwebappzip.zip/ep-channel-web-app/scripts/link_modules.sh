#!/bin/sh
ROOT_PATH=$(pwd)
cd /appdir
pigz -dc repo | tar xf -
rm -rf repo
PACKAGE_LIST=$(lerna list)
HOME_PATH='/appdir'
ln -sf $HOME_PATH/node_modules $ROOT_PATH/node_modules
for f in $PACKAGE_LIST; do
  PACKAGE_NAME=`echo $f | cut -d'@' -f 2`
  echo "creating symlink for" $PACKAGE_NAME
  if echo "$PACKAGE_NAME" | grep -Eq '^apps/if';
  then
    [ -d $HOME_PATH/apps/if.com/node_modules ] && ln -sf $HOME_PATH/apps/if.com/node_modules $ROOT_PATH/apps/if.com/node_modules || echo "dir doesn't exist"
  elif [ $PACKAGE_NAME == "assembler" ] || echo "$PACKAGE_NAME" | grep -Eq '^apps/' || [ $PACKAGE_NAME == "generators" ]
  then
    [ -d $HOME_PATH/$PACKAGE_NAME/node_modules ] && ln -sf $HOME_PATH/$PACKAGE_NAME/node_modules $ROOT_PATH/$PACKAGE_NAME/node_modules || echo "dir doesn't exist"
  elif echo "$PACKAGE_NAME" | grep -Eq '^channels/'
  then
    PACKAGE_REF=`echo "$PACKAGE_NAME" | sed 's/s\//\-/g'`
    [ -d $HOME_PATH/packages/$PACKAGE_REF/node_modules ] && ln -sf $HOME_PATH/packages/$PACKAGE_REF/node_modules $ROOT_PATH/packages/$PACKAGE_REF/node_modules || echo "dir doesn't exist"
  else
    PACKAGE_REF=`echo "$PACKAGE_NAME" | sed 's/\//\-/g'`
    [ -d $HOME_PATH/packages/$PACKAGE_REF/node_modules ] && ln -sf $HOME_PATH/packages/$PACKAGE_REF/node_modules $ROOT_PATH/packages/$PACKAGE_REF/node_modules || echo "dir doesn't exist"
  fi
done
cd $ROOT_PATH
