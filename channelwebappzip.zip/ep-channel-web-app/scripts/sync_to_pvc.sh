#!/bin/bash

# Wait for workload identity
sleep 60

# $1 is the GCS bucket name, full string including gs://
# $2 is the pvc mount point
echo "Checking directory state"
ls "/app"
ls "${2}"
echo "Syncing journey artifacts"
gsutil -m rsync -r "${1}" "${2}"
echo "Sync completed"
