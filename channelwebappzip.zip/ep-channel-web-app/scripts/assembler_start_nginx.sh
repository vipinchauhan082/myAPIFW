#!/bin/sh


IF_APP_CONFIG_JSON=${IF_APP_CONFIG_JSON:-\{\}}

# replace first and last double quote from  IF CONFIG
IF_APP_CONFIG_JSON="${IF_APP_CONFIG_JSON%\"}"
IF_APP_CONFIG_JSON="${IF_APP_CONFIG_JSON#\"}"

SJPB_APP_CONFIG_JSON=${SJPB_APP_CONFIG_JSON:-\{\}}

# replace first and last double quote from  IF CONFIG
SJPB_APP_CONFIG_JSON="${SJPB_APP_CONFIG_JSON%\"}"
SJPB_APP_CONFIG_JSON="${SJPB_APP_CONFIG_JSON#\"}"

# Inject config in brand_env.json by escaping / in URLs
echo "injecting if $IF_APP_CONFIG_JSON"
sed -i "s/__APP_CONFIG_JSON__/${IF_APP_CONFIG_JSON//\//\\/}/g" /usr/share/nginx/html/if.com/brand/brand-env.json
echo "injecting if $IF_APP_CONFIG_JSON"
sed -i "s/__APP_CONFIG_JSON__/${SJPB_APP_CONFIG_JSON//\//\\/}/g" /usr/share/nginx/html/sjpb/brand/brand-env.json
echo "injecting if $IF_APP_CONFIG_JSON"
nginx -g "daemon off;"

/bin/sh
