#### What does this PR do?

- [EXAMPLE] This PR adds the functionality for login functionality
- [EXAMPLE] This PR has all BDD test coverage

#### What are the relevant tickets?

[BB-\*\*\*](https://ltmhedge.atlassian.net/browse/BB-****)

#### Does your PR meet the definition of DOD as described below?

- [ ] Core Implementation : Does the change meet all functional requirements?
- [ ] Have you written new unit tests for your changes as applicable?
- [ ] Does this PR have API Integration?
- [ ] Have you linted your code correctly and does it pass quality gates within Sonar?
- [ ] Have you updated or created the relevant storybook components?
- [ ] Have you added the appropriate documentation to your code to understand the context?
- [ ] Have you had UX review?
- [ ] Have you had copy review?
- [ ] Does BDD tests cover appropriate scenarios or have meaningful coverage?
- [ ] Does the change meet all functional and visual use across browser and devices?
- [ ] Have you migrated X-Ray test cases to JIRA?

#### Notes

- [EXAMPLE] Tell me something useful. API Dependency raised BB-1234
