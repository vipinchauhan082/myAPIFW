module.exports = {
  processors: ['stylelint-processor-styled-components'],
  extends: [
    'stylelint-config-styled-components',
    'stylelint-config-recommended',
    'stylelint-config-prettier',
  ],
  rules: {
    'no-empty-source': null,
    'color-no-hex': true,
    'color-no-invalid-hex': true,
    'color-named': 'never',
    'comment-empty-line-before': [
      'always',
      {
        ignore: ['stylelint-commands', 'after-comment'],
      },
    ],
    'declaration-colon-space-after': 'always',
    'no-descending-specificity': null,
    'no-invalid-double-slash-comments': null,
    'declaration-block-trailing-semicolon': 'always',
    'no-duplicate-selectors': null,
    'property-no-unknown': null,
    'function-blacklist': ['rgb', 'rgba'],
    'max-empty-lines': 2,
    'rule-empty-line-before': [
      'always',
      {
        except: ['first-nested'],
        ignore: ['after-comment'],
      },
    ],
    'unit-whitelist': ['px', 'vh', 'vw', '%'],
  },
};
