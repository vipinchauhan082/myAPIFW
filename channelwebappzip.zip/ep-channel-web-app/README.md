# ep-channel-web-app

Monorepo for web channel development

## Quality Report

| Package                         | Quality Gate                                                                                                                                                                                                                         | Coverage                                                                                                                                                                                                              |
| ------------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ | --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| IF                              | [![Quality Gate Status](https://sonar.mgmt-bld.oncp.dev/api/project_badges/measure?project=ep-journey-if&metric=alert_status)](https://sonar.mgmt-bld.oncp.dev/dashboard?id=ep-journey-if)                                           | [![Coverage](https://sonar.mgmt-bld.oncp.dev/api/project_badges/measure?project=ep-journey-if&metric=coverage)](https://sonar.mgmt-bld.oncp.dev/dashboard?id=ep-journey-if)                                           |
| SJPB                            | [![Quality Gate Status](https://sonar.mgmt-bld.oncp.dev/api/project_badges/measure?project=ep-journey-sjpb&metric=alert_status)](https://sonar.mgmt-bld.oncp.dev/dashboard?id=ep-journey-sjpb)                                       | [![Coverage](https://sonar.mgmt-bld.oncp.dev/api/project_badges/measure?project=ep-journey-sjpb&metric=coverage)](https://sonar.mgmt-bld.oncp.dev/dashboard?id=ep-journey-sjpb)                                       |
| Colleague                       | [![Quality Gate Status](https://sonar.mgmt-bld.oncp.dev/api/project_badges/measure?project=ep-journey-colleague&metric=alert_status)](https://sonar.mgmt-bld.oncp.dev/dashboard?id=ep-journey-colleague)                             | [![Coverage](https://sonar.mgmt-bld.oncp.dev/api/project_badges/measure?project=ep-journey-colleague&metric=coverage)](https://sonar.mgmt-bld.oncp.dev/dashboard?id=ep-journey-colleague)                             |
| Assembler                       | [![Quality Gate Status](https://sonar.mgmt-bld.oncp.dev/api/project_badges/measure?project=ep-channel-assembler&metric=alert_status)](https://sonar.mgmt-bld.oncp.dev/dashboard?id=ep-channel-assembler)                             | [![Coverage](https://sonar.mgmt-bld.oncp.dev/api/project_badges/measure?project=ep-channel-assembler&metric=coverage)](https://sonar.mgmt-bld.oncp.dev/dashboard?id=ep-channel-assembler)                             |
| channel-automation              | [![Quality Gate Status](https://sonar.mgmt-bld.oncp.dev/api/project_badges/measure?project=ep-channel-automation&metric=alert_status)](https://sonar.mgmt-bld.oncp.dev/dashboard?id=ep-channel-automation)                           | [![Coverage](https://sonar.mgmt-bld.oncp.dev/api/project_badges/measure?project=ep-channel-automation&metric=coverage)](https://sonar.mgmt-bld.oncp.dev/dashboard?id=ep-channel-automation)                           |
| channel-components              | [![Quality Gate Status](https://sonar.mgmt-bld.oncp.dev/api/project_badges/measure?project=ep-channel-components&metric=alert_status)](https://sonar.mgmt-bld.oncp.dev/dashboard?id=ep-channel-components)                           | [![Coverage](https://sonar.mgmt-bld.oncp.dev/api/project_badges/measure?project=ep-channel-components&metric=coverage)](https://sonar.mgmt-bld.oncp.dev/dashboard?id=ep-channel-components)                           |
| channel-context                 | [![Quality Gate Status](https://sonar.mgmt-bld.oncp.dev/api/project_badges/measure?project=ep-channel-context&metric=alert_status)](https://sonar.mgmt-bld.oncp.dev/dashboard?id=ep-channel-context)                                 | [![Coverage](https://sonar.mgmt-bld.oncp.dev/api/project_badges/measure?project=ep-channel-context&metric=coverage)](https://sonar.mgmt-bld.oncp.dev/dashboard?id=ep-channel-context)                                 |
| channel-utils                   | [![Quality Gate Status](https://sonar.mgmt-bld.oncp.dev/api/project_badges/measure?project=ep-channel-utils&metric=alert_status)](https://sonar.mgmt-bld.oncp.dev/dashboard?id=ep-channel-utils)                                     | [![Coverage](https://sonar.mgmt-bld.oncp.dev/api/project_badges/measure?project=ep-channel-utils&metric=coverage)](https://sonar.mgmt-bld.oncp.dev/dashboard?id=ep-channel-utils)                                     |
| journey-amend-account-options   | [![Quality Gate Status](https://sonar.mgmt-bld.oncp.dev/api/project_badges/measure?project=ep-journey-amend-account-options&metric=alert_status)](https://sonar.mgmt-bld.oncp.dev/dashboard?id=ep-journey-amend-account-options)     | [![Coverage](https://sonar.mgmt-bld.oncp.dev/api/project_badges/measure?project=ep-journey-amend-account-options&metric=coverage)](https://sonar.mgmt-bld.oncp.dev/dashboard?id=ep-journey-amend-account-options)     |
| journey-auth-platform           | [![Quality Gate Status](https://sonar.mgmt-bld.oncp.dev/api/project_badges/measure?project=ep-journey-auth-platform&metric=alert_status)](https://sonar.mgmt-bld.oncp.dev/dashboard?id=ep-journey-auth-platform)                     | [![Coverage](https://sonar.mgmt-bld.oncp.dev/api/project_badges/measure?project=ep-journey-auth-platform&metric=coverage)](https://sonar.mgmt-bld.oncp.dev/dashboard?id=ep-journey-auth-platform)                     |
| journey-auth-platform-colleague | [![Quality Gate Status](https://sonar.mgmt-bld.oncp.dev/api/project_badges/measure?project=ep-journey-auth-platform-colleague&metric=alert_status)](https://sonar.mgmt-bld.oncp.dev/dashboard?id=ep-journey-auth-platform-colleague) | [![Coverage](https://sonar.mgmt-bld.oncp.dev/api/project_badges/measure?project=ep-journey-auth-platform-colleague&metric=coverage)](https://sonar.mgmt-bld.oncp.dev/dashboard?id=ep-journey-auth-platform-colleague) |
| journey-auth-reset              | [![Quality Gate Status](https://sonar.mgmt-bld.oncp.dev/api/project_badges/measure?project=ep-journey-auth-reset&metric=alert_status)](https://sonar.mgmt-bld.oncp.dev/dashboard?id=ep-journey-auth-reset)                           | [![Coverage](https://sonar.mgmt-bld.oncp.dev/api/project_badges/measure?project=ep-journey-auth-reset&metric=coverage)](https://sonar.mgmt-bld.oncp.dev/dashboard?id=ep-journey-auth-reset)                           |
| journey-colleague-finder        | [![Quality Gate Status](https://sonar.mgmt-bld.oncp.dev/api/project_badges/measure?project=ep-journey-colleague-finder&metric=alert_status)](https://sonar.mgmt-bld.oncp.dev/dashboard?id=ep-journey-colleague-finder)               | [![Coverage](https://sonar.mgmt-bld.oncp.dev/api/project_badges/measure?project=ep-journey-colleague-finder&metric=coverage)](https://sonar.mgmt-bld.oncp.dev/dashboard?id=ep-journey-colleague-finder)               |
| journey-colleague-payments      | [![Quality Gate Status](https://sonar.mgmt-bld.oncp.dev/api/project_badges/measure?project=ep-journey-colleague-payments&metric=alert_status)](https://sonar.mgmt-bld.oncp.dev/dashboard?id=ep-journey-colleague-payments)           | [![Coverage](https://sonar.mgmt-bld.oncp.dev/api/project_badges/measure?project=ep-journey-colleague-payments&metric=coverage)](https://sonar.mgmt-bld.oncp.dev/dashboard?id=ep-journey-colleague-payments)           |
| journey-create-account          | [![Quality Gate Status](https://sonar.mgmt-bld.oncp.dev/api/project_badges/measure?project=ep-journey-create-account&metric=alert_status)](https://sonar.mgmt-bld.oncp.dev/dashboard?id=ep-journey-create-account)                   | [![Coverage](https://sonar.mgmt-bld.oncp.dev/api/project_badges/measure?project=ep-journey-create-account&metric=coverage)](https://sonar.mgmt-bld.oncp.dev/dashboard?id=ep-journey-create-account)                   |
| journey-create-customer         | [![Quality Gate Status](https://sonar.mgmt-bld.oncp.dev/api/project_badges/measure?project=ep-journey-create-customer&metric=alert_status)](https://sonar.mgmt-bld.oncp.dev/dashboard?id=ep-journey-create-customer)                 | [![Coverage](https://sonar.mgmt-bld.oncp.dev/api/project_badges/measure?project=ep-journey-create-customer&metric=coverage)](https://sonar.mgmt-bld.oncp.dev/dashboard?id=ep-journey-create-customer)                 |
| journey-make-payment            | [![Quality Gate Status](https://sonar.mgmt-bld.oncp.dev/api/project_badges/measure?project=ep-journey-make-payment&metric=alert_status)](https://sonar.mgmt-bld.oncp.dev/dashboard?id=ep-journey-make-payment)                       | [![Coverage](https://sonar.mgmt-bld.oncp.dev/api/project_badges/measure?project=ep-journey-make-payment&metric=coverage)](https://sonar.mgmt-bld.oncp.dev/dashboard?id=ep-journey-make-payment)                       |
| journey-manage-cards            | [![Quality Gate Status](https://sonar.mgmt-bld.oncp.dev/api/project_badges/measure?project=ep-journey-manage-cards&metric=alert_status)](https://sonar.mgmt-bld.oncp.dev/dashboard?id=ep-journey-manage-cards)                       | [![Coverage](https://sonar.mgmt-bld.oncp.dev/api/project_badges/measure?project=ep-journey-manage-cards&metric=coverage)](https://sonar.mgmt-bld.oncp.dev/dashboard?id=ep-journey-manage-cards)                       |
| journey-manage-indicators       | [![Quality Gate Status](https://sonar.mgmt-bld.oncp.dev/api/project_badges/measure?project=ep-journey-manage-indicators&metric=alert_status)](https://sonar.mgmt-bld.oncp.dev/dashboard?id=ep-journey-manage-indicators)             | [![Coverage](https://sonar.mgmt-bld.oncp.dev/api/project_badges/measure?project=ep-journey-manage-indicators&metric=coverage)](https://sonar.mgmt-bld.oncp.dev/dashboard?id=ep-journey-manage-indicators)             |
| journey-manage-payments         | [![Quality Gate Status](https://sonar.mgmt-bld.oncp.dev/api/project_badges/measure?project=ep-journey-manage-payments&metric=alert_status)](https://sonar.mgmt-bld.oncp.dev/dashboard?id=ep-journey-manage-payments)                 | [![Coverage](https://sonar.mgmt-bld.oncp.dev/api/project_badges/measure?project=ep-journey-manage-payments&metric=coverage)](https://sonar.mgmt-bld.oncp.dev/dashboard?id=ep-journey-manage-payments)                 |
| journey-personal-details        | [![Quality Gate Status](https://sonar.mgmt-bld.oncp.dev/api/project_badges/measure?project=ep-journey-personal-details&metric=alert_status)](https://sonar.mgmt-bld.oncp.dev/dashboard?id=ep-journey-personal-details)               | [![Coverage](https://sonar.mgmt-bld.oncp.dev/api/project_badges/measure?project=ep-journey-personal-details&metric=coverage)](https://sonar.mgmt-bld.oncp.dev/dashboard?id=ep-journey-personal-details)               |
| journey-search-customer         | [![Quality Gate Status](https://sonar.mgmt-bld.oncp.dev/api/project_badges/measure?project=ep-journey-search-customer&metric=alert_status)](https://sonar.mgmt-bld.oncp.dev/dashboard?id=ep-journey-search-customer)                 | [![Coverage](https://sonar.mgmt-bld.oncp.dev/api/project_badges/measure?project=ep-journey-search-customer&metric=coverage)](https://sonar.mgmt-bld.oncp.dev/dashboard?id=ep-journey-search-customer)                 |
| journey-view-account-overview   | [![Quality Gate Status](https://sonar.mgmt-bld.oncp.dev/api/project_badges/measure?project=ep-journey-view-account-overview&metric=alert_status)](https://sonar.mgmt-bld.oncp.dev/dashboard?id=ep-journey-view-account-overview)     | [![Coverage](https://sonar.mgmt-bld.oncp.dev/api/project_badges/measure?project=ep-journey-view-account-overview&metric=coverage)](https://sonar.mgmt-bld.oncp.dev/dashboard?id=ep-journey-view-account-overview)     |
| journey-view-beneficiaries      | [![Quality Gate Status](https://sonar.mgmt-bld.oncp.dev/api/project_badges/measure?project=ep-journey-view-beneficiaries&metric=alert_status)](https://sonar.mgmt-bld.oncp.dev/dashboard?id=ep-journey-view-beneficiaries)           | [![Coverage](https://sonar.mgmt-bld.oncp.dev/api/project_badges/measure?project=ep-journey-view-beneficiaries&metric=coverage)](https://sonar.mgmt-bld.oncp.dev/dashboard?id=ep-journey-view-beneficiaries)           |
| journey-view-statement          | [![Quality Gate Status](https://sonar.mgmt-bld.oncp.dev/api/project_badges/measure?project=ep-journey-view-statement&metric=alert_status)](https://sonar.mgmt-bld.oncp.dev/dashboard?id=ep-journey-view-statement)                   | [![Coverage](https://sonar.mgmt-bld.oncp.dev/api/project_badges/measure?project=ep-journey-view-statement&metric=coverage)](https://sonar.mgmt-bld.oncp.dev/dashboard?id=ep-journey-view-statement)                   |
| journey-view-transaction        | [![Quality Gate Status](https://sonar.mgmt-bld.oncp.dev/api/project_badges/measure?project=ep-journey-view-transaction&metric=alert_status)](https://sonar.mgmt-bld.oncp.dev/dashboard?id=ep-journey-view-transaction)               | [![Coverage](https://sonar.mgmt-bld.oncp.dev/api/project_badges/measure?project=ep-journey-view-transaction&metric=coverage)](https://sonar.mgmt-bld.oncp.dev/dashboard?id=ep-journey-view-transaction)               |

## Installation

This repo uses [lerna](https://github.com/lerna/lerna) and [yarn workspaces](https://classic.yarnpkg.com/en/docs/workspaces/) for monorepo.

```sh
$ lerna bootstrap --use-workspaces
```

All dependencies should be retrieved via the central Nexus rather than the npm registry
This scans the dependencies for any security vulnerabilities. To set this run the following commands:

```sh
npm config set registry 'https://nexus.mgmt-bld.oncp.dev/repository/npm-proxy/'
yarn config set registry 'https://nexus.mgmt-bld.oncp.dev/repository/npm-proxy/'
```

You will need to be connected to the build environment to install any dependencies.

## Commands

### Serve and Watch:

Component library: this will start the storybook development instance.

```sh
yarn serve:common 
```

Channel Steel Thread Journey:

```sh
yarn serve:channel
```

```sh
// default
yarn serve
```

Example: you can use yarn serve:if to run IF brand on your local.

### Build

Build all _changed_ monorepo packages _since_ last change (tag):

```sh
yarn build
```

Build Common: Build Story book static bundle.

```sh
yarn build:common
```

Build: Channel Steel Thread Journey.

```sh
yarn build:channel
```

### Local Docker Micro-App Set-up

Local Docker setup equivalent to build environment micro-app. Container app communicates with journeys running in a separate container. Docker needs to be installed in system and in running state. VPN needs to be connected.

```sh
docker-compose -f docker/local/docker-compose.yml up --build  --remove-orphans
```

Journey app - localhost:1337

if.com app - if.localhost:1338

### Local Docker Set-up with mock service

Local Docker setup equivalent to build environment micro-app. Container app communicates with journeys running in a separate container. Docker needs to be installed in system and in running state. VPN needs to be connected.

```sh
docker-compose -f docker/local/docker-compose-mock-server.yml up --build  --remove-orphans
```

Journey mock - localhost:3000

wiremock app - localhost:3001

### Local Docker Quick Setup

A trimmed down version of the micro-app with local Docker set-up. Docker needs to be installed in system and in running state. VPN needs to be connected.

```sh
docker-compose -f docker/local/docker-compose-speedy.yml up --build  --remove-orphans
```

if.com app - if.localhost:1339

### Local Docker Setup for Build Level Validation

Docker needs to be installed in system and in running state. VPN needs to be connected

```sh
docker-compose -f docker/local/docker-compose-validate.yml up --build  --remove-orphans
```

### Generate Component

Generate component scaffolding

```sh
yarn generate
```

### Code style:

Coding styles to adhere to when working on this project are as follows:

[Frontend Development](https://ltmhedge.atlassian.net/wiki/spaces/EN/pages/435388538/Frontend+Development)

[Frontend Coding Standards and Best Practices](https://ltmhedge.atlassian.net/wiki/spaces/EN/pages/457278130/Frontend+Coding+Standards+and+Best+Practices)

[React component structure](https://ltmhedge.atlassian.net/wiki/spaces/EN/pages/645103882/React+component+structure)

#### Application build tools

| Tools     | URL                                                                                                     |
| --------- | ------------------------------------------------------------------------------------------------------- |
| Jenkins   | [https://jenkins-jrn-ctl.eplus-bld-02.oncp.dev/](https://jenkins-jrn-ctl.eplus-bld-02.oncp.dev/)        |
| Sonar     | [https://sonar.mgmt-bld.oncp.dev/](https://sonar.mgmt-bld.oncp.dev/)                                    |
| Speedy    | [https://speedy-cwa-ple.mgmt-bld.oncp.dev/](https://speedy-cwa-ple.mgmt-bld.oncp.dev/)                  |
| Storybook | [https://icp-ilbgw.eplus-bld-02.oncp.dev/storybook/](https://icp-ilbgw.eplus-bld-02.oncp.dev/storybook) |

#### Web Application IF

| Environment | URL                                                                                          |
| ----------- | -------------------------------------------------------------------------------------------- |
| BLD02       | [https://if-app.ew2.bld-02.ep.gcp.oncp.cloud/](https://if-app.ew2.bld-02.ep.gcp.oncp.cloud/) |
| Integration | [https://app.int01.if.e.lloydsbanking.com/](https://app.int01.if.e.lloydsbanking.com/)       |
| NFT         | [https://app.pre01.if.e.lloydsbanking.com/](https://app.pre01.if.e.lloydsbanking.com/)       |
| PROD        | [https://app.if.com/](https://app.if.com/)                                                   |

## Contact Information

### Maintainers

- Ankit Singhal: <ankit.singhal@publicissapient.com>
- David Crane: <david.crane@publicissapient.com>
- Kamar Rizwan: <kamar.rizwan@publicissapient.com>
- Mayank Singh: <mayank.singh@publicissapient.com>
- Marcus Kourie: <marcus.kourie@publicissapient.com>
- Venkatesh Mishra: <venkatesh.mishra@publicissapient.com>

## Release Notes

[v1.925.1](https://github.com/lbg-gcp-foundation/ep-channel-web-app/releases/tag/v1.925.1)
[v1.924.1](https://github.com/lbg-gcp-foundation/ep-channel-web-app/releases/tag/v1.924.1)
[v1.923.1](https://github.com/lbg-gcp-foundation/ep-channel-web-app/releases/tag/v1.923.1)

