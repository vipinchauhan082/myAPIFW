module.exports = {
  transform: {
    '^.+\\.svg$': 'jest-svg-transformer',
  },
  collectCoverageFrom: [
    './src/**/*.{js,jsx,ts,tsx}',
    '!**/*.style.ts',
    '!**/*.styles.ts',
    '!**/*.config.ts',
    '!**/*.page.ts',
    '!**/config.ts',
    '!**/enum.ts',
  ],
  coveragePathIgnorePatterns: [
    '/node_modules/',
    'App.tsx',
    '!*/__snapshots__',
    'setupTests.ts',
    'preSetupTests.ts',
    'react-app-env.d.ts',
    'style.ts',
    'styles.ts',
    'story.tsx',
    'types.ts',
  ],
  coverageReporters: ['lcov', 'text'],
  snapshotSerializers: [],
  coverageThreshold: {
    global: {
      branches: 80,
      functions: 80,
      lines: 80,
      statements: 80,
    },
  },
};
