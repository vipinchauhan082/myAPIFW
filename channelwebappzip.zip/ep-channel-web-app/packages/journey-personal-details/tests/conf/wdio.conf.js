/* eslint-disable @typescript-eslint/no-var-requires */
const path = require('path');
const baseConf = require('../../../../tests/conf/wdio.sauce.functional.js');

const featureFiles = path.resolve(__dirname, '../featuresFiles/*.feature');

const config = Object.assign(baseConf.config, {
  specs: [featureFiles],
});

exports.config = config;
