/* eslint-disable @typescript-eslint/no-var-requires */
const path = require('path');
const baseConf = require('../../../../tests/conf/wdio.sauce.perf.js');

const featureFiles = path.resolve(__dirname, '../featuresFiles/*.perf.feature');

const journeyName = __dirname.split('packages/')[1].split('/tests/')[0];

baseConf.config.capabilities[0]['sauce:options'] = {
  ...baseConf.config.capabilities[0]['sauce:options'],
  build: `BB ${journeyName} Perf BDDs ${Math.ceil(Date.now() / 1000)}`,
  name: `BB ${journeyName} perf BDDs ${Math.ceil(Date.now() / 1000)}`,
};

const config = Object.assign(baseConf.config, {
  specs: [featureFiles],
});

exports.config = config;
