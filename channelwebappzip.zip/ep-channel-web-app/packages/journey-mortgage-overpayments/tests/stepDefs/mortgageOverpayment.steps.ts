/* eslint-disable no-undef */
/* eslint-disable @typescript-eslint/no-var-requires */
const { Then } = require('cucumber');
const { assert } = require('chai');
const Selectors = require('../../../../tests/src/features/support/loadDataAndLocators');

let NoOfLinkBeforeCancel;
let NoOfLinkAfterCancel;
Then(/^User set the collectionsColleague flag$/, () => {
  browser.execute("sessionStorage.setItem('collectionsColleague', 'true')");
  //  browser.refresh();
});
Then(
  /^User fetch the cancel links from "(.*)" before canecelling paymentArrangement$/,
  element => {
    const locatorString = Selectors.getSelector(element);
    const selectors = $$(locatorString);
    NoOfLinkBeforeCancel = selectors.length;
  },
);
Then(
  /^User fetch the cancel links from the "(.*)" after canecelling paymentArrangement$/,
  element => {
    const locatorString = Selectors.getSelector(element);
    const selectors = $$(locatorString);
    NoOfLinkAfterCancel = selectors.length;
  },
);

Then(
  /^User is verifying that paymentArrangement is cancel from overview list$/,
  () => {
    assert.isTrue(
      NoOfLinkBeforeCancel > NoOfLinkAfterCancel,
      `Payment Arrangement is not cancelled, expected ${NoOfLinkAfterCancel} links but got ${NoOfLinkBeforeCancel} links`,
    );
  },
);
Then(
  /^User cancel the existing arrangement if cancel link is equal to 1$/,
  async () => {
    const locatorString = Selectors.getSelector('coll_sub1_Action');
    const selectors = $$(locatorString);
    const deleteLinkCount: any = selectors.length;
    // deleteLinkCount = deleteLinkCount.toString();
    if (deleteLinkCount === 1) {
      const deleteLink = $(locatorString);
      const yesButtonLocator = Selectors.getSelector('btn_Yes');
      const yesButton = $(yesButtonLocator);
      // const closeIconLocator = Selectors.getSelector('deleteModalCloseIcon');
      // const closeIcon = $(closeIconLocator);
      // deleteLink.click();
      deleteLink.click();
      browser.pause(3000);
      yesButton.click();
      // yesButton.click();
      browser.pause(3000);

      // closeIcon.click(); // temp step
    }
  },
);
Then(/^User cancel the existing arrangement if already setup$/, async () => {
  const locatorString = Selectors.getSelector('sub1_Action');
  const selectors = $$(locatorString);
  const deleteLinkCount: any = selectors.length;
  // deleteLinkCount = deleteLinkCount.toString();
  if (deleteLinkCount === 1) {
    const deleteLink = $(locatorString);
    const yesButtonLocator = Selectors.getSelector('btn_Yes');
    const yesButton = $(yesButtonLocator);
    // const closeIconLocator = Selectors.getSelector('deleteModalCloseIcon');
    // const closeIcon = $(closeIconLocator);
    // deleteLink.click();
    deleteLink.click();
    browser.pause(3000);
    yesButton.click();
    // yesButton.click();
    browser.pause(3000);

    // closeIcon.click(); // temp step
  }
});

Then(
  /^User is verifying that "(.*)" option is present in the dropdown$/,
  expectedText => {
    const list = [];
    const listElements = $$(
      '//option[@value="lastThreeMonths"]//parent::select',
    );
    listElements.forEach(element => {
      const text = element.getText();
      list.push(text);
    });
    assert.isTrue(
      list.includes(expectedText),
      `${expectedText} not present in dropdown, found these options ${list}`,
    );
    browser.refresh();
  },
);
