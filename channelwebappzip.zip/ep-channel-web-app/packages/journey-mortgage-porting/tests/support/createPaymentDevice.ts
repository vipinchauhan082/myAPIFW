/* eslint-disable @typescript-eslint/camelcase */
/* eslint-disable @typescript-eslint/no-var-requires */
const { v4: uuidv4 } = require('uuid');
const request = require('request-promise');
const userData = require('../../../../tests/src/features/support/globalTestData.js');
const bodyData = require('../apiData/createPaymentDevice.json');
const {
  ENV_API_PAY,
  ENV_AUTH_CORE,
} = require('../../../../tests/conf/shared/env.conf').getConfig(
  process.env.ENV,
);

module.exports = async () => {
  bodyData.request_id = uuidv4();
  const options = {
    method: 'POST',
    url: `${ENV_API_PAY}/v1/uk/bbans`,
    gzip: true,
    headers: {
      'Content-Type': 'application/json',
      'X-Auth-Token': ENV_AUTH_CORE,
    },
    body: bodyData,
    resolveWithFullResponse: true,
    json: true,
  };
  const response = await request(options).catch(err => {
    throw new Error(err);
  });
  const bankId = response.body.id;
  const bankIdCode = response.body.bank_id_code;
  const accountNumber = response.body.account_number;

  userData.setField('BankId', bankId);
  userData.setField('BankIdCode', bankIdCode);
  userData.setField('AccountNumber', accountNumber);
  return response.body;
};
