/* eslint-disable @typescript-eslint/camelcase */
/* eslint-disable @typescript-eslint/no-var-requires */
const { v4: uuidv4 } = require('uuid');
const request = require('request-promise');
const userData = require('../../../../tests/src/features/support/globalTestData.js');
const bodyData = require('../apiData/createRepaymentAccount.json');
const {
  ENV_PROXY,
  ENV_API_ICP,
} = require('../../../../tests/conf/shared/env.conf').getConfig(
  process.env.ENV,
);

module.exports = async () => {
  bodyData.mortgage_number = uuidv4();
  bodyData.details.plan_number = userData.getField('PlanNumber');
  bodyData.stakeholder_ids = [userData.getField('StackholderID')];
  const options = {
    method: 'POST',
    url: `${ENV_API_ICP}/mortgage-service/v1.0/mortgages/accounts/create`,
    proxy: `${ENV_PROXY}`,
    gzip: true,
    headers: {
      'Content-Type': 'application/json',
      'x-lbg-brand': 'IF',
      Accept: '*/*',
      'x-lbg-org': 'LBG',
      'x-lbg-txn-correlation-id': 'testing123456',
      Connection: 'Keep-Alive',
      // Authorization: global.authtoken,
      Authorization: `Bearer VALID_STATIC_TOKEN`,
      // 'C-Authorization': `Bearer ${global.colleagueToken}`,
      'x-lbg-channel': 'TELEPHONE',
    },
    body: bodyData,
    resolveWithFullResponse: true,
    json: true,
  };
  const response = await request(options).catch(err => {
    throw new Error(err);
  });

  const mortgageNo = response.body.instance_param_vals.mortgage_number;
  const repaymentAccountID = response.body.id;
  userData.setField('MortgageNo', mortgageNo);
  userData.setField('RepaymentAccountID', repaymentAccountID);
  return response.body;
};
