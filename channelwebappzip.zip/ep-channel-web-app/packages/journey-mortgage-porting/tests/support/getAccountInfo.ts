/* eslint-disable @typescript-eslint/no-var-requires */
const request = require('request-promise');
const userData = require('../../../../tests/src/features/support/globalTestData.js');
const {
  ENV_API,
  ENV_PROXY,
} = require('../../../../tests/conf/shared/env.conf').getConfig(
  process.env.ENV,
);

module.exports = async () => {
  const accountID = userData.getField('AccountID');
  const options = {
    method: 'GET',
    url: `${ENV_API}/accounts/v2.0/accounts/${accountID}/general-account-info`,
    proxy: `${ENV_PROXY}`,
    gzip: true,
    headers: {
      'x-lbg-brand': 'IF',
      Accept: '*/*',
      'x-lbg-txn-correlation-id': 'testing123456',
      Connection: 'Keep-Alive',
      'C-Authorization': `Bearer ${global.colleagueToken}`,
      'x-lbg-channel': 'TELEPHONE',
    },
    resolveWithFullResponse: true,
    json: true,
  };
  const response = await request(options).catch(err => {
    throw new Error(err);
  });

  const stackholderID =
    response.body.Data.Account[0].Customer[0].ExternalCustomerId;
  const planNumber =
    response.body.Data.Account[0].Details.AccountDetails.PlanNumber;
  userData.setField('StackholderID', stackholderID);
  userData.setField('PlanNumber', planNumber);
  return response.body;
};
