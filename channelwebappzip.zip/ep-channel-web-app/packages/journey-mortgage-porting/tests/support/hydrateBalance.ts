/* eslint-disable @typescript-eslint/camelcase */
/* eslint-disable @typescript-eslint/no-var-requires */
const { v4: uuidv4 } = require('uuid');
const request = require('request-promise');
const userData = require('../../../../tests/src/features/support/globalTestData.js');
const bodyData = require('../apiData/hydrateBalance.json');
const {
  ENV_API_CORE,
  ENV_AUTH_CORE,
} = require('../../../../tests/conf/shared/env.conf').getConfig(
  process.env.ENV,
);

module.exports = async ({ subAccountType }) => {
  bodyData.request_id = uuidv4();
  bodyData.posting_instruction_batch.client_batch_id = uuidv4();
  bodyData.posting_instruction_batch.posting_instructions[0].client_transaction_id = uuidv4();
  bodyData.posting_instruction_batch.posting_instructions[0].custom_instruction.postings[0].amount = userData.getField(
    'PrincipalAmount',
  );
  bodyData.posting_instruction_batch.posting_instructions[0].custom_instruction.postings[0].account_id = userData.getField(
    'SubAccountId',
  );
  bodyData.posting_instruction_batch.posting_instructions[0].custom_instruction.postings[0].account_id = userData.getField(
    subAccountType,
  );
  bodyData.posting_instruction_batch.posting_instructions[0].custom_instruction.postings[1].amount = userData.getField(
    'PrincipalAmount',
  );
  const options = {
    method: 'POST',
    url: `${ENV_API_CORE}/v1/posting-instruction-batches:asyncCreate`,
    gzip: true,
    headers: {
      'Content-Type': 'application/json',
      'X-Auth-Token': ENV_AUTH_CORE,
    },
    body: bodyData,
    resolveWithFullResponse: true,
    json: true,
  };
  const response = await request(options).catch(err => {
    throw new Error(err);
  });
  return response.body;
};
