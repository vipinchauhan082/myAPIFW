/* eslint-disable @typescript-eslint/no-var-requires */
const request = require('request-promise');
const userData = require('../../../../tests/src/features/support/globalTestData.js');
const bodyData = require('../apiData/createMortgagePortingApp.json');
const {
  ENV_API,
  ENV_PROXY,
} = require('../../../../tests/conf/shared/env.conf').getConfig(
  process.env.ENV,
);

module.exports = async () => {
  bodyData.customerId = userData.getField('CustomerId');
  bodyData.previousMortgageNumber = userData.getField('MortgageNo');
  const options = {
    method: 'POST',
    url: `${ENV_API}/mortgages/v1.0/mortgages/application`,
    proxy: `${ENV_PROXY}`,
    gzip: true,
    headers: {
      'Content-Type': 'application/json',
      'x-lbg-brand': 'IF',
      Accept: '*/*',
      // 'x-lbg-org': 'LBG',
      'x-lbg-txn-correlation-id': 'testing123456',
      Connection: 'Keep-Alive',
      // Authorization: 'Bearer VALID_STATIC_TOKEN',
      Authorization: `Bearer VALID_STATIC_TOKEN`,
      // Authorization: global.authtoken,
      // 'C-Authorization': `Bearer ${global.colleagueToken}`,
      // 'Accept-Encoding': 'gzip, deflate, br',
      'x-lbg-channel': 'TELEPHONE',
      'x-lbg-org': 'LBG',
    },
    body: bodyData,
    resolveWithFullResponse: true,
    json: true,
  };
  const response = await request(options).catch(err => {
    throw new Error(err);
  });

  const applicationID = response.body.ApplicationId;
  const portMortgageNo = response.body.MortgageNumber;
  userData.setField('ApplicationID', applicationID);
  userData.setField('PortMortgageNo', portMortgageNo);
  return response.body;
};
