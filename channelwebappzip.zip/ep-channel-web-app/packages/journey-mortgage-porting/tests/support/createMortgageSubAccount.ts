/* eslint-disable @typescript-eslint/camelcase */
/* eslint-disable @typescript-eslint/no-var-requires */
const request = require('request-promise');
const userData = require('../../../../tests/src/features/support/globalTestData.js');
const bodyData = require('../apiData/createMortgageSubAccount.json');
const {
  ENV_PROXY,
  ENV_API_ICP,
} = require('../../../../tests/conf/shared/env.conf').getConfig(
  process.env.ENV,
);

module.exports = async () => {
  bodyData.stakeholder_ids = [userData.getField('StackholderID')];
  bodyData.details.plan_number = userData.getField('PlanNumber');
  bodyData.mortgage_number = userData.getField('MortgageNo');
  const options = {
    method: 'POST',
    url: `${ENV_API_ICP}/mortgage-service/v1.0/mortgages/accounts/create`,
    proxy: `${ENV_PROXY}`,
    gzip: true,
    headers: {
      'Content-Type': 'application/json',
      'x-lbg-brand': 'IF',
      Accept: '*/*',
      'x-lbg-org': 'LBG',
      'x-lbg-txn-correlation-id': 'testing123456',
      Connection: 'Keep-Alive',
      // Authorization: global.authtoken,
      Authorization: `Bearer VALID_STATIC_TOKEN`,
      // 'C-Authorization': `Bearer ${global.colleagueToken}`,
      'x-lbg-channel': 'TELEPHONE',
    },
    body: bodyData,
    resolveWithFullResponse: true,
    json: true,
  };
  const response = await request(options).catch(err => {
    throw new Error(err);
  });
  const subAccountId = response.body.id;
  const principalAmount =
    response.body.instance_param_vals.mortgage_calculation_principal;
  userData.setField('SubAccountId', subAccountId);
  userData.setField('PrincipalAmount', principalAmount);
  return response.body;
};
