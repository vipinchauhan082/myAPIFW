/* eslint-disable */
const { When, Then, Given} = require('cucumber');
const { assert, expect } = require('chai');
const Selectors = require('../../../../tests/src/features/support/loadDataAndLocators');
const randGenerator = require('../../../../tests/src/features/support/getRandomData');
const createAccount = require('../../../journey-amend-account-options/tests/support/createAccount.ts');
const getAccountInfo = require('../support/getAccountInfo.ts');
const createMortgageAccount = require('../support/createMortgageAccount.ts');
const globalContext = require('../../../../tests/src/features/support/context');
const createMortgageSubAccount = require('../support/createMortgageSubAccount.ts');
const hydrateBalance = require('../support/hydrateBalance.ts');
const createPaymentDevice = require('../support/createPaymentDevice.ts');
const linkPaymentDevice = require('../support/linkPaymentDevice.ts');
const createMortgagePortingApp = require('../support/createMortgagePortingApp.ts');
const createPortMortgageSubAcc = require('../support/createPortMortgageSubAcc.ts');
const createPortMortgageSubmit = require('../support/createPortMortgageSubmit.ts');
const actions = require('../../../../tests/src/features/support/common-actions.ts');


let customerId;
//  let externalReference;
let accesstoken;
let accountId;
let CustomerAccountId;
// let JointcustomerId;

const {
  ENV_URL_COLLEAGUE
} = require('../../../../tests/conf/shared/env.conf').getConfig(
  process.env.ENV,
);

When(
  /^User has created the new account for "(.*)" and "(.*)"$/,
  async (cust, productId) => {
    const { username, externalReference, customerId} = globalContext.context; 
    console.log("username:   ", username)
    console.log("externalReference:   ", externalReference) 
    console.log("CustomerId:   ", customerId) 
    const { AccountId, AccountNumber } = await createAccount({
      customerId,
      productId,
    });
    console.log("AccountId:   ", AccountId)
    accountId = AccountId
  },
);

When(
  /^User has created the new Mortgage repayment account$/,
  async () => {
    await getAccountInfo();
    await createMortgageAccount();
  },
);

When(
  /^User has created the  Mortgage sub-account with "(.*)"$/,
  async (subAccountType) => {
    await createMortgageSubAccount();
    await hydrateBalance(subAccountType);
  },
);

When(
  /^User has linked Payment Device with Mortgage repayment account$/,
  async () => {
    await createPaymentDevice();
    await linkPaymentDevice();
  },
);

When(
  /^User has created and submitted Mortgage porting application$/,
  async () => {
    await createMortgagePortingApp()
    await createPortMortgageSubAcc()
    await createPortMortgageSubmit()
  },
);

When(
  /^User clicks on "(.*)" of page and validate the status of API as "(.*)"$/,
  (element, expectedvalue) => {
    browser.setupInterceptor(); // capture ajax calls
    actions.click(element);
    browser.pause(30000); // maybe wait a bit until request is finished
    const request = browser.getRequest(0);
    console.log("actual : value::", request.response.statusCode)
    assert.equal(request.response.statusCode, expectedvalue);
  },
);

When(
  /^User validate the status of API as "(.*)"$/,
  (expectedvalue) => {
    const request = browser.getRequest(0);
    console.log("actual : value::", request.response.statusCode)
    assert.equal(request.response.statusCode, expectedvalue);
  },
);

When(
  /^User clicks on "(.*)" of page to validate the status of API$/,
  (element) => {
    browser.setupInterceptor(); // capture ajax calls
    actions.click(element);
  },
);

When(
  /^User clicks on "(.*)" of page and validate that requested url contains "(.*)"$/,
  (element, expectedvalue) => {
    browser.setupInterceptor(); // capture ajax calls
    actions.click(element);
    browser.pause(10000); // maybe wait a bit until request is finished
    const request = browser.getRequest(0);
    assert.include(request.url, expectedvalue);
  },
);

When(
  /^User validate that requested body contains "(.*)"$/,
  (expectedvalue) => {
    expectedvalue = Selectors.getData(expectedvalue);
    const request = browser.getRequest(0);
    assert.include(JSON.stringify(request.body), expectedvalue);
  },
);

Then(/^User navigate to colleague url "(.*)"$/, url => {
  const finalUrl = ENV_URL_COLLEAGUE + url
  browser.url(finalUrl);
});

Given(/^User enables Mock$/, ()=> {
    browser.execute("sessionStorage.setItem('MOCK', 'true')");
    browser.refresh();
});