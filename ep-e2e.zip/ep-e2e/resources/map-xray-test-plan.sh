#!/bin/bash

set -ex
which awk
cd ./tests/"${target_dir}"

for file in $(ls ./Jenkinsfile*); do
	testPlanId=""
	testPlanKey=""		
	while read line; do
		if [[ "$line" == *xrayTestPlanID* ]]; then
	  		testPlanKey=$(echo $line | sed -e 's/xrayTestPlanID=\"\(.*\)\"/\1/')
	  		echo $testPlanKey
	  		break
		fi		
	done < $file
	curl --request GET --url 'https://ltmhedge.atlassian.net/rest/api/3/issue/'${testPlanKey}'' --user 'sukesh.jha@publicissapient.com:jQ0bOnfhodgp4bT1ix9d2347' --header 'Accept: application/json' > output.json	
	testPlanId=$(cat output.json | jq ".id" | tr -d '"')
	
	testId=""
	token=$(curl -H "Content-Type: application/json" -X POST --data @../../configs/xray_client_cred.json  https://xray.cloud.xpand-it.com/api/v1/authenticate | tr -d '"')
  	while read line; do
		if [[ "$line" == *//* ]]; then
			echo "Commented line of Code, No action required."
		else
			if [[ "$line" == *@* ]]; then				
				tag=$(echo $line | awk -F'"' '{print $2}' | awk -F'@' '{print $2}')
		  		curl --request GET --url 'https://ltmhedge.atlassian.net/rest/api/3/issue/'${tag}'' --user 'sukesh.jha@publicissapient.com:jQ0bOnfhodgp4bT1ix9d2347' --header 'Accept: application/json' > output.json	
				testId=$(cat output.json | jq ".id" | tr -d '"')
				curl --location --request POST 'https://xray.cloud.xpand-it.com/api/v2/graphql' --header "Authorization: Bearer ${token}" --header 'Content-Type: application/json' --data-raw '{"query":"mutation {addTestsToTestPlan(issueId: \"'${testPlanId}'\", testIssueIds: [\"'${testId}'\"]) {addedTests warning}}","variables":{}}'
			fi
		fi
	done < $file
	
done