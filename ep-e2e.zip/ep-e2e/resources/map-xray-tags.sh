#!/bin/bash
set -ex
which awk
cd ./tests/"${target_dir}"

for file in $(ls ./Jenkinsfile*); do
	mpcId=""
	while read line; do
		if [[ "$line" == *MPC* ]]; then
			mpcId=$(echo $line | sed -e 's/MPC=\"\(.*\)\"/\1/')
			echo ${mpcId}
			break
		fi
	done < $file
		
	while read line; do
		if [[ "$line" == *xrayTestPlanID* ]]; then
	  		testPlanId=$(echo $line | sed -e 's/xrayTestPlanID=\"\(.*\)\"/\1/')
	  		echo $testPlanId
	  		for mpc in $(echo $mpcId | sed "s/;/ /g"); do
			  curl --request POST --url 'https://ltmhedge.atlassian.net/rest/api/3/issueLink' --user 'sukesh.jha@publicissapient.com:jQ0bOnfhodgp4bT1ix9d2347' --header 'Accept: application/json' --header 'Content-Type: application/json' --data '{"outwardIssue": {"key": "'${mpc}'"}, "inwardIssue": {"key": "'${testPlanId}'"}, "type": {"name": "Test"}}'
			done	  		
	  		break
		fi		
	done < $file	
	
	
  	while read line; do
		if [[ "$line" == *//* ]]; then
			echo "Commented line of Code, No action required."
		else
			if [[ "$line" == *@* ]]; then				
				tag=$(echo $line | awk -F'"' '{print $2}' | awk -F'@' '{print $2}')
				for mpc in $(echo $mpcId | sed "s/;/ /g"); do
				  curl --request POST --url 'https://ltmhedge.atlassian.net/rest/api/3/issueLink' --user 'sukesh.jha@publicissapient.com:jQ0bOnfhodgp4bT1ix9d2347' --header 'Accept: application/json' --header 'Content-Type: application/json' --data '{"outwardIssue": {"key": "'${mpc}'"}, "inwardIssue": {"key": "'${tag}'"}, "type": {"name": "Test"}}'
				done		  		
			fi
		fi
	done < $file
	
done