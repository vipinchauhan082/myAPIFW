#!/bin/bash

set -ex
which awk
cd ./tests/"${target_dir}"

for file in $(ls ./Jenkinsfile*); do
	testPlanId=""
	testPlanKey=""		
	while read line; do
		if [[ "$line" == *xrayTestPlanID* ]]; then
	  		testPlanKey=$(echo $line | sed -e 's/xrayTestPlanID=\"\(.*\)\"/\1/')
	  		echo $testPlanKey
	  		break
		fi		
	done < $file
	curl --request GET --url 'https://ltmhedge.atlassian.net/rest/api/3/issue/'${testPlanKey}'' --user 'sukesh.jha@publicissapient.com:jQ0bOnfhodgp4bT1ix9d2347' --header 'Accept: application/json' > output.json	
	testPlanId=$(cat output.json | jq ".id" | tr -d '"')
	
	testId=""
	token=$(curl -H "Content-Type: application/json" -X POST --data @../../configs/xray_client_cred.json  https://xray.cloud.xpand-it.com/api/v1/authenticate | tr -d '"')
	
	curl --location --request POST 'https://xray.cloud.xpand-it.com/api/v2/graphql' --header "Authorization: Bearer ${token}" --header 'Content-Type: application/json' --data-raw '{"query":"{getTestPlan(issueId: \"'${testPlanId}'\") {issueId tests(limit: 100) {results {issueId testType {name}}}}}","variables":{}}' > output.json
	totallinkedIssue=$(cat output.json | jq ".data.getTestPlan.tests.results|length")
	for eachLinkedTkt in $(seq 0 $((totallinkedIssue-1))); do
		if [ $(cat output.json | jq .data.getTestPlan.tests.results[${eachLinkedTkt}].testType.name | tr -d '"') == "Cucumber" ]; then
			testId=$(cat output.json | jq ".data.getTestPlan.tests.results[${eachLinkedTkt}].issueId" | tr -d '"')
			curl --location --request POST 'https://xray.cloud.xpand-it.com/api/v2/graphql' --header "Authorization: Bearer ${token}" --header 'Content-Type: application/json' --data-raw '{"query":"mutation {removeTestsFromTestPlan(issueId: \"'${testPlanId}'\", testIssueIds: [\"'${testId}'\"])}","variables":{}}'
		fi
	done
	
done