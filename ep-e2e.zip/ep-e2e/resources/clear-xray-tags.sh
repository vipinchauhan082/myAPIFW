#!/bin/bash

set -ex
which awk
cd ./tests/"${target_dir}"

for file in $(ls ./Jenkinsfile*); do
	echo "Updating Test plan linking to MPC"
	xrayTag=""
	while read line; do
		if [[ "$line" == *MPC* ]]; then
			mpcId=$(echo $line | sed -e 's/MPC=\"\(.*\)\"/\1/')
			echo ${mpcId}
			break
		fi
	done < $file
	
	for mpc in $(echo $mpcId | sed "s/;/ /g"); do
		curl --request GET --url 'https://ltmhedge.atlassian.net/rest/api/3/issue/'${mpc}'' --user 'sukesh.jha@publicissapient.com:jQ0bOnfhodgp4bT1ix9d2347' --header 'Accept: application/json' > mpcOutput.json
		totallinkedIssue=$(cat mpcOutput.json | jq ".fields.issuelinks|length")
		for eachLinkedTkt in $(seq 0 $((totallinkedIssue-1))); do
			if [ $(cat mpcOutput.json | jq .fields.issuelinks[${eachLinkedTkt}].type.name | tr -d '"') == "Test" ]; then
				testId=$(cat mpcOutput.json | jq ".fields.issuelinks[${eachLinkedTkt}].id" | tr -d '"')
				testKey=$(cat mpcOutput.json | jq ".fields.issuelinks[${eachLinkedTkt}].inwardIssue.key" | tr -d '"')
				curl --request DELETE --url 'https://ltmhedge.atlassian.net/rest/api/3/issueLink/'${testId}'' --user 'sukesh.jha@publicissapient.com:jQ0bOnfhodgp4bT1ix9d2347'
	        fi
		done	
	done	  				
done