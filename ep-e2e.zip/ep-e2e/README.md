# EPlus Outcome-based E2E Tests

User guide: https://ltmhedge.atlassian.net/wiki/spaces/EN/pages/1589936599/User+Guide+-+How+to+create+assemble+E2E+Outcome+tests 


