def call() {
	container('gradle') {
		script{				
			def filename = 'configs/cucumberReportCounter.yaml'
			def data = readYaml file: filename
			int JsonReport = data.version 
			JsonReport  = JsonReport  + 1
    
   		 sh """
				> ./configs/cucumberReportCounter.yaml echo 'version: "${JsonReport}"'
				cat ./configs/cucumberReportCounter.yaml
				""" 
	return JsonReport
		}
	}
}


