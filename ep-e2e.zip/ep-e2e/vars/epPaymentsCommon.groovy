
def call(String TAGS, String environ, String repo, String testDataFile, String featureFile) {
	script {
      	def pymtTags = TAGS.replaceAll(",", " or ")
      	repoUrl = 'https://github.com/lbg-gcp-foundation/' + repo
		branchConfig = readJSON(file: './configs/repo_branch_mapping.json')
		branch = branchConfig[repo]
		reportFileName = cucumberReportIncrementor() + ".json"
      	container('node') {
	      	checkout([
		            $class: 'GitSCM',
		            branches: [[name: "${branch}"]],
		            doGenerateSubmoduleConfigurations: false,
		            extensions: [[$class: 'RelativeTargetDirectory', relativeTargetDir: 'PaymentsBDD']],
		            submoduleCfg: [],
		            userRemoteConfigs: [[credentialsId: 'jenkinsPAT', url: "${repoUrl}"]]
	        ])
	        dir('PaymentsBDD') {
		        withCredentials([
		                usernamePassword(credentialsId: 'copinboundtoken_int', usernameVariable: 'token_id', passwordVariable: 'token_secret'),
		                file(credentialsId: 'obtransportcrt', variable: 'tlsCert'),
		                file(credentialsId: 'obtransportkey', variable: 'tlsKey')
		        ])
	         	{
		        	echo "Payments User Input Validation"
		            script{
		            	try{
			               	sh """
			                cd domains/payments/qe/ep_payments_e2e_test
			                cp -R /home/nodebase/node_modules .
			                cp -Rf ../../../../../testdata/"${testDataFile}".json ./testdata.json
			                export 'PATH=./node_modules/.bin:/usr/local/openjdk-8/bin:/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin'
			                npx wdio wdio.conf.int.js --tags '"${pymtTags}"' --ff "${featureFile}"  --TARGET_ENV="${environ}" --clientid $token_id --clientpass $token_secret --cert $tlsCert --obkey $tlsKey
			                cp -Rf "./jsonReports/"*.json ../../../../../Cucumber_Report/
     									cp -Rf ./testdata.json ../../../../../testdata/"${testDataFile}".json
		                	"""
		                } catch (err) {
                        	sh """
													cd domains/payments/qe/ep_payments_e2e_test
	                        cp -Rf "./jsonReports/"*.json ../../../../../Cucumber_Report/
     											cp -Rf ./testdata.json ../../../../../testdata/"${testDataFile}".json
													exit 1
													"""
						}
		            }
	          	}
	       }
      }
   }
}
