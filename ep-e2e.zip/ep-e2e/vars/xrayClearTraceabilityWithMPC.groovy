def call(String productTeam) {
	container('infra-tools') {
		env.target_dir = "${productTeam}"
		def functions = libraryResource 'clear-xray-tags.sh'
		writeFile file: 'clear-xray-tags.sh', text: functions 		
		script{	 
	        sh '''
	        chmod +x ./clear-xray-tags.sh
	        ./clear-xray-tags.sh
	        '''
	    }	    		
	}
}


