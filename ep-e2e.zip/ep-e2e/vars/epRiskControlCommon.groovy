def call(String TAGS, String environ, String repo, String testDataFile) {
    container('maven-rnc') {
        if (env.TemporarilyBypassRC.equals("NO"))
        {
        repoUrl = 'https://github.com/lbg-gcp-foundation/' + repo
        branchConfig = readJSON(file: './configs/repo_branch_mapping.json')
		branch = branchConfig[repo]
		reportFileName = cucumberReportIncrementor() + ".json"
        checkout([
                $class                           : 'GitSCM',
                branches                         : [[name: "${branch}"]],
                doGenerateSubmoduleConfigurations: false,
                extensions                       : [[$class: 'RelativeTargetDirectory', relativeTargetDir: 'riskandcontrol-test']],
                submoduleCfg                     : [],
                userRemoteConfigs                : [[credentialsId: 'jenkins-data-pat', url: "${repoUrl}"]]
        ])

        dir('riskandcontrol-test') {
            script {
                try {
                    echo "Maven Building"
                    sh """
                       cd riskandcontrol-test
                       cp -Rf ../../testdata/"${testDataFile}".json ./testdata.json
                       mvn -o clean test -Denv="${environ}" -Dcucumber.options="--tags ${TAGS}"
                       cp -Rf ./testdata.json  ../../testdata/"${testDataFile}".json 
                       cp -Rf ./target/cucumber.json ../../Cucumber_Report/"${reportFileName}".json
                       """
                    }
                    catch (err) {
                        sh """
	                 	cd riskandcontrol-test
	                    cp -Rf ./testdata.json  ../../testdata/"${testDataFile}".json 
	    				cp -Rf ./target/cucumber.json ../../Cucumber_Report/"${reportFileName}".json		                
						exit 1
					"""
                    }

                }
            }
        }
        else
        {
            echo ("Risk Control test skip")
        }
    }
}

def call(String  INT_CLUSTER_NAME, String REGION_NAME, String INT_PROJECT_NAME) {

    container('bdd-run') {
        if (env.TemporarilyBypassRC.equals("NO")) {
            script {
                sh """
		   			gcloud container clusters get-credentials $INT_CLUSTER_NAME --region $REGION_NAME --project $INT_PROJECT_NAME
		   			argo submit --from=CronWorkflow/eplus-rnc-dbt-control-execution-wf -n ns-kcl-eplus-rnc-rnc-argo --watch
		 			"""
            }
        }
    
    else
    {
        echo ("Risk Control test skip")
    }
}

}













