def call(String productTeam) {
	container('infra-tools') {
		env.target_dir = "${productTeam}"
		def functions = libraryResource 'map-xray-tags.sh'
		writeFile file: 'map-xray-tags.sh', text: functions 		
		script{	 
	        sh '''
	        chmod +x ./map-xray-tags.sh
	        ./map-xray-tags.sh
	        '''
	    }	    		
	}
}


