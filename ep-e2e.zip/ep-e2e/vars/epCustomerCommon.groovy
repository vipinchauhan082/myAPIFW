
def call(String TAGS, String environ, String repo, String testDataFile) {
	container('gradle') {		   
		repoUrl = 'https://github.com/lbg-gcp-foundation/' + repo
		branchConfig = readJSON(file: './configs/repo_branch_mapping.json')
		branch = branchConfig[repo]
		reportFileName = cucumberReportIncrementor() + ".json"
    	checkout([  
            $class: 'GitSCM', 
            branches: [[name: "${branch}"]], 
            doGenerateSubmoduleConfigurations: false, 
            extensions: [[$class: 'RelativeTargetDirectory', relativeTargetDir: 'CustomerE2E']], 
            submoduleCfg: [], 
            userRemoteConfigs: [[credentialsId: 'jenkinsPAT', url: "${repoUrl}"]]
        ])
        
        dir('CustomerE2E') {
           dir('bdd') {
             script{
             	try{
                	sh """
                  	echo "*********************** Customers BDD Execution ***********************************"
                  	pwd
                  	cp -Rf ../../testdata/"${testDataFile}".json ./testdata.json
                  	gradle cucumber -Dtags="${TAGS}" -Denv.type="${environ}"_apigee
                  	cp -Rf ./target/cucumber.json ../../Cucumber_Report/"${reportFileName}"
                  	cp -Rf ./testdata.json ../../testdata/"${testDataFile}".json
                	"""
					archive includes: 'logs/*'
					archive includes: 'logs/**/*'
                }
                catch (err) {
					archive includes: 'logs/*'
					archive includes: 'logs/**/*'
            		sh """
                  	cp -Rf ./target/cucumber.json ../../Cucumber_Report/"${reportFileName}"
                  	cp -Rf ./testdata.json ../../testdata/"${testDataFile}".json
                  	exit 1
              		"""
          		}
            }
          }
       }
    }	        
}