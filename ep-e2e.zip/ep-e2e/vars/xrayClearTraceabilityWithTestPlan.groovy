def call(String productTeam) {
	container('infra-tools') {
		env.target_dir = "${productTeam}"
		def functions = libraryResource 'clear-xray-test-plan.sh'
		writeFile file: 'clear-xray-test-plan.sh', text: functions 		
		script{	 
	        sh '''
	        chmod +x ./clear-xray-test-plan.sh
	        ./clear-xray-test-plan.sh
	        '''
	    }	    		
	}
}


