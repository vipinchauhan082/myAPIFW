import groovy.xml.*;
import com.cloudbees.hudson.plugins.folder.*;



def call(fn) {

    def list=""
    def allJobs = hudson.model.Hudson.getInstance().getItems()

    for (int i = 0; i < allJobs.size(); i++) {
        def job = allJobs[i]
        if (job instanceof Folder )
        {
            if (job.getFullName().equals("E2E_OUTCOME_TESTS"))
            {
                list=  processFolderEntity(job,fn)
            }
        }
    }

    return list
}


String processFolderEntity(Item folder,fn) {
    def list1=""
    folder.getItems().each
            {
                def foldername=it.getFullName();
                if (foldername.contains(fn))
                {
                    list1=getjoblist(it);
                }
            }

    return list1
}
String getjoblist(Item folder)
{
    def list1=""
    print "Processing Folder -" + folder.getFullName()
    folder.getItems().each {
        def name=it.name
        list1=list1+","+name
        print(name)
    }
    print ("list1:::::"+ list1)
    return list1
}