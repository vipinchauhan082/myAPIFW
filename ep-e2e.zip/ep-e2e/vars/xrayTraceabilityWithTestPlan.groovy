def call(String productTeam) {
	container('infra-tools') {
		env.target_dir = "${productTeam}"
		def functions = libraryResource 'map-xray-test-plan.sh'
		writeFile file: 'map-xray-test-plan.sh', text: functions 		
		script{	 
	        sh '''
	        chmod +x ./map-xray-test-plan.sh
	        ./map-xray-test-plan.sh
	        '''
	    }	    		
	}
}


