def call(String INT_CLUSTER_NAME, String REGION_NAME, String INT_PROJECT_NAMES) {

    container('bdd-run') {
        if (env.TemporarilyBypassRC.equals("NO"))
        {
            script {
                sh """
		   			gcloud container clusters get-credentials $INT_CLUSTER_NAME --region $REGION_NAME --project $INT_PROJECT_NAMES
		   			argo cron suspend eplus-rnc-dbt-control-execution-wf -n ns-kcl-eplus-rnc-rnc-argo
		 			"""
            }
        }
        else
        {
            echo("Risk Control Test Skip")
        }
    }


}