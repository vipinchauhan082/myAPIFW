def call(String INT_CLUSTER_NAME, String REGION_NAME, String INT_PROJECT_NAME) {
    dir('CC_BDD') {

        script {
            container('bdd-run') {


                if (env.TemporarilyBypassCCO.equals("NO")) {
                    echo ("******************CC SDL Test Execution Start********************")
                    dir('bdd') {
                        sh """
                       
                        unset HTTPS_PROXY
                        gcloud container clusters get-credentials $INT_CLUSTER_NAME --region $REGION_NAME --project $INT_PROJECT_NAME
                        cat ~/.kube/config
                        
                        argo logs -n ns-kcl-eplus-cco-all-argo -f -w \$(argo submit -n ns-kcl-eplus-cco-all-argo --watch e2e-test/bdd-sdl-argo-int.yaml -p reporting-date=t --instanceid cco-argo-2-12-1 --output name)

                    """
                    }
                }
                else
                {
                    echo ("******************CC SDL Test Skip********************")
                }
            }
        }

    }
}
