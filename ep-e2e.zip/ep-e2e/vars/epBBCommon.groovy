
def call(String TAGS, String environ, String userType, String repo, String testDataFile, String brand) {
	container('node'){
		repoUrl = 'https://github.com/lbg-gcp-foundation/' + repo
		branchConfig = readJSON(file: './configs/repo_branch_mapping.json')
		branch = branchConfig[repo]  
		reportFileName = cucumberReportIncrementor() + ".json"
		checkout([  
	            $class: 'GitSCM', 
	            branches: [[name: "${branch}"]], 
	            doGenerateSubmoduleConfigurations: false, 
	            extensions: [[$class: 'RelativeTargetDirectory', relativeTargetDir: 'channel_web_app']], 
	            submoduleCfg: [], 
	            userRemoteConfigs: [[credentialsId: 'jenkinsPAT', url: "${repoUrl}"]]
        ])
        
         dir('channel_web_app') {
             script{
             	try{
                   sh """
                   	cp -Rf ../testdata/"${testDataFile}".json ./testdata.json
                    cp -R /home/nodebase/node_modules .
                    export PATH=./node_modules/.bin$PATH
	                ENV=${environ} DATA=jrn USERTYPE=${userType} BRAND=${brand} SCENARIO=${TAGS} npm run test:bdd:if:e2e:outcome:pipeline
	                cp -Rf ./tests/reports/json/*.json ../Cucumber_Report/"${reportFileName}"
	                cp -Rf ./testdata.json ../testdata/"${testDataFile}".json
					cat ./testdata.json         	
					"""
						archive includes: 'logs/*'
					}
					catch (err) {
						archive includes: 'logs/*'
						sh """
                 	cp -Rf ./tests/reports/json/*.json ../Cucumber_Report/"${reportFileName}"
                 	cp -Rf ./testdata.json ../testdata/"${testDataFile}".json
					cat ./testdata.json        
					exit 1
					"""
					}
				}
			}

	}
}