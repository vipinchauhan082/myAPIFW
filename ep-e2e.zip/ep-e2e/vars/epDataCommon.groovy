
def call(String TAGS, String environ, String repo, String testDataFile) {
	container('maven-data') {
		repoUrl = 'https://github.com/lbg-gcp-foundation/' + repo
		branchConfig = readJSON(file: './configs/repo_branch_mapping.json')
		branch = branchConfig[repo]
		reportFileName = cucumberReportIncrementor() + ".json"
    	checkout([
	            $class: 'GitSCM',
	            branches: [[name: "${branch}"]],
	            doGenerateSubmoduleConfigurations: false,
	            extensions: [[$class: 'RelativeTargetDirectory', relativeTargetDir: 'DataBDD']],
	            submoduleCfg: [],
	            userRemoteConfigs: [[credentialsId: 'jenkinsPAT', url: "${repoUrl}"]]
        ])

        dir('DataBDD') {
          	script{
          		try{
	                sh """
                	echo "*********************** Data BDD execution starts ***********************************"
                	cd integration-test
                	cp -Rf ../../testdata/"${testDataFile}".json ./testdata.json
                	mvn -o clean test -Denv="${environ}" -Dcucumber.options=\"--tags "${TAGS}"\"
                	cp -Rf ./target/cucumber.json ../../Cucumber_Report/"${reportFileName}"
                	cp -Rf ./testdata.json ../../testdata/"${testDataFile}".json
	                """
                 }
                 catch (err) {
                 	sh """
                 	cd integration-test
					cp -Rf ./target/cucumber.json ../../Cucumber_Report/"${reportFileName}"
					cp -Rf ./testdata.json ../../testdata/"${testDataFile}".json
					exit 1
					"""
                 }
        	}

        }
    }
}
