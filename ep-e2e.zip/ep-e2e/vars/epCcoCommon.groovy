def call(String repo) {
    container('mvn-ccore') {
        if (env.TemporarilyBypassCCO.equals("NO")) {

            repoUrl = 'https://github.com/lbg-gcp-foundation/' + repo
            branchConfig = readJSON(file: './configs/repo_branch_mapping.json')
            branch = branchConfig[repo]
            checkout([
                    $class                           : 'GitSCM',
                    branches                         : [[name: "${branch}"]],
                    doGenerateSubmoduleConfigurations: false,
                    extensions                       : [[$class: 'RelativeTargetDirectory', relativeTargetDir: 'CC_BDD']],
                    submoduleCfg                     : [],
                    userRemoteConfigs                : [[credentialsId: 'jenkins-data-pat', url: 'https://github.com/lbg-gcp-foundation/ep-cco.git']]
            ])
        }
        else
        {
            echo ("******************CC Common Test Skip********************")
        }
    }
}

def call(String TAGS, String environ, String repo, String testDataFile) {

    container('mvn-ccore') {
         if (env.TemporarilyBypassCCO.equals("NO"))
        {
        repoUrl = 'https://github.com/lbg-gcp-foundation/' + repo
        branchConfig = readJSON(file: './configs/repo_branch_mapping.json')
        branch = branchConfig[repo]
		reportFileName = cucumberReportIncrementor() + ".json"
        dir('CC_BDD') {
            dir('bdd') {
                try {
                    sh """
                    echo "*********************** CC BDD execution starts ***********************************"
                    cp -Rf ../../testdata/"${testDataFile}".json ./e2e-test/src/test/resources/output/testdata.json
                    echo "*********************** File print testdata.json *********************************"
                    cat ./e2e-test/src/test/resources/output/testdata.json
                    mvn -o clean test -f e2e-test/pom.xml -Denv="${environ}" -Dcucumber.options="--tags ${TAGS}"
                    cp -Rf ./e2e-test/target/cucumber.json ../../Cucumber_Report/"${reportFileName}"
                    cp -Rf ./e2e-test/src/test/resources/output/testdata.json ../../testdata/"${testDataFile}".json
                    """
                        archiveArtifacts artifacts: 'e2e-test/src/test/resources/output/ccArgoInput.json', onlyIfSuccessful: true
                    }
                    catch (err) {
                        sh """
	                cp -Rf ./e2e-test/target/cucumber.json ../../Cucumber_Report/"${reportFileName}"
	                exit 1
	                """
                    }
                }
            }
        }
        else
        {
            echo ("******************CC Common Test Skip********************")
        }
    }
}


def call(String TAGS, String environ) {
    container('mvn-ccore') {
        if (env.TemporarilyBypassCCO.equals("NO"))
        {
        dir('CC_BDD') {
            dir('bdd') {
            reportFileName = cucumberReportIncrementor() + ".json"
                try {
                    sh """
	                mvn -o clean test -f e2e-test/pom.xml -Denv="${environ}" -Dcucumber.options="--tags ${TAGS}"
	                cp -Rf ./e2e-test/target/cucumber.json ../../Cucumber_Report/"${reportFileName}"
	                """
                }
                catch (err) {
                    sh """
	                cp -Rf ./e2e-test/target/cucumber.json ../../Cucumber_Report/"${reportFileName}"
	                exit 1
	                """
                }
            }
        }
    }
        else
        {
            echo ("******************CC Common Test Skip********************")
        }
    }
}