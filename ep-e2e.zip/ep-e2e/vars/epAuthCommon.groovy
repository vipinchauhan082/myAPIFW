
def call(String TAGS, String environ, String repo, String testDataFile) {
	container('gradle') {			
		repoUrl = 'https://github.com/lbg-gcp-foundation/' + repo
		branchConfig = readJSON(file: './configs/repo_branch_mapping.json')
		branch = branchConfig[repo]
		reportFileName = cucumberReportIncrementor() + ".json"
		checkout([  
	            $class: 'GitSCM', 
	            branches: [[name: "${branch}"]], 
	            doGenerateSubmoduleConfigurations: false, 
	            extensions: [[$class: 'RelativeTargetDirectory', relativeTargetDir: 'AuthE2E']],
	            submoduleCfg: [], 
	            userRemoteConfigs: [[credentialsId: 'jenkins-data-pat', url: "${repoUrl}"]]
	     ])
	     
	     dir('AuthE2E') {
			 dir('bdd') {
				 script {
				 		try{
						 	sh """
		                    echo "*********************** Auth E2E Execution ***********************************"
		                    pwd
		                    cp -Rf ../../testdata/"${testDataFile}".json ./testdata.json
		                    gradle cucumber -Dtags="${TAGS}" -Denv.type="${environ}"
		                    cp -Rf ./target/cucumber.json ../../Cucumber_Report/"${reportFileName}"
							cp -Rf ./testdata.json ../../testdata/"${testDataFile}".json
	                    	"""
	                    }
	                    catch (err) {
							sh """
							cp -Rf ./target/cucumber.json ../../Cucumber_Report/"${reportFileName}"
							cp -Rf ./testdata.json ../../testdata/"${testDataFile}".json
							exit 1
							"""
						}
				 }
			 }
	     }
	}	        			
}