def call(String TAGS, String environ, String repo, String testDataFile) {
    container('maven') {        
        repoUrl = 'https://github.com/lbg-gcp-foundation/' + repo
		branchConfig = readJSON(file: './configs/repo_branch_mapping.json')
		branch = branchConfig[repo]
		reportFileName = cucumberReportIncrementor() + ".json"
        checkout([
                $class                           : 'GitSCM',
                branches                         : [[name: "${branch}"]],
                doGenerateSubmoduleConfigurations: false,
                extensions                       : [[$class: 'RelativeTargetDirectory', relativeTargetDir: 'BDD']],
                submoduleCfg                     : [],
                userRemoteConfigs                : [[credentialsId: 'jenkinsPAT', url: "${repoUrl}"]]
        ])

        dir('BDD') {
            dir('bdd') {
                script {
                	try{
                    	sh """
						echo "*********************** PnA BDD execution starts ***********************************"						
						cp -Rf ../../testdata/"${testDataFile}".json ./testdata.json
						mvn -fn -o clean test -P"${environ}" -B -Dcucumber.options="--tags '${TAGS}'"
						cp -Rf ./testdata.json ../../testdata/"${testDataFile}".json 
						cp -Rf ./target/cucumber/cucumber.json ../../Cucumber_Report/"${reportFileName}"
						"""
					}
					catch (err) {
                    	sh """
						cp -Rf ./target/cucumber/cucumber.json ../../Cucumber_Report/"${reportFileName}"
						cp -Rf ./testdata.json ../../testdata/"${testDataFile}".json
						exit 1
						"""
					}
                }
            }
        }
    }
}