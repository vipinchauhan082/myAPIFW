const defaultTimeoutInterval = process.env.DEBUG ? 60 * 60 * 500 : 9000000;
let scenarioName = '';
const fs = require('fs');
var path = require('path');
var VisualRegressionCompare = require('wdio-visual-regression-service/compare');
var dir = './test/screenshots';
let screenReportFile = process.env.REP_VAR + '_screenReport.json';
var file = './test/screenshots/visual-results/' + screenReportFile;
var browserWidth;
var browserHeight;

if (!fs.existsSync(dir)) {
  fs.mkdirSync(dir);
} else if (!fs.existsSync(file)) {
  if (!fs.existsSync(dir + '/visual-results')) {
    fs.mkdirSync(dir + '/visual-results');
  }
} else {
  fs.unlinkSync(file);
}
fs.writeFileSync(file, '{  "output": [');

function getScreenshotName(basePath) {
  return function(context) {
    let jsonVar = '';
    var type = context.type;
    var stepName = context.step.text;
    let stepNameString = stepName.split('"');
    let screenName = stepNameString[1] != null ? stepNameString[1].replace(/ /g, '-') : process.env.PAGENAME;
    if (stepNameString[3] != null) {
      let pageName = stepNameString[3].replace(/ /g, '-');
      screenName = pageName + screenName;
    }
    var browserVersion = parseInt(context.browser.version, 10);
    var browserName = context.browser.name;
    var browserViewport = context.meta.viewport;
    browserWidth = browserViewport.width;
    browserHeight = browserViewport.height;

    let fileName = path.join(basePath, `${screenName}_${type}_desktop_${browserWidth}x${browserHeight}.png`);

    if (scenarioName != screenName) {
      if (scenarioName != '') {
        jsonVar = jsonVar + ',{' + '"ScenarioName" : ' + '"' + screenName + '"' + ',';
      } else {
        jsonVar = jsonVar + '{' + '"ScenarioName" : ' + '"' + screenName + '"' + ',';
      }
      scenarioName = screenName;
    }

    let x = basePath.split('\\');
    let folderName = x[x.length - 1];
    fileName = fileName.replace(/\\/g, '/');
    let fileName2 = fileName.replace('C:/workingFolder/FWD/devRepo/FWD-XT/tests/test/', '');
    let Fname = fileName2.split('test/');

    if (folderName.includes('reference')) {
      jsonVar = jsonVar + '"ExpectedFile" : ' + '"' + Fname[1] + '"';
    } else if (folderName.includes('screen')) {
      jsonVar = jsonVar + '"ActualFile" : ' + '"' + Fname[1] + '"' + ',';
    } else if (folderName.includes('diff')) {
      jsonVar = jsonVar + ',' + '"DiffFile" : ' + '"' + Fname[1] + '"';
    }
    fs.appendFileSync(file, jsonVar);
    return fileName;
  };
}

exports.config = {
  serverUrls: {
    market: 'HK',
    environment: 'qa',
    buildid: '',
    language: 'en',
  },
  screenshotName: '',
  specs: ['./test/features/Visual_Regression/ScreenCompare_URLS.feature'],
  // Patterns to exclude.
  exclude: [
    // 'path/to/excluded/files'
  ],

  maxInstances: 1,

  capabilities: [
    {
      browserName: 'chrome',
      // browserName: 'firefox',
      'goog:chromeOptions': {
        args: ['--window-size=1366,768'],
      },
    },
  ],
  //
  // ===================
  // Test Configurations
  // ===================
  // Define all options that are relevant for the WebdriverIO instance here
  //
  // By default WebdriverIO commands are executed in a synchronous way using
  // the wdio-sync package. If you still want to run your tests in an async way
  // e.g. using promises you can set the sync option to false.
  sync: true,
  logLevel: 'silent', // Level of logging verbosity: silent | verbose | command | data | result | error
  coloredLogs: true, // Enables colors for log output.
  screenshotPath: './test/reports/errorShots/', // Saves a screenshot to a given path if a command fails.
  //
  // Set a base URL in order to shorten url command calls. If your url parameter starts
  // with "/", then the base url gets prepended.
  baseUrl: 'http://localhost:8080',
  waitforTimeout: 9000000, // Default timeout for all waitFor* commands.
  connectionRetryTimeout: 9000000, // Default timeout in milliseconds for request  if Selenium Grid doesn't send response
  connectionRetryCount: 3, // Default request retries count

  // Services take over a specific job you don't want to take care of. They enhance
  // your test setup with almost no effort. Unlike plugins, they don't add new
  // commands. Instead, they hook themselves up into the test process.
  //
  services: ['selenium-standalone', 'visual-regression'],

  framework: 'cucumber',
  reporters: ['spec', 'allure', 'json', 'junit'],

  reporterOptions: {
    json: {
      outputDir: './test/reports/json-results/',
    },
    allure: {
      outputDir: './test/reports/allure-results/',
      disableWebdriverStepsReporting: true,
      useCucumberStepReporter: true,
    },
    junit: {
      outputDir: './test/reports/junit-results/',
      outputFileFormat: function(opts) {
        // optional
        return `results-${opts.cid}.${opts.capabilities}.xml`;
      },
    },
  },

  // If you are using Cucumber you need to specify the location of your step definitions.
  cucumberOpts: {
    require: ['./test/bddcode/stepDefinitions/*.js', './test/bddcode/support/*js'], // <string[]> (file/dir) require files before executing features
    backtrace: true, // <boolean> show full backtrace for errors
    compiler: ['js:babel-core/register'], // <string[]> filetype:compiler used for processing required features
    failAmbiguousDefinitions: true, // <boolean< Treat ambiguous definitions as errors
    dryRun: false, // <boolean> invoke formatters without executing steps
    failFast: false, // <boolean> abort the run on first failure
    ignoreUndefinedDefinitions: false, // <boolean> Enable this config to treat undefined definitions as warnings
    name: [], // <string[]> ("extension:module") require files with the given EXTENSION after requiring MODULE (repeatable)
    snippets: true, // <boolean> hide step definition snippets for pending steps
    format: ['pretty'], // <string[]> (type[:path]) specify the output format, optionally supply PATH to redirect formatter output (repeatable)
    colors: true, // <boolean> disable colors in formatter output
    snippets: false, // <boolean> hide step definition snippets for pending steps
    source: false, // <boolean> hide source uris
    profile: [], // <string[]> (name) specify the profile to use
    strict: true, // <boolean> fail if there are any undefined or pending steps
    tagExpression: '@ScreenCompare', // <string> (expression) only execute the features or scenarios with tags matching the expression, see https://docs.cucumber.io/tag-expressions/
    timeout: defaultTimeoutInterval, // <number> timeout for step definitions
    tagsInTitle: true, // <boolean> add cucumber tags to feature or scenario name
    snippetSyntax: undefined, // <string> specify a custom snippet syntax
  },

  before: function() {
    const chai = require('chai');
    global.expect = chai.expect;
    global.assert = chai.assert;
    global.should = chai.should();
  },

  afterFeature: function(feature) {
    fs.appendFileSync(
      file,
      '], "browser": {     "name": "Chrome",    "version": "78.0.3904.108",  "userAgent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_13_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/78.0.3904.108 Safari/537.36",  ' +
        '    "Environment": "' +
        process.env.ENVIRONMENT_VAR +
        '",  "viewport": {      "width": ' +
        browserWidth +
        ',      "height": ' +
        browserHeight +
        '   }  } }'
    );
  },

  // ******** Visual regression ************
  visualRegression: {
    compare: new VisualRegressionCompare.LocalCompare({
      referenceName: getScreenshotName(path.join(process.cwd(), 'test/screenshots/reference')), //exp
      screenshotName: getScreenshotName(path.join(process.cwd(), 'test/screenshots/screen')), //actu
      diffName: getScreenshotName(path.join(process.cwd(), 'test/screenshots/diff')),
      misMatchTolerance: 0.01,
    }),
    viewports: [
      {
        width: 1366,
        height: 768,
      },
    ],
  },

  // ******** Visual regression ************
};
