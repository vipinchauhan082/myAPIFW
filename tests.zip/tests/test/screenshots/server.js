const http = require('http');
var express = require('express');
var cors = require('cors');
const bodyParser = require('body-parser');
const url = require('url');
const querystring = require('querystring');
var fs = require('fs');
var os = require('path');

//express server
const app = express();

// cors settings
app.use(
  cors({
    origin: 'http://localhost:3000',
    credentials: true,
  })
);

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

app.get('/screenshots/:reference/:img', function(req, res) {
  const reference = req.params.reference;
  const img = req.params.img;
  var path = `./${reference}/${img}`;
  console.log('Image path', path);
  res.sendFile(os.join(__dirname, path));
});

app.get('/', function(req, res) {
  var path = './visual-results/index.html';
  try {
    if (fs.existsSync(path)) {
      var contents = fs.readFileSync(path);
      //var jsonContent = JSON.parse(contents);

      res.setHeader('Content-Type', 'text/html');
      res.end(contents);
    } else {
      console.log(`Could not find ${path}`);
      res.send(`Could not find ${path}`);
    }
  } catch (err) {
    console.log(err);
    res.send(err.message);
  }
});

app.get('/replacefile/:screenshots/:reference/:img', function(req, res) {
  let img = req.params.img;
  const source = `./screen/${img}`;
  const destination = `./reference/${img}`;
  var sourcePath = os.join(__dirname, source);
  var destinationPath = os.join(__dirname, destination);

  console.log('source', sourcePath);
  console.log('destination', destinationPath);

  try {
    fs.copyFileSync(sourcePath, destinationPath);
    res.setHeader('Content-Type', 'application/json');
    res.send({
      status: 200,
    });
  } catch (err) {
    console.log(err);
    res.send(err.message);
  }
});
var server = http.createServer(app);
const port = 8001;
server.listen(port, () => console.log(`Example app listening on port ${port}!`));
