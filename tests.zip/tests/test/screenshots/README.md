# Visual Regression Framework

## 👋 Introduction:

This document will help you to setup visual regression automation framework and how to start server to access report url and use replace screen action.

##Before begin Please follow the steps below

## Major features

1. Cross Browser, Device and platform execution.
2. Compare page for specific browser resolution so it does not impact whether execution is happening on laptop, desktop or cloud.
3. Can compare specific element on page instead full page using element Xpath.
4. Reporting :
   - Report works as independent web application.
   - Report can be deployed on cloud, local machine or company VM with single "npm start" command.
   - Multiple reports can be viewed on same time with seperate link and in seperate tab.
   - Separate report for Desktop and Mobile report.
   - Number of PASS\FAIL with pia chart graph.
   - Last execution date on dashboard and individual report.
   - Individual report opens in new tab with detailed comparation of full page with expected image, Actual Image and diffirence image can be viewed.
   - Report contains failure reason summary.
5. Each failure image has option to replace Actual Image with expected image to update baseline image.
6. Covers static and dynamic both type of pages.
   - Static Pages: Can be covered through writing feature file or Provide static urls in "test\screenshots\urls.txt" file.
   - Dynamic Pages : you need to write feature file and run application journey using cucumber steps.

## Basic Requirements : Check if you have following basic setup on your machine.

1. GIT on machine
2. Repository access ""
3. [Node 10.16.3](https://nodejs.org/en/download/)
4. Java jdk 8+
5. [Visual Studio Code](https://code.visualstudio.com/download) (or any other ID that support JS)

## 👋 SETUP

### Step1: Clone and Setup

1. Clone repository on local machine.
2. Navigate to working directory and run "npm install"
3. Navigate to "..\test\screenshots" location and do "npm install"

```shell
git clone https://pscode.lioncloud.net/engineering-community/quality-engineering/webautomation-js.git
cd <Framework folder name>
npm install
cd test
cd screenshots
npm install
```

### Step2: Create test case

#### Option-1 For Static Page :

1. Add application domain url in environment file for each environment. "test\config\environmentdetails.yml"
2. Update page urls in "" file without domain name.

#### Option-2 For Dynamic Page :

1. Add application domain url in environment file for each environment. "test\config\environmentdetails.yml"
2. Update page urls in "test\config\environmentdetails.yml" file.
3. Write feature files to run journey and incluse following steps to compare screen:
   I compare screenshot for "PAGE NAME"
   I compare "SELECTOR" element screenshot on "PAGE NAME"

### Step3: Execution

#### Create baseline images before build.

1. Enter environment name in "desktop-screen.conf.js" file
2. Run "npm run desktop-screen" command from working directory. ("npm run mobile-screen" for mobile)
   Note: Change screen resolution as per you requirement. (Desktop: 1366*768, Mobile: 360*640)

```shell
cd ..
npm run desktop-screen
```

3. Make sure after execution following file has created in "test\screenshots\visual-results\" folder:
   - chrome_screenReport.json
   - chrome_reportSummary.json
   - chrome_index.html
4. Repeat 1-3 steps for Mobile as well.

#### Capture actual images after build.

1. Repeat 1-4 steps.
2. Run "npm start" command from "..\test\screenshots" to start local host server.

```shell
cd screenshots
npm start
```

3. Make sure "Example app listening on port 8001!" message for success start.

### Step4: Access Report

1. Open "localhost:8001" to access report dashboard and see status summary with pia chart.
2. Click on "Chrome Execution Report" to access detailed report for Chrome.
3. Click on "Mobile Execution Report" to access detailed report for Mobile.

### Pipeline Integration:

Following scripts need to execute in sequence through bash script: (TO DO)
