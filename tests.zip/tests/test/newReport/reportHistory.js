const fs = require('fs');
const path = require('path');
// JSON data
//const data = require('../reports/priorityBasisFailureReport_1-5-2020-12-39-25-AM.json');
let rows = '';
let data = '';
const testFolder = 'test/newReport/json/';
let graphData = "['Date', 'Passed', 'Failed']";

// Build paths
const buildPathHtml = path.resolve('./test/newReport');

const createRow = item => {
  // console.log('new row');

  let date = item.Date.split(',');
  let date1 = date[0].split('/');
  let date2 = date[1].split(':');
  date = date1[0] + '-' + date1[1] + date2[0] + ':' + date2[1];
  graphData = graphData + `,['${date}', ${item.Passed_Percentage},${item.Failed_Percentage}]`;
  console.log('graphData', graphData);
  return `
  <tr>
    <td class="status">${item.Date}</td>
    <td class="status">${item.Browser}</td>
    <td class="status">${item.Plateform}</td>
    <td class="status">${item.Total_Scenarios}</td>
    <td class="status">${item.Passed_Percentage} %</td>
    <td class="status">${item.Failed_Percentage} %</td>
    <td class="status">${item.P1_Failures}</td>
    <td class="status">${item.P2_Failures}</td>
    <td class="status">${item.P3_Failures}</td>
    <td class="status">${item.CSS_Issues}</td>
    <td class="status">${item.Other_Issues}</td>
    <td class="status">${item.Functional_Issues}</td>
  </tr>
`;
};

const createTable = rows => `
  <table  id="regressionTable">
    <thead>
      <tr>
          <th>Date</td>
          <th>Browser</td>
          <th>Plateform</td>
          <th>Total Scenarios</td>
          <th class='green'>Passed %</td>
          <th class='red'>Failed %</td>
          <th>P1 Failures</td>
          <th>P2 Failures</td>
          <th>P3 Failures</td>
          <th>CSS Issues</td>
          <th>Functional Issues</td>
          <th>Other Issues</td>
      </tr>
    </thead>
    <tbody>
      ${rows}
    </tbody>
  </table>
  <script>
  $(document).ready(function () {
    $('#regressionTable').DataTable();
  });
</script>
`;

const createHeader = data => `

<div class="container">
  <div class="logo">
    <img src="./logo.png" alt="Logo" width="150px" height="100px" />
  </div>
  <div class="title">
    <div class="label-area">
      <h1 style="color:#e87722;"> Regression History </h1>
    </div>
    <div class="secondary-header">
      <p>
        Browser: <span>${data.Browser}</span> | Version: <span>${data.Plateform} </span>|
      </p>
    </div>
  </div>
  <div id="curve_chart" style="width: 900px; height: 200px"></div>
</div>
`;

const createHtml = (table, header) => `
  <html>
    <head>
    <title>Regression Automation Execution History</title>
    <link href="http://cdn.datatables.net/1.10.20/css/jquery.dataTables.min.css" rel="stylesheet" type="text/css" />
    <script src=" https://code.jquery.com/jquery-3.4.1.min.js"></script>
    <script src="http://cdn.datatables.net/1.10.20/js/jquery.dataTables.min.js"></script>
      <style>
      table {
        width: 100%;
        color: #293A2A;
      }
  
      thead tr {
        background-color: #000;
        font-weight: normal;
      }
  
      tr {
  
        border: 1px solid #442424;
  
        text-transform: capitalize;
      }
  
      th,
      td {
        padding: 15px;
      }
  
      table.dataTable tbody th,
      table.dataTable tbody td {
        border: 1px solid #ddd;
      }

      thead tr {
        text-align: center;
  
        color: #fff;
      }
  
      tr,
      td {
        background-color: #ececec;
        white-space: nowrap;
      }
  
      .container {
        width: 100%;
        position: relative;
        display: flex;
      }
  
      .logo {
        width: 12%;
        float: left;
        text-align: left;
      }
   
      th.green {
        background-color: #9fd34f;
      }
  
      th.red {
        background-color: red;
      }
      </style>
      <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
      <script type="text/javascript">
        google.charts.load('current', { 'packages': ['corechart'] });
        google.charts.setOnLoadCallback(drawChart);
    
        function drawChart() {
          var data = google.visualization.arrayToDataTable([
            ${graphData}
          ]);
    
          var options = {
            title: 'Regression History',
            curveType: 'function',
            legend: { position: 'bottom' },
            trendlines: {
              0: { type: 'linear', lineWidth: 2, opacity: .2 },
              1: { type: 'exponential', lineWidth: 5, opacity: .2 }
            }
          };
    
          var chart = new google.visualization.ColumnChart(document.getElementById('curve_chart'));
    
          chart.draw(data, options);
        }
      </script>
    </head>
    <body>
    <div class="container">
    <div class="logo">
      <img src="https://www.fwd.com/en/images/home/fwdfaq.png" alt="Logo" width="150px" height="100px" />

      ${header}      
      ${table}

    </body>
  </html>
`;

/**
 * @description this method takes in a path as a string & returns true/false
 * as to if the specified file path exists in the system or not.
 * @param {String} filePath
 * @returns {Boolean}
 */

const doesFileExist = filePath => {
  try {
    fs.statSync(filePath); // get information of the specified file path.
    return true;
  } catch (error) {
    return false;
  }
};

try {
  /* Check if the file for `html` build exists in system or not */
  if (doesFileExist(buildPathHtml + '/index.html')) {
    // console.log('Deleting old build file');
    /* If the file exists delete the file from system */
    fs.unlinkSync(buildPathHtml + '/index.html');
  }
  /* generate rows */
  //const rows = data.map(createRow).join('');
  // const rows = createRow(data);
  // console.log("row data", rows);

  //var dir = './'; // your directory

  var files = fs.readdirSync(testFolder);
  files.sort(function(a, b) {
    return fs.statSync(testFolder + b).mtime.getTime() - fs.statSync(testFolder + a).mtime.getTime();
  });

  files.forEach(file => {
    let jsonFile = './json/' + file;
    // console.log('json file data', jsonFile);
    data = require(jsonFile);
    // console.log('data file data', data);
    rows = rows + createRow(data);
    // console.log('row data', rows);
  });

  /* generate table */
  const table = createTable(rows);
  const header = createHeader(data);
  console.log('header', header);
  /* generate html */
  const html = createHtml(table, header);
  fs.mkdir(buildPathHtml, { recursive: true }, err => {
    if (err) throw err;
    fs.writeFileSync(buildPathHtml + '/index.html', html);
  });
  /* write the generated html to file */

  console.log('Succesfully created an HTML table');
} catch (error) {
  console.log('Error generating table', error);
}
