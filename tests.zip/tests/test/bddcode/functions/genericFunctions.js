import Page from './page';
const fs = require('graceful-fs');
const yaml = require('js-yaml');
let userData = require('../support/globalTestData');
import request from 'request';

let csvData = 'Header Tag, , URL, HTML' + '\n';
var finalApiName, apiSuffix, apiUrlName;

class GenericFunctions extends Page {
  generateAPIURL({ apiname, language, market }) {
    apiSuffix = this.getValueAsPerMarket({ key: apiname, market });
    const currentEnv = process.env.ENVIRONMENT_VAR;

    if (currentEnv === 'uat') {
      apiUrlName = this.getValueAsPerMarket({ key: currentEnv + '-api', market });
    } else {
      apiUrlName = this.getValueAsPerMarket({ key: currentEnv + '-api', market }) + `${process.env.RELEASE}/`;
    }

    apiSuffix = apiSuffix.replace('#LANG-VAR#', language);
    apiSuffix = apiSuffix.replace('#VERSION#', process.env.VERSION);
    finalApiName = apiUrlName + apiSuffix;
    console.log('API URL to be formed = ', finalApiName);
    return finalApiName;
  }

  getAPIURL(apiname) {
    apiSuffix = this.getValueforEnv(apiname);
    const currentEnv = process.env.ENVIRONMENT_VAR;

    if (currentEnv === 'uat') {
      apiUrlName = this.getValueforEnv(currentEnv + '-api');
    } else {
      apiUrlName = this.getValueforEnv(currentEnv + '-api') + `${process.env.RELEASE}/`;
    }

    console.log('process.env.ENVIRONMENT', process.env.ENVIRONMENT_VAR);
    console.log('apiUrlName', apiUrlName);
    apiSuffix = apiSuffix.replace('#LANG-VAR#', process.env.LANGUAGE);
    finalApiName = apiUrlName + apiSuffix;
    console.log('API URL to be formed = ', finalApiName);
    return finalApiName;
  }
  openUrl(pageName) {
    let baseurlName = this.getValueforEnv(process.env.ENVIRONMENT_VAR);
    apiUrlName = this.getValueforEnv(process.env.ENVIRONMENT_API_VAR);
    let pageNameSuffix = this.getValueforEnv(pageName);
    baseurlName = baseurlName + '/' + process.env.LANGUAGE;

    if (baseurlName.includes('#BUILD_VAR#')) {
      baseurlName = baseurlName.replace('#BUILD_VAR#', process.env.BUILD_VAR);
      console.log('baseurlName ', baseurlName && ' has opened for feature environment successfully');
    }
    let finalURL = baseurlName + pageNameSuffix;
    console.log('Final url', finalURL);
    userData.setField('url', finalURL);
    this.open(finalURL);
    browser.execute(function() {
      localStorage.setItem('hideSplash', true);
      localStorage.setItem('cookieBannerRead', true);
      localStorage.setItem('hideNotification', true);
    });
    browser.refresh();
    browser.pause(1000);
    if (browser.isExisting('#UserName')) {
      let fuser = this.getValueforEnv('fuserName');
      let fpwd = this.getValueforEnv('fpassWord');
      browser.setValue('#UserName', fuser);
      browser.setValue('#UserPass', fpwd);
      browser.click('#Submit1');
    }
  }

  openPrefilteredPLPUrl(pageName, query_param, value) {
    let baseurlName = this.getValueforEnv(process.env.ENVIRONMENT_VAR);
    //console.log(baseurlName);
    apiUrlName = this.getValueforEnv(process.env.ENVIRONMENT_API_VAR);
    let pageNameSuffix = this.getValueforEnv(pageName);
    baseurlName = baseurlName + '/' + process.env.LANGUAGE;

    if (baseurlName.includes('#BUILD_VAR#')) {
      baseurlName = baseurlName.replace('#BUILD_VAR#', process.env.BUILD_VAR);
      console.log('baseurlName ', baseurlName && ' has opened for feature environment successfully');
    }
    let finalURL = baseurlName + pageNameSuffix;
    //let finalURL = baseurlName;
    //let url = browser.getUrl();
    let filter;
    switch (query_param) {
      case 'primarytags':
        filter = 'primarytags=' + value.toString();
        finalURL = finalURL + '?' + filter;
        break;
      case 'primarytags,secondarytags':
        value = value.split(',');
        filter = 'primarytags=' + value[0].toString() + '&' + 'secondarytags=' + value[1].toString();
        finalURL = finalURL + '?' + filter;
        break;
      case 'plancomponent':
        filter = 'plancomponent=' + value.toString();
        finalURL = finalURL + '?' + filter;
        break;
      case 'purchasemethods':
        filter = 'purchasemethods=' + value.toString();
        finalURL = finalURL + '?' + filter;
        break;
      case 'promotion':
        filter = 'promotion=' + value.toString();
        finalURL = finalURL + '?' + filter;
        break;
      default:
        var valuePssed = query_param.split(',');
        console.log(valuePssed);
        console.log(valuePssed.length);
        var filtervalue = value.split(',');
        console.log(filtervalue);
        console.log(filtervalue.length);
        let i;
        let rsArr = [];
        for (i = 0; i < valuePssed.length; i++) {
          console.log(valuePssed[i]);
          console.log(filtervalue[i]);
          rsArr[i] = valuePssed[i].toString() + '=' + filtervalue[i].toString();
          console.log(rsArr[i]);
          filter = rsArr.join('&');
          console.log(filter);
        }
        finalURL = finalURL + '?' + filter;
    }
    console.log('Final url', finalURL);
    userData.setField('url', finalURL);
    this.open(finalURL);
    browser.execute(function() {
      localStorage.setItem('hideSplash', true);
      localStorage.setItem('cookieBannerRead', true);
      localStorage.setItem('hideNotification', true);
    });
    browser.refresh();
    browser.pause(1000);
  }

  writeValueinFile(val123, status) {
    console.log('yaml file loading start');
    let environment_Data = yaml.load(fs.readFileSync('test/testdata/temp.yml'));
    console.log('yaml file loaded');
    fs.appendFileSync('test/testdata/temp.yml', '\n' + '  ' + val123 + status);
    console.log('Written CSS value is:', 'CSS:' + '  ' + val123 + status);
  }

  readAllfromTempFile(val123) {
    let environment_Data = yaml.load(fs.readFileSync('test/testdata/temp.yml'));
    return fs.readFile('test/config/temp.yml');
  }

  closeFile(val123) {
    let environment_Data = yaml.load(fs.readFileSync('test/testdata/temp.yml'));
    fs.close();
  }

  getValueFromEnv(env, key) {
    let environment_Data = yaml.load(fs.readFileSync('test/config/environmentdetails.yml'));
    let envData = environment_Data[env];
    return envData[key];
  }

  getValueforEnv(key) {
    let environment_Data;
    if (process.env.MARKET == 'HK') {
      environment_Data = yaml.load(fs.readFileSync('test/config/environmentdetails-hk.yml'));
    } else if (process.env.MARKET == 'GO' && process.env.ENVIRONMENT_VAR=='live') {
      environment_Data = yaml.load(fs.readFileSync('test/config/environmentdetails-live-go.yml'));
    }
      else if(process.env.MARKET == 'GO'){
        environment_Data = yaml.load(fs.readFileSync('test/config/environmentdetails-go.yml'));
  }
      else if (process.env.MARKET == 'ID') {
        environment_Data = yaml.load(fs.readFileSync('test/config/environmentdetails-id.yml'));
      }
      else if(process.env.MARKET == 'JP'){
        environment_Data = yaml.load(fs.readFileSync('test/config/environmentdetails-jp.yml'));
      }
     else {
      environment_Data = yaml.load(fs.readFileSync('test/config/environmentdetails-th.yml'));
    }

    let envData = environment_Data[key];
    return envData;
  }

  getValueAsPerMarket({ key, market = process.env.MARKET }) {
    let environment_Data;
    if (market == 'HK') {
      environment_Data = yaml.load(fs.readFileSync('test/config/environmentdetails-hk.yml'));
    } else {
      environment_Data = yaml.load(fs.readFileSync('test/config/environmentdetails-th.yml'));
    }

    let envData = environment_Data[key];
    return envData;
  }

  getSelector(key) {
    let xPathValList = userData.getField('locatorList')['FWD'];
    let xPathVal = xPathValList[key];
    browser.element(xPathVal).waitForVisible(30000);
    return browser.element(xPathVal);
  }

  getSelectorWithIndex(key, index) {
    let xPathValList = userData.getField('locatorList')['FWD'];
    let xPathVal = xPathValList[key] + '[' + index + ']';
    browser.element(xPathVal).waitForVisible(50000);
    return browser.element(xPathVal);
  }

  getXpath(key) {
    let xPathValList = userData.getField('locatorList')['FWD'];
    return xPathValList[key];
  }

  getContent(key) {
    let environment_Data = yaml.load(fs.readFileSync('test/content/content.yml'));
    let contentList = environment_Data['FWD'];
    return contentList[key];
  }

  // getProperties(key) {
  //   let environment_Data = yaml.load(fs.readFileSync('test/content/CSSDesktopProperties.yml'));
  //   return environment_Data[key];
  // }

  getCSSProperties(key) {
    let environment_Data;
    if (process.env.DEVICEVIEW_TYPE == 'mobile') {
      environment_Data = yaml.load(fs.readFileSync('test/content/CSSMobProperties.yml'));
    } else {
      environment_Data = yaml.load(fs.readFileSync('test/content/CSSDesktopProperties.yml'));
    }
    return environment_Data[key];
  }

  getPayloads(key) {
    let environment_Data = yaml.load(fs.readFileSync('test/content/Payloads.yml'));
    return environment_Data[key];
  }
  getFontFamily(family) {
    let fontData = yaml.load(fs.readFileSync('test/content/languageFontMapping.yml'));
    let languageFilter = fontData[process.env.LANGUAGE];
    let fontFamily = languageFilter[family];
    return fontFamily;
  }

  waitForElemReady(selector) {
    for (let i = 0; i <= 30; i++) {
      if (!this.getSelector(selector).isVisible()) {
        browser.waitForVisible(selector, 1000);
      } else return;
    }
  }

  checkFileExists(fileName) {
    var dir = global.downloadDir + '/' + fileName;
    var fileExists = false;
    if (fs.existsSync(dir)) {
      fileExists = true;
      return fileExists;
    } else return fileExists;
  }

  selectItemFromDropdown(selector, value) {
    this.getSelector(selector).click();
    browser.pause(2000);
    let Selector2 = "//li[.='" + value + "']";
    browser.element(Selector2).click();
    browser.pause(2000);
  }

  selectItemFromDropdownUsingContains(selector, value) {
    let Selector = this.getXpath(selector);
    let selector2 = [selector, "//span[contains(text(),'", value, "')]"].join('');
    browser.element(Selector).click();
    browser.pause(2000);
    browser.element(Selector2).click();
    browser.pause(2000);
  }
  sendkey(inputText, selector) {
    this.getSelector(selector).click();
    let inputarray = inputText.split('');
    inputarray.forEach(element => {
      browser.keys(element);
      //browser.pause(2000);
    });
  }
  getAttributeValue(selector, attribute) {
    let attributeValue = this.getSelector(selector).getAttribute(attribute);
    return attributeValue;
  }

  getAttributeTextValue(selector) {
    let attributeValue = this.getSelector(selector).getText();
    return attributeValue;
  }

  createRandomString(value) {
    var chars = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXTZabcdefghiklmnopqrstuvwxyz',
      randomString = '',
      rnum;
    for (var i = 0; i < value; i++) {
      rnum = Math.floor(Math.random() * chars.length);
      randomString += chars.substring(rnum, rnum + 1);
    }
    return randomString;
  }

  getAPICall(recipeID, url) {
    let apiurl = this.getValueFromEnv(process.env.ENVIRONMENT_VAR, url);
    apiurl = apiurl.replace('#replace#', recipeID);

    var options = {
      url: apiurl,
      headers: {
        'x-api-key': 'BVukNygdGw7rfnmFAyoKp6aNWVEcpgWD3jnoo5O3',
      },
    };

    browser.call(() => {
      return new Promise((resolve, reject) => {
        request(options, function(error, response, body) {
          console.log('statusCode:', response && response.statusCode); // Print the response status code if a response was received
          userData.setField('recipeResponse', JSON.parse(body));
          if (error) {
            return reject(error);
          }
          resolve(response);
        });
      });
    });
  }

  postAPICall(url, postData, extraHeaders) {
    var rs;
    let apiurl = url;
    let envName;
    if (
      process.env.ENVIRONMENT_VAR == 'local' ||
      process.env.ENVIRONMENT_VAR == 'dev' ||
      process.env.ENVIRONMENT_VAR == 'feature'
    ) {
      envName = 'dev';
    } else {
      envName = process.env.ENVIRONMENT_VAR;
    }

    let SubscriptionKey = this.getValueforEnv(envName + '-' + 'Authorization');
    console.log('SubscriptionKey', SubscriptionKey);
    let locType = this.getValueforEnv('Location-Type');

    var options = {
      url: apiurl,
      body: postData,
      JSON: true,
      headers: {
        Authorization: SubscriptionKey,
        'Location-Type': locType,
        'Content-Type': 'text/plain',
      },
    };
    Object.assign(options.headers, extraHeaders);

    return browser.call(() => {
      return new Promise((resolve, reject) => {
        request.post(options, function(error, response, body) {
          console.log('statusCode:', response && response.statusCode); // Print the response status code if a response was received
          //console.log('body:', JSON.parse(body)); // Print the response status code if a response was received
          userData.setField('recipeResponse', JSON.parse(body));
          if (error) {
            return reject(error);
          }
          resolve(response);
        });
      });
    });
  }

  getPayloads(key) {
    let environment_Data = yaml.load(fs.readFileSync('test/content/Payloads.yml'));
    return environment_Data[key];
  }

  getFontFamily(family) {
    let fontData = yaml.load(fs.readFileSync('test/content/languageFontMapping.yml'));
    let languageFilter = fontData[process.env.LANGUAGE];
    let fontFamily = languageFilter[family];
    return fontFamily;
  }

  selectItemFromDropdownByIndex(selector, value) {
    this.getSelector(selector).click();
    browser.pause(2000);
    let Selector2 = "//*[@class='MuiList-root MuiMenu-list MuiList-padding']//li[" + value + ']';
    browser.element(Selector2).click();
    browser.pause(5000);
  }

  onlyNumbers(s) {
    for (let i = s.length; i >= 1; i--) {
      const d = s.charCodeAt(i);
      if (d < 48 || d > 57) return false;
    }
    return true;
  }

  findHeaderTags(selector) {
    // this.waitForElemReady(selector);
    let xpathVal = this.getXpath(selector);
    var cnt = $$(xpathVal).length;
    for (let i = 1; i <= cnt; i++) {
      csvData =
        selector +
        ',' +
        browser.getUrl() +
        ',' +
        browser.getAttribute('(' + this.getXpath(selector) + ')' + '[' + i + ']', 'outerHTML') +
        '\n';
      fs.appendFile('test/HeaderHierarchy.csv', csvData, function(err) {
        if (err) throw err;
      });
    }
  }
}

export default new GenericFunctions();
