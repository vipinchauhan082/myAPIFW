try {
  const fsexe = require('fs-extra');
  let jpath = require('jsonpath');
  const fs = require('fs');

  var readJSONReport = function readJSONReport() {
    let P1_Failures = 0;
    let P2_Failures = 0;
    let P3_Failures = 0;

    let QAOwner = '';
    let Functional_Issues = 0;
    let CSS_Issues = 0;
    let Script_Issues = 0;
    let BrokenLink_Issues = 0;
    let TestDataAPI_Issues = 0;
    let Other_Issues = 0;
    let total_testCases = 0;
    let csvData = 'Tags, Scenario Name, First Step, Error Message, Failure Type, Status, QA Owner';
    let browserName = '';
    let plateform = '"Desktop"';

    const testFolder = 'test/reports/json-results/';
    fs.readdirSync(testFolder).forEach(file => {
      let jsonFile = 'test/reports/json-results/' + file;
      var data = fsexe.readFileSync(jsonFile, 'utf8');
      var jsonFileData = JSON.parse(data);
      browserName = jsonFileData.capabilities.browserName;
      let chromeOptions1 = jsonFileData.capabilities['goog:chromeOptions'];
      if (typeof chromeOptions1 != 'undefined' && chromeOptions1 != null) {
        if (chromeOptions1.hasOwnProperty('mobileEmulation')) {
          plateform = JSON.stringify(chromeOptions1.mobileEmulation.deviceName);
        }
      }

      var jsonData = jsonFileData['suites'];

      if (jsonData.length > 0) {
        total_testCases = total_testCases + jsonData.length - 1;
      }
      for (scenarios = 1; scenarios < jsonData.length; scenarios++) {
        let FailureType = '';
        var errorMessage = jpath.query(jsonData[scenarios], 'tests..error');

        if (errorMessage != '') {
          let firstStep = jpath.query(jsonData[scenarios], 'tests..name')[0];
          // Identify priority failure from Tags
          var scenarioName = jsonData[scenarios].name;
          if (scenarioName.includes('@P1') || scenarioName.includes('@p1')) {
            P1_Failures = P1_Failures + 1;
          } else if (scenarioName.includes('@P2') || scenarioName.includes('@p2')) {
            P2_Failures = P2_Failures + 1;
          } else if (scenarioName.includes('@P3') || scenarioName.includes('@p3')) {
            P3_Failures = P3_Failures + 1;
          }

          // QAOwner categrization
          if (scenarioName.includes('@Accessibility')) {
            QAOwner = 'Amit Garg';
          } else if (
            scenarioName.includes('@ProductCards') ||
            scenarioName.includes('@ProductListingTags') ||
            scenarioName.includes('@ProductPromotionsFilter') ||
            scenarioName.includes('@ArticleCards') ||
            scenarioName.includes('@ClaimCardList') ||
            scenarioName.includes('@ClaimCardVariant') ||
            scenarioName.includes('@RegDisclosure') ||
            scenarioName.includes('@ArticleListing') ||
            scenarioName.includes('@PremiumPayment') ||
            scenarioName.includes('@SupportLanding') ||
            scenarioName.includes('@ArticleCard') ||
            scenarioName.includes('@PrivilegeCards') ||
            scenarioName.includes('@PDP')
          ) {
            QAOwner = 'Anchal Vaish';
          } else if (
            scenarioName.includes('@PlanCards') ||
            scenarioName.includes('@Quick') ||
            scenarioName.includes('@PressRelease') ||
            scenarioName.includes('@TNC') ||
            scenarioName.includes('@ClaimsDetailStepper') ||
            scenarioName.includes('@ClaimsDownloadForms') ||
            scenarioName.includes('@AllForms') ||
            scenarioName.includes('@ErrorScreen') ||
            scenarioName.includes('@CSR') ||
            scenarioName.includes('@PartnerInfo') ||
            scenarioName.includes('@NonTranslatedPageModal') ||
            scenarioName.includes('@DownloadForms')
          ) {
            QAOwner = 'Rajiv Gautam';
          } else if (
            scenarioName.includes('@Announcements') ||
            scenarioName.includes('@CareerAgent') ||
            scenarioName.includes('@EmployeeListing') ||
            scenarioName.includes('@FAQsTab') ||
            scenarioName.includes('@FAQTab') ||
            scenarioName.includes('@Press') ||
            scenarioName.includes('@Privileges') ||
            scenarioName.includes('@Management') ||
            scenarioName.includes('@CookieBanner') ||
            scenarioName.includes('@Career') ||
            scenarioName.includes('@OurValues') ||
            scenarioName.includes('@FAQ')
          ) {
            QAOwner = 'Parveen Awasthi';
          } else if (
            scenarioName.includes('@Awards') ||
            scenarioName.includes('@BookAnAgent') ||
            scenarioName.includes('@BriefHistory') ||
            scenarioName.includes('@CallBackForm') ||
            scenarioName.includes('@Book') ||
            scenarioName.includes('@Reports') ||
            scenarioName.includes('@Quote') ||
            scenarioName.includes('@JoinUs') ||
            scenarioName.includes('@ProductLink') ||
            scenarioName.includes('@GroupInsurance') ||
            scenarioName.includes('@HomePage')
          ) {
            QAOwner = 'Sanchita Gupta';
          } else if (
            scenarioName.includes('@PlanCardList') ||
            scenarioName.includes('@HeroBanner') ||
            scenarioName.includes('@ProductRelatedArticle') ||
            scenarioName.includes('@SupportOptions') ||
            scenarioName.includes('@SectionContent')
          ) {
            QAOwner = 'Anjali Gulati';
          } else if (
            scenarioName.includes('@ManagementCardList') ||
            scenarioName.includes('@GlobalShare') ||
            scenarioName.includes('@AnnouncementNotification')
          ) {
            QAOwner = 'Vipin Chauhan';
          } else if (
            scenarioName.includes('@Map') ||
            scenarioName.includes('@ArticleDetails') ||
            scenarioName.includes('@GlobalSearch') ||
            scenarioName.includes('@HistoricalSearch') ||
            scenarioName.includes('@SupportOptionsExpend') ||
            scenarioName.includes('@DynamicTagList') ||
            scenarioName.includes('@FWD-1154')
          ) {
            QAOwner = 'Bhawna Vohra';
          } else if (
            scenarioName.includes('@CampaignCard') ||
            scenarioName.includes('@EnquiryForm') ||
            scenarioName.includes('@Calculator') ||
            scenarioName.includes('@Recommender') ||
            scenarioName.includes('@Calculate') ||
            scenarioName.includes('@Rider') ||
            scenarioName.includes('@RecommendedCards') ||
            scenarioName.includes('@SearcHeader') ||
            scenarioName.includes('@ProductListingReset')
          ) {
            QAOwner = 'Jitendra Nakra';
          } else {
            QAOwner = 'Not Assigned';
          }

          // Error categrization from error message
          let e = errorMessage[0];

          if (
            e.includes('still not visible') ||
            e.includes('An element could not be located') ||
            e.includes('is not displayed')
          ) {
            Functional_Issues = Functional_Issues + 1;
            FailureType = 'Functional Issue';
          } else if (e.includes('CSS')) {
            CSS_Issues = CSS_Issues + 1;
            FailureType = 'CSS Property Issue';
          } else if (e.includes("'toString' of undefined") || e.includes("Cannot read property 'split' of undefined")) {
            Script_Issues = Script_Issues + 1;
            FailureType = 'Automation Script Issue';
          } else if (e.includes('expected undefined to equal 200')) {
            BrokenLink_Issues = BrokenLink_Issues + 1;
            FailureType = 'Broken Link Issue';
          } else if (e.includes('does not contains') || e.includes('promise resolves within')) {
            Functional_Issues = Functional_Issues + 1;
            FailureType = 'Functional Issue';
          } else if (e.includes('API Response contains error') || e.includes('Service data validation failed')) {
            TestDataAPI_Issues = TestDataAPI_Issues + 1;
            FailureType = 'API response Issue';
          } else {
            Other_Issues = Other_Issues + 1;
            FailureType = 'Other Issue';
          }
          scenarioName = scenarioName.replace(/,/g, '');
          scenarioAndTag = scenarioName.split(':');
          errorMSG = e.replace(/,/g, '');
          csvData =
            csvData +
            '\n' +
            scenarioAndTag[0] +
            ',' +
            scenarioAndTag[1] +
            ',' +
            firstStep +
            ',' +
            errorMSG +
            ',' +
            FailureType +
            ',' +
            'Fail,' +
            QAOwner;
        }
        //else{
        //   console.log("in else")
        //   let firstStep1 = jpath.query(jsonData[scenarios], 'tests..name')[0];
        //   // Identify priority failure from Tags
        //   var scenarioName1 = jsonData[scenarios].name;
        //   scenarioName1 = scenarioName1.replace(/,/g, '');
        //   scenarioAndTag1 = scenarioName1.split(':');
        //   csvData =
        //   csvData +
        //   '\n' +
        //   scenarioAndTag1[0] +
        //   ',' +
        //   scenarioAndTag1[1] +
        //   ',' +
        //   firstStep1 +
        //   ',' +
        //   'NA' +
        //   ',' +
        //   FailureType +
        //   ',' +
        //   'Pass' +
        //   ',' +
        //   ' ';
        // }
      }
    });

    console.log('P1 scenarios ', P1_Failures);
    console.log('P2 scenarios ', P2_Failures);
    console.log('P3 scenarios ', P3_Failures);

    let passed_Percentage = (
      ((total_testCases - (P1_Failures + P2_Failures + P3_Failures)) * 100) /
      total_testCases
    ).toFixed(2);
    console.log('total_testCases', total_testCases);

    console.log('passed_Percentage : ', passed_Percentage);
    console.log('failed_Percentage : ', (100 - passed_Percentage).toFixed(2));
    console.log('Functional_Issues ', Functional_Issues);
    console.log('CSS_Issues ', CSS_Issues);
    console.log('Script_Issues ', Script_Issues);
    console.log('BrokenLink_Issues ', BrokenLink_Issues);
    console.log('TestDataAPI_Issues ', TestDataAPI_Issues);
    console.log('Other_Issues ', Other_Issues);

    // console.log('CSV File data', csvData);

    let currentTime = new Date().toLocaleString();
    let timeVar = currentTime.replace(/,/g, '');
    timeVar = timeVar.replace(/:/g, '-');
    timeVar = timeVar.replace(/\s/g, '-');
    timeVar = timeVar.replace(/\//g, '-');

    fs.writeFileSync('test/reports/report.csv', csvData, function(err) {
      if (err) throw err;
      console.log('csvData : ', csvData);
      res.send('done');
    });

    let reportSummary =
      '<table style="width:30%">  <tr> <th>Total Test Cases</th>  <th>Passed TC</th>  <th>Failed TC</th>	<th>Passed %</th>    <th>Failed %</th>	<th>Functional Failure</th><th>Other Failures</th>	<th>CSS_Issues</th>  </tr><tr>  <td>' +
      total_testCases +
      '</td> <td>' +
      (total_testCases - (P1_Failures + P2_Failures + P3_Failures)) +
      '</td> <td>' +
      (P1_Failures + P2_Failures + P3_Failures) +
      '</td>	<td>' +
      passed_Percentage +
      '</td> <td>' +
      (100 - passed_Percentage).toFixed(2) +
      '</td> <td>' +
      Functional_Issues +
      '</td>	<td>' +
      (Script_Issues + BrokenLink_Issues + Other_Issues + TestDataAPI_Issues) +
      '</td> <td>' +
      CSS_Issues +
      '</td> </tr></table>';

    // For report summary in email
    console.log('reportSummary : ', reportSummary);
    fs.writeFileSync('test/bddcode/customFeature/reportSummary.txt', reportSummary, function(err) {
      if (err) throw err;
      console.log('reportSummary : ', reportSummary);
      res.send('done');
    });

    let priorityCSVData =
      '{' +
      '"Date"' +
      ':' +
      '"' +
      currentTime +
      '"' +
      ',\n' +
      '"Browser"' +
      ':' +
      '"' +
      browserName +
      '"' +
      ',\n' +
      '"Plateform"' +
      ':' +
      plateform +
      ',\n' +
      '"Total_Scenarios"' +
      ':' +
      total_testCases +
      ',\n' +
      '"Passed_Percentage"' +
      ':' +
      passed_Percentage +
      ',\n' +
      '"Failed_Percentage"' +
      ':' +
      (100 - passed_Percentage).toFixed(2) +
      ',\n' +
      '"P1_Failures"' +
      ':' +
      P1_Failures +
      ',\n' +
      '"P2_Failures"' +
      ':' +
      P2_Failures +
      ',\n' +
      '"P3_Failures"' +
      ':' +
      P3_Failures +
      ',\n' +
      '"CSS_Issues"' +
      ':' +
      CSS_Issues +
      ',\n' +
      '"Other_Issues"' +
      ':' +
      (Script_Issues + BrokenLink_Issues + Other_Issues + TestDataAPI_Issues) +
      ',\n' +
      '"Functional_Issues"' +
      ':' +
      Functional_Issues +
      '}';

    fs.writeFileSync('test/newReport/json/priorityBasisFailureReport_' + timeVar + '.json', priorityCSVData, function(err) {
      if (err) throw err;
      console.log('priorityCSVData : ', priorityCSVData);
      res.send('done');
    });
  };

  exports.readJSONReport = readJSONReport;
} catch (err) {
  console.log('readJSONReport.js file');
  console.log(err);
}

readJSONReport();
