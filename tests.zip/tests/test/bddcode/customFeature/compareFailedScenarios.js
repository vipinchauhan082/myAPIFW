try {
  const fsexe = require('fs-extra');
  let jpath = require('jsonpath');
  const fs = require('fs');

  var readJSONReport1 = function readJSONReport1() {
    var scenariosArr = [];
    var scenariosArr2 = [];
    let csvData = 'Tags, Scenario Name, First Step, Error Message, Failure Type, QA Owner, History' + '\n';

    const reportFolder = '../test/reports/';
    const histFolder = '../../tests/lastRegressionResult/';

    file = 'report.csv';
    let csvFile = reportFolder + file;
    var newFileData = fsexe.readFileSync(csvFile, 'utf8');
    scenariosArr = newFileData.split('\n');

    file = 'report.csv';
    let csvFile2 = histFolder + file;
    if (!fs.existsSync(csvFile2)) {
      console.log('History file does not exists, No comparision will be done');
      fs.copyFile(csvFile, csvFile2, err => {
        if (err) throw err;
        console.log('History file created');
      });
      return;
    }
    var newFileData2 = fsexe.readFileSync(csvFile2, 'utf8');

    let row = '';
    for (var i = 1; i < scenariosArr.length; i++) {
      let row = scenariosArr[i].replace(/(\r\n|\n|\r)/gm, ''); //remove all types of line break

      if (newFileData2.includes(scenariosArr[i])) {
        csvData = csvData + row + ',Old Failure' + '\n';
      } else {
        csvData = csvData + row + ',New Failure' + '\n';
      }
    }

    fs.writeFileSync('reports/newReport.csv', csvData, function(err) {
      if (err) throw err;
      console.log('csvData : ', csvData);
      res.send('done');
    });
    fs.copyFile(csvFile, csvFile2, err => {
      if (err) throw err;
      console.log('Execution replrt copied to tests/lastRegressionResult location');
    });
  };

  exports.readJSONReport1 = readJSONReport1;
} catch (err) {
  console.log('readJSONReport1.js file');
  console.log(err);
}

readJSONReport1();
