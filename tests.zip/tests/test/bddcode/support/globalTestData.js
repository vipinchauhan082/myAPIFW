var globalTestData = function() {
  this.testData = {
    recipeResponse: '',
    accessibilityFile: '',
    scenariosData: '',
    locatorList: '',
    Test_Data: '',
    locatorList: '',
    commentMessage: '',
    commenterName: '',
    url: '',
    elementText: '',
  };
  this.setField = function(field, value) {
    this.testData[field] = value;
  };

  this.getField = function(field) {
    return this.testData[field];
  };
};
module.exports = new globalTestData();
