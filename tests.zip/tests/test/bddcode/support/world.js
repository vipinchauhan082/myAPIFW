try {
  const yaml = require('js-yaml');
  const fs = require('fs-extra');
  const mergeYaml = require('merge-yaml');
  const userData = require('../support/globalTestData');

  var World = function World() {
    const devicename = global.browser.desiredCapabilities.browserName;
    process.env.BROWSERNAME = devicename;

    if (process.env.ENVIRONMENT_VAR == null) {
      process.env.ENVIRONMENT_VAR = global.browser.options.serverUrls.environment;
      process.env.ENVIRONMENT_API_VAR = global.browser.options.serverUrls.environment + '-api';
    } else {
      process.env.ENVIRONMENT_API_VAR = process.env.ENVIRONMENT_VAR + '-api';
    }

    if (process.env.RELEASE == null) {
      process.env.RELEASE = global.browser.options.serverUrls.release;
    }

    if (process.env.VERSION == null) {
      process.env.VERSION = global.browser.options.serverUrls.version;
    }

    if (process.env.BUILD_VAR == null) {
      process.env.BUILD_VAR = global.browser.options.serverUrls.buildid;
    }

    if (process.env.LANGUAGE == null) {
      process.env.LANGUAGE = global.browser.options.serverUrls.language;
    }

    if (process.env.MARKET == null) {
      process.env.MARKET = global.browser.options.serverUrls.market;
    }

    if (process.env.ACCESSIBILITY == null) {
      process.env.ACCESSIBILITY = global.browser.options.serverUrls.accessibilityFlag;
    }

    let DeviceViewType = global.browser.desiredCapabilities['goog:chromeOptions'];
    let DeviceViewTypeText = JSON.stringify(DeviceViewType.mobileEmulation);
    console.log('DeviceViewTypeText', DeviceViewTypeText);
    if (typeof DeviceViewTypeText != 'undefined' && DeviceViewTypeText != null) {
      if (DeviceViewTypeText.includes('deviceName')) {
        process.env.DEVICEVIEW_TYPE = 'mobile';
      } else {
        process.env.DEVICEVIEW_TYPE = 'desktop';
      }
    } else {
      process.env.DEVICEVIEW_TYPE = 'desktop';
    }

    // else{
    //   process.env.DEVICEVIEW_TYPE="desktop";
    // }

    process.env.BROWSERNAME = global.browser.desiredCapabilities.browserName;
    console.log('Browser to be Launched is :', process.env.BROWSERNAME);

    let yamlFile = [];
    let pageelementlocatorfiles = fs.readdirSync('test/locator/');
    for (let pages = 0; pages < pageelementlocatorfiles.length; pages++) {
      yamlFile[pages] = 'test/locator/' + pageelementlocatorfiles[pages];
    }
    userData.setField('locatorList', mergeYaml(yamlFile));

    // let test_Data = '';
    // if (process.env.ENVIRONMENT_VAR.includes('dev')) {
    //   test_Data = yaml.load(fs.readFileSync('test/testdata/dev_Test_Data.yml'));
    // } else if (process.env.ENVIRONMENT_VAR.includes('qa')) {
    //   test_Data = yaml.load(fs.readFileSync('test/testdata/qa_Test_Data.yml'));
    // } else if (process.env.ENVIRONMENT_VAR.includes('feature')) {
    //   test_Data = yaml.load(fs.readFileSync('test/testdata/feature_Test_Data.yml'));
    // }
    // userData.setField('', test_Data);
    // console.log('Test Data Value', userData.getField('Test_Data'));
  };

  exports.World = World;
} catch (err) {
  console.log('world.conf file');
  console.log(err);
}

World();
