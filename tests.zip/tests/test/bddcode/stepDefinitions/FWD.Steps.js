var { Given, When, Then } = require('cucumber');
import generic from '../functions/genericFunctions';
let userData = require('../support/globalTestData');
const fs = require('fs');
var elementInteger;
var elementText;
var href_RC;
var Notificationcount;
var plan = new Map();
let APIStatusCode;

try {
  Then(/^I calculate the "([^"]*)"$/, function(selector) {
    generic.waitForElemReady(selector);
    var elementList = $$(generic.getXpath(selector));
    Notificationcount = elementList.length;
  });

  Then(/^I should see total count less than "([^"]*)"$/, function(selector) {
    generic.waitForElemReady(selector);
    var elementList = $$(generic.getXpath(selector));
    let New_Notificationcount = elementList.length;
    assert.isTrue(
      New_Notificationcount < Notificationcount,
      'new count is ' + New_Notificationcount + ' and old count is ' + Notificationcount
    );
  });

  Then(/^I validate correct number of cards are loaded when "([^"]*)" is clicked for "([^"]*)" "([^"]*)"/, function(
    seeMore,
    cardVariant,
    wrapper
  ) {
    let seeMoreCount = 1;
    let xpathVal = generic.getXpath(wrapper);
    let cardCount = $$(xpathVal).length;
    let prevCount = $$(xpathVal).length;

    while (browser.element(generic.getXpath(seeMore)).isExisting()) {
      seeMoreCount = seeMoreCount + 1;
      generic.getSelector(seeMore).click();
      const newCardCount = $$(xpathVal).length;

      if (browser.element(generic.getXpath(seeMore)).isExisting()) {
        assert.isTrue(newCardCount >= prevCount, 'correct card count is not displayed');
      } else assert.isTrue(newCardCount <= cardCount * seeMoreCount, 'correct card count');

      prevCount = newCardCount;
    }
  });

  Then(
    /^I should get "([^"]*)", "([^"]*)", "([^"]*)" for "([^"]*)" and validate "([^"]*)", "([^"]*)" and "([^"]*)" are same/,
    function(image, name, designation, wrapper, modalImage, modalCardName, modalCardDesignation) {
      let xpathVal = generic.getXpath(wrapper);
      let cardCount = $$(xpathVal).length;
      if (cardCount >= 1) {
        for (let j = 1; j <= cardCount; j++) {
          let cardImage = browser.getAttribute(generic.getXpath(image) + '[' + j + ']', 'data-src');
          let cardName = browser.element(generic.getXpath(name) + '[' + j + ']').getText();
          let cardDesignation = browser.element(generic.getXpath(designation) + '[' + j + ']').getText();

          browser.element(generic.getXpath(name) + '[' + j + ']').click();
          browser.pause(1000);
          let modalImg = browser.getAttribute(generic.getXpath(modalImage), 'data-src');
          assert.include(modalImg, cardImage, 'Image is incorrect');
          assert(generic.getSelector(modalCardName).getText() === cardName, 'Expected text does not match');
          assert(
            generic.getSelector(modalCardDesignation).getText() === cardDesignation,
            'Expected text and actual text does not match'
          );

          browser.element(generic.getXpath('ManagementTeam Modal CloseBtn')).click();
          browser.pause(1000);
        }
      } else assert.isTrue(cardCount < 1, 'No clickable cards');
    }
  );

  Then(/^I should validate clickable "([^"]*)" count "([^"]*)" is same as displayed in "([^"]*)"$/, function(
    cardImage,
    wrapper,
    modalWrapper
  ) {
    let xpathVal = generic.getXpath(wrapper);
    let globalCardCount = $$(xpathVal).length;

    if (globalCardCount > 0) {
      browser.element(generic.getXpath(cardImage)).click();
      let xpathVal = generic.getXpath(modalWrapper);
      assert($$(xpathVal).length === globalCardCount, 'Expected count and actual count does not match');
    }

    browser.pause(1000);
    browser.element(generic.getXpath('ManagementTeam Modal CloseBtn')).click();
    browser.pause(1000);
  });

  Then(/^I validate CheckBox count of \"(.*)\" items and it should be same as CardList$/, function(selector) {
    let xpathVal = generic.getXpath(selector);
    let checkBoxCount = $$(xpathVal).length;
    assert.isTrue(checkBoxCount > 0, 'Expected Checkbox Count and actual Rider Card count does not match');
  });

  Then(/^I validate count of \"(.*)\" item$/, function(selector) {
    let xpathVal = generic.getXpath(selector);
    let checkBoxCount = $$(xpathVal).length;
    assert.isTrue(checkBoxCount > 0, `Expected ${selector} Count to be greater than 0`);
  });

  Then(/^I validate social share link opens with "([^"]*)" desktop url$/, function(value) {
    let url = browser.getUrl();
    let valuePssed;

    switch (value) {
      case 'Facebook':
        valuePssed = 'facebook.com';
        break;
      case 'Twitter':
        valuePssed = 'https://twitter.com';
        break;
      case 'Line':
        valuePssed = 'https://access.line.me';
        break;
    }
    assert.isTrue(url.includes(valuePssed));
  });

  Then(/^I validate social share link opens with "([^"]*)" mobile url$/, function(value) {
    let url = browser.getUrl();
    let valuePssed;
    switch (value) {
      case 'Facebook':
        valuePssed = 'https://m.facebook.com';
        break;
      case 'Twitter':
        valuePssed = 'https://twitter.com';
        break;
    }
    assert.isTrue(url.includes(valuePssed));
  });

  Then(/^I send "(.*)\" request with "(.*)\" province and "(.*)\" facilitytype and "(.*)\" facets$/, function(
    url,
    province,
    facilitytype,
    facets
  ) {
    //let url = 'https://dev-api.fwdxt.com/search/en/GetServiceLocationList';

    let postData = generic.getPayloads(url);
    postData = postData.replace('{province}', province);
    postData = postData.replace('{facilitytype}', facilitytype);
    postData = postData.replace('{facets}', facets);
    generic.postAPICall(generic.getAPIURL(url), postData);
    //generic.postAPICall(url, postData);
  });

  Then(/^I send "(.*)\" request with "(.*)\" province and "(.*)\" primaryFilters$/, function(url, province, primaryFilters) {
    //let url = 'https://dev-api.fwdxt.com/search/en/GetServiceLocationList';

    let postData = generic.getPayloads(url);
    postData = postData.replace('{province}', province);
    postData = postData.replace('{primaryFilters}', primaryFilters);
    const responseD = generic.postAPICall(generic.getAPIURL(url), postData);
    let respData = JSON.parse(responseD.body);
    APIStatusCode = respData.statusCode;
  });

  Then(/^I send request "(.*)\" with "(.*)\" province and "(.*)\" facilitytype and "(.*)\" facets$/, function(
    apiName,
    province,
    facilitytype,
    facets
  ) {
    let url = 'https://dev-api.fwdxt.com/search/en/GetServiceLocationList';

    let postData = generic.getPayloads(apiName);

    postData = postData.replace('{province}', province);
    postData = postData.replace('{facilitytype}', facilitytype);
    postData = postData.replace('{facets}', facets);
    generic.postAPICall(url, postData);
  });

  Given(/^I open splash screen "([^"]*)"$/, function(url) {
    generic.openUrl(url);
    browser.execute(function() {
      localStorage.clear();
      localStorage.setItem('hideNotification', true);
      localStorage.setItem('hideSplash', false);
    });
    browser.refresh();
    browser.pause(1000);
  });

  Given(/^I set "([^"]*)" as "([^"]*)"$/, function(key, value) {
    browser.execute(function() {
      localStorage.setItem('hideNotification', false);
    });
    browser.refresh();
    browser.pause(4000);
  });

  Then(/^I switch on iframe validate "(.*)" exists$/, function(selector) {
    browser.frame(0);
    browser.pause(2000);
    browser.element(generic.getXpath(selector)).click;
  });

  Then(/^I should see "(.*)" and "(.*)" exist on iframe$/, function(selector1, selector2) {
    browser.frame(0);
    browser.pause(2000);
    assert(browser.element(generic.getXpath(selector1)).isExisting() == true, selector1 + 'not exist');
    assert(browser.element(generic.getXpath(selector2)).isExisting() == true, selector2 + 'not exist');
  });

  When(/^I validate the "(.*)" flow of the page$/, function(flowName) {
    assert.isTrue(flowName.includes(userData.getField('elementText')), flowName + 'flow doesnot contain right Title');
  });

  When(/^I click on "([^"]*)" and verify that PDP page opens for that "(.*)"$/, function(allLinks, selector1) {
    var titleList = generic.getXpath(allLinks);

    const href_links = $$(titleList);
    // Need to add list>0 and Try catch Logic console.log('Title List is : ', href_links);
    href_links.forEach(element => {
      href_RC = element.getAttribute('href');
      //console.log('Href fron loop is : ', href_RC);
    });
    var titleHeader = $$(generic.getXpath(selector1));
    for (let i = 0; i < titleHeader.length; i++) {
      var titleHeaderFirst = titleHeader[i].getText().split(/(\s+)/);
      assert.isTrue(
        href_links[i]
          .getAttribute('href')
          .toLowerCase()
          .includes(titleHeaderFirst[0].toLowerCase()),
        'Expected result at ' + i + ' is' + href_links[i].getAttribute('href')
      );
    }
  });

  When(/^I validate the "(.*)" in "(.*)" most element on search$/, function(value, selector) {
    var topElement = generic
      .getSelector(selector)
      .getText()
      .toLowerCase();

    if (topElement.length > 0 && value.length > 0) {
      try {
        let localstrPrint = window.localStorage.getItem('searchHistoryFWD');
        console.log(
          'value of top element is :' + topElement + 'Value Passed from UI :- ' + value,
          'Local Storage is ' + localstrPrint
        );
      } catch (oError) {
        console.log(oError);
      }
      assert.isTrue(topElement == value.toLowerCase(), 'Top' + value.toLowerCase() + 'is not present');
      console.log('Found Match at the top' + topElement);
    } else assert.isNull(topElement, 'TopSearch value' + value.toLowerCase() + 'is not present or an Empty String');
  });

  Then(/^I should see Carousel "([^"]*)" of length "([^"]*)" with "([^"]*)" exist|existed/, function(
    selector1,
    CardCount,
    selector2
  ) {
    generic.waitForElemReady(selector1);
    let xpathVal = generic.getXpath(selector1);
    var cnt = $$(xpathVal).length;
    if (cnt > CardCount) {
      // Arrow existance check
      assert(generic.getSelector(selector2).isExisting() === true, selector2 + 'not exist');
    }
  });

  When(/^I validate computed css properties for "(.*)\"$/, function(selector) {
    generic.waitForElemReady(selector);
    let Property = '';
    let cssProperties = generic.getCSSProperties(selector).split('|');
    let xVal = generic.getXpath(selector);
    xVal = xVal.replace('//*', '').replace('@', '');
    for (let item = 0; item < cssProperties.length; item++) {
      Property = cssProperties[item].split(':');
      let actualValue = browser.execute(
        function(xVal, Property) {
          window.scrollBy(0, 1500);
          let para = document.querySelector(xVal);
          return window.getComputedStyle(para)[Property[0]];
          //return getComputedStyle(document.querySelector(xVal))['position'];
        },
        xVal,
        Property
      );
      if (selector.includes('mage') && (Property[0] == 'height' || Property[0] == 'width')) {
        let expectedVal = parseInt(Property[1].replace('px', ''));
        let actualVal = Number(actualValue.value.replace('px', ''));
        assert.isTrue(
          expectedVal + 3 > actualVal && expectedVal - 3 < actualVal,
          'CSS property of "' +
            generic.getXpath(selector) +
            '" does not match. Expected is ' +
            Property[1] +
            ' but actual is ' +
            actualValue.value
        );
      } else {
        assert.include(
          JSON.stringify(actualValue.value).toLowerCase(),
          Property[1].trim().toLowerCase(),
          'CSS property of "' + generic.getXpath(selector) + '" does not match'
        );
      }
    }
  });

  // Validate given text against content speficied in Cucumber.
  Then(/^I validate text "(.*)" should not be empty and match with UI (.*) at index (.*)$/, function(
    selector,
    stringtobeMatched,
    index
  ) {
    var selector = generic.getXpath(selector);
    selector = selector.replace('#replace#', index);
    if (browser.element(selector).isVisible()) {
      let elementText = browser
        .element(selector)
        .getText()
        .toLowerCase();
      stringtobeMatched = stringtobeMatched.replace(/"/g, '');
      console.log('FF is ' + stringtobeMatched.toLowerCase().trim() + 'UI is ' + elementText.toLowerCase().trim());
      assert.isTrue(elementText.length >= 0, 'element does not contain any text');
      //assert.isTrue(.includes(), ');
      assert.deepEqual(
        stringtobeMatched.toLowerCase().trim(),
        elementText.toLowerCase().trim(),
        'UI text is different than Passed from FF'
      );
    } else {
      assert.isTrue('Element is not visible');
    }
  });

  // Convert a String into Integer.
  Then(/^I convert String "(.*)" to Integer Value$/, function(selector) {
    if (generic.getSelector(selector).isVisible()) {
      //changing it to global var to access it across steps
      elementText = generic.getSelector(selector).getText();
      if (!Number.isInteger(elementText)) {
        elementInteger = parseInt(elementText);
        console.log('Integer fetched from UI is :' + elementInteger);
      }
      //assert.isTrue(elementText.length >= 0, 'element does not contain any text');
    }
  });

  Then(/^I click on "([^"]*)" and "([^"]*)" validate no click Action/, function(selector1, selector2) {
    var url = browser.getUrl();
    generic.waitForElemReady(selector1);
    generic.getSelector(selector1).click();
    var newUrl = browser.getUrl();
    assert.isTrue(url.includes(newUrl));
    assert(browser.element(generic.getXpath(selector2)).isExisting() !== true, selector2 + 'still exist');
  });

  Then(/^I validate login links "([^"]*)" are available and navigate to different tab/, function(link) {
    browser.moveToObject(generic.getXpath('Header Login'));
    browser.pause(2000);
    assert(generic.getSelector('Header LoginPopper').isExisting() === true, 'Header LoginPopper' + 'Not exist');
    let xpathVal = generic.getXpath(link);
    var cnt = $$(xpathVal).length;
    for (let i = 1; i <= cnt; i++) {
      browser.pause(2000);
      let text_href = browser.getAttribute(generic.getXpath(link) + '[' + i + ']', 'href');
      browser.element(generic.getXpath(link) + '[' + i + ']').click();
      var TabID = browser.getTabIds();
      browser.switchTab(TabID[i]);
      var urlfull = browser.getUrl().toLowerCase();
      assert.isTrue(
        urlfull.includes(text_href),
        'URL of ' + generic.getXpath(link) + ' element is ' + urlfull + ' but it does not contains ' + link
      );
      browser.switchTab(TabID[0]);
      browser.moveToObject(generic.getXpath('Header Login'));
      browser.pause(2000);
    }
  });

  Then(/^I should validate the url with the selected value selected$/, function() {
    // generic.selectItemFromDropdownByIndex('Header LanguageSwitcherText', 1);
    browser.pause(1000);
    if (browser.element(generic.getXpath('Header LanguageDialogContainer')).isExisting()) {
      assert.log('Selected value page is not configured');
    } else {
      var langSwitcherText = generic
        .getSelector('Header LanguageSwitcherText')
        .getText()
        .toLowerCase();
      var urlfull = browser.getUrl().toLowerCase();
      assert.isTrue(urlfull.includes(langSwitcherText), 'URL does not contains ' + langSwitcherText);
    }
  });

  Then(/^I click "([^"]*)" "([^"]*)"$/, function(i, card) {
    browser.element(generic.getXpath(card) + '[' + i + ']').click();
  });

  Then(/^I should validate "([^"]*)" "([^"]*)" is checked for "([^"]*)" "([^"]*)" in "([^"]*)"$/, function(
    label,
    checkbox,
    i,
    name,
    wrapper
  ) {
    let count = generic.getXpath(wrapper);
    var cnt = $$(count).length;
    for (let j = 1; j <= cnt; j++) {
      if (
        browser
          .element(generic.getXpath(label) + '[' + j + ']')
          .getText()
          .toLowerCase() === plan.get(name + i)
      )
        break;
      assert(
        browser.getAttribute(generic.getXpath(checkbox) + '[' + j + ']', 'checked') === 'true',
        'Expected checkbox is not checked'
      );
    }
  });

  Then(/^I should click "([^"]*)" in "([^"]*)" which is "([^"]*)"$/, function(checkbox, wrapper, string) {
    let count = generic.getXpath(wrapper);
    var cnt = $$(count).length;
    for (let j = 1; j <= cnt; j++) {
      switch (string) {
        case 'checked':
          if (browser.getAttribute(generic.getXpath(checkbox) + '[' + j + ']', 'checked') === 'true') {
            browser.element(generic.getXpath(checkbox) + '[' + j + ']').click();
          }
          break;
        case 'unchecked':
          if (browser.getAttribute(generic.getXpath(checkbox) + '[' + j + ']', 'checked') === 'false') {
            browser.element(generic.getXpath(checkbox) + '[' + j + ']').click();
          }
          break;
      }
    }
  });

  Then(/^I should see "([^"]*)" "([^"]*)" is not checked$/, function(i, selector) {
    assert(
      browser.getAttribute(generic.getXpath(selector) + '[' + i + ']', 'checked') !== 'true',
      'Expected checkbox is checked'
    );
  });

  Then(/^I retrieve "([^"]*)" for "([^"]*)" card$/, function(label, i) {
    let value = browser
      .element(generic.getXpath(label) + '[' + i + ']')
      .getText()
      .toLowerCase();
    plan.set(label + i, value);
  });

  Then(/^I validate "([^"]*)" "([^"]*)" with "([^"]*)","([^"]*)" card$/, function(i, fieldname, j, name) {
    let fieldValue = browser
      .element(generic.getXpath(name) + '[' + j + ']')
      .getText()
      .toLowerCase();
    assert.strictEqual(fieldValue, plan.get(fieldname + i), 'Element Value is not correct');
  });

  Then(/^I validate status of MapApi to be "([^"]*)"$/, function(statusCode) {
    browser.pause(2000);
    assert.isTrue(
      parseInt(APIStatusCode) === parseInt(statusCode),
      'Expected status code ' + statusCode + ' to be ' + APIStatusCode
    );
  });
} catch (err) {
  console.log('FWD.Steps.js file');
  console.log(err);
}
