var { Given, When, Then } = require('cucumber');
import generic from '../functions/genericFunctions';
let userData = require('../../bddcode/support/globalTestData');
const fs = require('fs');
let screenReportFile = process.env.REP_VAR + '_screenReport.json';

try {
  When(/^I compare all urls$/, function() {
    let baseurlName = generic.getValueforEnv(process.env.ENVIRONMENT_VAR);
    baseurlName = baseurlName + '/' + process.env.LANGUAGE;
    var text = fs.readFileSync('./test/screenshots/urls.txt').toString('utf-8');
    var textByLine = text.split('\n');

    textByLine.forEach(launchURL);

    function launchURL(urlName, index) {
      let url = urlName.split(': ');
      process.env.PAGENAME = url[0];
      let pageURL = baseurlName + url[1].trim();
      browser.url(pageURL);
      browser.execute(function() {
        localStorage.setItem('hideSplash', true);
        localStorage.setItem('cookieBannerRead', true);
        localStorage.setItem('hideNotification', true);
      });
      browser.refresh();
      browser.pause(5000);
      let results = browser.checkDocument();
      let FileString = ', "Page_URL" : "' + pageURL + '"';
      FileString = FileString + ', "Status" : ' + JSON.stringify(results) + '}';
      fs.appendFileSync('./test/screenshots/visual-results/' + screenReportFile, FileString);
      // results.forEach((result) => assert.isTrue(result.isExactSameImage, `${index} visual regression`));
    }
  });

  When(/^I compare screenshot for "([^"]*)"$/, function(pageName) {
    let results = browser.checkDocument();
    let FileString = ', "Page_URL" : "' + userData.getField('url') + '"';
    FileString = FileString + ', "Status" : ' + JSON.stringify(results) + '}';
    fs.appendFileSync('./test/screenshots/visual-results/' + screenReportFile, FileString);

    //results.forEach((result) => assert.isTrue(result.isExactSameImage, `${pageName} visual regression`));
  });

  When(/^I compare "([^"]*)" element screenshot on "([^"]*)"$/, function(selector, pageName) {
    let xpath = generic.getXpath(selector);
    let results = browser.checkElement(xpath);
    let FileString = ', "Page_URL" : "' + userData.getField('url') + '"';
    FileString = FileString + ', "Status" : ' + JSON.stringify(results) + '}';

    fs.appendFileSync('./test/screenshots/visual-results/' + screenReportFile, FileString);
    //results.forEach((result) => assert.isTrue(result.isExactSameImage, `${selector} visual regression`));
  });
} catch (err) {
  console.log('screenCompare.js file');
  console.log(err);
}
