var { Given, When, Then } = require('cucumber');
import generic from '../functions/genericFunctions';
let userData = require('../support/globalTestData');
const fs = require('fs');
let jpath = require('jsonpath');
let cardCount = 0;
var cardText;
var globalCardCount = 0;
var Notificationcount;
let APIStatusCode;

try {
  Given(/^I send request "(.*)\" for "([^"]*)" market should give "([^"]*)"$/, function(apiname, market, status) {
    let postData = generic.getPayloads(`${process.env.ENVIRONMENT_VAR}Static${apiname}`);
    postData = postData.replace('#ENVIRONMENT#', process.env.ENVIRONMENT_VAR);
    postData = postData.replace('#MARKET#', market.toLowerCase());
    postData = postData.replace('#RELEASE#', process.env.RELEASE);
    const headers = { entity: market };
    const dataTest = generic.postAPICall(generic.generateAPIURL({ apiname, market }), postData, headers);
    const statusCode = dataTest.statusCode;
    assert.isTrue(statusCode.toString() === status, `API ${apiname} is giving ${statusCode}`);
  });

  Given(/^I send request "(.*)\" for "([^"]*)" and "([^"]*)" market$/, function(apiname, language, market) {
    const postData = generic.getPayloads(`${process.env.ENVIRONMENT_VAR}Static${apiname}`);
    const headers = { 'Location-Type': `fwd-${market.toLowerCase()}` };
    const dataTest = JSON.parse(
      generic.postAPICall(generic.generateAPIURL({ apiname, language, market }), postData, headers).body
    );
    console.log('errorMessage = ', dataTest.errorMessage);
    APIStatusCode = dataTest.statusCode ? dataTest.statusCode : dataTest.StatusCode;
    assert.isTrue(dataTest.errorMessage === null, `API ${apiname} is giving error message ${dataTest.errorMessage}`);
  });

  Given(/^"(.*)\" should give "([^"]*)"$/, function(apiname, status) {
    assert.isTrue(APIStatusCode.toString() === status, `API ${apiname} is giving ${APIStatusCode}`);
  });

  When(
    /^I send request "(.*)\" with body attributes "(.*)\" as "(.*)\" and "(.*)\" as "(.*)\" and "(.*)\" as "(.*)\" and "(.*)\" as "(.*)\"$/,
    function(apiname, key1, value1, key2, value2, key3, value3, key4, value4) {
      //var url = generic.getValueforEnv(apiname);
      var postData = generic.getPayloads('FourAttributesBody');
      postData = postData.replace('Key1', key1);
      postData = postData.replace('Value1', value1);
      postData = postData.replace('Key2', key2);
      postData = postData.replace('Value2', value2);
      postData = postData.replace('Key3', key3);
      postData = postData.replace('Value3', value3);
      postData = postData.replace('Key4', key4);
      postData = postData.replace('Value4', value4);
      generic.postAPICall(generic.getAPIURL(apiname), postData);
    }
  );

  // get all the featured tags from get article list
  When(
    /^I send request "(.*)\" from SearchApi using "(.*)\" as ContentType "(.*)\" as SortBy and "(.*)\" as ContentSubType$/,
    function(url, contentType, sortBy, contentSubType) {
      var postData = generic.getPayloads('DynamicTagsList');
      postData = postData.replace('{ContentTypeValue}', contentType);
      postData = postData.replace('{DateValue}', sortBy);
      postData = postData.replace('{ContentSubTypeValue}', contentSubType);
      generic.postAPICall(generic.getAPIURL(url), postData);
    }
  );

  Then(
    /^I send request "(.*)\" from SearchApi using "(.*)\" as SearchText and "([^"]*)" as ContentType and "(.*)\" as PageSize and "(.*)\" as PageNumber$/,
    function(url, searchText, contentTypes, pageSize, pageNumber) {
      //url = 'https://dev-api.fwdxt.com/search/en/' + url;
      var postData = generic.getPayloads('GetSearchResults');
      postData = postData.replace('{SearchTextValue}', searchText);
      postData = postData.replace('{ContentTypeValue}', contentTypes);
      postData = postData.replace('{pageSizeValue}', pageSize);
      postData = postData.replace('{pageNumberValue}', pageNumber);
      generic.postAPICall(generic.getAPIURL(url), postData);
    }
  );

  Then(
    /^I send request "(.*)\" from file "(.*)\" using "(.*)\" as SearchText and "([^"]*)" as ContentType and "(.*)\" as PageSize and "(.*)\" as PageNumber and "([^"]*)" as filters$/,
    function(url, filename, searchText, contentTypes, pageSize, pageNumber, filters) {
      //var apiurl = generic.getValueforEnv('APIGetSearchResults');
      var postData;
      const fs = require('fs'); //imports node.js FileSystem
      var jsonFile = fs.readFileSync('./test/content/ServiceAPIRequestPayloads/' + filename + '.json'); //reads the file in synchronized way
      var jsonData = JSON.parse(jsonFile); //parses bits so it can be readable
      let filter;
      var filter1;
      var filter2;

      switch (contentTypes) {
        case 'Article':
          if (filters === '') {
            jsonData.filters = {
              filters,
            };
          } else {
            filter = filters.split(',');
            filter1 = generic.getSelector(filter[0]).getText();
            filter2 = generic.getSelector(filter[1]).getText();
            jsonData.filters.maincontentsubtypefield_s[0] = filter1;
            jsonData.filters.publishedyearfield_s[0] = filter2;
          }
          break;

        case 'Product':
          if (filters === '') {
            jsonData.filters = {
              filters,
            };
          } else {
            filter = filters.split(',');
            filter1 = generic.getSelector(filter[0]).getText();
            filter2 = filter[1];
            jsonData.filters.usertypefield_sm[0] = filter1;
            jsonData.filters.isbrochurefield_b[0] = filter2;
          }
          break;

        case 'Claim':
          if (filters === '') {
            jsonData.filters = {
              filters,
            };
          } else {
            filter = filters.split(',');
            filter1 = generic.getSelector(filter[0]).getText();
            filter2 = filter[1];
            jsonData.filters.primaryneedtagsfield_sm[0] = filter1;
            jsonData.filters.isformfield_b[0] = filter2;
          }
          break;

        case Default:
          jsonData.filters = {
            filters,
          };
          break;
      }
      postData = JSON.stringify(jsonData);
      generic.postAPICall(generic.getAPIURL(url), postData);
    }
  );

  Then(/^I validate recipe instruction data in SearchApi "(.*)\" to be equal to "(.*)\"$/, function(jsonData, selector) {
    var apiResponse = userData.getField('recipeResponse');
    var jsonValue = jpath.query(apiResponse, jsonData);
    generic.waitForElemReady(selector);
    let steps = $$(generic.getXpath(selector));
    for (let i = 0; i < jsonValue.length; i++) {
      assert.include(jsonValue[i], steps[i].getText(), 'Service data validation failed');
    }
  });

  Then(/^I validate Tags in SearchApi "(.*)\" to be equal to "(.*)\"$/, function(jsonData, selector) {
    var apiResponse = userData.getField('recipeResponse');
    var jsonValue = jpath.query(apiResponse, jsonData);
    generic.waitForElemReady(selector);
    let steps = $$(generic.getXpath(selector));
    var listOfTags = [];
    try {
      for (var i = 0; i < jsonValue.length; i++) {
        listOfTags.push(jsonValue[i].toLowerCase());
      }
      for (let i = 0; i < jsonValue.length; i++) {
        assert.include(listOfTags, steps[i].getText(), 'Tag is not available on page');
      }
    } catch (err) {
      console.log('Get Article List API does not have any Tags');
      console.log(err);
    }
  });

  Then(/^I validate recipe instruction steps time in SearchApi "(.*)\" to be equal to "(.*)\"$/, function(
    jsonData,
    selector
  ) {
    var apiResponse = userData.getField('recipeResponse');

    var jsonValue = jpath.query(apiResponse, jsonData);
    generic.waitForElemReady(selector);

    let steps = $$(generic.getXpath(selector));
    for (let i = 0; i < jsonValue.count; i++) {
      assert.include(jsonValue[i], steps[i].getText(), 'Steps is not available on page');
    }
  });

  Then(/^I validate in SearchApi "(.*)\" to be equal to "(.*)\"$/, function(jsonData, selector) {
    var apiResponse = userData.getField('recipeResponse');
    var arr;
    browser.pause(3000);
    generic.waitForElemReady(selector);
    if (jsonData.includes('.')) {
      arr = jsonData.split('.');
      for (var i = 0; i < arr.length; i++) {
        apiResponse = apiResponse[arr[i]];
      }
      browser.pause(3000);
      assert.include(generic.getSelector(selector).getText(), apiResponse.toString(), 'Client value matches with SearchApi');
    } else assert.include(generic.getSelector(selector).getText(), apiResponse[jsonData].toString(), 'Client value matches with SearchApi');
  });

  Then(/^I validate "(.*)\" to be equal to "(.*)\" in SearchApi/, function(jsonData, selector) {
    var apiResponse = userData.getField('recipeResponse');
    var jsonValue = jpath.query(apiResponse, jsonData);
    browser.pause(3000);
    generic.waitForElemReady(selector);
    let xpathval = generic.getXpath(selector);
    let steps = $$(xpathval);
    for (let i = 0; i < jsonValue.length; i++)
      assert.include(
        steps[i].getText().replace(/\s/g, ''),
        jsonValue[i].toString().replace(/\s/g, ''),
        'SearchApi data matches with client'
      );
  });

  Then(/^I validate number of search results in SearchApi "(.*)\" to be included in "(.*)\"$/, function(jsonData, selector) {
    var apiResponse = userData.getField('recipeResponse');
    var jsonValue = jpath.query(apiResponse, jsonData);
    console.log(
      'Data fetched from API is : ' +
        jsonValue +
        '\n' +
        'Data fetched from UI is :' +
        generic.getSelector(selector).getText()
    );
    generic.waitForElemReady(selector);
    for (let i = 0; i < jsonValue.length; i++) {
      assert.include(
        generic.getSelector(selector).getText(),
        jsonValue[i].toString(),
        'Search results count does not match'
      );
    }
  });

  Then(/^I validate contentTypes of search results in SearchApi "(.*)\" to be equal to "(.*)\"$/, function(
    jsonData,
    selector
  ) {
    var apiResponse = userData.getField('recipeResponse');
    var jsonValue = jpath.query(apiResponse, jsonData);
    generic.waitForElemReady(selector);
    let steps = $$(generic.getXpath(selector));
    if (steps.length > 0) {
      for (let i = 0; i < steps.length; i++) {
        assert.isTrue(steps[i].getText().toLowerCase() == jsonValue[i].toLowerCase());
      }
    } else {
      assert.isTrue(steps.length == jsonValue.length);
    }
  });

  Then(/^I validate number of search cards in SearchApi "(.*)\" to be equal to "(.*)\"$/, function(jsonData, selector) {
    var apiResponse = userData.getField('recipeResponse');
    var jsonValue = jpath.query(apiResponse, jsonData);
    generic.waitForElemReady(selector);
    let steps = $$(generic.getXpath(selector));
    assert.isTrue(
      steps.length == jsonValue.length,
      'Expected Search count ' + steps.length + ' and json count ' + jsonValue.length
    );
  });

  Then(/^I validate number of search results in SearchApi "(.*)\" should be "(.*)\"$/, function(jsonData, number) {
    var apiResponse = userData.getField('recipeResponse');
    var jsonValue = jpath.query(apiResponse, jsonData);
    assert.isTrue(number == jsonValue, 'Expected Search count ' + number + ' and json count ' + jsonValue);
  });

  Then(/^I validate number of search cards in SearchApi "(.*)\" to be greater then "(.*)\"$/, function(
    jsonData,
    expectedCount
  ) {
    var apiResponse = userData.getField('recipeResponse');
    var jsonValue = jpath.query(apiResponse, jsonData);
    assert.isTrue(
      expectedCount == jsonValue.length,
      'Expected Search count ' + expectedCount + ' and json count ' + jsonValue.length
    );
  });

  When(/^I search using "(.*)\" as primarytag and using "(.*)\" as secondary tag$/, function(ptag, scndrytag) {
    var postData = generic.getPayloads('ProductPayLoad');
    var ptag = generic.getAttributeTextValue(ptag);
    var scndrytag = generic.getAttributeTextValue(scndrytag);
    //var sectags = stags.split(',');
    //var stagval = [generic.getAttributeTextValue(sectags[0]), generic.getAttributeTextValue(sectags[1])];
    //sectags = stagval.join("','");
    var postData = postData.replace('{PrimaryTags}', ptag);
    var postData = postData.replace('{SecondaryTags}', scndrytag);
    //var postData = postData.replace('{SecondaryTags}', sectags);
    generic.postAPICall(generic.getAPIURL('APIGetProductList'), postData);
  });

  When(/^I see service "(.*)\" is up and running for "(.*)\"$/, function(serviceName, apppageName) {
    generic.getCMSService(apppageName);
  });

  Then(/^I validate manual override for component "(.*)\" for "(.*)\"$/, function(jsonData, selector) {
    var apiResponse = userData.getField('recipeResponse');
    // console.log('apiResponse:' + JSON.stringify(apiResponse));
    var jsonValue = jpath.query(apiResponse, jsonData);
    //console.log('jsonValue:' + jsonValue);
    //console.log('jsonValue length:' + jsonValue.length);
    //console.log('jsonValue:' + JSON.stringify(jsonValue));
    generic.waitForElemReady(selector);
    let steps = $$(generic.getXpath(selector));
    for (let i = 0; i < jsonValue.length; i++) {
      //console.log(steps[i].getText());
      //console.log(JSON.stringify(jsonValue[i]));
      //console.log(jsonValue[i]);
      assert.include(steps[i].getText(), jsonValue[i], 'Service data validation failed');
    }
  });

  Then(/^I validate data in response "(.*)\" to be equal to "(.*)\"$/, function(jsonData, selector) {
    var apiResponse = userData.getField('recipeResponse');
    var jsonValue = jpath.query(apiResponse, jsonData);
    generic.waitForElemReady(selector);
    let steps = $$(generic.getXpath(selector));
    for (let i = 0; i < jsonValue.length; i++) {
      assert.include(steps[i].getText(), jsonValue[i], 'Service data validation failed');
    }
  });

  Then(/^I validate number of map results in MapApi "(.*)\" to be included in "(.*)\"$/, function(jsonData, selector) {
    var apiResponse = userData.getField('recipeResponse');
    var jsonValue = jpath.query(apiResponse, jsonData);

    console.log(
      'Data fetched from API is : ' +
        jsonValue +
        '\n' +
        'Data fetched from UI is :' +
        generic.getSelector(selector).getText() +
        'apiResponse:' +
        apiResponse
    );
    generic.waitForElemReady(selector);
    for (let i = 0; i < jsonValue.length; i++) {
      assert.include(
        generic.getSelector(selector).getText(),
        jsonValue[i].toString(),
        'Search results count does not match'
      );
    }
  });

  Then(/^I validate number of map results in MapApi "(.*)" should be "(.*)"$/, function(jsonData, selector) {
    browser.pause(2000);
    var apiResponse = userData.getField('recipeResponse');
    var jsonValue = jpath.query(apiResponse, jsonData);

    var elementList = $$(generic.getXpath(selector));
    var number = elementList.length;
    var apiResponse = userData.getField('recipeResponse');
    var jsonValue = jpath.query(apiResponse, jsonData);
    assert.isTrue(number == jsonValue, 'Expected Search count ' + number + ' and json count ' + jsonValue);
  });
} catch (err) {
  console.log('FWD.Steps.js file');
  console.log(err);
}
