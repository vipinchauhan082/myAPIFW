var { Given, When, Then } = require('cucumber');
import generic from '../functions/genericFunctions';
import request from 'request';
//import { fstat } from 'fs';
let userData = require('../../bddcode/support/globalTestData');
let jpath = require('jsonpath');
var selectedTag;
const fs = require('fs');
const scdir = './test/ScreenshotPath/';
try {
  Given(/^I open "([^"]*)"$/, { timeout: -1 }, function(url) {
    generic.openUrl(url);
    const currentURL = browser.getUrl();
    assert.isFalse(currentURL.includes('/404'), `The page(${url}) you are trying to open does not exist`);
  });

  Then(/^Title should contain "([^"]*)"$/, { wrapperOptions: { retry: 2 } }, function(title) {
    assert.isTrue(
      browser
        .getTitle()
        .toLowerCase()
        .includes(title.toLowerCase()),
      `Expected browser title ${browser.getTitle()} to be ${title}`
    );
  });

  Then(/^I take a percy shot "([^"]*)"$/, async function(shotName) {
    browser.pause(3000);
    generic.waitForElemReady('Copy Right Footer Locator');
    if (process.env.BROWSERNAME != 'internet explorer') {
      browser.pause(3000);
      browser.execute(() => {
        for (let index = 0; index < window.document.body.scrollHeight; index = index + 768) {
          setTimeout(() => {
            window.scrollTo(0, index);
          }, 1000);
        }
      });
      browser.pause(1000);

      browser.execute(() => {
        window.scrollTo(0, 0);
      });
      browser.pause(3000);
    }
    console.log('percy', shotName);
    await percySnapshot(browser, `Snap_Shot_${shotName}`);
    
  });
  
  Given(/^I capture Screenshot for component "([^"]*)"$/, function(selector) {
    var sShotFileName = scdir + selector + '.jpg';
    console.log('file name is', sShotFileName);
    if (fs.existsSync(sShotFileName)) {
      console.log('Screenshot is already present for component : - ', selector);
    } else {
      if (generic.getSelector(selector).isVisible()) {
        browser.saveElementScreenshot('./test/ScreenshotPath/' + selector + '.jpg', generic.getXpath(selector));
      }
    }
  });

  When(/^I click on "([^"]*)"$/, function(selector) {
    generic.waitForElemReady(selector);
    generic.getSelector(selector).click();
  });

  When(/^I find "([^"]*)" tag on page$/, function(selector) {
    generic.findHeaderTags(selector);
  });

  When(/^I double click on "([^"]*)"$/, function(selector) {
    generic.waitForElemReady(selector);
    browser.element(generic.getXpath(selector)).doubleClick();
  });

  When(/^I click on "([^"]*)" element$/, function(selector) {
    //generic.getSelector(selector).click();
    browser.element(generic.getXpath(selector)).click();
  });

  Then(/^I dismiss on "([^"]*)"$/, function(selector) {
    $("//input[@name='confirmation']").click();
    browser.dismissAlert();
  });

  When(/^I enter "(.*)" in "(.*)"$/, function(value, selector) {
    if (value.length > 0) {
      generic.getSelector(selector).setValue(value);
    } else {
      assert.isNull(value, 'value is not passed or an Empty String');
    }
  });

  When(/^I enter key value as "(.*)" in "(.*)"$/, function(value, selector) {
    generic.getSelector(selector).setValue('');
    generic.sendkey(value, selector);
  });

  When(/^I am using "(.*)" data$/, function(LoginCredentials) {
    userData.setField('scenariosData', userData.getField('username')[LoginCredentials]);
    userData.setField('scenariosData', userData.getField('password')[LoginCredentials]);
  });

  When(/^I am using invalid data "(.*)"$/, function(UnregisteredUser) {
    userData.setField('scenariosData', userData.getField('invalidUsername')[UnregisteredUser]);
    userData.setField('scenariosData', userData.getField('invalidPassword')[UnregisteredUser]);
  });

  When(/^I am using data "(.*)" for password validation$/, function(UnregisteredUser) {
    userData.setField('scenariosData', userData.getField('invalidUsername')[UnregisteredUser]);
    userData.setField('scenariosData', userData.getField('invalidPassword')[UnregisteredUser]);
  });

  When(/^I pause for (.*) ms$/, function(timeoutVal) {
    browser.pause(timeoutVal);
  });

  //Click on a element by JS
  When(/^I click by js on "(.*)" element$/, function(selector) {
    generic.waitForElemReady(selector);
    browser.pause(7000);
    browser.execute(function(sal1) {
      document.querySelector(sal1).click();
    }, selector);
  });

  Given(/^I maximize the window$/, function() {
    browser.windowHandleFullscreen();
  });

  When(/^I delete browser cookies and close$/, function(callback) {
    browser.deleteCookie();
    browser.end();
  });

  Then(/^I should see "(.*)" is enabled/, function(selector) {
    generic.waitForElemReady(selector);
    assert.notInclude(browser.getAttribute(generic.getXpath(selector), 'class'), 'disabled', 'Element is disabled');
  });

  Then(/^I should see "(.*)" is sticky/, function(selector) {
    generic.waitForElemReady(selector);
    assert.notInclude(browser.getAttribute(generic.getXpath(selector), 'style'), 'position: sticky', 'Element is disabled');
  });

  //  Validate element has specific text in class, like disabled, inactive
  Then(/^I should see "(.*)" is "(.*)"$/, function(selector, property) {
    generic.waitForElemReady(selector);
    assert.include(
      browser.getAttribute(generic.getXpath(selector), 'class'),
      property,
      'Element does not have ' + property + ' in class'
    );
  });

  //Check if an element not exists
  Then(/^I should not see "(.*)" exist|existed/, function(selector) {
    browser.pause(1000);
    assert(browser.element(generic.getXpath(selector)).isExisting() !== true, selector + 'still exist');
  });

  //Check if an element not visible
  Then(/^I should not see "(.*)" visible|present/, function(selector) {
    assert(browser.element(generic.getXpath(selector)).isVisible() !== true, selector + 'still visible on the page');
  });

  //Check if an element visible
  Then(/^I should see "(.*)" visible|present/, function(selector) {
    assert(browser.element(generic.getXpath(selector)).isVisible() == true, selector + 'Not visible on the page');
  });

  //Check if an element exists
  Then(/^I should see "([^"]*)" exist|existed/, function(selector) {
    // browser.pause(2000);
    generic.waitForElemReady(selector);
    //assert(generic.getSelector(selector).isExisting() === true, selector + 'Not exist');
  });

  // checks if the first argument exits if and pnly if the second exists
  Then(/^"([^"]*)" should only exists in the presence of "([^"]*)"/, function(selector, mandatorySelector) {
    // browser.pause(2000);
    assert.isTrue(
      generic.getSelector(mandatorySelector).isExisting(),
      `${mandatorySelector} should exist for the existence of ${selector}.`
    );
    assert.isTrue(generic.getSelector(selector).isExisting(), `${selector} does'nt exist.`);
  });

  Then(/^I should see link "([^"]*)" exists incase results are greater than 12/, function(selector) {
    if (browser.element(generic.getXpath(selector)).isExisting()) {
      generic.waitForElemReady(selector);
      assert.isTrue(generic.getSelector(selector).isExisting() === true, selector + 'exist');
      generic.getSelector(selector).click();
    }
  });

  // Checks if the element exists in case the given counter is greater than the max counter
  Then(/^I should see "([^"]*)" if "([^"]*)" is more than "([^"]*)"/, function(selector, counter, maxCount) {
    const counterElement = browser.element(generic.getXpath(counter));
    const selectorElement = browser.element(generic.getXpath(selector));

    if (counterElement && counterElement.isExisting() && parseInt(counterElement.value) > maxCount) {
      assert.isTrue(selectorElement.isExisting() === true, `${selector} does not exist`);
      selectorElement.click();
    }
  });

  Then(/^I should see "([^"]*)" with "([^"]*)" exist|existed/, function(selector1, selector2) {
    generic.waitForElemReady(selector1);
    let xpathVal = generic.getXpath(selector1);
    var cnt = $$(xpathVal).length;
    if (cnt > 4) {
      // Arrow existance check
      assert(generic.getSelector(selector2).isExisting() === true, selector2 + 'not exist');
    }
  });

  //Get text from element
  Then(/^I should see \"(.*)\" with \"(.*)\" text$/, function(selector, expectedValue) {
    assert(generic.getSelector(selector).getText() === expectedValue, 'Expected and actual text does not match');
  });

  Then(/^I should see \"(.*)\" contains \"(.*)\" text$/, function(selector, expectedValue) {
    expect(
      generic
        .getSelector(selector)
        .getText()
        .toLowerCase()
    ).to.contains(expectedValue.toLowerCase());
  });

  Then(/^I should see .*\"(.*)\".* as grayed out/, function(selector) {
    generic.waitForElemReady(selector);
    assert.include(browser.getAttribute(generic.getXpath(selector), 'class'), 'grayed', 'Element is not grayed');
  });

  Then(/^I should see the URL of "(.*)" as "(.*)"$/, function(selector, expectedValue) {
    generic.waitForElemReady(selector);
    assert.strictEqual(
      browser.getAttribute(generic.getXpath(selector), 'href'),
      expectedValue,
      'Element url is not correct'
    );
  });

  Then(/^I should see "(.*)\" value as "(.*)\"$/, function(selector, expectedValue) {
    generic.waitForElemReady(selector);
    assert.strictEqual(
      browser.getAttribute(generic.getXpath(selector), 'value'),
      expectedValue,
      'Element Value is not correct'
    );
  });

  //Shiwali
  Then(/^I should validate value of "(.*)\"$/, function(selector) {
    generic.waitForElemReady(selector);
    assert.strictEqual(
      browser.getAttribute(generic.getXpath(selector), 'value'),
      selectedTag,
      'Element Value is not correct'
    );
  });

  // I should see "Signup Password" type as "text"
  Then(/^I should see "(.*)\" type as "(.*)\"$/, function(selector, expectedValue) {
    generic.waitForElemReady(selector);
    assert.strictEqual(
      browser.getAttribute(generic.getXpath(selector), 'type'),
      expectedValue,
      'Element Type is not correct'
    );
  });

  When(/^I refresh the page$/, function() {
    browser.refresh();
  });

  When(/^I press back button on the page$/, function() {
    browser.back();
  });

  When(/^I close the page$/, function() {
    browser.close();
  });

  When(/^I press .*\"(.*)\".* key$/, function(key) {
    browser.keys(key);
  });

  When(/^I press ENTER key$/, function() {
    browser.keys('\uE007');
  });

  When(/^I press TAB key$/, function() {
    browser.keys('\ue004');
  });

  // Read element CSS properties from CSSProperties file and validate with actual
  When(/^I validate css properties for "(.*)\"$/, function(selector) {
    generic.waitForElemReady(selector);
    let Property = '';
    let cssProperties = generic.getCSSProperties(selector).split('|');
    for (let item = 0; item < cssProperties.length; item++) {
      Property = cssProperties[item].split(':');
      var actualValue = browser.getCssProperty(generic.getXpath(selector), Property[0]);
      if (Array.isArray(actualValue)) {
        actualValue = actualValue[0];
      }
      if (selector.includes('mage') && (Property[0] == 'height' || Property[0] == 'width')) {
        let expectedVal = parseInt(Property[1].replace('px', ''));
        let actualVal = Number(actualValue.value.replace('px', ''));
        assert.isTrue(
          expectedVal + 3 > actualVal && expectedVal - 3 < actualVal,
          'CSS property of "' +
            generic.getXpath(selector) +
            '" does not match. Expected is ' +
            Property[1] +
            ' but actual is ' +
            actualValue.value
        );
      } else {
        //Ignoring font-weight and color due to Branding.
        if (Property[0] != 'font-weight' && Property[0] != 'color') {
          if (Property[0] == 'font-family' && Property[1].includes('#')) {
            Property[1] = generic.getFontFamily(Property[1].replace(/#/g, ''));
          }
          assert.include(
            JSON.stringify(actualValue.value).toLowerCase(),
            Property[1].trim().toLowerCase(),
            'CSS property of "' + generic.getXpath(selector) + '" does not match with ' + Property
          );
        }
      }
    }
  });

  // Read element CSS properties from feature file and validate with actual
  When(/^I validate "(.*)\" css properties for "(.*)\"$/, function(cssProp, selector) {
    generic.waitForElemReady(selector);
    let Property = '';
    let cssProperties = cssProp.split('|');
    for (let item = 0; item < cssProperties.length; item++) {
      Property = cssProperties[item].split(':');
      var actualValue = browser.getCssProperty(generic.getXpath(selector), Property[0]);
      assert.include(
        JSON.stringify(actualValue.value).toLowerCase(),
        Property[1].trim().toLowerCase(),
        'CSS property does not match'
      );
    }
  });

  //Check number of element are available on page
  Then(/^I see "(.*)" elements of "(.*)"$/, function(numberOfElement, selector) {
    generic.waitForElemReady(selector);
    let xpathVal = generic.getXpath(selector);
    assert.equal($$(xpathVal).length, numberOfElement, 'Element count does not match');
  });

  //Check number of element are available on page
  Then(/^I see maximum "(.*)" elements of "(.*)"$/, function(numberOfElement, selector) {
    generic.waitForElemReady(selector);
    let xpathVal = generic.getXpath(selector);
    assert.isTrue($$(xpathVal).length <= numberOfElement);
  });

  //Check mimimum number of element are available on page
  Then(/^I see minimum "(.*)" elements of "(.*)"$/, function(numberOfElement, selector) {
    generic.waitForElemReady(selector);
    let xpathVal = generic.getXpath(selector);
    assert.isTrue($$(xpathVal).length >= numberOfElement);
  });

  // Validate given text should not be empty.
  Then(/^I validate text "(.*)" should not be empty$/, function(selector) {
    if (generic.getSelector(selector).isVisible()) {
      //changing it to global var to access it across steps
      userData.setField('elementText', generic.getSelector(selector).getText());
      assert.isTrue(userData.getField('elementText').length >= 0, 'element does not contain any text');
    }
  });

  // Click on an object that opens a new page in new tab\window. It will switch focus on mew window
  Then(/^I click on "([^"]*)" and switch to new Window$/, function(selector) {
    generic.getSelector(selector).click();
    browser.pause(2000);
    var TabID = browser.getTabIds();
    browser.switchTab(TabID[1]);
  });

  // It will switch focus on mew frame
  Then(/^I switch to "([^"]*)" Frame$/, function(selector) {
    browser.pause(2000);
    browser.switchTab(generic.getSelector(selector));
    generic.getSelector(selector).click();
  });

  // It will switch focus on parent window
  Then(/^I switch to current window$/, function(url) {
    var TabID = browser.getTabIds();
    browser.switchTab(TabID[0]);
  });

  // Close current tab, if working on second tab, then focus will move back to first tab
  Then(/^I close current tab$/, function() {
    browser.close();
  });

  // Move element\object in focus
  Then(/^I scroll "(.*)" to view port$/, function(selector) {
    console.log('browser name', process.env.BROWSERNAME);
    generic.waitForElemReady(selector);
    if (process.env.BROWSERNAME != 'internet explorer') {
      browser.moveToObject(generic.getXpath(selector));
      browser.pause(2000);
    }
  });

  // scroll down window
  Then(/^I scroll window down$/, function() {
    browser.execute(function() {
      window.scrollBy(0, 100);
    });
  });

  // scroll down window
  Then(/^I scroll window up$/, function() {
    browser.execute(function() {
      window.scrollBy(0, -100);
    });
  });

  // scroll up window
  Then(/^I scroll window end$/, function() {
    browser.execute(function() {
      window.scrollBy(0, 1500);
    });
  });

  // Validate image has loaded on page.
  Then(/^I validate "(.*)" exists and loaded on page$/, function(selector) {
    generic.waitForElemReady(selector);
    let dataSRC = browser.getAttribute(generic.getXpath(selector), 'data-src');
    let urlSuffix = generic.getValueforEnv(process.env.ENVIRONMENT_VAR);
    let image_href = urlSuffix + dataSRC;
    console.log('img', image_href);
    let options = {
      url: image_href,
    };

    browser.call(() => {
      return new Promise((resolve, reject) => {
        request(options, function(error, response, body) {
          console.log('statusCode:', response && response.statusCode); // Print the response status code if a response was received
          assert.equal(response && response.statusCode, 200, selector + 'Image is not available on page');

          if (error) {
            return reject(error);
          }
          resolve(response);
        });
      });
    });

    // request(options, function (error, response, body) {
    //   console.log("response", response);
    //   assert.equal(response && response.statusCode, 200, selector + 'Image is not available on page');
    // });
  });

  Then(/^I validate "(.*)" exists in data src and loaded on page$/, function(selector) {
    generic.waitForElemReady(selector);
    let dataSRC = browser.getAttribute(generic.getXpath(selector), 'data-src');
    let urlSuffix = generic.getValueforEnv(process.env.ENVIRONMENT_VAR);
    let image_href = urlSuffix + dataSRC;
    console.log('img', image_href);
    let options = {
      url: image_href,
    };

    browser.call(() => {
      return new Promise((resolve, reject) => {
        request(options, function(error, response, body) {
          console.log('statusCode:', response && response.statusCode); // Print the response status code if a response was received
          assert.equal(response && response.statusCode, 200, selector + 'Image is not available on page');

          if (error) {
            return reject(error);
          }
          resolve(response);
        });
      });
    });

    // request(options, function (error, response, body) {
    //   console.log("response", response);
    //   assert.equal(response && response.statusCode, 200, selector + 'Image is not available on page');
    // });
  });

  Then(/^I validate broken links not exists for "(.*)"$/, function(selector) {
    generic.waitForElemReady(selector);
    let xpathVal = generic.getXpath(selector);
    const image_links = $$(xpathVal);
    image_links.forEach(element => {
      let image_href = element.getAttribute('src');
      let options = {
        url: image_href,
      };
      request(options.url, function(error, response, body) {
        assert.equal(response && response.statusCode, 200, selector + 'Image is not available on page');
      });
    });
  });

  When(/^I bring "(.*)" into focus/, function(selector) {
    generic.bringElementToFocus(selector);
  });

  // Click on an object that opens a new page in new tab\window. It will switch focus on mew window
  Then(/^I click on "([^"]*)" and validate it opens with same href in new Window$/, function(selector) {
    generic.waitForElemReady(selector);
    let image_href = browser.getAttribute(generic.getXpath(selector), 'href');
    generic.getSelector(selector).click();
    browser.pause(5000);
    var TabID = browser.getTabIds();
    browser.switchTab(TabID[1]);
    assert.equal(browser.getUrl(), image_href, 'Captured href and new page url is not same');
  });

  // Validate given text should not be empty.
  Then(/^I verify "(.*)" placeholder should not be empty$/, function(selector) {
    generic.waitForElemReady(selector);
    let placeholderValue = browser.getAttribute(generic.getXpath(selector), 'placeholder');
    assert.isTrue(placeholderValue.length >= 0, 'element does not contain any text');
  });

  Then(/^I click on "([^"]*)" and validate it opens with "([^"]*)" url in same Window$/, function(selector, value) {
    generic.waitForElemReady(selector);
    selectedTag = generic.getSelector(selector).getText();
    generic.getSelector(selector).click();
    browser.pause(2000);
    var urlfull = browser.getUrl().toLowerCase();
    console.log('Direced url' + urlfull);
    assert.isTrue(
      urlfull.includes(value.toLowerCase()),
      'URL of ' + generic.getXpath(selector) + ' element is ' + urlfull + ' but it does not contains ' + value
    );
  });

  Then(/^I validate browser open with "([^"]*)" url$/, function(value) {
    var url = browser.getUrl();
    assert.isTrue(url.includes(value));
  });

  Then(/^I should validate "([^"]*)" file exists$/, function(fileName) {
    assert.isTrue(generic.checkFileExists(fileName), 'Checking File Existance.');
  });

  Then(/^I should delete folder$/, function() {
    generic.deleteFolderRecursive();
  });

  Then(/^I click on "([^"]*)" and validate it opens with same text$/, function(selector) {
    generic.waitForElemReady(selector);
    var selectedText = generic
      .getSelector(selector)
      .getText()
      .split(' ');
    var text = selectedText[0].toLowerCase();
    generic.getSelector(selector).click();
    var urlfull = browser.getUrl().toLowerCase();
    assert.isTrue(
      urlfull.includes(text),
      'URL of ' + generic.getXpath(selector) + ' element is ' + urlfull + ' but it does not contains ' + text
    );
  });

  Then(/^I select "([^"]*)" dropdown "([^"]*)" value$/, function(selector, value) {
    generic.waitForElemReady(selector);
    generic.selectItemFromDropdown(selector, value);
    generic.waitForElemReady(selector);
  });

  Then(/^I should see total "(.*)" are more than & equal to "([^"]*)"$/, function(selector, lower) {
    generic.waitForElemReady(selector);
    let xpathVal = generic.getXpath(selector);
    assert.isTrue($$(xpathVal).length >= lower, 'Element count is less than 1');
  });

  Then(/^I select "([^"]*)" dropdown "([^"]*)" value by index$/, function(selector, value) {
    generic.selectItemFromDropdownByIndex(selector, value);
    generic.waitForElemReady(selector);
  });

  Then(/^I should see "(.*)" is disabled/, function(selector) {
    generic.waitForElemReady(selector);
    assert.include(browser.getAttribute(generic.getXpath(selector), 'class'), 'disabled', 'Element is Enabled');
  });

  Then(/^I should see total "(.*)" are more than & equal to "(.*)" and less than & equal to "(.*)"$/, function(
    selector,
    lower,
    upper
  ) {
    generic.waitForElemReady(selector);
    let xpathVal = generic.getXpath(selector);
    assert.isTrue($$(xpathVal).length >= lower && $$(xpathVal).length <= upper, 'Element count does not match');
  });

  //  Validate element has specific text in class, like disabled, inactive
  Then(/^I should see "(.*)" display as "(.*)"$/, function(selector, expanded_status) {
    let aria_expanded_status = false;

    if (expanded_status == 'expended') {
      aria_expanded_status = true;
    }

    generic.waitForElemReady(selector);
    assert.include(
      browser.getAttribute(generic.getXpath(selector), 'aria-expanded'),
      aria_expanded_status,
      'Element does not have ' + aria_expanded_status + ' in aria-expanded'
    );
  });

  Then(/^I see "(.*)" elements from "([^"]*)" with property "(.*)"$/, function(numberOfElement, selector, property) {
    generic.waitForElemReady(selector);
    let steps = generic.getXpath(selector);
    var cnt = 0;
    const active_elements = $$(steps);
    active_elements.forEach(element => {
      let active_class = element.getAttribute('class');
      if (active_class.includes(property)) {
        cnt++;
      }
    });

    assert.isTrue(cnt == numberOfElement);
  });

  Then(/^I should see "([^"]*)" text exists in "(.*)"$/, function(contentTypeLists, selector) {
    var contentType = contentTypeLists.split(',');
    var isContentType = false;
    generic.waitForElemReady(selector);
    let steps = $$(generic.getXpath(selector));
    for (let i = 0; i < contentType.length; i++) {
      for (let j = 0; j <= contentType.length; j++) {
        if (contentType[i] == steps[j].getText());
        {
          isContentType = true;
          break;
        }
      }
    }

    assert.isTrue(isContentType);
  });

  Then(/^I should validate text in "(.*)" is empty$/, function(selector) {
    if (generic.getSelector(selector).isVisible()) {
      //changing it to global var to access it across steps
      let elementText = generic.getSelector(selector).getText();
      assert.isTrue(elementText.length == 0, 'element contains text');
    }
  });

  Then(/^I should see "(.*)" is highlighted$/, function(selector) {
    generic.waitForElemReady(selector);
    var contentType = generic.getSelector(selector);
    assert.isTrue(contentType.getAttribute('aria-selected') == 'true');
  });

  Then(/^I validate "(.*)" has css property "([^"]*)" value "(.*)"$/, function(selector, property, value) {
    generic.waitForElemReady(selector);
    browser.pause(2000);
    var actualValue = browser.getCssProperty(generic.getXpath(selector), property);
    assert.isTrue(actualValue.value == value);
  });

  Then(/^I should see SEO "(.*)" Presence for "(.*)"/, function(metadata, tagValue) {
    let SEO_xpath = generic.getXpath(metadata);
    SEO_xpath = SEO_xpath.replace('#replace#', tagValue);
    assert(browser.element(SEO_xpath).isExisting() === true, 'Tagvalues : - ' + tagValue + 'is not present on DOM');
  });

  Then(/^I validate "(.*)" has css property "([^"]*)" contains value "(.*)"$/, function(selector, property, value) {
    generic.waitForElemReady(selector);
    browser.pause(2000);
    var actualValue = browser.getAttribute(generic.getXpath(selector), property);
    console.log(actualValue);
    assert.isTrue(actualValue.includes(value));
  });

  Then(/^I validate "(.*)" has css property "([^"]*)" does not contains value "(.*)"$/, function(selector, property, value) {
    generic.waitForElemReady(selector);
    browser.pause(2000);
    var actualValue = browser.getAttribute(generic.getXpath(selector), property);
    assert.isFalse(actualValue.includes(value));
  });

  Then(/^I select the "([^"]*)" in "([^"]*)" dropdown/, function(value, selector) {
    generic.waitForElemReady(selector);
    generic.getSelector(selector).click();
    generic.waitForElemReady("HistFundPerformace DropDownList");
    let dropDownValue_xpath = generic.getXpath('HistFundPerformace DropdownValue');
    dropDownValue_xpath = dropDownValue_xpath.replace('#replace#', value);
    console.log("dropDownValue_xpath: ", dropDownValue_xpath)
    if (process.env.BROWSERNAME != 'internet explorer') {
      browser.moveToObject(generic.getXpath(selector));
      browser.pause(2000);
    }
    browser.element(dropDownValue_xpath).click();
    browser.pause(1000)
  });

  Then(/^I should not see "([^"]*)" in "([^"]*)" dropdown/, function(value, selector) {
    generic.waitForElemReady(selector);
    generic.getSelector(selector).click();
    generic.waitForElemReady("HistFundPerformace DropDownList");
    let dropDownValue_xpath = generic.getXpath('HistFundPerformace DropdownValue');
    dropDownValue_xpath = dropDownValue_xpath.replace('#replace#', value);
    console.log("dropDownValue_xpath: ", dropDownValue_xpath)
    assert(browser.element(dropDownValue_xpath).isVisible() !== true, dropDownValue_xpath + ' still visible on the page');
  });

  Then(/^I should see "([^"]*)" in "([^"]*)" dropdown/, function(value, selector) {
    generic.waitForElemReady(selector);
    generic.getSelector(selector).click();
    generic.waitForElemReady("HistFundPerformace DropDownList");
    let dropDownValue_xpath = generic.getXpath('HistFundPerformace DropdownValue');
    dropDownValue_xpath = dropDownValue_xpath.replace('#replace#', value);
    console.log("dropDownValue_xpath: ", dropDownValue_xpath)
    assert(browser.element(dropDownValue_xpath).isVisible() == true, dropDownValue_xpath + ' still not visible on the page');
  });
  
  Then(/^I click on "([^"]*)" and validate it opens in "([^"]*)" tab/, function(link, tab) {
    let text_href = browser.getAttribute(generic.getXpath(link), 'href');
    console.log('Text' + text_href);
    switch (tab) {
      case 'same':
        browser.element(generic.getXpath(link)).click();
        var urlfull = browser.getUrl().toLowerCase();
        console.log('Url' + urlfull);
        assert.isTrue(
          urlfull.includes(text_href),
          'URL of ' + generic.getXpath(link) + ' element is ' + urlfull + ' but it does not contains ' + link
        );
        browser.back();
        break;
      case 'new':
        browser.element(generic.getXpath(link)).click();
        var TabID = browser.getTabIds();
        browser.switchTab(TabID[1]);
        var urlfull = browser.getUrl().toLowerCase();
        console.log('Url' + urlfull);
        assert.isTrue(
          urlfull.includes(text_href),
          'URL of ' + generic.getXpath(link) + ' element is ' + urlfull + ' but it does not contains ' + link
        );
        browser.close();
        browser.switchTab(TabID[0]);
        break;
    }
  });
} catch (err) {
  console.log('genericStep.js file');
  console.log(err);
}
