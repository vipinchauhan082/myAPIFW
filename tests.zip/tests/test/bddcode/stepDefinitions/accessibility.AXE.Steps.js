import generic from '../functions/genericFunctions';
var { Given, When, Then } = require('cucumber');
const axeReports = require('axe-reports');
const axeBuilder = require('axe-webdriverio');
let userData = require('../support/globalTestData');
var fs = require('fs');

try {
  Then(/^I apply accessibility validation rules on page and create new report file with "(.*)" name$/, function async(
    filename
  ) {
    var accessibility = process.env.ACCESSIBILITY;
    if (accessibility) {
      var dir = './test/reports/accessibility';
      if (!fs.existsSync(dir)) {
        fs.mkdirSync(dir);
      }

      filename = 'test/reports/accessibility/' + filename;
      userData.setField('accessibilityFile', filename);
      return new axeBuilder(browser).withTags('wcag2aa').analyze(function(results) {
        axeReports.processResults(results.value, 'csv', filename, true);
      });
    }
  });

  Then(/^I apply accessibility validation rules on page and append report$/, function async() {
    return new axeBuilder(browser)
      .withTags('wcag2aa')
      .analyze()
      .then(function(results) {
        var accessibility = process.env.ACCESSIBILITY;
        if (accessibility) {
          axeReports.processResults(results.value, 'csv', userData.getField('accessibilityFile'));
        }
      });
  });
} catch (err) {
  console.log('accessibility.AXE.Step.js file');
  console.log(err);
}
