var { Given, When, Then } = require('cucumber');
import generic from '../functions/genericFunctions';
import { AssertionError } from 'assert';
let userData = require('../support/globalTestData');
const fs = require('fs');
var formValue = new Map();
var InfoValue;
var birthYear;
var valuetobechecked;
var prmnStepperInputValue, StepperIntervalValue, ProductValueUI, ProductValueHtext;
var stepperDif;
//use Moment lib for language specific entryies , change below array
var months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
var PremiumFrequencyRange = ['Single', 'Monthly', 'Quarterly', 'Half Yearly', 'Yearly'];
const today = new Date();
try {
  Then(/^I fetch the "([^"]*)" from InfoText of Respective plan card$/, function(MinorMaxValue) {
    InfoValue = generic.getSelector(MinorMaxValue).getText();
    InfoValue = InfoValue.replace(/,/g, '').trim();
  });

  Then(/^I "([^"]*)" the Date of birth to be entered with "([^"]*)"$/, function(validationText, agevr) {
    const currYear = today.getFullYear(); //TODO: Need to add Check for country
    if (process.env.LANGUAGE == 'th') {
      currYear = currYear + 543;
    }
    var yearConvertedInteger = parseInt(InfoValue, 10);

    if (agevr.includes('Maximum') && validationText.includes('Validate')) {
      birthYear = currYear - yearConvertedInteger - 1;
    } else if (agevr.includes('Maximum') && validationText.includes('Calculate')) {
      birthYear = currYear - yearConvertedInteger;
    } else if (agevr.includes('Minimum') && validationText.includes('Validate')) {
      birthYear = currYear - yearConvertedInteger + 1;
      if (birthYear > currYear) {
        birthYear = currYear;
      }
    } else {
      birthYear = currYear - yearConvertedInteger - 2;
    }
  });

  Then(/^I validate that "([^"]*)" is updated in "([^"]*)"$/, function(productValue, Inputboxvalue) {
    ProductValueUI = generic.getSelector(Inputboxvalue).getAttribute('value');
    ProductValueUI = ProductValueUI.replace(/,/g, '').trim();
    ProductValueHtext = generic.getSelector(productValue).getText();
    ProductValueHtext = ProductValueHtext.replace(/,/g, '').trim();
    ProductValueHtext = ProductValueHtext.replace('THB', '').trim();
    assert.isTrue(ProductValueUI == ProductValueHtext, 'Minimum value is not updated in input box');
    browser.pause(2000);
  });

  When(/^I simulate "(.*)\" key$/, function(key) {
    browser.keys(key);
  });

  Then(/^I validate the "([^"]*)" for "([^"]*)" by "([^"]*)"$/, function(Inputboxvalue, StepperValue, operation) {
    prmnStepperInputValue = generic.getSelector(Inputboxvalue).getAttribute('value');
    //to Remove Comma from Value
    prmnStepperInputValue = prmnStepperInputValue.replace(/,/g, '').trim();
    StepperIntervalValue = generic.getSelector(StepperValue).getText();
    StepperIntervalValue = StepperIntervalValue.replace(/,/g, '').trim();
    StepperIntervalValue = StepperIntervalValue.replace('THB', '').trim();
    if (operation.includes('Plus')) {
      stepperDif = prmnStepperInputValue - StepperIntervalValue;
    } else {
      stepperDif = prmnStepperInputValue;
    }
    InfoValue = InfoValue.replace('THB', '').trim();
    assert.isTrue(stepperDif == InfoValue, 'Stepper Interval is different from  CMS VS UI');
  });
  Then(/^I should validate error message exists for email/, function() {
    var emailText = browser.element(generic.getXpath('Form Section InputBox')).getText();
    if (!emailText.includes('@') && !emailText.includes('.')) {
      assert.isTrue(
        browser.element(generic.getXpath('Form Label Error')).getText().length > 0,
        'Error message is not displayed'
      );
    } else assert(browser.element(generic.getXpath('Form Label Error')).isExisting() !== true, 'Form Label Error' + 'still exist');
  });
  Then(/^I should validate error message exists for phoneNo/, function() {
    var text = browser.getAttribute(generic.getXpath('Form Section InputBox') + '[2]', 'value');
    if (text.length < 9 || text.length > 10) {
      assert.isTrue(
        browser.element(generic.getXpath('Form Label Error')).getText().length > 0,
        'Error message is not displayed'
      );
    } else if (!generic.onlyNumbers(text)) {
      assert.isTrue(
        browser.element(generic.getXpath('Form Label Error')).getText().length > 0,
        'Error message is not displayed'
      );
    } else
      assert(
        browser.element(generic.getXpath('Form Label Error')).isExisting() !== true,
        'Form Label Error' + 'still exist'
      );
  });
  Then(/^I select the "([^"]*)" from "([^"]*)" for year validation/, function(i, action) {
    //need to decide what to do with action- once all forms are in place , then can combine
    browser.element(generic.getXpath('Form Section Dropdown') + '[' + i + ']').click();
    browser.pause(3000);
    let year_xpath = generic.getXpath('Form DropdownValue');
    year_xpath = year_xpath.replace('#replace#', birthYear);
    browser.element(year_xpath).click();
    browser.pause(3000);
    formValue.set('Year', browser.element(generic.getXpath('Form Section Dropdown') + '[' + i + ']').getText());
  });

  Then(/^I select value for "([^"]*)" at index "([^"]*)"$/, function(fieldname, index) {
    var currYear = today.getFullYear();
    if (process.env.LANGUAGE == 'th') {
      currYear = currYear + 543;
    }
    browser.pause(2000);
    browser.element(generic.getXpath('Form Section Dropdown') + '[' + index + ']').click();
    browser.pause(2000);
    let year_xpath = generic.getXpath('Form DropdownValue');
    year_xpath = year_xpath.replace('#replace#', currYear);
    browser.element(year_xpath).click();
    browser.pause(2000);
    formValue.set(fieldname, browser.element(generic.getXpath('Form Section Dropdown') + '[' + index + ']').getText());
  });
  Then(/^I select the "([^"]*)" from "([^"]*)" for Month validation/, function(i, action) {
    //need to decide what to do with action- once all forms are in place , then can combine
    browser.pause(3000);
    browser.element(generic.getXpath('Form Section Dropdown') + '[' + i + ']').click();
    let Month_xpath = generic.getXpath('Form DropdownValue');
    var thisMonth = months[today.getMonth()];
    var thisMonth = 'Jun';
    // getMonth method returns the month of the date (0-January :: 11-December)
    Month_xpath = Month_xpath.replace('#replace#', thisMonth);
    browser.pause(2000);
    browser.element(Month_xpath).click();
    browser.pause(3000);
    formValue.set('Month', browser.element(generic.getXpath('Form Section Dropdown') + '[' + i + ']').getText());
  });

  Then(/^I select the "([^"]*)" from "([^"]*)" for Date validation/, function(i, action) {
    //need to decide what to do with action- once all forms are in place , then can combine

    browser.pause(3000);
    browser.element(generic.getXpath('Form Section Dropdown') + '[' + i + ']').click();
    browser.pause(3000);
    let day_xpath = generic.getXpath('Form DropdownValue');
    var thisDate = today.getDate();
    day_xpath = day_xpath.replace('#replace#', thisDate);
    browser.element(day_xpath).click();
    formValue.set('Date', browser.element(generic.getXpath('Form Section Dropdown') + '[' + i + ']').getText());
  });

  //Need to add details and Check - To do
  When(/^I send request for "(.*)" using "(.*)\" as age and "(.*)\" as paramater passed$/, function(
    url,
    ApiName,
    age,
    valueSAorPremium
  ) {
    if (ApiName.includes('Premium')) {
      url = ' ' + url;
      //  whichever fieldName is passed for premium that will be replaced below
    } else {
      url = ' ' + url;

      //  whichever fieldName is passed for Sum Assurance that will be replaced below
    }
    // Todo
    var postData = generic.getPayloads('');
    postData = postData.replace('{ContentTypeValue}', contentType);
    postData = postData.replace('{DOB}', birthYear);
    postData = postData.replace('{ContentSubTypeValue}', value);
    generic.postAPICall(url, postData);
  });

  //need to decide what to do with action- once all forms are in place , then can combine
  Then(/^I Enter value in "([^"]*)" input for Stepper/, function(i) {
    browser.element(generic.getXpath('Form Stepper InputBox') + '[' + i + ']').click();
    browser.element(generic.getXpath('Form Stepper InputBox')).doubleClick();
    // browser.setValue(generic.getSelectorWithIndex('Form Stepper InputBox', index).selector,"")
    browser.keys('Delete');
    //browser.keys(['Control', 'A', 'NULL']);
    browser.pause(2000);
    var InfoValueUpdate = parseInt(InfoValue, 10) - 100;
    browser.element(generic.getXpath('Form Stepper InputBox')).setValue(InfoValueUpdate);
    browser.pause(3000);
  });

  Then(/^I select the "([^"]*)" from "([^"]*)" Field/, function(i, action) {
    //need to decide what to do with action- once all forms are in place , then can combine
    browser.pause(3000);
    browser.element(generic.getXpath('Form Section RadioBox') + '[' + i + ']').click();
    browser.pause(3000);
  });

  When(/^I select "([^"]*)" for "([^"]*)" ,Enter value "([^"]*)" for label "([^"]*)"$/, function(
    i,
    action,
    value,
    labelText
  ) {
    valuetobechecked = value;
    //assert(generic.getSelector('Form Section Label').getText() === labelText, 'Expected and actual text does not match');
    switch (action) {
      case 'Input':
        browser.element(generic.getXpath('Form Stepper InputBox') + '[' + i + ']').setValue('');
        browser.element(generic.getXpath('Form Stepper InputBox') + '[' + i + ']').click();
        browser.keys(InfoValue);
        formValue.set(
          labelText + i,
          browser.getAttribute(generic.getXpath('Form Stepper InputBox') + '[' + i + ']', 'value')
        );
        break;
      case 'Dropdown':
        browser.element(generic.getXpath('Form Section Dropdown') + '[' + i + ']').click();
        browser.pause(3000);
        let day_xpath = generic.getXpath('Form DropdownValue');
        day_xpath = day_xpath.replace('#replace#', valuetobechecked);
        browser.element(day_xpath).click();
        browser.pause(3000);
        formValue.set('Value' + i, browser.element(generic.getXpath('Form Section Dropdown') + '[' + i + ']').getText());
        break;
      case 'Checkbox':
        browser.element(generic.getXpath('Form Section Checkbox') + '[' + i + ']').click();
        break;
      case 'Radio':
        browser.element(generic.getXpath('Form Section RadioBox') + '[' + i + ']').click();
        break;
    }
  });

  Then(/^I should validate "([^"]*)" text for "([^"]*)" for "([^"]*)" field/, function(action, expectedValue, i) {
    switch (action) {
      case 'Input':
        browser.waitForVisible(generic.getXpath('Form Section InputBox') + '[' + i + ']', 2000);
        assert.strictEqual(
          browser.getAttribute(generic.getXpath('Form Section InputBox') + '[' + i + ']', 'value'),
          formValue.get(expectedValue + i),
          'Element Value is not correct'
        );
        break;
      case 'Radio':
        assert.strictEqual(
          browser.getAttribute(generic.getXpath('Form RadioBoxLabel') + '[' + i + ']', 'checked'),
          expectedValue,
          'Correct field is not checked'
        );
        break;
      case 'Dropdown':
        assert(
          browser.element(generic.getXpath('Form Section Dropdown') + '[' + i + ']').getText() === formValue.get('Value' + i)
        );
        break;
    }
  });

  Then(/^I verify hint text for "([^"]*)","([^"]*)"$/, function(selector, i) {
    let placeholderValue = browser.getAttribute(generic.getXpath(selector) + '[' + i + ']', 'placeholder');
    assert.isTrue(placeholderValue.length > 0, 'Does not contain Hint Text');
  });

  Then(/^I validate no default value is selected for "([^"]*)"$/, function(screenName) {
    let xpathVal = generic.getXpath('RadioButton Form-Wrapper');
    if (screenName.includes('Plans')) {
      xpathVal = xpathVal.replace('#replace#', 'calculatorOptionsList');
    } else if (screenName.includes('Gender')) {
      xpathVal = xpathVal.replace('#replace#', 'Radio Button List');
    }
    var cnt = $$(xpathVal).length;
    for (let i = 1; i <= cnt; i++) {
      assert.strictEqual(
        browser.getAttribute(generic.getXpath('Form RadioBoxLabel') + '[' + i + ']', 'checked'),
        null,
        'Radio fields are checked'
      );
    }
  });

  Then(/^I select the "([^"]*)" from "([^"]*)" for Dropdown Range validation/, function(i, action) {
    //need to decide what to do with action- once all forms are in place , then can combine
    browser.pause(3000);
    browser.element(generic.getXpath('Form Section DropdownRange')).click();
    browser.pause(1000);
    if (!action.includes('Frequency')) {
      browser.pause(2000);
      browser.element(generic.getXpath('Form DropdownValueByIndex') + '[' + i + ']').click();
      formValue.set('Amount', browser.element(generic.getXpath('Form Section DropdownRange')).getText());
    } else {
      let range_xpath = generic.getXpath('Form DropdownValue');
      var thisRange = PremiumFrequencyRange[i].toLowerCase();
      range_xpath = range_xpath.replace('#replace#', thisRange);
      browser.element(range_xpath).click();
      formValue.set('Frequency', browser.element(generic.getXpath('Form Section DropdownRange')).getText());
    }
  });

  Then(/^I validate "([^"]*)" are not selected by default$/, function(radioValue) {
    generic.waitForElemReady('Radio Form-Wrapper');
    let xpathVal = generic.getXpath('Radio Form-Wrapper');
    var cnt = $$(xpathVal).length;
    for (let i = 1; i <= cnt; i++) {
      assert.strictEqual(
        browser.getAttribute(generic.getXpath('Form RadioBoxLabel') + '[' + i + ']', 'checked'),
        null,
        radioValue + ' are checked'
      );
    }
  });

  When(/^I select "([^"]*)" with "([^"]*)" "([^"]*)"$/, function(fieldname, value, string) {
    assert.isTrue(generic.getSelector('Form Section Label').getText().length > 0, 'Element does not contain any text');
    switch (string) {
      case 'index':
        const xPathValue = generic.getXpath('Form RadioBoxLabel') + '[' + value + ']';
        browser.waitUntil(() => browser.element(xPathValue).isVisible());
        browser.element(xPathValue).click();
        formValue.set(
          fieldname,
          generic
            .getSelectorWithIndex('Form Section RadioBox', value)
            .getText()
            .toLowerCase()
        );
        break;
      case 'text':
        let xpathVal = generic.getXpath('Radio Form-Wrapper');
        var cnt = $$(xpathVal).length;
        for (let i = 1; i <= cnt; i++) {
          let radioText = generic.getSelectorWithIndex('Form Section RadioBox', i).getText();
          if (radioText.includes(value)) {
            generic.getSelectorWithIndex('Form Section RadioBox', i).click();
            formValue.set(fieldname, generic.getSelectorWithIndex('Form Section RadioBox', i).getText());
          }
        }
    }
  });
  Then(/^I verify hint text for "([^"]*)" at index "([^"]*)"$/, function(selector, index) {
    let placeholderValue = browser.getAttribute(generic.getXpath(selector) + '[' + index + ']', 'placeholder');
    assert.isTrue(placeholderValue.length > 0, 'Hint Text is not displayed');
  });

  When(/^I enter "([^"]*)" value for "([^"]*)" at index "([^"]*)"$/, function(value, fieldname, index) {
    browser.pause(5000);
    assert.isTrue(generic.getSelector('Form Section Label').getText().length > 0, 'Element does not contain any text');
    assert(generic.getSelectorWithIndex('Form Section InputBox', index).isExisting() === true, fieldname + 'does not exist');
    generic.getSelectorWithIndex('Form Section InputBox', index).setValue('');
    generic.getSelectorWithIndex('Form Section InputBox', index).click();
    browser.setValue(generic.getSelectorWithIndex('Form Section InputBox', index).selector, value);
    // browser.keys(value);
    formValue.set(fieldname, browser.getAttribute(generic.getXpath('Form Section InputBox') + '[' + index + ']', 'value'));
  });

  When(/^I select "([^"]*)" "([^"]*)" for "([^"]*)" at index "([^"]*)"$/, function(value, string, fieldname, index) {
    assert.isTrue(generic.getSelector('Form Section Label').getText().length > 0, 'Element does not contain any text');
    assert(
      generic.getSelectorWithIndex('Form Section DropdownCallBack', index).isExisting() === true,
      fieldname + 'does not exist'
    );

    switch (string) {
      case 'value':
        generic.getSelectorWithIndex('Form Section DropdownCallBack', index).click();
        generic.getSelectorWithIndex('Form DropdownValueCallBack', value).click();
        browser.pause(1000);
        formValue.set(fieldname, browser.element(generic.getXpath('Form Section Dropdown') + '[' + index + ']').getText());
        break;
      case 'text':
        generic.getSelectorWithIndex('Form Section DropdownCallBack', index).click();
        browser.element(generic.getXpath('Form DropdownValueCallBack') + '[.=' + value + ']').click();
        formValue.set(fieldname, browser.element(generic.getXpath('Form Section Dropdown') + '[' + index + ']').getText());
    }
  });

  When(/^I select "([^"]*)" for "([^"]*)" at index "([^"]*)"$/, function(value, fieldname, index) {
    assert.isTrue(generic.getSelector('Form Section Label').getText().length > 0, 'Element does not contain any text');
    assert(generic.getSelectorWithIndex('Form Section DataList', index).isExisting() === true, fieldname + 'does not exist');
    generic.getSelectorWithIndex('Form Section DataList', index).click();
    generic.getSelectorWithIndex('Form DataListValue', value).click();
    formValue.set(fieldname, browser.getAttribute(generic.getXpath('Form DataListText') + '[' + index + ']', 'value'));
  });

  Then(/^I validate success for "([^"]*)" which includes "([^"]*)"/, function(fieldname, message) {
    assert.include(
      browser.element(generic.getXpath(fieldname)).getText(),
      formValue.get(message),
      fieldname + ' is not displayed in the message'
    );
  });

  Then(/^I validate value retention for "([^"]*)" "([^"]*)" field at index "([^"]*)"/, function(fieldname, action, index) {
    switch (action) {
      case 'Input':
        browser.waitForVisible(generic.getXpath('Form Section InputBox') + '[' + index + ']', 5000);
        assert.strictEqual(
          browser.getAttribute(generic.getXpath('Form Section InputBox') + '[' + index + ']', 'value'),
          formValue.get(fieldname),
          'Correct retained value is not displayed'
        );
        break;
      case 'Dropdown':
        console.log(browser.element(generic.getXpath('Form Section Dropdown') + '[' + index + ']').getText());
        console.log(formValue.get(fieldname));
        assert.isTrue(
          browser.element(generic.getXpath('Form Section Dropdown') + '[' + index + ']').getText() ===
            formValue.get(fieldname),
          'Correct retained value is not displayed'
        );
        break;
      case 'DataList':
        assert.isTrue(
          browser.getAttribute(generic.getXpath('Form DataListText') + '[' + index + ']', 'value') ===
            formValue.get(fieldname),
          'Correct retained value is not displayed'
        );
        break;
      case 'TextBox':
        browser.waitForVisible(generic.getXpath('Form Section TextArea') + '[' + index + ']', 2000);
        assert.strictEqual(
          browser.element(generic.getXpath('Form Section TextArea') + '[' + index + ']').getText(),
          formValue.get(fieldname),
          'Correct retained value is not displayed'
        );
        break;
    }
  });

  Then(/^I validate value retention for "([^"]*)" radio fields/, function(fieldname) {
    browser.waitForVisible(generic.getXpath('Radio Form-Wrapper'), 5000);
    let xpathVal = generic.getXpath('Radio Form-Wrapper');
    var cnt = $$(xpathVal).length;
    for (let i = 1; i <= cnt; i++) {
      if (browser.getAttribute(generic.getXpath('Form RadioBoxLabel') + '[' + i + ']', 'checked') === 'true') {
        assert.strictEqual(
          generic
            .getSelectorWithIndex('Form Section RadioBox', i)
            .getText()
            .toLowerCase(),
          formValue.get(fieldname),
          'Correct retained value is not displayed'
        );
      }
    }
  });

  Then(/^I validate value retention for "([^"]*)" in "([^"]*)" at index "([^"]*)"/, function(value, item, index) {
    let splitString, genderString;
    let selector = generic.getXpath(item) + '[' + index + ']';
    genderString = browser.element(selector).getText();
    splitString = genderString.split(',');
    if (value.includes('Gender')) {
      assert.deepEqual(
        formValue
          .get(value)
          .toLowerCase()
          .trim(),
        splitString[0].toLowerCase().trim(),
        'Not equal'
      );
    } else if (value.includes('Age')) {
      var ageString = splitString[1];
      assert.isTrue(ageString.includes('years old'));
      ageString = ageString.replace(/\D/g, '');
      if (!Number.isNaN(ageString)) {
        var ageINT = parseInt(ageString);
      }
      assert.isNumber(ageINT, 'Age value is not a number');
    } else {
      assert.include(
        browser.element(selector).getText().toLowerCase,
        formValue.get(value).toLowerCase,
        'Correct value is not retained for ' + value
      );
    }
  });

  Then(/^I select "([^"]*)" checkbox for "([^"]*)" field/, function(i, action) {
    browser.element(generic.getXpath('Group Enquiry Checkbox') + '[' + i + ']').click();
  });

  Then(/^I validate scroll arrow "([^"]*)" and click on it/, function(selector) {
    browser.pause(1000);
    if (browser.element(generic.getXpath(selector)).isVisible()) {
      generic.getSelector(selector).click();
    }
    browser.moveToObject(generic.getXpath('Form ActiveList'));
    generic.getSelector('Form ActiveList').click();
  });

  Then(/^I validate success message for "([^"]*)"/, function(fieldname) {
    browser.waitUntil(
      () => {
        return !browser.element(generic.getXpath(fieldname)).isVisible();
      },
      700000,
      'Progress Bar still exists',
      10000
    );
  });

  When(/^I enter "([^"]*)" for "([^"]*)" at index "([^"]*)"$/, function(value, fieldname, index) {
    assert.isTrue(generic.getSelector('Form Section Label').getText().length > 0, 'Element does not contain any text');
    generic.getSelectorWithIndex('Form Section TextArea', index).setValue('');
    generic.getSelectorWithIndex('Form Section TextArea', index).click();
    browser.setValue(generic.getSelectorWithIndex('Form Section TextArea', index).selector, value);
    // browser.keys(value);
    formValue.set(fieldname, value);
  });
} catch (err) {
  console.log('FWD.Steps.js file');
  console.log(err);
}
