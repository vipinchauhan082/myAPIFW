p1=$(jq .P1_Failures tests/test/reports/priorityBasisFailureReport.json)
p2=$(jq .P2_Failures tests/test/reports/priorityBasisFailureReport.json)
p3=$(jq .P3_Failures tests/test/reports/priorityBasisFailureReport.json)
per=$(jq .passed_Percentage tests/test/reports/priorityBasisFailureReport.json)


if [ $p1 -gt 3 ] || [ $p2 -gt 3 ] || [ $p3 -gt 3 ] || [ $per -lt 80 ]; then
echo "There are QA test failures: P1-$p1 P2-$p2 P3-$p3"
exit 1
else
echo "QA test execution successful"
fi