#!/bin/bash

# @creationdate 2017-09-24
# @author Karthik Gudodagi kgudodagi2@sapient.com
#
# Run pally test on URLS
#
# USAGE:
# ./pa11y-scan.sh -f urls-list.txt

# command to execute: "bash ./test/pa11y/pa11y-scan.sh -f test/pa11y/pa11y-urls-list-uat.txt >> test/pa11y/pa11yResults/pa11y-test-report.csv"

set +x

usage() { echo "Usage: sh $0 -f < File with URLs> " 1>&2; exit 1; }


#str=$(pwd)
find="pa11y"
#replace="acceptance/wdio/utilities/htmlOutput"
#resultpath=${str//$find/$replace}
resultpath=${find}
echo "Html result path $resultpath"

while getopts ":f:" o; do
    case "${o}" in
        f)
            PallyURLList=${OPTARG}
            echo "url list $PallyURLList"
            ;;
        *)
            usage
            ;;
    esac
done
shift $((OPTIND-1))

#Check if there is valid input from user

if [ -z "$PallyURLList" ]
then
echo "Pally results file missing"
usage
exit 1
else
  echo "Pally results file is $PallyURLList"
  if [ ! -f $PallyURLList ]; then
    echo "$PallyURLList: File not found!"
    exit 1
  fi
fi

pa11yResultsFile="test/pa11y/pa11yResults/pa11y-scan-report.csv"
pa11yResultsTempFile="/tmp/pa11y-tem.csv"

while read URL
do
        # Delete if file exists
        if [ -f $pa11yResultsTempFile ] ; then
             # echo "Deleting $pa11yResultsTempFile"
             echo "remove temp file"
             rm $pa11yResultsTempFile
        fi

        touch pa11yResultsTempFile
		
            FinalUrlPath=$URL

              echo "Running accesibility scans for $FinalUrlPath"
              pa11y -r csv $FinalUrlPath >> $pa11yResultsTempFile

              while read Pa11yViolaionDetails
              do
                    echo "$FinalUrlPath,$Pa11yViolaionDetails" >> $pa11yResultsFile 
              done < $pa11yResultsTempFile

              echo "Accesibility scan results written to $pa11yResultsFile "

        # Delete if file exists
        if [ -f $pa11yResultsTempFile ] ; then
             # echo "Deleting $pa11yResultsTempFile"
             rm $pa11yResultsTempFile
        fi

done <$PallyURLList


