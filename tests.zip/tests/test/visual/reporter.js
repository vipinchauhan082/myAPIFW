const fs = require('fs');
const path = require('path');
let jpath = require('jsonpath');
const fsexe = require('fs-extra');
let dateValue = new Date().toLocaleString();

let device = process.env.REP_VAR == 'mob' ? 'Mobile' : 'Chrome';

// JSON data
var screenReportFile = process.env.REP_VAR + '_screenReport.json';
const data = require('../screenshots/visual-results/' + screenReportFile);

var totalTC = jpath.query(data, 'output..isWithinMisMatchTolerance');
var passedTC = jpath.query(data, 'output..Status[?(@.isWithinMisMatchTolerance)]');

summaryData =
  '{ "passed": ' + passedTC.length + ', "failed": ' + (totalTC.length - passedTC.length) + ', "Date": "' + dateValue + '"}';
fs.writeFileSync('./test/screenshots/visual-results/' + process.env.REP_VAR + '_reportSummary.json', summaryData);

// Build paths
const buildPathHtml = path.resolve('./test/screenshots/visual-results');

var filename = process.env.REP_VAR + '_index.html';

const createRow = item => {
  if (item.Status[0].isWithinMisMatchTolerance === false)
    return `
  <tr>
    <td class="scenario">  
    <button type="button" onclick="replaceFile('${item.ActualFile}',)">Replace Expected</button>
    <a href=${item.Page_URL} target="_blank" > ${item.ScenarioName} </a> </td>
    <td class="expected"><img src="/${item.ExpectedFile}" alt="expected image for ${item.ScenarioName}"/></td>
    <td class="actual"><img src="/${item.ActualFile}" alt="actual image for ${item.ScenarioName}" /></td>
    <td class="difference"><img src="/${item.DiffFile}"  alt="difference image for ${item.ScenarioName}"/></td>
    <td class="status">${item.Status[0].misMatchPercentage}</td>
  </tr>
`;
};

const createTable = rows => `
  <table>
    <thead>
      <tr>
          <th>Scenario Name</td>
          <th>Expected Baseline Visual</td>
          <th>Actual Visual</td>
          <th>Difference</td>
          <th>Status - Mismatch Percentage</td>
      </tr>
    </thead>
    <tbody>
      ${rows}
    </tbody>
  </table>
`;

const createHeader = data => `
<div class="primary-header">
  <h1>${device} Visual Regression Report</h1>
</div>
<div class="secondary-header">
  <p>
  Browser: <span>${device} </span> | Version: <span>${data.version} </span> | Viewport: <span>${data.viewport.width} x ${data.viewport.height}</span> | Date: <span>${dateValue} </span> | Environment: <span>${data.Environment} </span> |
  </p>
</div>
`;

const createHtml = (table, header) => `
  <html>
    <head>
      <title>${device} Visual Regression Report</title>
      <style>
        h1 {
          text-align:center;
        }
        table {
          width: 100%;
          color:#293A2A;
        }
        tr {
          text-align: left;
          border: 1px solid black;
          background: #6ba8a9;
          font-weight:bold;
        }
        th, td {
          padding: 15px;
        }
        thead tr {
          text-align:center;
          background: #1d4d4f;
          color: #fff;
        }
        .secondary-header {
          font-weight:bold;
        }
        .secondary-header span{
          font-weight:normal;
          padding: 1px;
          display: inline-block;
        }
        .expected, .actual, .difference {
          width:30%;
        }
        .expected img, .actual img, .difference img {
          width:100%;
        }
        button{
          display: inline-block;
    margin-bottom: 0;
    font-weight: 400;
    text-align: center;
    white-space: nowrap;
    vertical-align: middle;
    cursor: pointer;
    border: 1px solid transparent;
    padding: 6px 12px;
    font-size: 14px;
    line-height: 1.42857143;
    border-radius: 4px;
     user-select: none;
     color: #fff;
    background-color: #9ACD32;
    border-color: #2e6da4;
    font-weight: bold;
}
        a{
          text-decoration: none;
    text-align: center;
    /* padding: 10px; */
    display: block;
    margin: 10px auto;
    color: #fff;
        }
      </style>
      <script> var replaceFile = (url) => {
        fetch(\`http://localhost:8001/replacefile/\${url}\`)
          .then((response) => {
            return response.json();
          })
          .then((myJson) => {
            console.log(myJson);
          });
      }</script>
    </head>
    <body>
      ${header}
      ${table}
    </body>
  </html>
`;

/**
 * @description this method takes in a path as a string & returns true/false
 * as to if the specified file path exists in the system or not.
 * @param {String} filePath
 * @returns {Boolean}
 */
const doesFileExist = filePath => {
  try {
    fs.statSync(filePath); // get information of the specified file path.
    return true;
  } catch (error) {
    return false;
  }
};

try {
  /* Check if the file for `html` build exists in system or not */
  console.log('REP_VAR', process.env.REP_VAR);
  if (doesFileExist(buildPathHtml + '/' + filename)) {
    console.log('Deleting old build file');
    /* If the file exists delete the file from system */
    fs.unlinkSync(buildPathHtml + '/' + filename);
  }
  /* generate rows */
  const rows = data.output.map(createRow).join('');
  /* generate table */
  const table = createTable(rows);
  const header = createHeader(data.browser);
  /* generate html */
  const html = createHtml(table, header);
  fs.mkdir(buildPathHtml, { recursive: true }, err => {
    if (err) throw err;
    fs.writeFileSync(buildPathHtml + '/' + filename, html);
  });
  /* write the generated html to file */

  console.log('Succesfully created an HTML table');
} catch (error) {
  console.log('Error generating table', error);
}
